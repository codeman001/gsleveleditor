#include "StdAfx.h"
#include "CColladaAnimationTrackFloat.h"

namespace irr
{
namespace collada
{
namespace animation_track
{

const CFloatEx CFloatEx::s_Instance;

}; // animation_track
}; // collada
}; // irr