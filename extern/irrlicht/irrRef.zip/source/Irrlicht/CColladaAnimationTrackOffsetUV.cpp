#include "StdAfx.h"
#include "CColladaAnimationTrackOffsetUV.h"

namespace irr
{
namespace collada
{
namespace animation_track
{

const CTextureTransformEx	CTextureTransformEx::s_Instance;
//const COffsetUEx			COffsetUEx::s_Instance;
//const COffsetVEx			COffsetVEx::s_Instance;
//const CRotateUVEx			CRotateUVEx::s_Instance;
//const CScaleUEx				CScaleUEx::s_Instance;
//const CScaleVEx				CScaleVEx::s_Instance;
}; // animation_track
}; // collada
}; // irr