#include "StdAfx.h"
#include "CColladaAnimationTrackPosition.h"

namespace irr
{
namespace collada
{
namespace animation_track
{
const CPositionEx CPositionEx::s_Instance;
const CPositionXEx CPositionXEx::s_Instance;
const CPositionYEx CPositionYEx::s_Instance;
const CPositionZEx CPositionZEx::s_Instance;
};
};
};