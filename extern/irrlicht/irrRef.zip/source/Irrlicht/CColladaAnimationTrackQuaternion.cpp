#include "StdAfx.h"
#include "CColladaAnimationTrackQuaternion.h"

namespace irr
{
namespace collada
{
namespace animation_track
{

const CQuaternionEx CQuaternionEx::s_Instance;
const CQuaternionAngleEx CQuaternionAngleEx::s_Instance;


}; // animation_track
}; // collada
}; // irr
