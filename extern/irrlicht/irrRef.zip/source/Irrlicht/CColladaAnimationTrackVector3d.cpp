#include "StdAfx.h"
#include "CColladaAnimationTrackVector3d.h"

namespace irr
{
namespace collada
{
namespace animation_track
{

const CVector3dEx CVector3dEx::s_Instance;


}; // animation_track
}; // collada
}; // irr