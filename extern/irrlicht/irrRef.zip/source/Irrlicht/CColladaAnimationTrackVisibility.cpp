#include "StdAfx.h"
#include "CColladaAnimationTrackVisibility.h"

namespace irr
{
namespace collada
{
namespace animation_track
{
const CVisibilityEx CVisibilityEx::s_Instance;
};
};
};