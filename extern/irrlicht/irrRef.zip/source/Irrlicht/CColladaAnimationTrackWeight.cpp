#include "StdAfx.h"
#include "CColladaAnimationTrackWeight.h"

namespace irr
{
namespace collada
{
namespace animation_track
{

const CWeightEx CWeightEx::s_Instance;

}; // animation_track
}; // collada
}; // irr