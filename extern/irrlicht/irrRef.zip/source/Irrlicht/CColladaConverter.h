#ifndef __CCOLLADACONVERTER_H__
#define __CCOLLADACONVERTER_H__

namespace irr
{
namespace collada
{

int ConvertMAX2BDAE(const char *pSourceFile, const char *pTargetFile);
int ConvertDAE2BDAE(const char *pSourceFile, const char *pTargetFile);

};
};

#endif