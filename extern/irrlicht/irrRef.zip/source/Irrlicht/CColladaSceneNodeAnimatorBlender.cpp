#include "StdAfx.h"
#include "IrrCompileConfig.h"
#ifdef _IRR_COMPILE_WITH_COLLADA_BINARY_LOADER_

#include "CColladaSceneNodeAnimatorBlender.h"

namespace irr
{
namespace collada
{

CSceneNodeAnimatorBlender::~CSceneNodeAnimatorBlender()
{
	for (u32 i = 0; i < Animators.size(); ++i)
	{
		Animators[i]->drop();
	}
//bbejan
	for (u32 i = 0; i < TimeControllers.size(); ++i)
	{
		TimeControllers[i]->drop();
	}
}

const SChannel&
CSceneNodeAnimatorBlender::getAnimationTrack(int track)
{
	return Animators[0]->getAnimationTrack(track);
}

const CAnimationTrackEx*
CSceneNodeAnimatorBlender::getAnimationTrackEx(int track)
{
	return Animators[0]->getAnimationTrackEx(track);
}

void
CSceneNodeAnimatorBlender::setTarget(int channelID, void* ptr)
{
	Targets[channelID] = ptr;
}

const char*
CSceneNodeAnimatorBlender::getBindURI(int i)
{
	return Animators[0]->getBindURI(i);
}

int
CSceneNodeAnimatorBlender::getTargetCount()
{
	return Animators[0]->getTargetCount();
}

int
CSceneNodeAnimatorBlender::getTargetSize(int i)
{
	return Animators[0]->getTargetSize(i);
}

int
CSceneNodeAnimatorBlender::getTargetsSize()
{
	// Potential problem here the first animator may not be the bigger one
	return Animators[0]->getTargetsSize();
}

int
CSceneNodeAnimatorBlender::getLength() const
{
	return Animators[0]->getLength();
}


//bgbejan bug fix
void
CSceneNodeAnimatorBlender::compile(irr::scene::ISceneNode* node, core::array<unsigned char>* workingBuffer)
{
	u32 size = getTargetsSize();
	u32 animators = Animators.size();
	u32 workingBufferSize = size * animators;
	int targetCount = getTargetCount();
		
	//Prepare buffers
	if (!workingBuffer)
	{
		workingBuffer = &DefaultBuffer;
		workingBuffer->reallocate(workingBufferSize);
		workingBuffer->set_used(workingBufferSize);
	}
	_IRR_DEBUG_BREAK_IF(workingBuffer->size() < workingBufferSize);

	Weights.reallocate(animators);
	Weights.set_used(animators);
	for (u32 j = 0, cnt = Weights.size(); j < cnt; ++j)
	{
		Weights[j] = 0.0f;	
	}
	
	BlendingBuffers.reallocate(targetCount);
	BlendingBuffers.set_used(targetCount);

	u32 workingBufferIt = 0;

	// Set blending buffers pointers
	ISceneNodeAnimator* animatorModel = Animators[0];
	int targetTotalSize = 0;

	memset(workingBuffer->pointer(), 0, workingBuffer->size());
	for (int i = 0;
		 i < targetCount; 
		 i++, workingBufferIt += targetTotalSize)
	{
		int targetSize = getTargetSize(i);

		_IRR_DEBUG_BREAK_IF(targetSize & 0x3); // MUST be 4 bytes align

		targetTotalSize = targetSize * animators;
		BlendingBuffers[i] = workingBuffer->pointer() + workingBufferIt;
		u8* blendingTarget = (u8*)BlendingBuffers[i];
			
		const char* bindURI = animatorModel->getBindURI(i);

		animatorModel->setTarget(i, blendingTarget);
//bgbejan BUG FIX!
		const SChannel& modelTrack = animatorModel->getAnimationTrack(i);

		if (node)
		{
			switch (modelTrack.type)
			{
				case SChannel::CT_ROTATION_W:
				case SChannel::CT_ROTATION:
				{
					scene::ISceneNode* target = node->getSceneNodeFromUID(bindURI);
					for(u32 i = 0;i<Animators.size();i++)
						*((irr::core::quaternion*)(blendingTarget + targetSize*i)) = target->getRotation();
					break;
				}
				case SChannel::CT_POSITION:
				case SChannel::CT_POSITION_X:
				case SChannel::CT_POSITION_Y:
				case SChannel::CT_POSITION_Z:
				{
					scene::ISceneNode* target = node->getSceneNodeFromUID(bindURI);
					for(u32 i = 0;i<Animators.size();i++)
						*((irr::core::vector3df*)(blendingTarget + targetSize*i)) = target->getPosition();
					break;
				}
				case SChannel::CT_VISIBILITY:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
				case SChannel::CT_SCALE:
				case SChannel::CT_SCALE_X:
				case SChannel::CT_SCALE_Y:
				case SChannel::CT_SCALE_Z:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
				case SChannel::CT_MORPHING_WEIGHT:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
				case SChannel::CT_IFL:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
				case SChannel::CT_LIGHT_COLOR:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
				case SChannel::CT_EFFECT_TRANSFORM_OFFSET_U:
				case SChannel::CT_EFFECT_TRANSFORM_OFFSET_V:
				case SChannel::CT_EFFECT_TRANSFORM_SCALE_U:
				case SChannel::CT_EFFECT_TRANSFORM_SCALE_V:
				case SChannel::CT_EFFECT_TRANSFORM_ROTATE:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
				case SChannel::CT_EFFECT_AMBIENT:
				case SChannel::CT_EFFECT_AMBIENT_R:
				case SChannel::CT_EFFECT_AMBIENT_G:
				case SChannel::CT_EFFECT_AMBIENT_B:
				case SChannel::CT_EFFECT_AMBIENT_A:
				case SChannel::CT_EFFECT_DIFFUSE:
				case SChannel::CT_EFFECT_DIFFUSE_R:
				case SChannel::CT_EFFECT_DIFFUSE_G:
				case SChannel::CT_EFFECT_DIFFUSE_B:
				case SChannel::CT_EFFECT_DIFFUSE_A:
				case SChannel::CT_EFFECT_SPECULAR:
				case SChannel::CT_EFFECT_SPECULAR_R:
				case SChannel::CT_EFFECT_SPECULAR_G:
				case SChannel::CT_EFFECT_SPECULAR_B:
				case SChannel::CT_EFFECT_SPECULAR_A:
				case SChannel::CT_EFFECT_EMISSION:
				case SChannel::CT_EFFECT_EMISSION_R:
				case SChannel::CT_EFFECT_EMISSION_G:
				case SChannel::CT_EFFECT_EMISSION_B:
				case SChannel::CT_EFFECT_EMISSION_A:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
				case SChannel::CT_EFFECT_TRANSPARENCY:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
				default:
				{
					_IRR_DEBUG_BREAK_IF("Not implemented");
					break;
				}
			}
		}

		blendingTarget += targetSize;

		for(u32 i = 1, cnt = Animators.size();
			i < cnt;
			blendingTarget += targetSize, ++i)
		{
			ISceneNodeAnimator* anim = Animators[i];
			bool found = anim->setCompatibleTarget(modelTrack, blendingTarget);
			//_IRR_DEBUG_BREAK_IF(!found);
		}
	}

	_IRR_DEBUG_BREAK_IF(workingBufferIt > workingBufferSize);

	Targets.reallocate(targetCount);
	Targets.set_used(targetCount);

	NeedCompilation = false;

	if(Animators.size() != 0)
	{
#ifdef SC5_DUAL_ANIMATOR_SUPPORT
		forceBind(NULL, NULL); //bgbejan
#else
		forceBind();
#endif
	}
}

void
CSceneNodeAnimatorBlender::applyAnimationValues(u32 timeMs)
{
	for (u32 i = 0, cnt = Animators.size(); i < cnt; ++i)
	{
		if (Weights[i])
		{
//bbejan
			Animators[i]->computeAnimationValues(TimeControllers[i]->getCtrlTime());
		}
	}

	normalizeWeights();

	for (u32 animTrackIt = 0; animTrackIt < Targets.size(); ++animTrackIt)
	{
		if (Targets[animTrackIt])
		{
			const CAnimationTrackEx* animTrack
				= Animators[0]->getAnimationTrackEx(animTrackIt);
			animTrack->applyBlendedValue(BlendingBuffers[animTrackIt], 
										 Weights.pointer(),
										 Weights.size(), 
										 Targets[animTrackIt]);
		}
		else
		{
			//_IRR_DEBUG_BREAK_IF("NOT Supported");
		}
	}
}

void
CSceneNodeAnimatorBlender::computeAnimationValues(u32 timeMs)
{
	for (u32 i = 0; i < Animators.size(); ++i)
	{
		if (Weights[i])
		{
			Animators[i]->computeAnimationValues(timeMs);
		}
	}

	normalizeWeights();

	for (u32 animTrackIt = 0; animTrackIt < Targets.size(); ++animTrackIt)
	{
		if (Targets[animTrackIt])
		{
			const CAnimationTrackEx* animTrack
				= Animators[0]->getAnimationTrackEx(animTrackIt);
			animTrack->getBlendedValue(BlendingBuffers[animTrackIt], 
									   Weights.pointer(),
									   Weights.size(), 
									   Targets[animTrackIt]);
		}
		else
		{
			//_IRR_DEBUG_BREAK_IF("NOT Supported");
		}
	}
}

//! animates a scene node
void
CSceneNodeAnimatorBlender::animateNode(scene::ISceneNode* node, u32 timeMs)
{
	applyAnimationValues(timeMs);
}

} // end namespace collada
} // end namespace irr
#endif