// Copyright (C) 2002-2008 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef __C_FPSCOUNTER_H_INCLUDED__
#define __C_FPSCOUNTER_H_INCLUDED__

#include "irrTypes.h"

namespace irr
{
namespace video  
{


class CFPSCounter  
{
public:
	CFPSCounter();

	//! returns current fps
	s32 getFPS() const;

	//! returns primitive count
	u32 getPrimitive() const;

	//! returns average primitive count of last period
	u32 getPrimitiveAverage() const;

	//! returns average render time of last period
	u32 getRenderTimeAverage() const;

	//! returns accumulated primitive count since start
	u32 getPrimitiveTotal() const;

	//! returns draw call count
	u32 getDrawCalls() const;

	//! returns 2D draw call count
	u32 getDrawCalls2D() const;

	//! returns draw call count
	u32 getTextureBindings() const;

	//! returns transparent objects count
	u32 getTransparentCounted() const;

	//! sets transparent objects count
	void setTransparentCounted(u32 count);

	//! to be called every frame
	void registerFrame(u32 now,
					   u32 primitive,
					   u32 drawCalls,
					   u32 drawCalls2D,
					   u32 textureBindings);

private:

	s32 FPS;
	u32 Primitive;
	u32 StartTime;

	u32 FramesCounted;
	u32 PrimitivesCounted;
	u32 PrimitiveAverage;
	u32 RenderTimeAverage;
	u32 PrimitiveTotal;
	u32 TransparentCounted;
	u32 TransparentAverage;

	u32 DrawCalls;

	u32 DrawCalls2D;

	u32 TextureBindings;
};


} // end namespace video
} // end namespace irr


#endif 

