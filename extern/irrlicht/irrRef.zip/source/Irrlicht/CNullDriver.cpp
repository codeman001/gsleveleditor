#include "StdAfx.h"
// Copyright (C) 2002-2008 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in irrlicht.h

#include "CNullDriver.h"
#include "irros.h"
#include "CImage.h"
#include "CAttributes.h"
#include "IReadFile.h"
#include "IWriteFile.h"
#include "IImageLoader.h"
#include "IImageWriter.h"
#include "IMaterialRenderer.h"
#include "CMeshManipulator.h"
#include "CTextureManager.h"
#include "CIrrFactory.h"
#include "coreutil.h"

extern irr::core::stringw tmpStr;

namespace irr
{
namespace video
{

#ifdef _DEBUG
bool ForceFullRange = false;
#endif

//! creates a loader which is able to load windows bitmaps
IImageLoader* createImageLoaderBMP();

//! creates a loader which is able to load jpeg images
IImageLoader* createImageLoaderJPG();

//! creates a loader which is able to load targa images
IImageLoader* createImageLoaderTGA();

//! creates a loader which is able to load psd images
IImageLoader* createImageLoaderPSD();

//! creates a loader which is able to load pcx images
IImageLoader* createImageLoaderPCX();

#ifdef _IRR_COMPILE_WITH_PS3_
IImageLoader* createPS3ImageLoaderPNG();
#endif
//! creates a loader which is able to load png images
IImageLoader* createImageLoaderPNG();

//! creates a loader which is able to load WAL images
IImageLoader* createImageLoaderWAL();

//! creates a loader which is able to load ppm/pgm/pbm images
IImageLoader* createImageLoaderPPM();

//! creates a loader which is able to load dds images
IImageLoader* createImageLoaderDDS();

//! creates a loader which is able to load bmp images
IImageWriter* createImageWriterBMP();

//! creates a loader which is able to load jpg images
IImageWriter* createImageWriterJPG();

//! creates a loader which is able to load tga images
IImageWriter* createImageWriterTGA();

//! creates a loader which is able to load psd images
IImageWriter* createImageWriterPSD();

//! creates a loader which is able to load pcx images
IImageWriter* createImageWriterPCX();

//! creates a loader which is able to load png images
IImageWriter* createImageWriterPNG();

//! creates a loader which is able to load ppm images
IImageWriter* createImageWriterPPM();



//! constructor
CNullDriver::CNullDriver(io::IFileSystem* io,
						 const core::dimension2d<s32>& screenSize)
	: FileSystem(io)
	, MeshManipulator(0)
	, ViewPort(0,0,0,0)
	, ScreenSize(screenSize)
#ifdef _IRR_WITH_FRAME_STATISTICS_
	, PrimitivesDrawn(0)
	, DrawCalls(0)
	, DrawCalls2D(0)
	, TextureBindings(0)
#endif
	, OptionFlags(ETCF_ALWAYS_32_BIT | ETCF_CREATE_MIP_MAPS)
	, MaxTextureSize(0, 0)
{
	TextureManager = CIrrFactory::getInstance()->createTextureManager(this);

	#ifdef _DEBUG
	setDebugName("CNullDriver");
	#endif

	setFog();

	ViewPort = core::rect<s32>(core::position2d<s32>(0,0), screenSize);

	// create manipulator
	MeshManipulator = irrnew scene::CMeshManipulator();

	if (FileSystem)
		FileSystem->grab();

	// create surface loader

#ifdef _IRR_COMPILE_WITH_BMP_LOADER_
	SurfaceLoader.push_back(video::createImageLoaderBMP());
#endif
#ifdef _IRR_COMPILE_WITH_JPG_LOADER_
	SurfaceLoader.push_back(video::createImageLoaderJPG());
#endif
#ifdef _IRR_COMPILE_WITH_TGA_LOADER_
	SurfaceLoader.push_back(video::createImageLoaderTGA());
#endif
#ifdef _IRR_COMPILE_WITH_PSD_LOADER_
	SurfaceLoader.push_back(video::createImageLoaderPSD());
#endif
#ifdef _IRR_COMPILE_WITH_PCX_LOADER_
	SurfaceLoader.push_back(video::createImageLoaderPCX());
#endif
#if 0//def _IRR_COMPILE_WITH_PS3_PNG_
    SurfaceLoader.push_back(video::createPS3ImageLoaderPNG());
#elif defined(_IRR_COMPILE_WITH_PNG_LOADER_)
	SurfaceLoader.push_back(video::createImageLoaderPNG());
#endif
#ifdef _IRR_COMPILE_WITH_WAL_LOADER_
	SurfaceLoader.push_back(video::createImageLoaderWAL());
#endif
#ifdef _IRR_COMPILE_WITH_PPM_LOADER_
	SurfaceLoader.push_back(video::createImageLoaderPPM());
#endif
#ifdef _IRR_COMPILE_WITH_DDS_LOADER_
	SurfaceLoader.push_back(video::createImageLoaderDDS());
#endif

#ifdef _IRR_COMPILE_WITH_BMP_WRITER_
	SurfaceWriter.push_back(video::createImageWriterBMP());
#endif
#ifdef _IRR_COMPILE_WITH_JPG_WRITER_
	SurfaceWriter.push_back(video::createImageWriterJPG());
#endif
#ifdef _IRR_COMPILE_WITH_TGA_WRITER_
	SurfaceWriter.push_back(video::createImageWriterTGA());
#endif
#ifdef _IRR_COMPILE_WITH_PSD_WRITER_
	SurfaceWriter.push_back(video::createImageWriterPSD());
#endif
#ifdef _IRR_COMPILE_WITH_PCX_WRITER_
	SurfaceWriter.push_back(video::createImageWriterPCX());
#endif
#ifdef _IRR_COMPILE_WITH_PNG_WRITER_
	SurfaceWriter.push_back(video::createImageWriterPNG());
#endif
#ifdef _IRR_COMPILE_WITH_PPM_WRITER_
	SurfaceWriter.push_back(video::createImageWriterPPM());
#endif

	// set ExposedData to 0
	memset(&ExposedData, 0, sizeof(ExposedData));
	for (u32 i=0; i<video::EVDF_COUNT; ++i)
		FeatureEnabled[i]=true;
}

//! destructor
CNullDriver::~CNullDriver()
{
	if (FileSystem)
		FileSystem->drop();

	if (MeshManipulator)
		MeshManipulator->drop();

	deleteAllTextures();

	delete (TextureManager);

	u32 i;
	for (i=0; i<SurfaceLoader.size(); ++i)
		SurfaceLoader[i]->drop();

	for (i=0; i<SurfaceWriter.size(); ++i)
		SurfaceWriter[i]->drop();

	// delete material renderers
	deleteMaterialRenders();

	// delete hardware mesh buffers
	removeAllHardwareBuffers();
}

io::IFileSystem* CNullDriver::getFileSystem()
{
	return FileSystem;
}

//! Adds an external surface loader to the engine.
void
CNullDriver::addExternalImageLoader(IImageLoader* loader)
{
	if (!loader)
		return;

	loader->grab();
	SurfaceLoader.push_back(loader);
}

//! Adds an external surface writer to the engine.
void
CNullDriver::addExternalImageWriter(IImageWriter* writer)
{
	if (!writer)
		return;

	writer->grab();
	SurfaceWriter.push_back(writer);
}

//! deletes all textures
void
CNullDriver::deleteAllTextures()
{
	TextureManager->deleteAllTextures();
}

bool
CNullDriver::beginScene()
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	PrimitivesDrawn = 0;
	DrawCalls = 0;
	DrawCalls2D = 0;
	TextureBindings = 0;
#endif
	return true;
}

bool
CNullDriver::endScene()
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	FPSCounter.registerFrame(os::Timer::getRealTime(), PrimitivesDrawn, DrawCalls, DrawCalls2D, TextureBindings);
#endif
	updateAllHardwareBuffers();
	return true;
}

bool
CNullDriver::swapBuffers(int)
{
	return true;
}

void
CNullDriver::clearBuffers(int)
{
}

void
CNullDriver::setClearColor(const SColor& color)
{
}

SColor
CNullDriver::getClearColor() const
{
	return SColor(0, 0, 0, 0);
}

void
CNullDriver::setClearDepth(float)
{
}

float
CNullDriver::getClearDepth() const
{
	return 1.0f;
}

void
CNullDriver::setClearStencil(int)
{
}

int
CNullDriver::getClearStencil() const
{
	return 0;
}

bool
CNullDriver::beginScene2D()
{
	return true;
}

bool
CNullDriver::endScene2D()
{
	return true;
}

//! Disable a feature of the driver.
void
CNullDriver::disableFeature(E_VIDEO_DRIVER_FEATURE feature, bool flag)
{
	FeatureEnabled[feature]=!flag;
}
 
//! queries the features of the driver, returns true if feature is available
bool
CNullDriver::queryFeature(E_VIDEO_DRIVER_FEATURE feature) const
{
	return false;
}

//! sets transformation
void
CNullDriver::setTransform(E_TRANSFORMATION_STATE state, const core::matrix4& mat)
{
}

//! Returns the transformation set by setTransform
const core::matrix4&
CNullDriver::getTransform(E_TRANSFORMATION_STATE state) const
{
	return TransformationMatrix;
}

//! sets a material
void
CNullDriver::setMaterial(const SMaterial& material)
{
}

//! Set a 2D Material if it's different from the next material to be used
void
CNullDriver::set2DMaterial(SMaterial& material)
{
}

//! Set the texture to be used with 2D render
//cdbratu
void
CNullDriver::set2DTexture(const ITexture* tex, bool useTextureAlpha, bool useTranspAdd)
{
}

//! Set if the vertex alpha will be used for the 2D render
void
CNullDriver::set2DUseVertexAlpha(bool value)
{
}

//! Removes a texture from the texture cache and deletes it, freeing lot of
//! memory.
void
CNullDriver::removeTexture(ITexture* texture)
{
	TextureManager->removeTexture(texture);
}

//! Removes all texture from the texture cache and deletes them, freeing lot of
//! memory.
void
CNullDriver::removeAllTextures()
{
	TextureManager->removeAllTextures();
}

//! Returns a texture by index
ITexture*
CNullDriver::getTextureByIndex(u32 i)
{
	return TextureManager->getTextureByIndex(i);
}

//! Returns amount of textures currently loaded
u32
CNullDriver::getTextureCount() const
{
	return TextureManager->getTextureCount();
}

//! Renames a texture
void
CNullDriver::renameTexture(ITexture* texture, const c8* newName)
{
	TextureManager->renameTexture(texture, newName);
}

//! loads a Texture
ITexture*
CNullDriver::getTexture(const c8* filename)
{
	return TextureManager->getTexture(filename);
}

//! loads a Texture
ITexture*
CNullDriver::getTexture(io::IReadFile* file, bool refData)
{
	return TextureManager->getTexture(file, refData);
}

video::ITexture*
CNullDriver::createDeviceDependentNativeTexture(const char* name,
												int w,
												int h,
												int fmt,
												void* data)
{
	return 0;
}

//! opens the file and loads it into the surface
video::ITexture*
CNullDriver::loadTextureFromFile(io::IReadFile* file,
								 const c8 *hashName,
								 bool refData )
{
	return TextureManager->loadTextureFromFile(file, hashName, refData);
}

//! adds a surface, not loaded or created by the Irrlicht Engine
void
CNullDriver::addTexture(video::ITexture* texture)
{
	TextureManager->addTexture(texture);
}

//! looks if the image is already loaded
video::ITexture*
CNullDriver::findTexture(const c8* filename)
{
	return TextureManager->findTexture(filename);
	
}

//! Creates a texture from a loaded IImage.
ITexture*
CNullDriver::addTexture(const c8* name, IImage* image)
{
	return TextureManager->addTexture(name, image);
}

//! creates a Texture
ITexture*
CNullDriver::addTexture(const core::dimension2d<s32>& size,
						const c8* name,
						ECOLOR_FORMAT format)
{
	return TextureManager->addTexture(size, name, format);
}

//! returns a device dependent texture from a software surface (IImage)
//! THIS METHOD HAS TO BE OVERRIDDEN BY DERIVED DRIVERS WITH OWN TEXTURES
ITexture*
CNullDriver::createDeviceDependentTexture(IImage* surface,
										  const char* name)
{
	return 0;
}

#ifdef _IRR_ENABLE_NATIVE_TEXTURE_FORMAT_
//! returns a device dependant texture from a "native" format in a file
//! THIS METHOD HAS TO BE OVERRIDDEN BY DERIVED DRIVERS WITH OWN TEXTURES
ITexture*
CNullDriver::createDeviceDependentNativeTextureFromFile(io::IReadFile* /*file*/,
														const c8* /*hashName*/,
														bool /*refData*/)
{
	// Not supported by default
	return 0;
}
#endif

//! sets a render target
bool
CNullDriver::setRenderTarget(video::ITexture* texture,
							 int clearMask)
{
	return false;
}

//! sets a viewport
void
CNullDriver::setViewPort(const core::rect<s32>& area)
{
}

//! gets the area of the current viewport
const core::rect<s32>&
CNullDriver::getViewPort() const
{
	return ViewPort;
}

//! draws a vertex primitive list
void
CNullDriver::drawVertexPrimitiveList(const void* /*vertices*/,
									 const void* /*indexList*/,
									 u32 /*minIndex*/,
									 u32 /*maxIndex*/,
									 u32 primitiveCount,
									 E_VERTEX_TYPE /*vType*/,
									 scene::E_PRIMITIVE_TYPE /*pType*/,
									 E_INDEX_TYPE /*iType*/,
									 IDriverBinding** /*binding*/)
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	PrimitivesDrawn += primitiveCount;
	++DrawCalls;
#endif
}

//! Draws a 3d line.
void
CNullDriver::draw3DLine(const core::vector3df& start,
						const core::vector3df& end,
						SColor color)
{
}

//! Draws a 3d triangle.
void
CNullDriver::draw3DTriangle(const core::triangle3df& triangle, SColor color)
{
	draw3DLine(triangle.pointA, triangle.pointB, color);
	draw3DLine(triangle.pointB, triangle.pointC, color);
	draw3DLine(triangle.pointC, triangle.pointA, color);
}

//! Draws a 3d axis aligned box.
void
CNullDriver::draw3DBox(const core::aabbox3d<f32>& box, SColor color)
{
	core::vector3df edges[8];
	box.getEdges(edges);

	// TODO: optimize into one big drawIndexPrimitive call.
	draw3DLine(edges[5], edges[1], color);
	draw3DLine(edges[1], edges[3], color);
	draw3DLine(edges[3], edges[7], color);
	draw3DLine(edges[7], edges[5], color);
	draw3DLine(edges[0], edges[2], color);
	draw3DLine(edges[2], edges[6], color);
	draw3DLine(edges[6], edges[4], color);
	draw3DLine(edges[4], edges[0], color);
	draw3DLine(edges[1], edges[0], color);
	draw3DLine(edges[3], edges[2], color);
	draw3DLine(edges[7], edges[6], color);
	draw3DLine(edges[5], edges[4], color);
}

//! draws an 2d image
void
CNullDriver::draw2DImage(const video::ITexture* texture,
						 const core::position2d<f32>& destPos)
{
	if (!texture)
		return;

	core::dimension2di texDimension = texture->getOriginalSize();
	core::dimension2df texDimensionf(texDimension.Width, texDimension.Height);

	draw2DImage(texture,
				destPos,
				core::rect<f32>(core::position2d<f32>(0,0), texDimensionf));
}

//! draws a set of 2d images, using a color and the alpha channel of the
//! texture if desired. The images are drawn beginning at pos and concatenated
//! in one line. All drawings are clipped against clipRect (if != 0).
//! The subtextures are defined by the array of sourceRects and are chosen
//! by the indices given.
void
CNullDriver::draw2DImage(const video::ITexture* texture,
						 const core::position2d<f32>& pos,
						 const core::array<core::rect<f32> >& sourceRects,
						 const core::array<s32>& indices,
						 s32 kerningWidth,
						 const core::rect<f32>* clipRect,
						 SColor color,
						 bool useAlphaChannelOfTexture)
{
	core::position2d<f32> target(pos);

	for (u32 i=0; i<indices.size(); ++i)
	{
		draw2DImage(texture,
					target,
					sourceRects[indices[i]],
					clipRect,
					color,
					useAlphaChannelOfTexture);
		target.X += sourceRects[indices[i]].getWidth();
		target.X += kerningWidth;
	}
}

//! Draws a part of the texture into the rectangle.
void
CNullDriver::draw2DImage(const video::ITexture* texture,
						 const core::rect<f32>& destRect,
						 const core::rect<f32>& sourceRect,
						 const core::rect<f32>* clipRect,
						 const video::SColor* const colors,
						 bool useAlphaChannelOfTexture)
{
}

//! draws an 2d image, using a color (if color is other then Color(255,255,255,255)) and the alpha channel of the texture if wanted.
void
CNullDriver::draw2DImage(const video::ITexture* texture,
						 const core::position2d<f32>& destPos,
						 const core::rect<f32>& sourceRect,
						 const core::rect<f32>* clipRect,
						 SColor color,
						 bool useAlphaChannelOfTexture)
{
}

//! draw an 2d rectangle
void
CNullDriver::draw2DRectangle(SColor color,
							 const core::rect<f32>& pos,
							 const core::rect<f32>* clip)
{
	draw2DRectangle(pos, color, color, color, color, clip);
}

void
CNullDriver::draw2DRectangle(SColor color,
							 const core::rect<s32>& pos,
							 const core::rect<s32>* clip)
{
	draw2DRectangle(pos, color, color, color, color, clip);
}

//!Draws an 2d rectangle with a gradient.
void
CNullDriver::draw2DRectangle(const core::rect<f32>& pos,
							 SColor colorLeftUp,
							 SColor colorRightUp,
							 SColor colorLeftDown,
							 SColor colorRightDown,
							 const core::rect<f32>* clip)
{
}

void
CNullDriver::draw2DRectangle(const core::rect<s32>& pos,
							 SColor colorLeftUp,
							 SColor colorRightUp,
							 SColor colorLeftDown,
							 SColor colorRightDown,
							 const core::rect<s32>* clip)
{
}


//! Draws a 2d line.
void
CNullDriver::draw2DLine(const core::position2d<s32>& start,
						const core::position2d<s32>& end,
						SColor color)
{
}

//! Draws a non filled concyclic regular 2d polyon.
void
CNullDriver::draw2DPolygon(core::position2d<s32> center,
						   f32 radius,
						   video::SColor color,
						   s32 count)
{
	if (count < 2)
		return;

	core::position2d<s32> first;
	core::position2d<s32> a, b;

	for (s32 j = 0; j < count; ++j)
	{
		b = a;

		f32 p = j / (f32)count * (core::PI*2);
		a = center + core::position2d<s32>((s32)(sin(p)*radius),
										   (s32)(cos(p)*radius));

		if (j==0)
			first = a;
		else
			draw2DLine(a, b, color);
	}

	draw2DLine(a, first, color);
}

//! Draw a 2D surface with the current 2D Material, this will replace all the draw2DImage and draw2DRectangle
void
CNullDriver::draw2DRectangle(const core::rect<f32>& destRect,
							 const core::rect<f32>& sourceRect,
							 const SColor colors[4],
							 const core::rect<f32>* clipRect)
{
}

void
CNullDriver::draw2DRectangle(const core::rect<s32>& destRect,
							 const core::rect<s32>& sourceRect,
							 const SColor colors[4],
							 const core::rect<s32>* clipRect)
{
}


//! returns color format
ECOLOR_FORMAT
CNullDriver::getColorFormat() const
{
	return ECF_R5G6B5;
}

//! returns screen size
const core::dimension2d<s32>&
CNullDriver::getScreenSize() const
{
	return ScreenSize;
}

//! returns the current render target size,
//! or the screen size if render targets are not implemented
const core::dimension2d<s32>&
CNullDriver::getCurrentRenderTargetSize() const
{
	return ScreenSize;
}

// returns current frames per second value
s32
CNullDriver::getFPS() const
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	return FPSCounter.getFPS();
#else
	return 0;
#endif
}

//! returns amount of primitives (mostly triangles) were drawn in the last frame.
//! very useful method for statistics.
u32
CNullDriver::getPrimitiveCountDrawn(u32 param) const
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	return (0 == param
			? FPSCounter.getPrimitive()
			: (1 == param
			   ? FPSCounter.getPrimitiveAverage()
			   : FPSCounter.getPrimitiveTotal()));
#else
	return 0;
#endif
}

u32
CNullDriver::getRenderTimeAverage() const
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	return FPSCounter.getRenderTimeAverage();
#else
	return 0;
#endif
}

//! returns the number of non-2D draw calls in the last frame.
//! very useful method for statistics.
u32
CNullDriver::getDrawCallCount() const
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	return FPSCounter.getDrawCalls();
#else
	return 0;
#endif
}

//! returns the number of non-2D draw calls in the last frame.
//! very useful method for statistics.
u32
CNullDriver::getDrawCall2DCount() const
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	return FPSCounter.getDrawCalls2D();
#else
	return 0;
#endif
}

//! returns the number of texture bindings in the last frame.
//! very useful method for statistics.
u32
CNullDriver::getTextureBindingCount() const
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	return FPSCounter.getTextureBindings();
#else
	return 0;
#endif
}

u32
CNullDriver::getTransparentCounted() const
{
#ifdef _IRR_WITH_FRAME_STATISTICS_
	return FPSCounter.getTransparentCounted();
#else
	return 0;
#endif
}

//! Sets the dynamic ambient light color. The default color is
//! (0,0,0,0) which means it is dark.
//! \param color: New color of the ambient light.
void
CNullDriver::setAmbientLight(const SColorf& color)
{
}

//! \return Returns the name of the video driver. Example: In case of the DIRECT3D8
//! driver, it would return "Direct3D8".
const WCHAR_T*
CNullDriver::getName() const
{
	tmpStr = "Irrlicht NullDevice";
	return tmpStr.c_str();
}

//! Draws a shadow volume into the stencil buffer. To draw a stencil shadow, do
//! this: Frist, draw all geometry. Then use this method, to draw the shadow
//! volume. Then, use IVideoDriver::drawStencilShadow() to visualize the shadow.
void
CNullDriver::drawStencilShadowVolume(const core::vector3df* triangles,
									 s32 count,
									 bool zfail)
{
}

//! Fills the stencil shadow with color. After the shadow volume has been drawn
//! into the stencil buffer using IVideoDriver::drawStencilShadowVolume(), use this
//! to draw the color of the shadow.
void
CNullDriver::drawStencilShadow(bool clearStencilBuffer,
							   video::SColor leftUpEdge,
							   video::SColor rightUpEdge,
							   video::SColor leftDownEdge,
							   video::SColor rightDownEdge)
{
}

//! deletes all dynamic lights there are
void
CNullDriver::deleteAllDynamicLights()
{
	Lights.set_used(0);
}

//! adds a dynamic light
void
CNullDriver::addDynamicLight(const SLight& light)
{
	Lights.push_back(light);
}

//! returns the maximal amount of dynamic lights the device can handle
u32
CNullDriver::getMaximalDynamicLightAmount() const
{
	return 0;
}

//! Returns current amount of dynamic lights set
//! \return Current amount of dynamic lights set
u32
CNullDriver::getDynamicLightCount() const
{
	return Lights.size();
}

//! Returns light data which was previously set by IVideoDriver::addDynamicLight().
//! \param idx: Zero based index of the light. Must be greater than 0 and smaller
//! than IVideoDriver()::getDynamicLightCount.
//! \return Light data.
const SLight&
CNullDriver::getDynamicLight(u32 idx) const
{
	if ( idx < Lights.size() )
		return Lights[idx];
	else
		return *((SLight*)0);
}

//! Creates an 1bit alpha channel of the texture based of an color key.
void
CNullDriver::makeColorKeyTexture(video::ITexture* texture,
								 video::SColor color) const
{
	if (!texture)
		return;

	if (texture->getColorFormat() != ECF_A1R5G5B5 &&
		texture->getColorFormat() != ECF_A8R8G8B8 )
	{
		os::Printer::log("Error: Unsupported texture color format for making color key channel.", ELL_ERROR);
		return;
	}

	if (texture->getColorFormat() == ECF_A1R5G5B5)
	{
		s16 *p = (s16*)texture->lock();

		if (!p)
		{
			os::Printer::log("Could not lock texture for making color key channel.", ELL_ERROR);
			return;
		}

		core::dimension2d<s32> dim = texture->getSize();
		s32 pitch = texture->getPitch() / 2;

		// color with alpha enabled (color opaque)
		s16 ref = (0x1<<15) | (0x7fff & color.toA1R5G5B5());

		for (s32 y=0; y<dim.Height; ++y)
		{
			for (s32 x=0; x<pitch; ++x)
			{
				s16 c = (0x1<<15) | (0x7fff & p[y*pitch + x]);
				p[y*pitch + x] = (c == ref) ? 0 : c;
			}
		}

		texture->unlock();
	}
	else
	{
		s32 *p = (s32*)texture->lock();

		if (!p)
		{
			os::Printer::log("Could not lock texture for making color key channel.", ELL_ERROR);
			return;
		}

		core::dimension2d<s32> dim = texture->getSize();
		s32 pitch = texture->getPitch() / 4;

		// color with alpha enabled (color opaque)
		s32 ref = 0xff000000 | (0x00ffffff & color.toARGB8());


		for (s32 y=0; y<dim.Height; ++y)
		{
			for (s32 x=0; x<pitch; ++x)
			{
				s32 c = (0xff<<24) | (0x00ffffff & p[y*pitch + x]);
				p[y*pitch + x] = (c == ref) ? 0 : c;
			}
		}

		texture->unlock();
	}
}

//! Creates an 1bit alpha channel of the texture based of an color key position.
void
CNullDriver::makeColorKeyTexture(video::ITexture* texture,
								 core::position2d<s32> colorKeyPixelPos) const
{
	if (!texture)
		return;

	if (texture->getColorFormat() != ECF_A1R5G5B5 &&
		texture->getColorFormat() != ECF_A8R8G8B8 )
	{
		os::Printer::log("Error: Unsupported texture color format for making color key channel.", ELL_ERROR);
		return;
	}

	if (texture->getColorFormat() == ECF_A1R5G5B5)
	{
		s16 *p = (s16*)texture->lock();

		if (!p)
		{
			os::Printer::log("Could not lock texture for making color key channel.", ELL_ERROR);
			return;
		}

		core::dimension2d<s32> dim = texture->getSize();
		s32 pitch = texture->getPitch() / 2;

		s16 ref = (0x1<<15) | (0x7fff & p[colorKeyPixelPos.Y*dim.Width + colorKeyPixelPos.X]);

		for (s32 y=0; y<dim.Height; ++y)
		{
			for (s32 x=0; x<pitch; ++x)
			{
				s16 c = (0x1<<15) | (0x7fff & p[y*pitch + x]);
				p[y*pitch + x] = (c == ref) ? 0 : c;
			}
		}

		texture->unlock();
	}
	else
	{
		s32 *p = (s32*)texture->lock();

		if (!p)
		{
			os::Printer::log("Could not lock texture for making color key channel.", ELL_ERROR);
			return;
		}

		core::dimension2d<s32> dim = texture->getSize();
		s32 pitch = texture->getPitch() / 4;

		s32 ref = (0xff<<24) | (0x00ffffff & p[colorKeyPixelPos.Y*dim.Width + colorKeyPixelPos.X]);

		for (s32 y=0; y<dim.Height; ++y)
		{
			for (s32 x=0; x<pitch; ++x)
			{
				s32 c = (0xff<<24) | (0x00ffffff & p[y*pitch + x]);
				p[y*pitch + x] = (c == ref) ? 0 : c;
			}
		}

		texture->unlock();
	}
}

//! Creates a normal map from a height map texture.
//! \param amplitude: Constant value by which the height information is multiplied.
void
CNullDriver::makeNormalMapTexture(video::ITexture* texture, f32 amplitude) const
{
	if (!texture)
		return;

	if (texture->getColorFormat() != ECF_A1R5G5B5 &&
		texture->getColorFormat() != ECF_A8R8G8B8 )
	{
		os::Printer::log("Error: Unsupported texture color format for making normal map.", ELL_ERROR);
		return;
	}

	core::dimension2d<s32> dim = texture->getSize();
	amplitude = amplitude / 255.0f;
	f32 vh = dim.Height / (f32)dim.Width;
	f32 hh = dim.Width / (f32)dim.Height;

	if (texture->getColorFormat() == ECF_A8R8G8B8)
	{
		// ECF_A8R8G8B8 version

		s32 *p = (s32*)texture->lock();

		if (!p)
		{
			os::Printer::log("Could not lock texture for making normal map.", ELL_ERROR);
			return;
		}

		// copy texture

		s32 pitch = texture->getPitch() / 4;

		s32* in = irrnew s32[dim.Height * pitch];
		memcpy(in, p, dim.Height * pitch * 4);

		for (s32 x=0; x<pitch; ++x)
			for (s32 y=0; y<dim.Height; ++y)
			{
				// TODO: this could be optimized really a lot

				core::vector3df h1((x-1)*hh, nml32(x-1, y, pitch, dim.Height, in)*amplitude, y*vh);
				core::vector3df h2((x+1)*hh, nml32(x+1, y, pitch, dim.Height, in)*amplitude, y*vh);
				//core::vector3df v1(x*hh, nml32(x, y-1, pitch, dim.Height, in)*amplitude, (y-1)*vh);
				//core::vector3df v2(x*hh, nml32(x, y+1, pitch, dim.Height, in)*amplitude, (y+1)*vh);
				core::vector3df v1(x*hh, nml32(x, y+1, pitch, dim.Height, in)*amplitude, (y-1)*vh);
				core::vector3df v2(x*hh, nml32(x, y-1, pitch, dim.Height, in)*amplitude, (y+1)*vh);

				core::vector3df v = v1-v2;
				core::vector3df h = h1-h2;

				core::vector3df n = v.crossProduct(h);
				n.normalize();
				n *= 0.5f;
				n += core::vector3df(0.5f,0.5f,0.5f); // now between 0 and 1
				n *= 255.0f;

				s32 height = (s32)nml32(x, y, pitch, dim.Height, in);
				p[y*pitch + x] = video::SColor(
					height, // store height in alpha
					(s32)n.X, (s32)n.Z, (s32)n.Y).toARGB8();
			}

		delete [] in;
		texture->unlock();
	}
	else
	{
		// ECF_A1R5G5B5 version

		s16 *p = (s16*)texture->lock();

		if (!p)
		{
			os::Printer::log("Could not lock texture for making normal map.", ELL_ERROR);
			return;
		}

		s32 pitch = texture->getPitch() / 2;

		// copy texture

		s16* in = irrnew s16[dim.Height * pitch];
		memcpy(in, p, dim.Height * pitch * 2);

		for (s32 x=0; x<pitch; ++x)
			for (s32 y=0; y<dim.Height; ++y)
			{
				// TODO: this could be optimized really a lot

				core::vector3df h1((x-1)*hh, nml16(x-1, y, pitch, dim.Height, in)*amplitude, y*vh);
				core::vector3df h2((x+1)*hh, nml16(x+1, y, pitch, dim.Height, in)*amplitude, y*vh);
				core::vector3df v1(x*hh, nml16(x, y-1, pitch, dim.Height, in)*amplitude, (y-1)*vh);
				core::vector3df v2(x*hh, nml16(x, y+1, pitch, dim.Height, in)*amplitude, (y+1)*vh);

				core::vector3df v = v1-v2;
				core::vector3df h = h1-h2;

				core::vector3df n = v.crossProduct(h);
				n.normalize();
				n *= 0.5f;
				n += core::vector3df(0.5f,0.5f,0.5f); // now between 0 and 1
				n *= 255.0f;

				p[y*pitch + x] = video::RGB16((s32)n.X, (s32)n.Z, (s32)n.Y);
			}

		delete [] in;
		texture->unlock();
	}

	texture->regenerateMipMapLevels();
}

//! Returns the maximum amount of primitives (mostly vertices) which
//! the device is able to render with one drawIndexedTriangleList
//! call.
u32
CNullDriver::getMaximalPrimitiveCount() const
{
	return 0xFFFFFFFF;
}

//! checks triangle count and print warning if wrong
bool
CNullDriver::checkPrimitiveCount(u32 prmCount) const
{
	const u32 m = getMaximalPrimitiveCount();

	if (prmCount > m)
	{
		char tmp[1024];
		sprintf(tmp,"Could not draw triangles, too many primitives(%u), maxium is %u.", prmCount, m);
		os::Printer::log(tmp, ELL_ERROR);
		return false;
	}

	return true;
}

//! Checks is a driver option is enabled (see E_VIDEO_DRIVER_OPTION).
bool
CNullDriver::getOption(u32 option) const
{
	return (OptionFlags & option) != 0;
}

//! Sets a driver option (see E_VIDEO_DRIVER_OPTION).
void
CNullDriver::setOption(u32 option, bool value)
{
	if (value)
	{
		// ensure texture format creation flag consistency
		if (option & (EVDO_CREATE_TEXTURE_ALWAYS_16_BIT
					  | EVDO_CREATE_TEXTURE_ALWAYS_32_BIT
					  | EVDO_CREATE_TEXTURE_OPTIMIZED_FOR_QUALITY
					  | EVDO_CREATE_TEXTURE_OPTIMIZED_FOR_SPEED))
		{
			OptionFlags &= ~(EVDO_CREATE_TEXTURE_ALWAYS_16_BIT
							 | EVDO_CREATE_TEXTURE_ALWAYS_32_BIT
							 | EVDO_CREATE_TEXTURE_OPTIMIZED_FOR_QUALITY
							 | EVDO_CREATE_TEXTURE_OPTIMIZED_FOR_SPEED);
		}
		OptionFlags |= option;
	}
	else
	{
		OptionFlags &= ~option;
	}
}

//! Creates a software image from a file.
IImage*
CNullDriver::createImageFromFile(const char* filename)
{
	if (!filename)
		return 0;

	IImage* image = 0;
	io::IReadFile* file = FileSystem->createAndOpenFile(filename);

	if (file)
	{
		image = createImageFromFile(file);
		file->drop();
	}
	else
		os::Printer::log("Could not open file of image", filename, ELL_WARNING);

	return image;
}

//! Creates a software image from a file.
IImage*
CNullDriver::createImageFromFile(io::IReadFile* file)
{
	if (!file)
		return 0;

	IImage* image = 0;

	u32 i;

	// try to load file based on file extension
	for (i=0; i<SurfaceLoader.size(); ++i)
	{
		if (SurfaceLoader[i]->isALoadableFileExtension(file->getFileName()))
		{
			// reset file position which might have changed due to previous loadImage calls
			file->seek(0);
			image = SurfaceLoader[i]->loadImage(file);
			if (image)
				return image;
		}
	}

	// try to load file based on what is in it
	for (i=0; i<SurfaceLoader.size(); ++i)
	{
		// dito
		file->seek(0);
		if (SurfaceLoader[i]->isALoadableFileFormat(file))
		{
			file->seek(0);
			image = SurfaceLoader[i]->loadImage(file);
			if (image)
				return image;
		}
	}

	return 0; // failed to load
}

//! Writes the provided image to disk file
bool
CNullDriver::writeImageToFile(IImage* image, const char* filename,u32 param)
{
	for (u32 i=0; i<SurfaceWriter.size(); ++i)
	{
		if (SurfaceWriter[i]->isAWriteableFileExtension(filename))
		{
			io::IWriteFile* file = FileSystem->createAndWriteFile(filename);
			if (file)
			{
				bool written = SurfaceWriter[i]->writeImage(file, image, param);
				file->drop();
				if (written)
					return true;
			}
		}
	}
	return false; // failed to write
}

//! Creates a software image from a byte array.
IImage*
CNullDriver::createImageFromData(ECOLOR_FORMAT format,
								 const core::dimension2d<s32>& size,
								 void *data,
								 bool ownForeignMemory,
								 bool deleteMemory)
{
	return irrnew CImage(format, size, data, ownForeignMemory, deleteMemory);
}

//! Creates an empty software image.
IImage*
CNullDriver::createImage(ECOLOR_FORMAT format, const core::dimension2d<s32>& size)
{
	return irrnew CImage(format, size);
}

//! Creates a software image from another image.
IImage*
CNullDriver::createImage(ECOLOR_FORMAT format, IImage *imageToCopy)
{
	return irrnew CImage(format, imageToCopy);
}

//! Creates a software image from part of another image.
IImage*
CNullDriver::createImage(IImage* imageToCopy,
						 const core::position2d<s32>& pos,
						 const core::dimension2d<s32>& size)
{
	return irrnew CImage(imageToCopy, pos, size);
}


//! Sets the fog mode.
void
CNullDriver::setFog(SColor color,
					bool linearFog,
					f32 start,
					f32 end,
					f32 density,
					bool pixelFog,
					bool rangeFog)
{
	FogColor = color;
	LinearFog = linearFog;
	FogStart = start;
	FogEnd = end;
	FogDensity = density;
	PixelFog = pixelFog;
	RangeFog = rangeFog;
}

//! Draws a mesh buffer
void
CNullDriver::drawMeshBuffer(const scene::IMeshBuffer* mb)
{
	if (!mb)
		return;

	//IVertexBuffer and IIndexBuffer later
	SHWBufferLink *HWBuffer=getBufferLink(mb);

	if (HWBuffer)
		drawHardwareBuffer(HWBuffer);
	else
		drawVertexPrimitiveList(mb->getVertices(),
								mb->getIndices(),
#ifdef _DEBUG
								ForceFullRange ? 0 : mb->getVertexIndexStart(),
								ForceFullRange ? mb->getVertexCount() : mb->getVertexIndexEnd(),
#else
								mb->getVertexIndexStart(),
								mb->getVertexIndexEnd(),
#endif
								mb->getIndexCount() / 3,
								mb->getVertexType(),
								mb->getPrimitiveType(),
								mb->getIndexType());
}

CNullDriver::SHWBufferLink*
CNullDriver::getBufferLink(const scene::IMeshBuffer* mb)
{
	if (!mb || !isHardwareBufferRecommend(mb))
		return 0;

	//search for hardware links
	core::map< const scene::IMeshBuffer*,SHWBufferLink* >::Node* node = HWBufferMap.find(mb);
	if (node) return node->getValue();

	return createHardwareBuffer(mb); //no hardware links, and mesh wants one, create it
}

//! Update all hardware buffers, remove unused ones
void
CNullDriver::updateAllHardwareBuffers()
{
	core::map<const scene::IMeshBuffer*,SHWBufferLink*>::ParentFirstIterator Iterator=HWBufferMap.getParentFirstIterator();

	for (;!Iterator.atEnd();Iterator++)
	{
		SHWBufferLink *Link=Iterator.getNode()->getValue();

		Link->LastUsed++;
		if (Link->LastUsed>20000)
		{
			deleteHardwareBuffer(Link);

			// todo: needs better fix
			Iterator = HWBufferMap.getParentFirstIterator();
		}
	}
}

void
CNullDriver::deleteHardwareBuffer(SHWBufferLink *HWBuffer)
{
	if (!HWBuffer) return;
	HWBufferMap.remove( HWBuffer->MeshBuffer );
	delete HWBuffer;
}

//! Remove hardware buffer
void
CNullDriver::removeHardwareBuffer(const scene::IMeshBuffer* mb)
{
	core::map<const scene::IMeshBuffer*,SHWBufferLink*>::Node* node = HWBufferMap.find(mb);
	if (node) deleteHardwareBuffer( node->getValue() );
}

//! Remove all hardware buffers
void
CNullDriver::removeAllHardwareBuffers()
{
	while (HWBufferMap.size())
		deleteHardwareBuffer(HWBufferMap.getRoot()->getValue());
}

bool
CNullDriver::isHardwareBufferRecommend(const scene::IMeshBuffer* mb)
{
	if (!mb || (mb->getHardwareMappingHint_Index()==scene::EHM_NEVER && mb->getHardwareMappingHint_Vertex()==scene::EHM_NEVER))
		return false;

//	if (mb->getVertexCount()<500) //todo: tweak and make user definable
//		return false;

	return true;
}

//! Only used by the internal engine. Used to notify the driver that
//! the window was resized.
void
CNullDriver::OnResize(const core::dimension2d<s32>& size)
{
	if (ViewPort.getWidth() == ScreenSize.Width &&
		ViewPort.getHeight() == ScreenSize.Height)
		ViewPort = core::rect<s32>(core::position2d<s32>(0,0), size);

	ScreenSize = size;
}

// adds a material renderer and drops it afterwards. To be used for internal creation
s32
CNullDriver::addAndDropMaterialRenderer(IMaterialRenderer* m)
{
	s32 i = addMaterialRenderer(m);

	if (m)
		m->drop();

	return i;
}

//! Adds a new material renderer to the video device.
s32
CNullDriver::addMaterialRenderer(IMaterialRenderer* renderer, const char* name)
{
	if (!renderer)
		return -1;

	SMaterialRenderer r;
	r.Renderer = renderer;
	r.Name = name;

	if (name == 0 && (MaterialRenderers.size() < (sizeof(sBuiltInMaterialTypeNames) / sizeof(char*))-1 ))
	{
		// set name of built in renderer so that we don't have to implement name
		// setting in all available renderers.
		r.Name = sBuiltInMaterialTypeNames[MaterialRenderers.size()];
	}

	MaterialRenderers.push_back(r);
	renderer->grab();

	return MaterialRenderers.size()-1;
}

//! Sets the name of a material renderer.
void
CNullDriver::setMaterialRendererName(s32 idx, const char* name)
{
	if (idx < s32(sizeof(sBuiltInMaterialTypeNames) / sizeof(char*))-1 ||
		idx >= (s32)MaterialRenderers.size())
		return;

	MaterialRenderers[idx].Name = name;
}

//! Creates material attributes list from a material, usable for serialization and more.
io::IAttributes*
CNullDriver::createAttributesFromMaterial(const video::SMaterial& material)
{
	io::CAttributes* attr = irrnew io::CAttributes(this);

	attr->addEnum("Type", material.getMaterialType(), sBuiltInMaterialTypeNames);

	attr->addColor("Ambient", material.getAmbientColor());
	attr->addColor("Diffuse", material.getDiffuseColor());
	attr->addColor("Emissive", material.getEmissiveColor());
	attr->addColor("Specular", material.getSpecularColor());

	attr->addFloat("Shininess", material.getShininess());
	attr->addFloat("Param1", material.getMaterialTypeParam(0));
	attr->addFloat("Param2", material.getMaterialTypeParam(1));

	core::stringc prefix="Texture";
	u32 i;
	for (i=0; i<MATERIAL_MAX_TEXTURES; ++i)
		attr->addTexture((prefix+core::stringc(i+1)).c_str(), material.getTexture(i));

	attr->addBool("Wireframe", material.getFlag(EMF_WIREFRAME));
	attr->addBool("GouraudShading", material.getFlag(EMF_GOURAUD_SHADING));
	attr->addBool("Lighting", material.getFlag(EMF_LIGHTING));
	attr->addBool("ZWriteEnable", material.getFlag(EMF_ZWRITE_ENABLE));
	attr->addBool("ZBuffer", material.getFlag(EMF_ZBUFFER));
	attr->addInt("ZBufferFunc", material.getZBufferFunc());
	attr->addBool("BackfaceCulling", material.getFlag(EMF_BACK_FACE_CULLING));
	attr->addBool("FrontfaceCulling", material.getFlag(EMF_FRONT_FACE_CULLING));
	attr->addBool("FogEnable", material.getFlag(EMF_FOG_ENABLE));
	attr->addBool("NormalizeNormals", material.getFlag(EMF_NORMALIZE_NORMALS));

	return attr;
}

//! Fills an SMaterial structure from attributes.
void
CNullDriver::fillMaterialStructureFromAttributes(video::SMaterial& outMaterial,
												 io::IAttributes* attr)
{
	outMaterial.setMaterialType(video::EMT_SOLID);

	core::stringc name = attr->getAttributeAsString("Type");

	u32 i;

	for (i = 0; i < MaterialRenderers.size(); ++i)
	{
		if (name == MaterialRenderers[i].Name)
		{
			outMaterial.setMaterialType((video::E_MATERIAL_TYPE)i);
			break;
		}
	}

	outMaterial.setAmbientColor(attr->getAttributeAsColor("Ambient"));
	outMaterial.setDiffuseColor(attr->getAttributeAsColor("Diffuse"));
	outMaterial.setEmissiveColor(attr->getAttributeAsColor("Emissive"));
	outMaterial.setSpecularColor(attr->getAttributeAsColor("Specular"));

	outMaterial.setShininess(attr->getAttributeAsFloat("Shininess"));
	outMaterial.setMaterialTypeParam(0, attr->getAttributeAsFloat("Param1"));
	outMaterial.setMaterialTypeParam(1, attr->getAttributeAsFloat("Param2"));

	core::stringc prefix="Texture";
	for (i=0; i<MATERIAL_MAX_TEXTURES; ++i)
		outMaterial.setTexture(i, attr->getAttributeAsTexture((prefix+core::stringc(i+1)).c_str()));

	outMaterial.setFlag(EMF_WIREFRAME, attr->getAttributeAsBool("Wireframe"));
	outMaterial.setFlag(EMF_GOURAUD_SHADING, attr->getAttributeAsBool("GouraudShading"));
	outMaterial.setFlag(EMF_LIGHTING, attr->getAttributeAsBool("Lighting"));
	outMaterial.setFlag(EMF_ZWRITE_ENABLE, attr->getAttributeAsBool("ZWriteEnable"));
	outMaterial.setFlag(EMF_ZBUFFER, attr->getAttributeAsBool("ZBuffer"));
	outMaterial.setZBufferFunc((E_COMPARE_FUNC)attr->getAttributeAsInt("ZBufferFunc"));
	outMaterial.setFlag(EMF_BACK_FACE_CULLING, attr->getAttributeAsBool("BackfaceCulling"));
	outMaterial.setFlag(EMF_FRONT_FACE_CULLING, attr->getAttributeAsBool("FrontfaceCulling"));
	outMaterial.setFlag(EMF_FOG_ENABLE, attr->getAttributeAsBool("FogEnable"));
	outMaterial.setFlag(EMF_NORMALIZE_NORMALS, attr->getAttributeAsBool("NormalizeNormals"));
}

//! Returns driver and operating system specific data about the IVideoDriver.
const SExposedVideoData&
CNullDriver::getExposedVideoData()
{
	return ExposedData;
}

//! Returns type of video driver
E_DRIVER_TYPE
CNullDriver::getDriverType() const
{
	return EDT_NULL;
}

//! deletes all material renderers
void
CNullDriver::deleteMaterialRenders()
{
	// delete material renderers
	for (u32 i=0; i<MaterialRenderers.size(); ++i)
		if (MaterialRenderers[i].Renderer)
			MaterialRenderers[i].Renderer->drop();

	MaterialRenderers.clear();
}

//! Returns pointer to material renderer or null
IMaterialRenderer*
CNullDriver::getMaterialRenderer(u32 idx) const
{
	if ( idx < MaterialRenderers.size() )
		return MaterialRenderers[idx].Renderer;
	else
		return 0;
}

//! Returns amount of currently available material renderers.
u32
CNullDriver::getMaterialRendererCount() const
{
	return MaterialRenderers.size();
}

//! Returns name of the material renderer
const char*
CNullDriver::getMaterialRendererName(u32 idx) const
{
	if ( idx < MaterialRenderers.size() )
		return MaterialRenderers[idx].Name.c_str();

	return 0;
}

//! Returns pointer to the IGPUProgrammingServices interface.
IGPUProgrammingServices*
CNullDriver::getGPUProgrammingServices()
{
	return 0;
}

//! Adds a new material renderer to the VideoDriver, based on a high level shading
//! language. Currently only HLSL in D3D9 is supported.
s32
CNullDriver::addHighLevelShaderMaterial(
	const c8* vertexShaderProgram,
	const c8* vertexShaderEntryPointName,
	E_VERTEX_SHADER_TYPE vsCompileTarget,
	const c8* pixelShaderProgram,
	const c8* pixelShaderEntryPointName,
	E_PIXEL_SHADER_TYPE psCompileTarget,
	IShaderConstantSetCallBack* callback,
	E_MATERIAL_TYPE baseMaterial,
	u32 vertexAttributeMask,
	s32 userData)
{
	os::Printer::log("High level shader materials not available (yet) in this driver, sorry");
	return -1;
}

//! Like IGPUProgrammingServices::addShaderMaterial() (look there for a detailed description),
//! but tries to load the programs from files.
s32
CNullDriver::addHighLevelShaderMaterialFromFiles(
	const c8* vertexShaderProgram,
	const c8* vertexShaderEntryPointName,
	E_VERTEX_SHADER_TYPE vsCompileTarget,
	const c8* pixelShaderProgram,
	const c8* pixelShaderEntryPointName,
	E_PIXEL_SHADER_TYPE psCompileTarget,
	IShaderConstantSetCallBack* callback,
	E_MATERIAL_TYPE baseMaterial,
	u32 vertexAttributeMask,
	s32 userData)
{
	io::IReadFile* vsfile = 0;
	io::IReadFile* psfile = 0;

	if (vertexShaderProgram)
	{
		vsfile = FileSystem->createAndOpenFile(vertexShaderProgram);
		if (!vsfile)
		{
			os::Printer::log("Could not open vertex shader program file",
				vertexShaderProgram, ELL_WARNING);
			return -1;
		}
	}

	if (pixelShaderProgram)
	{
		psfile = FileSystem->createAndOpenFile(pixelShaderProgram);
		if (!psfile)
		{
			os::Printer::log("Could not open pixel shader program file",
				pixelShaderProgram, ELL_WARNING);
			if (vsfile)
				vsfile->drop();
			return -1;
		}
	}

	s32 result = addHighLevelShaderMaterialFromFiles(
		vsfile, vertexShaderEntryPointName, vsCompileTarget,
		psfile, pixelShaderEntryPointName, psCompileTarget,
		callback, baseMaterial, vertexAttributeMask, userData);

	if (psfile)
		psfile->drop();

	if (vsfile)
		vsfile->drop();

	return result;
}

//! Like IGPUProgrammingServices::addShaderMaterial() (look there for a detailed description),
//! but tries to load the programs from files.
s32
CNullDriver::addHighLevelShaderMaterialFromFiles(
	io::IReadFile* vertexShaderProgram,
	const c8* vertexShaderEntryPointName,
	E_VERTEX_SHADER_TYPE vsCompileTarget,
	io::IReadFile* pixelShaderProgram,
	const c8* pixelShaderEntryPointName,
	E_PIXEL_SHADER_TYPE psCompileTarget,
	IShaderConstantSetCallBack* callback,
	E_MATERIAL_TYPE baseMaterial,
	u32 vertexAttributeMask,
	s32 userData)
{
	c8* vs = 0;
	c8* ps = 0;

	if (vertexShaderProgram)
	{
		const long size = vertexShaderProgram->getSize();
		if (size)
		{
			vs = irrnew c8[size+1];
			vertexShaderProgram->read(vs, size);
			vs[size] = 0;
		}
	}

	if (pixelShaderProgram)
	{
		const long size = pixelShaderProgram->getSize();
		if (size)
		{
			// if both handles are the same we must reset the file
			if (pixelShaderProgram==vertexShaderProgram)
				pixelShaderProgram->seek(0);
			ps = irrnew c8[size+1];
			pixelShaderProgram->read(ps, size);
			ps[size] = 0;
		}
	}

	s32 result = this->addHighLevelShaderMaterial(
		vs, vertexShaderEntryPointName, vsCompileTarget,
		ps, pixelShaderEntryPointName, psCompileTarget,
		callback, baseMaterial, vertexAttributeMask, userData);

#if !defined(_IRR_USE_PS3_DEVICE_)
	delete [] vs;
	delete [] ps;
#endif

	return result;
}

//! Adds a new material renderer to the VideoDriver, using pixel and/or
//! vertex shaders to render geometry.
s32
CNullDriver::addShaderMaterial(const c8* vertexShaderProgram,
	const c8* pixelShaderProgram,
	IShaderConstantSetCallBack* callback,
	E_MATERIAL_TYPE baseMaterial,
	s32 userData)
{
	os::Printer::log("Shader materials not implemented yet in this driver, sorry.");
	return -1;
}

//! Like IGPUProgrammingServices::addShaderMaterial(), but tries to load the
//! programs from files.
s32
CNullDriver::addShaderMaterialFromFiles(io::IReadFile* vertexShaderProgram,
	io::IReadFile* pixelShaderProgram,
	IShaderConstantSetCallBack* callback,
	E_MATERIAL_TYPE baseMaterial,
	s32 userData)
{
	c8* vs = 0;
	c8* ps = 0;

	if (vertexShaderProgram)
	{
		const long size = vertexShaderProgram->getSize();
		if (size)
		{
			vs = irrnew c8[size+1];
			vertexShaderProgram->read(vs, size);
			vs[size] = 0;
		}
	}

	if (pixelShaderProgram)
	{
		const long size = pixelShaderProgram->getSize();
		if (size)
		{
			ps = irrnew c8[size+1];
			pixelShaderProgram->read(ps, size);
			ps[size] = 0;
		}
	}

	s32 result = addShaderMaterial(vs, ps, callback, baseMaterial, userData);

	delete [] vs;
	delete [] ps;

	return result;
}

//! Like IGPUProgrammingServices::addShaderMaterial(), but tries to load the
//! programs from files.
s32
CNullDriver::addShaderMaterialFromFiles(const c8* vertexShaderProgramFileName,
	const c8* pixelShaderProgramFileName,
	IShaderConstantSetCallBack* callback,
	E_MATERIAL_TYPE baseMaterial,
	s32 userData)
{
	io::IReadFile* vsfile = 0;
	io::IReadFile* psfile = 0;

	if (vertexShaderProgramFileName)
	{
		vsfile = FileSystem->createAndOpenFile(vertexShaderProgramFileName);
		if (!vsfile)
		{
			os::Printer::log("Could not open vertex shader program file",
				vertexShaderProgramFileName, ELL_WARNING);
			return -1;
		}
	}

	if (pixelShaderProgramFileName)
	{
		psfile = FileSystem->createAndOpenFile(pixelShaderProgramFileName);
		if (!psfile)
		{
			os::Printer::log("Could not open pixel shader program file",
				pixelShaderProgramFileName, ELL_WARNING);
			if (vsfile)
				vsfile->drop();
			return -1;
		}
	}

	s32 result = addShaderMaterialFromFiles(vsfile, psfile, callback,
		baseMaterial, userData);

	if (psfile)
		psfile->drop();

	if (vsfile)
		vsfile->drop();

	return result;
}

//! Creates a render target texture.
ITexture*
CNullDriver::addRenderTargetTexture(const core::dimension2d<s32>& size,
									const c8* name,
									ECOLOR_FORMAT format)
{
	return 0;
}

//! Returns a pointer to the mesh manipulator.
scene::IMeshManipulator*
CNullDriver::getMeshManipulator()
{
	return MeshManipulator;
}

//! Returns an image created from the last rendered frame.
IImage*
CNullDriver::createScreenShot()
{
	return 0;
}

// prints renderer version
void
CNullDriver::printVersion()
{
	core::stringw namePrint = L"Using renderer: ";
	namePrint += getName();
	os::Printer::log(namePrint.c_str(), ELL_INFORMATION);
}

//! creates a video driver
IVideoDriver*
createNullDriver(io::IFileSystem* io, const core::dimension2d<s32>& screenSize)
{
	CNullDriver* nullDriver = irrnew CNullDriver(io, screenSize);

	// create empty material renderers
	for(u32 i=0; sBuiltInMaterialTypeNames[i]; ++i)
	{
		IMaterialRenderer* imr = irrnew CNullMaterialRenderer();
		nullDriver->addMaterialRenderer(imr);
		imr->drop();
	}

	return nullDriver;
}

//! Set/unset a clipping plane.
//! There are at least 6 clipping planes available for the user to set at will.
//! \param index: The plane index. Must be between 0 and MaxUserClipPlanes.
//! \param plane: The plane itself.
//! \param enable: If true, enable the clipping plane else disable it.
bool
CNullDriver::setClipPlane(u32 index, const core::plane3df& plane, bool enable)
{
	return false;
}

//! Enable/disable a clipping plane.
//! There are at least 6 clipping planes available for the user to set at will.
//! \param index: The plane index. Must be between 0 and MaxUserClipPlanes.
//! \param enable: If true, enable the clipping plane else disable it.
void
CNullDriver::enableClipPlane(u32 index, bool enable)
{
	// not necessary
}

ITexture*
CNullDriver::createRenderTargetTexture(const core::dimension2d<s32>& size,
									   const c8* name)
{
	os::Printer::log("createRenderTargetTexture is deprecated, use addRenderTargetTexture istead");
	ITexture* tex = addRenderTargetTexture(size, name);
	tex->grab();
	return tex;
}


//set scissor test
//! \param scissorRect: the scissor rect, upperleft cornor is 0,0
void
CNullDriver::setScissor(const core::rect<s32>& scissorRect)
{
	// not necessary in Null driver
}

//close scissor test
void
CNullDriver::resetScissor()
{
	// not necessary in Null driver
}

void
CNullDriver::setColorMask(bool red, bool green, bool blue, bool alpha)
{
}

void
CNullDriver::setDepthRange(float near, float far)
{
}

void CNullDriver::beginCompile(ICompileData*)
{
}

void
CNullDriver::endCompile()
{
}

E_DRIVER_ALLOCATION_RESULT
CNullDriver::getProcessBuffer(
	u32 vertexStart,
	u32 vertexEnd,
	u32 attributes,
	E_PROCESS_BUFFER_TYPE type,
	S3DVertexComponentArrays& components,
	IDriverBinding** binding,
	bool allocate
)
{
	_IRR_DEBUG_BREAK_IF("not implemented in null driver");
	return video::EDAR_FAILED;
}

void
CNullDriver::releaseProcessBuffer(E_PROCESS_BUFFER_TYPE type,
								  void* bindingOrDynamicBuffer,
								  u32 vertexStart,
								  u32 stride)
{
	_IRR_DEBUG_BREAK_IF("not implemented in null driver");
}

void
CNullDriver::setOrthoOrientation(E_ORTHO_ORIENTATION newOri)
{
}

void CNullDriver::Orientation3DProjectionTransform(irr::f32 *matrix, E_ORIENTATION orientation)
{
    if(orientation != EOO_0)
	{
		irr::f32 *glmat = matrix;
        if(orientation == EOO_90 || orientation == EOO_270)
		{
			irr::f32 h = glmat[5];
			irr::f32 w = glmat[0];
			irr::f32 fovVertical = atanf(1/h)*2;
			irr::f32 aspectRatio = h/w;
			f32 fovx = 2.0f*atanf(tanf(fovVertical/2.0f)*w/h);
			glmat[5] = 1.0f/tan(fovx/2.0f);
			glmat[0] = (glmat[5] / aspectRatio);
			
			//Rotate 90 or 270
			//core::swap(glmat[0], glmat[4]);
			//core::swap(glmat[1], glmat[5]);
			//core::swap(glmat[2], glmat[6]);
			//core::swap(glmat[3], glmat[7]);
        }
        
        if(orientation == EOO_270 || EOO_180 == orientation)
        {
            //* Rotate -90 with z under left hand
            //glmat[0] = -glmat[0];glmat[1] = -glmat[1];glmat[2] = -glmat[2];glmat[3] = -glmat[3];
        }
        if(orientation == EOO_90 || EOO_180 == orientation)
        {
            //* Rotate 90 with z under left hand
            //glmat[4] = -glmat[4];glmat[5] = -glmat[5];glmat[6] = -glmat[6];glmat[7] = -glmat[7];
		}
	} 		
}

void CNullDriver::Orientation3D_ScreenPos2Internal(irr::s32 &x, irr::s32 &y)
{
	s32 tmpx = 0;
	{
		video::E_ORIENTATION curOrien = getOrientation3D();
		switch(curOrien)
		{
		case video::EOO_0:
			break;
		case video::EOO_270:
			tmpx = y;
			y = x;
			x = ViewPort.getWidth() - tmpx;
			break;

		case video::EOO_90:
			tmpx = y;
			y = ViewPort.getHeight() - x;
			x = tmpx;
			break;
		case video::EOO_180:
			y = ViewPort.getHeight() - y;
			x = ViewPort.getWidth() - x;
			break;
		default:
			break;
		}
	}	
}

void CNullDriver::Orientation3D_Internal2ScreenPos(irr::s32 &x, irr::s32 &y)
{
	s32 tmpx = 0;
	{
		video::E_ORIENTATION curOrien = getOrientation3D();
		switch(curOrien)
		{
		case video::EOO_0:
			break;
		case video::EOO_270:
			tmpx = x;
			x = y;
			y = ViewPort.getWidth() - tmpx;
			break;

		case video::EOO_90:
			tmpx = x;
			x = ViewPort.getHeight() - y;
			y = tmpx;
			break;
		case video::EOO_180:
			y = ViewPort.getHeight() - y;
			x = ViewPort.getWidth() - x;
			break;
		default:
			break;
		}
	}	
}

void
CNullDriver::Orientation3DViewTransform(irr::f32 *matrix,
										E_ORIENTATION orientation)
{
	//core::matrix4 &mat = *(core::matrix4 *)matrix;
	//core::matrix4 matr;
	//if(orientation == EOO_90)
	//{
	//	matr.setRotationDegrees(core::vector3df(0, 0, 90));
	//}
	//else if(orientation == EOO_270)
	//{
	//	matr.setRotationDegrees(core::vector3df(0, 0, -90));
	//}
	//else if(orientation == EOO_180)
	//{
	//	matr.setRotationDegrees(core::vector3df(0, 0, 180));
	//}
	//mat = matr * mat;
///*
    if(orientation != EOO_0)
	{
		irr::f32 *glmat = matrix;

		if(orientation == EOO_90 || orientation == EOO_270)
		{	
			//Rotate 90 or 270
			core::swap(glmat[0], glmat[1]);
			core::swap(glmat[4], glmat[5]);
			core::swap(glmat[8], glmat[9]);
			core::swap(glmat[12], glmat[13]);
        }
        if(orientation == EOO_270 || EOO_180 == orientation)
        {
            //* Rotate -90 with z under left hand
			glmat[1] = -glmat[1];
			glmat[5] = -glmat[5];
			glmat[9] = -glmat[9];
			glmat[13] = -glmat[13];
        }
        if(orientation == EOO_90 || EOO_180 == orientation)
        {
            //* Rotate 90 with z under left hand
			glmat[0] = -glmat[0];
			glmat[4] = -glmat[4];
			glmat[8] = -glmat[8];
			glmat[12] = -glmat[12];
		}
	} 		
//*/
}

bool
CNullDriver::clip(core::rect<f32>& rect,
				  core::rect<f32>& sourceRect,
				  const core::rect<f32>& clipRect,
				  SColor* colors)
{
	// trivial clipping
	if (rect.UpperLeftCorner.X > clipRect.LowerRightCorner.X
		|| rect.UpperLeftCorner.Y > clipRect.LowerRightCorner.Y
		|| rect.LowerRightCorner.X < clipRect.UpperLeftCorner.X
		|| rect.LowerRightCorner.Y < clipRect.UpperLeftCorner.Y)
	{
		return false;
	}

	// Clip left and right
	if (clipRect.LowerRightCorner.X < rect.LowerRightCorner.X)
	{
		f32 w = (f32(rect.LowerRightCorner.X - clipRect.LowerRightCorner.X)
				 / rect.getWidth());
		sourceRect.LowerRightCorner.X = core::lerp(sourceRect.LowerRightCorner.X,
												   sourceRect.UpperLeftCorner.X,
												   w);
		if (colors)
		{
			colors[3] = colors[0].getInterpolated(colors[3], w);
			colors[2] = colors[1].getInterpolated(colors[2], w);
		}
		rect.LowerRightCorner.X = clipRect.LowerRightCorner.X;
	}
	if (clipRect.LowerRightCorner.Y < rect.LowerRightCorner.Y)
	{
		f32 w = (f32(rect.LowerRightCorner.Y - clipRect.LowerRightCorner.Y)
				 / rect.getHeight());
		sourceRect.LowerRightCorner.Y = core::lerp(sourceRect.LowerRightCorner.Y,
												   sourceRect.UpperLeftCorner.Y,
												   w);
		if (colors)
		{
			colors[1] = colors[0].getInterpolated(colors[1], w);
			colors[2] = colors[3].getInterpolated(colors[2], w);
		}
		rect.LowerRightCorner.Y = clipRect.LowerRightCorner.Y;
	}

	// Clip top and bottom
	if (clipRect.UpperLeftCorner.X > rect.UpperLeftCorner.X)
	{
		f32 w = (f32(clipRect.UpperLeftCorner.X - rect.UpperLeftCorner.X)
				 / rect.getWidth());
		sourceRect.UpperLeftCorner.X = core::lerp(sourceRect.UpperLeftCorner.X,
												  sourceRect.LowerRightCorner.X,
												  w);
		if (colors)
		{
			colors[0] = colors[3].getInterpolated(colors[0], w);
			colors[1] = colors[2].getInterpolated(colors[1], w);
		}
		rect.UpperLeftCorner.X = clipRect.UpperLeftCorner.X;
	}

	if (clipRect.UpperLeftCorner.Y > rect.UpperLeftCorner.Y)
	{
		f32 w = (f32(clipRect.UpperLeftCorner.Y - rect.UpperLeftCorner.Y)
				 / rect.getHeight());
		sourceRect.UpperLeftCorner.Y = core::lerp(sourceRect.UpperLeftCorner.Y,
												  sourceRect.LowerRightCorner.Y,
												  w);
		if (colors)
		{
			colors[0] = colors[1].getInterpolated(colors[0], w);
			colors[3] = colors[2].getInterpolated(colors[3], w);
		}
		rect.UpperLeftCorner.Y = clipRect.UpperLeftCorner.Y;
	}
	return true;
}

void CNullDriver::setTextureFullPathMode(bool value)
{
	if(TextureManager != NULL)
	{
		TextureManager->setFullPathMode(value);
	}
}

bool CNullDriver::getTextureFullPathMode()
{
	return TextureManager->getFullPathMode();
}



IDriverBinding* CNullDriver::createBinding()
{
	return NULL;
}
LibEffects::Manager*  CNullDriver::getPostProcess()
{
	return NULL;
}
} // end namespace video
} // end namespace irr
