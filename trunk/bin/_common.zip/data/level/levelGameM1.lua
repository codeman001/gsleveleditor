debug("-----------------------------------------------------------------")
debug("compile levelGameM1.lua")

function triggerInitLevel_enable(triggerID)	
	-- default ambient light
	setLevelAmbientLight(100,100,100)	
end

debug("-----------------------------------------------------------------\n\n")