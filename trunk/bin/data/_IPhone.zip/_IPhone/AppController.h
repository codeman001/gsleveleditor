
#import <UIKit/UIKit.h>
//IGP code integration
	#import "igphtmlViewController.h"
//END IGP code integration
#include "../Core/Commons.h"
#include "../GameStates/Menu/Multiplayer/Online/TextInput.h"
#import <AudioToolbox/AudioToolbox.h>

@class EAGLView;
@class igphtmlViewController;
@class Reachability;

#define ACCELEROMETER_FREQUENCY			(30.0f)

#if USE_ACCELEROMETER
@interface AppController : NSObject <UIApplicationDelegate, UIAccelerometerDelegate> 
#else 
@interface AppController : NSObject <UIApplicationDelegate> 
#endif 
{
    UIWindow *window;
    EAGLView *glView;

	//IBOutlet igphtmlViewController* igpViewController;
	//IGP code integration
		//UIButton *startIGPButton; //*** not necessary in your game - is used only in this example
		NSTimer *releaseIGPControlerTimer;
	//END IGP code integration

	Reachability	*internetReachable;
	BOOL			internetIsaccessible;
}

@property (readonly) UIWindow *window;
@property (readonly) EAGLView *glView;

@property (nonatomic, retain) IBOutlet igphtmlViewController *igpController;

@property(nonatomic, retain)	Reachability  *internetReachable;

-(EAGLView*)getView;
-(UIWindow*)getWindow;

+(AppController*)sharedInstance; 

-(void)removeTextField:(TextInput*)params;
-(void)initTextInput:(TextInputInitParams*)params; 

-(void)suspendMovie:(void*)params;
-(void)resumeMovie:(void*)params;
-(void)startMovie:(void*)params;

-(void)registerForOrientationNotifications:(void*)params;

-(void)enterTwitter:(int)language;

//IGP code integration
	//@property (nonatomic, retain) IBOutlet igphtmlViewController *igpController;
	@property (nonatomic, retain) UIButton* startIGPButton; //*** not necessary in your game - is used only in this example
	//-(void)createStartIGPButton; //*** not necessary in your game - is used only in this example
	//-(void)startIGPButtonPressed; //*** not necessary in your game - is used only in this example
	-(void)startIGP:(void*)params;
	-(void)releaseIGPControllerWhenQuitIgp;
	-(void)checkWiFiMessage:(void*)params;
	-(void)showAlertMessage: (void*)params;
-(void)dismissAlertMessage: (void*)params;
-(bool)checkSimpleSecurity: (void*)params;
//END IGP code integration
-(void)activateStatusBar:(void*)params;

-(void)setOrientationHelper:(void*)params;

- (void) CheckNetworkStatus:(NSNotification *)notice;
- (BOOL) DoWeHaveInternet;


//WIFI and bluetooth tests
- (bool)getWiFiIPAddress;
- (bool) testWifiConnection;

@end
