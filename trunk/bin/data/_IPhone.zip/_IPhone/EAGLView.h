
#import <UIKit/UIKit.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/EAGLDrawable.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

#import "AppController.h"

/*
This class wraps the CAEAGLLayer from CoreAnimation into a convenient UIView subclass.
The view content is basically an EAGL surface you render your OpenGL scene into.
Note that setting the view non-opaque will only work if the EAGL surface has an alpha channel.
*/

#define IGP_TIMER_INTERVAL              (1.0 / 60.0)

@class EAGLView;

@protocol EAGLViewDelegate <NSObject>
- (void) didResizeEAGLSurfaceForView:(EAGLView*)view; //Called whenever the EAGL surface has been resized
@end

@interface EAGLView : UIView 
{    
@private
  
    NSTimer*				m_igpTimer;
    NSTimeInterval			m_igpTimerInterval;
	BOOL					_autoresize;
	CGSize					_size;

	CGPoint	cursorStartPos;
}

@property NSTimeInterval m_igpTimerInterval;
@property BOOL autoresizesSurface; //NO by default - Set to YES to have the EAGL surface automatically resized when the view bounds change, otherwise the EAGL surface contents is rendered scaled
@property(readonly, nonatomic) CGSize surfaceSize;

- (id) initWithFrame:(CGRect)frame;

- (void)movieFinishedCallback;
- (void)movieStartsCallback;

//-----------------------------------------------------
// MainTimer related stuff
//-----------------------------------------------------
//- (void) igpTimerStart;
//- (void) igpTimerStop;
//- (void) igpTimerOnUpdate;
//-----------------------------------------------------

- (void)acceleratedInX:(float)xx Y:(float)yy Z:(float)zz;

- (CGPoint)ConvertCoordP:(CGPoint)p;

@end

