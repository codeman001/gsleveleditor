/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import <QuartzCore/QuartzCore.h>

#import "EAGLView.h"
#include "../Core/Commons.h"
#include "../IO/TouchScreen/TouchScreenIPhone.h"
#include "Application.h"

#include "GameEngine.h"

#pragma comment(lib, "libGlitch.a")

#include <glitch/glitch.h>

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using namespace glitch;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern void checkIsIPad();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern TouchScreenIPhone* g_TouchScreen;
extern bool g_bHasSDK3Features;

extern "C" void LockMainLoop();
extern "C" void UnlockMainLoop();
extern "C" void StartIGPThread();
extern float GetDeviceScaleFactor();
extern "C" void CreateOpenGlMutex();

EAGLView* g_EAGLView;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// A class extension to declare private methods
@interface EAGLView ()

@property (nonatomic, assign) NSTimer *m_igpTimer;

- (BOOL) createFramebuffer;
- (void) destroyFramebuffer;

@end


@implementation EAGLView

@synthesize m_igpTimer;
@synthesize m_igpTimerInterval;
@synthesize autoresizesSurface=_autoresize, surfaceSize=_size;


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

+ (Class) layerClass
{
	return [CAEAGLLayer class];
}

- (id) initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	
	if(self)
	{
		// I need this before getting the content Scale factor
		checkIsIPad();
		
		CreateOpenGlMutex();

		//Set up the ability to track multiple touches
		[self setMultipleTouchEnabled:YES];
		[self setExclusiveTouch:YES];

		// Get the layer
		g_EAGLLayer = (CAEAGLLayer *)self.layer;
		
		g_EAGLLayer.opaque = YES;
		g_EAGLLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
										[NSNumber numberWithBool:NO], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGB565, kEAGLDrawablePropertyColorFormat, nil];

		if([self respondsToSelector:@selector(contentScaleFactor)])
		 {
			if(GetDeviceScaleFactor() != 1.0f)
				self.contentScaleFactor = roundf(GetDeviceScaleFactor());
		 }
		 
		// Bogdan - moved
		//if (!GameEngine_InitWindow()) 
		//{
		//	[self release];
		//	return nil;
		//}
		
		//GameEngine_CreateFramebuffer();
		_size = [g_EAGLLayer bounds].size;
		_size.width = roundf(_size.width * GetDeviceScaleFactor());
		_size.height = roundf(_size.height * GetDeviceScaleFactor());
		//printf("w=%f h=%f\n",_size.width, _size.height);
		// Bogdan - moved
		//GameEngine_CreateApplication();
	}
	
	g_EAGLView = self;
	
	return self;
}

- (void)layoutSubviews 
{
	CGRect				bounds = [self bounds];
	
	if(_autoresize && ((roundf(bounds.size.width) != _size.width) || (roundf(bounds.size.height) != _size.height))) 
	{
		//LockMainLoop();
		
		//[self destroyFramebuffer];
		//[self createFramebuffer];
		
		//UnlockMainLoop();
	}
}

- (void) setAutoresizesEAGLSurface:(BOOL)autoresizesEAGLSurface;
{
	_autoresize = autoresizesEAGLSurface;
	if(_autoresize)
	[self layoutSubviews];
}



- (BOOL)createFramebuffer 
{
	BOOL bRet = GameEngine_CreateFramebuffer();
	
	_size = [g_EAGLLayer bounds].size;
	_size.width = roundf(_size.width);
	_size.height = roundf(_size.height);
	
	return bRet;
}


- (void)destroyFramebuffer 
{	
	GameEngine_DestroyFramebuffer();
}




- (void)dealloc
{	
	[super dealloc];
}

- (void)acceleratedInX:(float)xx Y:(float)yy Z:(float)zz
{
	glitch::SEvent event;
	event.EventType = glitch::EET_KEY_INPUT_EVENT;
	
	if (xx > 0.2f)
	{
		event.KeyInput.Key = glitch::KEY_RIGHT;	
		event.KeyInput.PressedDown = true;
		GetDevice()->postEventFromUser(event);
	}
	if (xx < -0.2f)
	{
		event.KeyInput.Key = glitch::KEY_LEFT;	
		event.KeyInput.PressedDown = true;
		GetDevice()->postEventFromUser(event);
	}
	if (yy > 0.2f)
	{
		event.KeyInput.Key = glitch::KEY_UP;	
		event.KeyInput.PressedDown = true;
		GetDevice()->postEventFromUser(event);
	}
	if (yy < -0.2f)
	{
		event.KeyInput.Key = glitch::KEY_DOWN;	
		event.KeyInput.PressedDown = true;
		GetDevice()->postEventFromUser(event);
	}
	
	if (xx < 0.2f && xx > -0.2f)
	{
		event.KeyInput.Key = glitch::KEY_LEFT;	
		event.KeyInput.PressedDown = false;
		GetDevice()->postEventFromUser(event);
		event.KeyInput.Key = glitch::KEY_RIGHT;
		GetDevice()->postEventFromUser(event);
	}
	
	if (yy < 0.2f && yy > -0.2f)
	{
		event.KeyInput.Key = glitch::KEY_UP;	
		event.KeyInput.PressedDown = false;
		GetDevice()->postEventFromUser(event);
		event.KeyInput.Key = glitch::KEY_DOWN;	
		GetDevice()->postEventFromUser(event);
	}
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (CGPoint)ConvertCoordP:(CGPoint)p
{
	short tmpX = p.x;
	CGPoint result;
	//TODO - if we lock the orientation use a variable - stop interogating for every touch...
	UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
	const float scale = GetDeviceScaleFactor();
	
	switch(orientation)
	{
		case UIInterfaceOrientationPortrait:
			result = p;
			break;
			
		case UIInterfaceOrientationLandscapeRight:
			//tmpX = p.x;
			result.x = p.y;
			result.y = SCR_H / scale - tmpX;
			break;
			
		case UIInterfaceOrientationLandscapeLeft:
			//tmpX = p.x;
			result.x = SCR_W / scale - p.y;
			result.y = tmpX;
			break;
	}

	result.x *= scale;
	result.y *= scale;

	return result;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Handles the start of a touch
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(!g_TouchScreen)
		return;

	for (UITouch *touch in touches) 
	{
		CGPoint iPoint	=	[touch locationInView:self];
		iPoint			=	[self ConvertCoordP:iPoint];
		g_TouchScreen->AddTouchEvent(TOUCH_QUEUE_EVENT_TOUCH, iPoint.x, iPoint.y, (long)touch);
	}
}

// Handles the continuation of a touch.
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(!g_TouchScreen)
		return;

	for (UITouch *touch in touches) 
	{
		CGPoint iPoint	=	[touch locationInView:self];
		iPoint			=	[self ConvertCoordP:iPoint];
		g_TouchScreen->AddTouchEvent(TOUCH_QUEUE_EVENT_MOVE, iPoint.x, iPoint.y, (long)touch);
	}
}

// Handles the end of a touch event when the touch is a tap.
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event 
{
	if(!g_TouchScreen)
		return;

	for (UITouch *touch in touches) 
	{
		CGPoint iPoint	=	[touch locationInView:self];
		iPoint			=	[self ConvertCoordP:iPoint];
		g_TouchScreen->AddTouchEvent(TOUCH_QUEUE_EVENT_UNTOUCH, iPoint.x, iPoint.y, (long)touch);
	}
}

// Handles the end of a touch event.
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(!g_TouchScreen)
		return;

	for (UITouch *touch in touches) 
	{
		CGPoint iPoint	=	[touch locationInView:self];
		iPoint			=	[self ConvertCoordP:iPoint];
		g_TouchScreen->AddTouchEvent(TOUCH_QUEUE_EVENT_UNTOUCH, iPoint.x, iPoint.y, (long)touch);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern bool g_movieDonePlaying;

- (void) movieFinishedCallback
{
	/* We'll move that to when the video actually starts, thx to 3704866
	Application* app = Application::GetInstance();
	if(!app->IsPlayLogo())
	{
		app->DrawGSInitBackground(true);
	}*/
	
	INTERRUPT_DEBUG("--- movieFinishedCallback\n");

	g_movieDonePlaying = true;
}

- (void) movieStartsCallback
{
	/*Application* app = Application::GetInstance();
	if(!app->IsPlayLogo())
	{
		app->DrawGSInitBackground(true);
	}*/
}

@end

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
