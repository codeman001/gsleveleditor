#ifndef __GAMEENGINE_H__
#define __GAMEENGINE_H__

//#include "iPhoneMiscFunct.h"
#import <OpenGLES/EAGLDrawable.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreFoundation/CFBundle.h>
#import <stdio.h>

extern CAEAGLLayer*			g_EAGLLayer;
extern EAGLContext*			g_EAGLContext;
extern int					g_isGameThreadActive;
extern bool					g_recreateFramebuffer;


bool	GameEngine_InitWindow();
void	GameEngine_CreateApplication();
int		GameEngine_CreateFramebuffer();
void	GameEngine_DestroyFramebuffer();
void	GameEngine_DestroyWindow();

void	GameEngine_StartGameThread();
void	GameEngine_JoinGameThread();
void	GameEngine_RenderFrame();
bool	HasSDK3Features();
bool	HasSDK4Features();

#endif //__GAMEENGINE_H__