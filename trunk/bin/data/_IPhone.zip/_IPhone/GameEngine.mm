/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <pthread.h>
#include <sched.h>
#include <unistd.h>

#include "AppController.h"
#include "EAGLView.h"
#include "GameEngine.h"
#include "Game/Utils/Profiler.h"

#import <QuartzCore/QuartzCore.h>

#include "../Application.h"
#include "../IO/TouchScreen/TouchScreen.h"
//#include "../SceneManager/FpsIrrFactory.h"

#include "Core/ConsoleProfiler.h"
#include "Game/Utils/Profiler.h"

#include "Game/Utils/MemoryProfiler.h"

#include "../RTSMultiplayer/RTSMpManager.h"

#include <sys/types.h>
#include <sys/sysctl.h>


#include <glitch/glitch.h>

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using namespace glitch;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//static FpsIrrFactory				s_fpsIrrFactory;

TouchScreenIPhone*				g_TouchScreen	=	0;

CNovaSceneManager*						g_sceneManager	=	0;
glitch::IDevice*					g_device		=	0;

extern int						g_launchIGPLang;

extern UIAlertView* g_alert;
extern bool g_alert_to_show;
extern "C" bool IsStartState();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

volatile bool   m_bIsAppPaused					=	false;
volatile bool   g_bInterruptReceived_Pause		=	false;
volatile bool   g_bInterruptReceived_Resume		=	false;
volatile bool   g_bInterruptBackground			=	false;
volatile bool   g_bInterruptForeground			=	false;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern "C" void GamePause();
extern "C" void GameResume();

extern int GetPlatform();
extern float GetDeviceScaleFactor();
extern "C" void DetectDeviceSDK();

extern "C" void RegisterForOrientationNotifications();

extern "C" bool MovieWillResignActive();
extern "C" void MovieDidBecomeActive();
extern "C" bool IsMoviePlaying();
extern "C" void ClearSubtitles();
extern "C" void StartMovieOnMainThread();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int					g_isGameThreadActive = 0;
pthread_t			g_gameThreadId;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

pthread_mutex_t			mutex_movie;
static pthread_mutex_t		g_openGlMutex;
static pthread_mutex_t		g_mainLoopMutex;
	  
static bool					g_isOpenGlMutexInited		=	false;

extern "C" void CreateOpenGlMutex()
{
	if(g_isOpenGlMutexInited)
		return;

	pthread_mutexattr_t mutexattr;
	pthread_mutexattr_init(&mutexattr);
	pthread_mutexattr_settype(&mutexattr, PTHREAD_MUTEX_RECURSIVE);

	pthread_mutex_init(&g_openGlMutex, &mutexattr);

	pthread_mutexattr_init(&mutexattr);
	pthread_mutexattr_settype(&mutexattr, PTHREAD_MUTEX_RECURSIVE);

	pthread_mutex_init(&g_mainLoopMutex, &mutexattr);

	g_isOpenGlMutexInited = true;
}

void DestroyOpenGlMutex()
{
	if(!g_isOpenGlMutexInited)
		return;

	g_isOpenGlMutexInited = false;

	pthread_mutex_destroy(&g_openGlMutex);
	pthread_mutex_destroy(&g_mainLoopMutex);
}


void LockOpenGl()
{
	if(g_isOpenGlMutexInited)
	{
		pthread_mutex_lock(&g_openGlMutex);
	}
}

void UnlockOpenGl()
{
	if(g_isOpenGlMutexInited)
	{
		pthread_mutex_unlock(&g_openGlMutex);
	}
}

extern "C" void LockMainLoop()
{
	if(g_isOpenGlMutexInited)
	{
		pthread_mutex_lock(&g_mainLoopMutex);
	}
}

extern "C" void UnlockMainLoop()
{
	if(g_isOpenGlMutexInited)
	{
		pthread_mutex_unlock(&g_mainLoopMutex);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void* GameThreadRoutine(void* param);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// OpenGL vars
CAEAGLLayer*    g_EAGLLayer			=	0;
EAGLContext*    g_EAGLContext		=	0;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

GLuint viewRenderbuffer		=	0;
GLuint viewFramebuffer		=	0;
GLuint depthRenderbuffer	=	0;

GLint backingWidth;
GLint backingHeight;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

long lastIdleTimerDisabled = 0;
bool g_isOpenGL11 = false;
bool isIPad();
void checkIsIPad();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool GameEngine_InitWindow()
{
	bool bOpenGLES20 = false;
	
	// test to see if the device has OpenGL ES 2.0 capabilities
	g_EAGLContext = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
	if (g_EAGLContext)
	{
		bOpenGLES20 = true;
		g_isOpenGL11 = false;
		
		//if (isIPad())
		//{
		//	CImageLoaderPVR::SkipMipMapLevels(1, 256); // DannyD force skip of first mipmap level for textures >= 256
		//}
		
		//if (GetPlatform() == PLATFORM_IPOD_4G)
		//{
		//	CImageLoaderPVR::SkipMipMapLevels(1, 256); // DannyD force skip of first mipmap level for textures >= 256
		//}
	}
	else
	{
		g_EAGLContext = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
		CImageLoaderPVR::SkipMipMapLevels(1, 256); // DannyD force skip of first mipmap level for textures >= 256
		g_isOpenGL11 = true;
	}
	 
	if (!g_EAGLContext || ![EAGLContext setCurrentContext:g_EAGLContext]) 
	{
		return false;
	}

	// init opengl mutex
	//CreateOpenGlMutex();

	return true;
}

bool isOpenGL11()
{
	return g_isOpenGL11;
}

void GameEngine_CreateApplication()
{
	if (GetDeviceScaleFactor() == 2.0)
	{
		SCR_H *= GetDeviceScaleFactor();
		SCR_W *= GetDeviceScaleFactor();
	}

	g_device = createDevice( video::EDT_OPENGL, dimension2d<s32>(SCR_H, SCR_W), 16, false, false, false, 0);
	collada::CResFileManager::getInst()->setDisableZipArchiveOnFirstNonZipArchiveLoaded(false);

	Application* app = Application::GetInstance();
	app->InitIPhone(g_device);

	g_sceneManager = (CNovaSceneManager*)g_device->getSceneManager();
	g_TouchScreen = (GetTouchScreen());
	
	UIDeviceOrientation _g_direction = UIDeviceOrientationLandscapeRight;
	//if (isIPad())
	//{
	//	_g_direction = [[UIDevice currentDevice] orientation];
	//	if (_g_direction != UIDeviceOrientationLandscapeRight)
	//		_g_direction = UIDeviceOrientationLandscapeLeft;
	//}

	glitch::video::E_ORTHO_ORIENTATION orientation = glitch::video::EOO_0;

	if (_g_direction == UIDeviceOrientationLandscapeLeft)
	{
		orientation = glitch::video::EOO_90;
	}
	else if (_g_direction == UIDeviceOrientationLandscapeRight)
	{
		orientation = glitch::video::EOO_270;
	}

	app->SetOrientation(orientation, true, false);

	RegisterForOrientationNotifications();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GameEngine_DestroyWindow()
{
	if ([EAGLContext currentContext] == g_EAGLContext)
	{
		[EAGLContext setCurrentContext:nil];
	}
	
	[g_EAGLContext release];  

	DestroyOpenGlMutex();

	printf("GAME END\n");
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int GameEngine_CreateFramebuffer()
{
	LockOpenGl();

	glGenFramebuffersOES(1, &viewFramebuffer);
	glGenRenderbuffersOES(1, &viewRenderbuffer);
	
	glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
	glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
	[g_EAGLContext renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:(CAEAGLLayer*)g_EAGLLayer];
	glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, viewRenderbuffer);
	
	glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
	glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);
	
	if (1) 
	{
		glGenRenderbuffersOES(1, &depthRenderbuffer);
		glBindRenderbufferOES(GL_RENDERBUFFER_OES, depthRenderbuffer);
		glRenderbufferStorageOES(GL_RENDERBUFFER_OES, GL_DEPTH_COMPONENT16_OES, backingWidth, backingHeight);
		glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER_OES, depthRenderbuffer);
	}
	
	if(glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES) 
	{
		UnlockOpenGl();
		NSLog(@"failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
		return NO;
	}

	glClearColor(1.f, 1.f, 1.f, 1.f);
	glClear(GL_COLOR_BUFFER_BIT);
	[g_EAGLContext presentRenderbuffer:GL_RENDERBUFFER_OES];
	
	UnlockOpenGl();
	return YES;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GameEngine_DestroyFramebuffer()
{
	LockOpenGl();

	if(viewFramebuffer)
	{
		glDeleteFramebuffersOES(1, &viewFramebuffer);
		viewFramebuffer = 0;
	}

	if(viewRenderbuffer)
	{
		glDeleteRenderbuffersOES(1, &viewRenderbuffer);
		viewRenderbuffer = 0;
	}
	
	if(depthRenderbuffer) 
	{
		glDeleteRenderbuffersOES(1, &depthRenderbuffer);
		depthRenderbuffer = 0;
	}

	UnlockOpenGl();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GameEngine_StartGameThread()
{
	pthread_mutex_init( &mutex_movie, NULL);
	
	if (pthread_create(&g_gameThreadId, NULL, &GameThreadRoutine, NULL)) 
	{
		perror("pthread_create\n");
		exit(1);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GameEngine_JoinGameThread()
{
	//[[g_sharedInstanceAppController getView] mainTimer_stop];

	g_isGameThreadActive = 0;

	int err = pthread_join(g_gameThreadId, NULL);
	if (err)
	{
		perror("pthread_join\n");
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GameEngine_RenderFrame()
{
	GLITCH_PROFILE("GameEngine_RenderFrame()");

	if (g_device->run())
	{
		if ( g_bInterruptReceived_Pause )
		{
			g_bInterruptReceived_Pause = false;
			INTERRUPT_DEBUG("--- Processing Pause\n");
						
			GamePause();
		}
		else if ( g_bInterruptReceived_Resume )
		{
			g_bInterruptReceived_Resume = false;

			INTERRUPT_DEBUG("--- Processing Resume\n");

			GameResume();
		}
	
		if (g_bInterruptBackground)
		{
			INTERRUPT_DEBUG("--- GameEnterBackground\n");
			//Application::GetInstance()->GameEnterBackground();

			g_bInterruptBackground = false;
		}
		
		if (g_bInterruptForeground)
		{
			INTERRUPT_DEBUG("--- GameEnterForeground\n");
			//Application::GetInstance()->GameEnterForeground();
		
			g_bInterruptForeground = false;
		}

		if (m_bIsAppPaused)
		{
	//		CTouchScreen::ClearEvents();
	//		CTouchScreen::s_MouseEvenQueueLength = 0;
		}
		else
		{
			LockOpenGl();

			if(!IsStartState() && g_alert_to_show)
			{
				//printf("g_alert 5\n");
				g_alert_to_show = false;
				[g_alert show];
			}

			[EAGLContext setCurrentContext:g_EAGLContext];
			glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
		
			Application::GetInstance()->Update();

			long time1 = os::Timer::getRealTime();
			if ((time1 > lastIdleTimerDisabled) && (time1 - lastIdleTimerDisabled > 30000))
			{
				[UIApplication sharedApplication].idleTimerDisabled = NO;
				[UIApplication sharedApplication].idleTimerDisabled = YES;
				lastIdleTimerDisabled = os::Timer::getRealTime();
			}
			
			if(!Application::GetInstance()->m_bSkipRender)
			{
				glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
				[g_EAGLContext presentRenderbuffer:GL_RENDERBUFFER_OES];
			}
			
			UnlockOpenGl();
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern bool isIGPActive();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void* GameThreadRoutine(void* param)
{
	g_isGameThreadActive = 1;
	
	NSAutoreleasePool* pool = [(NSAutoreleasePool*)[NSAutoreleasePool alloc] init];
	
	{
		LockMainLoop();
		
		DetectDeviceSDK();
	
		GameEngine_InitWindow();
		GameEngine_CreateFramebuffer();
		GameEngine_CreateApplication();
	
		UnlockMainLoop();
	}
	
	sched_yield();

	while(g_isGameThreadActive)
	{
		//if (g_launchIGPLang == -1)
		{
			LockMainLoop();
			
			GameEngine_RenderFrame();
			
			UnlockMainLoop();
		}

		CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.001, false);
	}

	Application::SelfDestroy();
	
	GameEngine_DestroyFramebuffer();
	GameEngine_DestroyWindow();

	[pool release];

	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern bool g_bHasSDK3Features;

bool HasSDK3Features()
{
	return g_bHasSDK3Features;
}

extern bool g_bHasSDK32Features;

bool HasSDK32Features()
{
	return g_bHasSDK32Features;
}

extern bool g_bHasSDK4Features;

bool HasSDK4Features()
{
	return g_bHasSDK4Features;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// platform detection

int saved_platform = -1;

bool is_ipad = false;

void checkIsIPad()
{
  NSString* model = [UIDevice currentDevice].model;
  if ([model rangeOfString:@"iPad"].location != NSNotFound) 
  {
    is_ipad = true;
	return;
  }
  is_ipad = false;
}

bool isIPad()
{
	return is_ipad;
}

int GetPlatform()
{
	if(saved_platform == -1)
	{
		NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];

		size_t size;
		int platform = PLATFORM_UNKNOWN;
		sysctlbyname("hw.machine", NULL, &size, NULL, 0);
		char *machine = new char[size];
		sysctlbyname("hw.machine", machine, &size, NULL, 0);

		if (!strcasecmp(machine, "iPhone1,1"))	platform = PLATFORM_IPHONE_1G;
		else if (!strcasecmp(machine, "iPhone1,2"))	platform = PLATFORM_IPHONE_3G;
		else if (!strcasecmp(machine, "iPhone2,1"))	platform = PLATFORM_IPHONE_3GS;
		else if (!strcasecmp(machine, "iPhone3,1"))	platform = PLATFORM_IPHONE_4;
		else if (!strncmp(machine, "iPhone", 6))	platform = PLATFORM_IPHONE_UNKNOWN;

		else if (!strcasecmp(machine, "iPod1,1"))	platform = PLATFORM_IPOD_1G;
		else if (!strcasecmp(machine, "iPod2,1"))	platform = PLATFORM_IPOD_2G;
		else if (!strcasecmp(machine, "iPod3,1"))	platform = PLATFORM_IPOD_3G;
		else if (!strcasecmp(machine, "iPod4,1"))	platform = PLATFORM_IPOD_4G;
		else if (!strncmp(machine, "iPod", 4))	platform = PLATFORM_IPOD_UNKNOWN;
		
		else if (!strcasecmp(machine, "iPad1,1"))	platform = PLATFORM_IPAD_1G;
		else if (!strncmp(machine, "iPad", 4))	platform = PLATFORM_IPAD_UNKNOWN;


		SAFE_DEL(machine);
		
		[pool release];

		saved_platform = platform;
	}
	return saved_platform;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool IsGameKitAvailable()
{
	bool bIsGameKitAvailable = false;
	int platform = GetPlatform();
	
	{
		NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
		
		Class myClass = (NSClassFromString(@"GKSession"));

		bIsGameKitAvailable = ((myClass != nil) && platform != PLATFORM_IPHONE_1G && platform != PLATFORM_IPOD_1G);
		
		[pool release];
	}
		
	return bIsGameKitAvailable;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void SetUILanguage(const char* lang)
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:[NSArray arrayWithObjects:[NSString stringWithUTF8String:lang], /*@"en", */nil] forKey:@"AppleLanguages"];
    [ud synchronize];
    [pool release];
} 

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern void GetDeviceLanguage(char *lang)
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];

	NSUserDefaults* defs = [NSUserDefaults standardUserDefaults];
	NSArray* languages = [defs objectForKey:@"AppleLanguages"];
	NSString* preferredLang = [languages objectAtIndex:0];
	sprintf(lang, "%s", [preferredLang UTF8String]);
	
	[pool release];
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
