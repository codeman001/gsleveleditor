
#undef WIN32
#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import "substView.h"

@class MoviePlayer;

@interface MoviePlayerViewController : MPMoviePlayerViewController
{
	MoviePlayer *m_parent;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation;
- (void) setParent:(MoviePlayer*)parent; 

@end

@interface MoviePlayer : NSObject
{
	UIViewController		*mMoviePlayer; 
	Boolean					m_isMoviePlaying;
	Boolean					m_isMovieLoading;
	
	substView				*m_subtitles;
	NSTimer					*m_subtitlesTimer;
	
	Boolean					m_isFlipped;

	UIInterfaceOrientation  m_orientation;

	UIButton  *m_btnSkip;                       // skip video
}

- (id)			initWithFile:(NSString*)fileName andFlipped:(Boolean)flip;
- (IBAction)	playMovie;
- (IBAction)	stopMovie;
- (Boolean)		isPlaying;
- (void)		willStop;
- (Boolean)		isLoading;
- (void)		movieSubtitles_init;
- (void)		movieSubtitles_reset;
- (substView*)	getSubstView;

@end
