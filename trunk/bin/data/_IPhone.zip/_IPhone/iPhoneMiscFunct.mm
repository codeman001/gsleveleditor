
#undef WIN32
#include "Application.h"
#import "AppController.h"
#import "Accelerometer.h"
#import <UIKit/UIKit.h>

//for free mem function
#import <mach/mach.h>
#import <mach/mach_host.h>

//#import "IGP.h"
#import "igphtmlViewController.h"
#import "sendInfo.h"

class AppController;

extern AppController* g_sharedInstanceAppController;

class UIApplication;
extern UIApplication* g_sharedInstanceUIApplication;

extern bool HasSDK4Features();

extern "C" void LockMainLoop();
extern "C" void UnlockMainLoop();


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// IGP
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int             g_launchIGPLang = -1;
int				g_alertLanguage =0;

extern "C" void LaunchIGP(int lang_idx)
{
	g_launchIGPLang = lang_idx;

	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
		
	NSNumber* param = [[NSNumber alloc] initWithInt:lang_idx];
	
	UnlockMainLoop();
	
	[[AppController sharedInstance] performSelectorOnMainThread:@selector(startIGP:) withObject:param waitUntilDone:YES];
	
	LockMainLoop();
	
	[pool release];
}


extern "C" bool isInIGP()
{
	return  ( g_launchIGPLang != -1 );
}

extern UIInterfaceOrientation saved_orientation;

extern "C" bool UpdateIGP()
{
	if ( !isInIGP() ) return false;
	
	if ([AppController sharedInstance].igpController.view.window == nil)
	{			
		g_launchIGPLang = -1;
		
		//[[UIApplication sharedApplication] setStatusBarOrientation: saved_orientation animated:NO];
		if (HasSDK4Features())
		{
			dispatch_async(dispatch_get_main_queue(), ^{			
				[[UIApplication sharedApplication] setStatusBarOrientation:saved_orientation];
			});
		}
		else
		{
			[[UIApplication sharedApplication] setStatusBarOrientation:saved_orientation];
		}
	}
	
	return g_launchIGPLang >= 0;
}
extern "C" void ReleaseIGP()
{
	[[AppController sharedInstance] releaseIGPControllerWhenQuitIgp];
	//[[AppController sharedInstance] performSelectorOnMainThread:@selector(releaseIGPControllerWhenQuitIgp:) waitUntilDone:YES];
}

void SendIGPInfo(int lang, char *version, char* name)
{
	//[sendInfoInterface IGPSendGameInfo : language : version];
	 [sendInfoInterface IGPSendGameInfo:lang :version :[[NSString alloc] initWithUTF8String:name]];
}

void getFiles(const char* path, Application::FileList& flist)
{
    //TODO
    NSFileManager*        _fileManager = [NSFileManager defaultManager];

    NSString*            _path1        = [[NSString alloc] initWithCString:path encoding:NSASCIIStringEncoding];
    NSString*            _pathdir    = [_path1 stringByDeletingLastPathComponent];
    NSString*            _fileext    = [_path1 pathExtension];
    
    NSError*  _error;

    NSArray*            _filelist        = [_fileManager contentsOfDirectoryAtPath:_pathdir error:&_error];
    if(_filelist == Nil)
        NSLog([_error localizedDescription]);
        
    for (unsigned int i =0; i < [_filelist count]; ++i)
    {
        NSString* x = [_filelist objectAtIndex:i];
        
        if(_fileext && [x hasSuffix:_fileext])
        {
        
            std::string fname = [x UTF8String];
            flist.push_back(fname);
        }

        
    }
}

extern char g_AppPath[1024];

bool deleteSavefile(const char* path)
{
	NSFileManager*	_fileManager = [NSFileManager defaultManager];
	NSString*		_path = [[NSString alloc] initWithCString:g_AppPath encoding:NSASCIIStringEncoding];
	NSString*		_file = [[NSString alloc] initWithCString:path encoding:NSASCIIStringEncoding];
	NSError*		_error;
	bool			_result;

	NSString* _fullpath = [[NSString alloc] initWithString:_path];
	_fullpath = [_fullpath stringByAppendingString:_file];

	_result = [_fileManager removeItemAtPath:_fullpath error:&_error];

	return _result;
}
extern "C" void getFilesMatching(const char* path, const char *expr, Application::FileList& flist)
{
    NSFileManager* _fileManager = [NSFileManager defaultManager];

    NSString* _path    = [[NSString alloc] initWithCString:path encoding:NSASCIIStringEncoding];
    NSString* _expr    = [[NSString alloc] initWithCString:expr encoding:NSASCIIStringEncoding];
    
    NSError*  _error;

    NSArray* _filelist = [_fileManager contentsOfDirectoryAtPath:_path error:&_error];
    if(_filelist == Nil)
        NSLog([_error localizedDescription]);
        
    for (unsigned int i =0; i < [_filelist count]; ++i)
    {
        NSString* f = [_filelist objectAtIndex:i];
        
        NSRange found = [f rangeOfString:_expr];

        if(found.location != NSNotFound)
        {
            std::string fname = [f UTF8String];
            flist.push_back(fname);
        }
    }
}

extern "C" void IAPMessage(int lang, int msg)
{
	g_alertLanguage = lang;
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
		
	NSNumber* param = [[NSNumber alloc] initWithInt:msg];
		[[AppController sharedInstance] performSelectorOnMainThread:@selector(checkWiFiMessage:) withObject:param waitUntilDone:NO];
	[pool release];
}
extern "C" void checkDeviceId()
{
	[[AppController sharedInstance] performSelectorOnMainThread:@selector(checkSimpleSecurity:) withObject:nil waitUntilDone:NO];	
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void GetDeviceLanguage(char *lang)
{
    //To know the current language    
     NSUserDefaults* defs = [NSUserDefaults standardUserDefaults];
     NSArray* languages = [defs objectForKey:@"AppleLanguages"];
     NSString* preferredLang = [languages objectAtIndex:0];
     sprintf(lang, "%s", [preferredLang UTF8String]);
}

extern "C" void showStatusBarOnMainThread(bool bShow)
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

	NSNumber* param = [[NSNumber alloc] initWithBool:bShow];
	
	[[AppController sharedInstance] performSelectorOnMainThread:@selector(showStatusBar:) withObject:param waitUntilDone:NO];
	
	[pool release];
}

extern "C" void setStatusBarOrientation(int orient)
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	UIDeviceOrientation orientation;
		
	switch (orient)
	{
		case ORIENTATION_PORTRAIT:
		default:
			orientation = UIDeviceOrientationPortrait;
			break;
		case ORIENTATION_LANDSCAPE_90:
			orientation = UIDeviceOrientationLandscapeRight;
			break;
		case ORIENTATION_LANDSCAPE_270:
			orientation = UIDeviceOrientationLandscapeLeft;
			break;
	}
	
	g_sharedInstanceUIApplication.statusBarOrientation = (UIInterfaceOrientation) orientation;
	
	[pool release];
}

NSString* txt_lang;
NSString* txt_ok;
NSString* txt_conn_err;

extern void _ConvertUnicodeToUTF8(char* dst, const unsigned short* src);

extern "C" void EnterTwitter(unsigned short *lang, unsigned short *ok, unsigned short *conn_err)
{
	char szTmpUTF8[1024];
	
	[txt_lang release];
	_ConvertUnicodeToUTF8(szTmpUTF8, lang);
	txt_lang = [[NSString alloc] initWithUTF8String:szTmpUTF8];

	[txt_ok release];
	_ConvertUnicodeToUTF8(szTmpUTF8, ok);
	txt_ok = [[NSString alloc] initWithUTF8String:szTmpUTF8];

	[txt_conn_err release];
	_ConvertUnicodeToUTF8(szTmpUTF8, conn_err);
	txt_conn_err = [[NSString alloc] initWithUTF8String:szTmpUTF8];

	[g_sharedInstanceAppController entertwitter];
}

extern "C" bool reloadSounds()
{
	NSString* firmware = [[UIDevice currentDevice] systemVersion];
	NSString* major = [firmware substringToIndex:1];
	int sdkMajorVal = [major intValue];
	//NSLog(@"Major val %d\n\n", sdkMajorVal);
	
	if (sdkMajorVal >= 3)
		return true;
	else
		return false;
}

extern "C" int GetFreeMemory()
{
	mach_port_t host_port;
	mach_msg_type_number_t host_size;
	vm_size_t pagesize;
	host_port = mach_host_self();
	host_size = sizeof(vm_statistics_data_t) / sizeof(integer_t);
	host_page_size(host_port, &pagesize);
	vm_statistics_data_t vm_stat;
	if (host_statistics(host_port, HOST_VM_INFO, (host_info_t)&vm_stat, &host_size) != KERN_SUCCESS) 
	{
	}
	// Stats in bytes 
	natural_t mem_free = vm_stat.free_count * pagesize;
	
	return mem_free;
}

extern "C" int GetUsedMemory()
{
	struct task_basic_info info;
	mach_msg_type_number_t size = sizeof(info);
	kern_return_t kerr = task_info(mach_task_self(),
		TASK_BASIC_INFO,
		(task_info_t)&info,
		&size);

	if( kerr == KERN_SUCCESS ) {
		//NSLog(@"Memory in use (in bytes): %u", info.resident_size);
		return info.resident_size;
	} else {
		//NSLog(@"Error with task_info(): %s", mach_error_string(kerr));
		return -1;
	}
}
*/