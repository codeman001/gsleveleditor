﻿////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

// x4 IGP
#include "storekit/CStoreFacade.h"
#include "storekit/CNetworkChecker.h"
//#include "../../GX_Device.h"
#import "AppController.h"
#include "Application.h"
////////////////////////////////////////////////////////////////////////////////////////////////////

CStoreFacade * g_store= NULL;
bool g_bEnableStore;
//bool g_bIsApplicationValidatingFirst = false;
//bool g_bIsApplicationValidatingSecond = false;
extern int g_fullVersionIsAvailableHasChanged;
extern bool g_fullVersionIsAvailable;
extern bool g_bCanStartServerDialog;
extern int languageSelectedNumber;
extern UIAlertView *_IAPalert;
extern char* gc_fullBundleID;
extern bool g_bAlertWasDisplayed;
extern UIActivityIndicatorView*		_activityStore;
extern int g_alertLanguage;
extern bool g_bMustRestartBuyProcess;
extern int g_bMustRestartBuyProcessCnt;
extern bool g_bDoNotDisplaySecondAlert;
class AppController;
////////////////////////////////////////////////////////////////////////////////////////////////////

extern "C" void CreateStoreInstance()
{
	if (IsCurrentNetworkConnectionWIFI())
	{
		g_store = new CStoreFacade;
		g_bEnableStore = true;
	}
	else
	{
		g_store = NULL;
		g_bEnableStore = false;
	}
}

extern "C" bool UpdatePurchase(int dt)
{
	static int inapp_timeout = 0;
	
	if (_activityStore != nil  && !g_fullVersionIsAvailable && !g_bCanStartServerDialog)
	{
		inapp_timeout += dt;
		if (inapp_timeout >= 190000 && g_store->okToClear())
		{
			g_alertLanguage = Application::GetInstance()->m_nLanguage; 
			int msgIdx = 6;
			NSNumber* param = [[NSNumber alloc] initWithInt:msgIdx];
			[[AppController sharedInstance] performSelectorOnMainThread:@selector(showAlertMessage:) withObject:param waitUntilDone:NO];
			g_store->setNetworkError();
			if ( _activityStore != nil )
			{
				[_activityStore removeFromSuperview];
				[_activityStore release];
				_activityStore = nil;
			}
			g_fullVersionIsAvailableHasChanged = 1;
		}
	}
	else
	{
		inapp_timeout = 0;
	}

	
	if( g_store->getState() == CSTORE_FACADE_ENUMS::STATE_WAITING)
	{
		if( g_store->hasPendingTransaction() )
		{
			if( g_store->getPendingStoreItem() )
			{
				g_store->resumePendingTransaction("ServerResponse.info");
			}
			else
			{
				g_store->confirmTransationCompleted(false);
			}
		}
		
	}
	if( g_store->getState() == CSTORE_FACADE_ENUMS::STATE_WAITING_CONFIRM )
	{
		if(g_fullVersionIsAvailableHasChanged == 1)
		{
			g_store->confirmTransationCompleted(false);
		}
		else
		{
			g_store->confirmTransationCompleted();
		}	
	}
	if(g_bMustRestartBuyProcess && (g_bMustRestartBuyProcessCnt<=2))
	{
		g_bDoNotDisplaySecondAlert = true;
		languageSelectedNumber = Application::GetInstance()->m_nLanguage;
		if(!g_bEnableStore)
			return false;
		if ( g_fullVersionIsAvailableHasChanged == 1 || g_fullVersionIsAvailableHasChanged < 0 )
		{
			g_fullVersionIsAvailableHasChanged = 0;
			UNLOCK_DEBUG("UpdatePurchase 0\n");
			//g_store->confirmTransationCompleted();
			g_store->buy(gc_fullBundleID);
		}	
		g_bMustRestartBuyProcess = false;
	}
		
	
}
extern "C" bool CheckPreviousPurchase(int lang)
{
	languageSelectedNumber = lang;
	if(!g_bEnableStore)
		return false;
	if( g_store->hasPendingTransaction() )
	{
		g_store->resumePendingTransaction("ServerResponse.info");
	}
	else	
		return g_store->sendTransactionLink();
	return true;
}


extern "C" bool CheckValidationPreviousPurchase(int lang)
{
	languageSelectedNumber = lang;
	if(!g_bEnableStore)
		return false;
	
		if( g_store->hasPendingTransaction() )
	{
		g_store->resumePendingTransaction("ServerResponse.info");
	}
	else	
		g_store->sendValidationLink();
	return true;
}
extern "C" bool RestoreAllPreviuosPurchase(int lang)
{
	languageSelectedNumber = lang;
	if(!g_bEnableStore)
		return false;
	g_store->restoreAllTransactions();
}

////////////////////////////////////////////////////////////////////////////////////////////////////

extern "C" void DestroyStoreInstance()
{
	if(!g_bEnableStore)
		return;
	SAFE_DEL(g_store);
}
extern "C" void BuyStore(int lang)
{
	languageSelectedNumber = lang;
	if(!g_bEnableStore)
		return;
	g_bDoNotDisplaySecondAlert = false;
	//if ( g_fullVersionIsAvailableHasChanged == 1 || g_fullVersionIsAvailableHasChanged < 0 )
	//{
	//	g_fullVersionIsAvailableHasChanged = 0;
	//	UNLOCK_DEBUG("BuyStore 0\n");
		//g_store->confirmTransationCompleted();
	g_bAlertWasDisplayed = false;
		g_store->buy(gc_fullBundleID);
	//}
	
}
extern "C" bool checkSecurity()
{
	if(!g_bEnableStore)
		return false;
	if(g_store->checkSecurity() != 0)
		return false;
	return true;
}

extern "C" const char* GetPrice()
{
	
	if(!g_bEnableStore)
		return NULL;
	return g_store->price;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
extern "C" int getStoreState()
{
	if(!g_bEnableStore)
		return 0;
	return g_store->getState();
}

extern "C" int getQueuedTransationsCount()
{
	if (!g_bEnableStore)
		return 0;
		
	return g_store->getQueuedTransationsCount();
}

extern "C" void ShowValidationAlert(char* message)
{
	NSString* texts[1][9] = {
		{@"OK",@"OK",@"OK",@"Acep.",@"OK",@"Ok",@"Ok",@"확인",@"Ok"},
	};
	if(_IAPalert)
	{
		[_IAPalert dismissWithClickedButtonIndex:0 animated:YES];
	    [_IAPalert release];
		
	}
	_IAPalert = [[UIAlertView alloc] initWithTitle:@"" message:[[NSString alloc] initWithUTF8String:message] delegate:nil cancelButtonTitle:texts[0][0]otherButtonTitles:nil];
	[_IAPalert show];
}