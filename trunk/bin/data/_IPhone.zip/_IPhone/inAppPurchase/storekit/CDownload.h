#ifndef _CDOWNLOAD_H_
#define _CDOWNLOAD_H_
#import <UIKit/UIKit.h>
namespace CDOWNLOAD_ENUMS
{
	enum
	{
		STATE_ERROR = -1,
		STATE_WAITING,
		STATE_DOWNLOADING,
	};
	enum
	{
		ERROR_WRONG_USER = -6,
		ERROR_DL_NO_WIFI = -5,
		ERROR_DL_CANCEL = -4,
		ERROR_DL_OTHER = -3,
		ERROR_DL_DEST_FILE = -2,
		ERROR_DL_SRC_FILE = -1,
		ERROR_OK = 0,
	};
};

typedef void (*DownloadCallback) (int result, void* caller);

@interface CDownload:NSObject {
	int					m_status;
	int					m_error;
	long long			bytesReceived;
	NSURLResponse*		downloadResponse;
	NSMutableData*		receivedData;
	DownloadCallback	callback;
	void*				caller;
	FILE*				savefile;
	NSURLConnection*	m_connection;
}

-(void) cancel;
-(void) downloadFile:(char*)src to:(char*)dest;
-(long long) getDownloadSize;
-(long long) getDownloadedSize;
-(void) setCallback:(DownloadCallback)method from:(void*)sender;

@end
#endif