#import "CDownload.h"
#import "AppController.h"
#import <UIKit/UIKit.h>
#include "Store_defines.h"
#include "CNetworkChecker.h"


@implementation CDownload
extern UIActivityIndicatorView*		_activityStore;
extern void getApplicationPath(char *path); //Framework.m
extern bool g_fullVersionIsAvailable;
extern UIApplication* g_sharedAppInstance; 
extern UIAlertView *_myAlert;

extern int g_fullVersionIsAvailableHasChanged;
-(id) init
{
	self = [super init];
	downloadResponse = nil;
	m_connection = nil;
	return self;
}

-(void)dealloc
{
	if(downloadResponse != nil)
		[downloadResponse release];
	if(m_connection != nil)
		[m_connection release];
	[super dealloc];
}

-(void) cancel
{
	DEBUG_OUT_STORE(@"User cancelled download");
	if(savefile)
	{
		fseek(savefile, 0, SEEK_SET);
		fclose(savefile);
		savefile = 0;
	}
	[m_connection cancel];
	[m_connection release];
	m_connection = nil;
	m_status = CDOWNLOAD_ENUMS::STATE_ERROR;
	m_error = CDOWNLOAD_ENUMS::ERROR_DL_CANCEL;
	callback(m_error, caller);
}

-(void) downloadFile:(char*)src to:(char*)dest;
{
	//if(dest == nil )
	//{
	//	m_status = CDOWNLOAD_ENUMS::STATE_ERROR;
	//	m_error = CDOWNLOAD_ENUMS::ERROR_DL_DEST_FILE;
	//	callback(m_error, caller);
	//	return;
	//}
	if (!IsCurrentNetworkConnectionWIFI())
	{
		DEBUG_OUT_STORE(@"No WIFI to download");
		m_status = CDOWNLOAD_ENUMS::STATE_ERROR;
		m_error = CDOWNLOAD_ENUMS::ERROR_DL_NO_WIFI;
		callback(m_error, caller);
	}
	//Convert relative path to absolute
	//This should probably change so the caller send the absolute path
	char GLOBAL_FILE_PATH_APP[512];
	getApplicationPath(GLOBAL_FILE_PATH_APP);
	char destpath[512];
	strcpy(destpath, GLOBAL_FILE_PATH_APP);
	strcat(destpath, "/../Documents/Security.test");
	//strcat(destpath, dest);
	
	//Open dest file in write mode
	savefile = fopen(destpath,"wb");
	if(!savefile)
	{
		printf("Error saving file %s\n", destpath);
		m_status = CDOWNLOAD_ENUMS::STATE_ERROR;
		m_error = CDOWNLOAD_ENUMS::ERROR_DL_DEST_FILE;
		callback(m_error, caller);
		return;
	}
	
	//Create url to src file
	NSURL *url = [[NSURL alloc]initWithString:[NSString stringWithUTF8String:src]];
	NSURLRequest * myURLRequest = [[NSURLRequest alloc] initWithURL: url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:60.0];
	m_connection = [[NSURLConnection alloc] initWithRequest:myURLRequest delegate:self startImmediately:YES];
	
	DEBUG_OUT_STORE(@"\nStart download\n");
	
	[myURLRequest release];
	[url release];

	//Check if connection is valid
	if (m_connection)
	{
		DEBUG_OUT_STORE(@"\nStart download m_connection\n");
		
		m_status = CDOWNLOAD_ENUMS::STATE_DOWNLOADING;
		m_error = CDOWNLOAD_ENUMS::ERROR_OK;
	}
	else
	{
		DEBUG_OUT_STORE(@"\nStart download !m_connection\n");
		
		//[[AppController sharedInstance] window].userInteractionEnabled = YES;
		if ( _activityStore != nil )
		{
			[_activityStore removeFromSuperview];
			[_activityStore release];
			_activityStore = nil;
		}
		m_connection = nil;
		m_status = CDOWNLOAD_ENUMS::STATE_ERROR;
		m_error = CDOWNLOAD_ENUMS::ERROR_DL_SRC_FILE;
		callback(m_error, caller);
	}
}

-(void) setCallback:(DownloadCallback)method from:(void*)sender
{
	callback = method;
	caller =  sender;
}

- (void)setDownloadResponse:(NSURLResponse *)aDownloadResponse
{
    [aDownloadResponse retain];
	if(downloadResponse != nil)
		[downloadResponse release];
    downloadResponse = aDownloadResponse;
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    bytesReceived = 0;
	[self setDownloadResponse:response];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    bytesReceived += [data length];

	//Get raw data
	char* receivedBytes = (char*)[data bytes];
	int nbbytes = [data length];
	//Write directly to file to clear ram asap
	int br = fwrite(receivedBytes, nbbytes ,sizeof(char), savefile);
	
	UIDevice *device = [UIDevice currentDevice];
	NSString *uniqueIdentifier = [device uniqueIdentifier];
	char *res = strstr(receivedBytes, "OK");
	if (!res)
	{
		m_error = CDOWNLOAD_ENUMS::ERROR_WRONG_USER;
		UNLOCK_DEBUG("didReceiveData 1\n");
		DEBUG_OUT_STORE(@"\nconnection didReceiveData: !res\n");
		g_fullVersionIsAvailable = false;
	}
	else
		g_fullVersionIsAvailable = true;
	
	char *res1 = strstr(receivedBytes, [uniqueIdentifier cStringUsingEncoding:[NSString defaultCStringEncoding]]);
	//char *res2 = strstr([uniqueIdentifier cStringUsingEncoding:[NSString defaultCStringEncoding]], receivedBytes);
	if (!res1)
	{
		m_error = CDOWNLOAD_ENUMS::ERROR_WRONG_USER;
		UNLOCK_DEBUG("didReceiveData 2\n");
		DEBUG_OUT_STORE(@"\nconnection didReceiveData: !res1\n");
		g_fullVersionIsAvailable = false;
	}
	else
		g_fullVersionIsAvailable = true;
	
	[[AppController sharedInstance] performSelectorOnMainThread:@selector(dismissAlertMessage:) withObject:nil waitUntilDone:NO];

	if(br != sizeof(char))
	{
		DEBUG_OUT_STORE(@"Error while writing to file\n");
		fseek(savefile, 0, SEEK_SET);
		fclose(savefile);
		savefile = 0;
		[m_connection cancel];
		[m_connection release];
		m_connection = nil;
		m_status = CDOWNLOAD_ENUMS::STATE_ERROR;
		m_error = CDOWNLOAD_ENUMS::ERROR_DL_DEST_FILE;
		if ( _activityStore != nil )
		{
			[_activityStore removeFromSuperview];
			[_activityStore release];
			_activityStore = nil;
		}
		callback(m_error, caller);
	}
	
	if (m_error == CDOWNLOAD_ENUMS::ERROR_WRONG_USER)
	{
		DEBUG_OUT_STORE(@"\nconnection didReceiveData: m_error == CDOWNLOAD_ENUMS::ERROR_WRONG_USER\n");
		
		[m_connection cancel];
		[m_connection release];
		m_connection = nil;
		
		if ( _activityStore != nil )
		{
			[_activityStore removeFromSuperview];
			[_activityStore release];
			_activityStore = nil;
		}
		
		callback(m_error, caller);
	}
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	DEBUG_OUT_STORE(@"\nError download : %@\n", [error localizedDescription]);
	if(savefile)
	{
		fseek(savefile, 0, SEEK_SET);
		fclose(savefile);
		savefile = 0;
	}
	g_fullVersionIsAvailableHasChanged = 2;
	UNLOCK_DEBUG("didFailWithError - g_fullVersionIsAvailableHasChanged 2\n");
	//[[AppController sharedInstance] window].userInteractionEnabled = YES;
	if ( _activityStore != nil )
	{
		[_activityStore removeFromSuperview];
		[_activityStore release];
		_activityStore = nil;
	}
	
		
    [m_connection release];
	m_connection = nil;
	m_status = CDOWNLOAD_ENUMS::STATE_ERROR;
	m_error = CDOWNLOAD_ENUMS::ERROR_DL_OTHER;
	callback(m_error, caller);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	DEBUG_OUT_STORE(@"\nEnd download : %d bytes\n", bytesReceived);
	fclose(savefile);
	savefile = 0;
	g_fullVersionIsAvailableHasChanged = 2;
	UNLOCK_DEBUG("connection - g_fullVersionIsAvailableHasChanged 2\n");
	[m_connection release];//? not sure it's needed
	m_connection = nil;
	//[[AppController sharedInstance] window].userInteractionEnabled = YES;
	if ( _activityStore != nil )
	{
		[_activityStore removeFromSuperview];
		[_activityStore release];
		_activityStore = nil;
	}
	
	m_status = CDOWNLOAD_ENUMS::STATE_WAITING;
	m_error = CDOWNLOAD_ENUMS::ERROR_OK;
	//Call callback from original caller
	callback(m_error, caller);
}

-(long long) getDownloadSize
{
	return downloadResponse.expectedContentLength; 
}

-(long long) getDownloadedSize
{
	return bytesReceived; 
}

@end