#ifndef _CNETWORKCHECKER_H_
#define _CNETWORKCHECKER_H_

bool IsCurrentNetworkConnectionWIFI();

#endif