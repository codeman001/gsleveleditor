#include "CNetworkChecker.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import <netinet/in.h>

bool IsCurrentNetworkConnectionWIFI()
{
	struct sockaddr_in zeroAddr;
	bzero(&zeroAddr, sizeof(zeroAddr));
	zeroAddr.sin_len = sizeof(zeroAddr);
	zeroAddr.sin_family = AF_INET;
	
	// Part 2- Create target in format need by SCNetwork
	SCNetworkReachabilityRef target = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *) &zeroAddr);
	
	// Part 3 - Get the flags
	SCNetworkReachabilityFlags flags;
	SCNetworkReachabilityGetFlags(target, &flags);
	//ceg - to be checked
	CFRelease(target);
	
	return  (((flags & kSCNetworkFlagsReachable) || (flags & kSCNetworkReachabilityFlagsIsWWAN)) 
	&& !(flags & kSCNetworkFlagsConnectionRequired))
	
	
	/*&& !(flags & kSCNetworkReachabilityFlagsIsWWAN)*/;	
	//BOOL isReachable = flags & kSCNetworkFlagsReachable;
    //BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
    //BOOL nonWiFi = flags & kSCNetworkReachabilityFlagsTransientConnection;

    //return (((flags & kSCNetworkFlagsReachable) && !(flags & kSCNetworkFlagsConnectionRequired)) || (flags & kSCNetworkReachabilityFlagsTransientConnection));


}