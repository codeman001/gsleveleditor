#ifndef _CSTORE_H_
#define _CSTORE_H_

#import <StoreKit/StoreKit.h>


typedef void (*StoreProductCallback) (SKProduct* product, void* caller);

@interface CStore:NSObject <SKProductsRequestDelegate> {
	int bidon;
	StoreProductCallback m_callback;
	void* m_caller;
	SKProductsRequest* m_request;
	SKProduct* m_prod;
}

- (void) requestProductData;
- (void) productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response;
- (void) cancelProductsRequest;
- (void) buy:(NSString*)content;
- (void) setCallback:(StoreProductCallback)method from:(void*)sender;

@end
#endif