﻿#import "CStore.h"
#include "Store_defines.h"
#import "AppController.h"
#import <UIKit/UIKit.h>
extern int languageSelectedNumber;
extern UIAlertView *_myAlert;
extern char* gc_fullBundleID;
extern UIActivityIndicatorView*		_activityStore;
extern int g_fullVersionIsAvailableHasChanged;
extern int g_alertLanguage;
bool g_bReceivedResponse;
extern bool g_bMustRestartBuyProcess;
extern int g_bMustRestartBuyProcessCnt;
extern bool g_bDoNotDisplaySecondAlert;
@implementation CStore

-(id) alloc
{
	self = [super init];
	m_request = nil;
	m_prod = nil;
	g_bReceivedResponse = false;	
	return self;
	
}

- (void) dealloc
{
	[self cancelProductsRequest];
	[super dealloc];
}
- (void) requestProductData
{
	//NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];

	g_bReceivedResponse = false;
	m_request = [[SKProductsRequest alloc] initWithProductIdentifiers: [NSSet setWithObject: [[NSString alloc] initWithUTF8String:gc_fullBundleID]]];
	m_request.delegate = self;
	[m_request start];
	//[pool release];
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response
{
	//NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
    NSArray *myProduct = response.products;
	[m_prod release];
	DEBUG_OUT_STORE(@"Product found :\n");
	g_bReceivedResponse = true;
	if ([myProduct count] == 0)
	{
		DEBUG_OUT_STORE(@"none\n");
	}
	else
	{
		for(int i = 0; i < [myProduct count]; i++)
		{
			SKProduct *prod = [myProduct objectAtIndex:(i)];
			
			DEBUG_OUT_STORE(prod.productIdentifier);
			DEBUG_OUT_STORE(@"price %@", prod.price);
			m_prod = prod;
			[m_prod retain];
			m_callback(prod, m_caller);
		}
	}
	NSArray *myInvProduct = response.invalidProductIdentifiers;
	DEBUG_OUT_STORE(@"Product not found :\n");
	if ([myInvProduct count] == 0)
	{
		DEBUG_OUT_STORE(@"none\n");
	}
	else
	{
		for (int i = 0; i < [myInvProduct count]; i++)
		{
			DEBUG_OUT_STORE([myInvProduct objectAtIndex:(i)]);
		}
	}
	m_callback(0, m_caller);
	[m_request release];
	m_request = nil;
    // populate UI
	//[pool release];
}

- (void) buy:(NSString*)content
{
	//NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	if (g_bReceivedResponse)
	{
		DEBUG_OUT_STORE(@"Adding payment to the queue for %@", content);
		if (!g_bDoNotDisplaySecondAlert)
		{
			g_alertLanguage = languageSelectedNumber; 
			int msgIdx = 1;
			NSNumber* param = [[NSNumber alloc] initWithInt:msgIdx];
			[[AppController sharedInstance] performSelectorOnMainThread:@selector(showAlertMessage:) withObject:param waitUntilDone:NO];
			//g_bDoNotDisplaySecondAlert = false;
		}
		DEBUG_OUT_STORE(m_prod.productIdentifier);
		SKPayment *payment = [SKPayment paymentWithProduct: m_prod];
		if (m_prod!=nil)
		{
			[[SKPaymentQueue defaultQueue] addPayment:payment];
		}
		else
		{
			//g_alertLanguage = languageSelectedNumber; 
			//int msgIdx = 2;
			//NSNumber* param = [[NSNumber alloc] initWithInt:msgIdx];
			//[[AppController sharedInstance] performSelectorOnMainThread:@selector(showAlertMessage:) withObject:param waitUntilDone:NO];
			if ( _activityStore != nil )
			{
				[_activityStore removeFromSuperview];
				[_activityStore release];
				_activityStore = nil;
			}
			[self cancelProductsRequest];	
			[self requestProductData];
			g_fullVersionIsAvailableHasChanged = 1;
			UNLOCK_DEBUG("content 1 - g_fullVersionIsAvailableHasChanged 1\n");
		}
	}
	else
	{
		g_alertLanguage = languageSelectedNumber; 
		int msgIdx = 3;
		NSNumber* param = [[NSNumber alloc] initWithInt:msgIdx];
		[[AppController sharedInstance] performSelectorOnMainThread:@selector(showAlertMessage:) withObject:param waitUntilDone:NO];
		if ( _activityStore != nil )
		{
			[_activityStore removeFromSuperview];
			[_activityStore release];
			_activityStore = nil;
		}
		g_fullVersionIsAvailableHasChanged = 1;
		UNLOCK_DEBUG("content 2 - g_fullVersionIsAvailableHasChanged 1\n");
	}
	//[pool release];			
	//[m_request release];
	//m_request = nil;
}

- (void) setCallback:(StoreProductCallback)method from:(void*)sender
{
	m_callback = method;
	m_caller =  sender;	
}

- (void) cancelProductsRequest
{
	if(m_request != nil)
	{
		[m_request cancel];
		[m_request release];
		m_request = nil;
	}
}

@end