#ifndef _CSTORE_FACADE_H_
#define _CSTORE_FACADE_H_

#import "CDownload.h"
#import "CStore.h"
#import "CStoreObserver.h"
#include "IStoreFacade.h"
#import "StorekitLinkGrabber.h"



class CStoreFacade: public IStoreFacade
{
public:
	CStoreFacade();
	virtual ~CStoreFacade();
	
	virtual void init();
	virtual void checkStore();  
	void getProductData();
	
	virtual void downloadFile(char* src, char* dest);
	virtual int getState(){return m_state;}
	virtual int getError(){return m_error;}
	virtual void resetError(){m_state = CSTORE_FACADE_ENUMS::STATE_WAITING, m_error = CSTORE_FACADE_ENUMS::ERROR_OK;}
	virtual void buy(char* content);

	virtual const char* getPriceItem(){return price;}
	
	virtual bool hasPendingTransaction();
	virtual void resumePendingTransaction(char* dest);
	virtual int getPendingStoreItem();
	virtual long long getDownloadSize();
	virtual long long getDownloadedSize();
	virtual void confirmTransationCompleted(bool setState = true);
	virtual void restoreAllTransactions();

	virtual void cancelCurrentDownload();
	virtual bool sendTransactionLink();
	virtual bool sendValidationLink();
	virtual void setNetworkError();

	
	
	static void callbackDownload(int result, void* caller);
	static void callbackContentLink(char* contentLink, void* caller);
	static void callbackStoreObserver(SKPaymentTransaction *transaction, void* caller);
	static void callbackStoreProduct(SKProduct* product, void* caller);
	bool checkSecurity();
	
	static bool checkWifiNoMessage();
	//static bool showPirateMessage();

	int getQueuedTransationsCount();
	void clearQueuedTransations();
	bool okToClear();

private:
	void updateStoreItem(SKProduct* product);
	void freeDownload();	
	void downloadFile(char* src);
	void requestContentLink(SKPaymentTransaction *transaction);
	void requestResumedContentLink(SKPaymentTransaction *transaction);
	
	void setError(int errorCode);
	void processPushRegisterResponse(char* result);
	bool checkWifi();
	
	int m_state;
	int m_error;
	CDownload* m_currentDL;
	char* m_dlDestination;
	StorekitLinkGrabber* m_request;
	CStore* m_store;
	CStoreObserver* m_storeObserver;
	NSData* m_deviceToken;
public:
	char* price;
};

#endif