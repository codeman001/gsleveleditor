﻿#include "CStoreFacade.h"
#include "Store_defines.h"
//#include "../../Sources/Defs.h" //Only needed for gll_new/SAFE_DEL
//#include "../../../GX_Device.h"
#import "StorekitLinkGrabber.h"
#import "CStoreObserver.h"
#include "base64.h"
#include "CNetworkChecker.h"
#import "AppController.h"

extern void getApplicationPath(char *path); //Framework.m
extern bool g_fullVersionIsAvailable;
extern bool g_bShowPirateMessage;
extern int g_fullVersionIsAvailableHasChanged;
extern bool g_bAlertWasDisplayed;

extern bool g_bIsApplicationValidatingFirst;
extern bool g_bIsApplicationValidatingSecond;
extern UIApplication* g_sharedAppInstance; 
UIActivityIndicatorView*		_activityStore;
UIAlertView *_myAlert = nil;
extern int languageSelectedNumber;
extern int g_alertLanguage;



CStoreFacade::CStoreFacade()
{
	m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
	m_error = CSTORE_FACADE_ENUMS::ERROR_OK;
	m_dlDestination = 0;
	m_request = nil;
	m_deviceToken = nil;
	init();
	m_storeObserver = [[CStoreObserver alloc] init];
	[m_storeObserver setCallback:&CStoreFacade::callbackStoreObserver from:(void*)this];
	[[SKPaymentQueue defaultQueue] addTransactionObserver:m_storeObserver];
}

CStoreFacade::~CStoreFacade()
{
	SAFE_DEL_ARRAY(price);
	if(m_request != nil)
		[m_request release];	
	if(m_deviceToken != nil)
	{
		[m_deviceToken release];
		m_deviceToken = nil;
	}
	[m_store release];
	[[SKPaymentQueue defaultQueue] removeTransactionObserver:m_storeObserver];
	[m_storeObserver release];
	[_myAlert release];
	_myAlert = nil;
}

void CStoreFacade::init()
{
	m_state = CSTORE_FACADE_ENUMS::STATE_INIT;

	m_store = [[CStore alloc]init];
	[m_store cancelProductsRequest];

	[m_store setCallback:&CStoreFacade::callbackStoreProduct from:(void*)this];

	[m_store requestProductData];
}

void CStoreFacade::getProductData()
{
	[m_store cancelProductsRequest];
	
	[m_store setCallback:&CStoreFacade::callbackStoreProduct from:(void*)this];
	[m_store requestProductData];
}

void CStoreFacade:: buy(char* content)
{
	if(!checkWifi())
	{
		return;
	}	
	//m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
	if ( _activityStore != nil )
	{
		[_activityStore removeFromSuperview];
		[_activityStore release];
		_activityStore = nil;
	}
	
	_activityStore	= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	
   //[[AppController sharedInstance] window].userInteractionEnabled = NO;
   [_activityStore startAnimating];
   [_activityStore setAlpha:1.0];
   [[[AppController sharedInstance] window] addSubview:_activityStore];
    m_state = CSTORE_FACADE_ENUMS::STATE_PROCESSING_PAYMENT;    
	
	//Bogdan - test - this would help with handling a transaction complete event
	//Bogdan -	- from a transaction that was finished while the app was closed
	//if (content)
	{
		//SAFE_DEL_ARRAY(m_dlDestination);
		NSString* str = [[NSString alloc] initWithBytes:content length:strlen(content) encoding:NSASCIIStringEncoding];
	
		[m_store buy:str];	
		[str release];
		//str = nil;
	}
}

void CStoreFacade::resumePendingTransaction(char* dest)
{
	if(!checkWifi())
	{
		return;
	}	
	if(![m_storeObserver hasPendingTransaction])
		return;
	
	SKPaymentTransaction* pendingTransaction = [m_storeObserver getCurrentTransaction];	
	m_state = CSTORE_FACADE_ENUMS::STATE_PROCESSING_PAYMENT;
	SAFE_DEL_ARRAY(m_dlDestination);
	m_dlDestination = NEW char[strlen(dest) + 1];
	strcpy(m_dlDestination, dest);
	
	DEBUG_OUT_STORE(@"Request to resume %@ to %s", pendingTransaction.payment.productIdentifier, m_dlDestination);
	requestResumedContentLink(pendingTransaction);
}

void CStoreFacade::downloadFile(char* src, char* dest)
{
	if(!checkWifi())
	{
		return;
	}	
	m_state = CSTORE_FACADE_ENUMS::STATE_DOWNLOADING;
	m_currentDL = [[CDownload alloc]init];
	[m_currentDL setCallback:&CStoreFacade::callbackDownload from:(void*)this];
	[m_currentDL downloadFile:src to:dest];
}

void CStoreFacade::downloadFile(char* src)
{
	if(!checkWifi())
	{
		return;
	}	
	m_state = CSTORE_FACADE_ENUMS::STATE_DOWNLOADING;
	m_currentDL = [[CDownload alloc]init];
	[m_currentDL setCallback:&CStoreFacade::callbackDownload from:(void*)this];
	[m_currentDL downloadFile:src to:m_dlDestination];
}

void  CStoreFacade::cancelCurrentDownload()
{
	if(m_currentDL != nil)
	{
		[m_currentDL cancel];
		freeDownload();
		g_fullVersionIsAvailableHasChanged = 1;
		UNLOCK_DEBUG("cancelCurrentDownload - g_fullVersionIsAvailableHasChanged 1\n");
		m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
	}
	if ( _activityStore != nil )
	{
		[_activityStore removeFromSuperview];
		[_activityStore release];
		_activityStore = nil;
	}
}

void CStoreFacade::freeDownload()
{
	if(m_dlDestination)
	{
		SAFE_DEL_ARRAY(m_dlDestination);
		m_state = CSTORE_FACADE_ENUMS::STATE_WAITING_CONFIRM;
	}
	else
	{
		m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
	}
	[m_currentDL release];
	m_currentDL = nil;
}

void CStoreFacade::requestContentLink(SKPaymentTransaction *transaction) //call from callback
{
	DEBUG_OUT_STORE(@"CStoreFacade::requestContentLink\n");
	
	if (transaction.error != nil)
	{
		if (transaction.error.code != SKErrorPaymentCancelled)
		{
			m_state = CSTORE_FACADE_ENUMS::STATE_ERROR;
			m_error = CSTORE_FACADE_ENUMS::ERROR_PAYMENT;
		}
		else
		{
			m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
		}
		if ( _activityStore != nil )
		{
			[_activityStore removeFromSuperview];
			[_activityStore release];
			_activityStore = nil;
		}
		return;
	}
	if (transaction.originalTransaction == nil && m_state == CSTORE_FACADE_ENUMS::STATE_PROCESSING_PAYMENT)//Don't change state for a restored transaction
	{
		DEBUG_OUT_STORE(@"CStoreFacade::requestContentLink transaction.originalTransaction == nil\n");
		
		//No destination leave the transaction pending to be resume when app is ready
		m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
		return;
	}
	if (g_bIsApplicationValidatingSecond)
	{
		DEBUG_OUT_STORE(@"CStoreFacade::requestContentLink g_bIsApplicationValidatingSecond\n");
		
		g_bIsApplicationValidatingSecond = false;
		m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
		UIDevice *device = [UIDevice currentDevice];
		NSString *uniqueIdentifier = [device uniqueIdentifier];
		if (m_request != nil)
			[m_request release];
		m_request = [[StorekitLinkGrabber alloc]init];
		[m_request getContentLink:callbackContentLink from:(void*)this withDeviceId:uniqueIdentifier withData:transaction.transactionReceipt];
	}
}

void CStoreFacade::requestResumedContentLink(SKPaymentTransaction *transaction)
{
	DEBUG_OUT_STORE(@"CStoreFacade::requestResumedContentLink\n");
	
	if(!checkWifi())
	{
		return;
	}

	if(transaction.error != nil) //Should not happen since failed transaction are not queued
	{
		if (transaction.error.code != SKErrorPaymentCancelled)
		{
			m_state = CSTORE_FACADE_ENUMS::STATE_ERROR;
			m_error = CSTORE_FACADE_ENUMS::ERROR_PAYMENT;
		}
		else
		{
			m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
		}
		if ( _activityStore != nil )
		{
			[_activityStore removeFromSuperview];
			[_activityStore release];
			_activityStore = nil;
		}
		return;
	}
	if(m_dlDestination == 0)//Need a destination for dl
	{
		m_state = CSTORE_FACADE_ENUMS::STATE_ERROR;
		m_error = CSTORE_FACADE_ENUMS::ERROR_DL_DEST_FILE;
		return;
	}
	UIDevice *device = [UIDevice currentDevice];
	NSString *uniqueIdentifier = [device uniqueIdentifier];
	if(m_request != nil)
		[m_request release];	
	m_request = [[StorekitLinkGrabber alloc]init];
	[m_request getContentLink:callbackContentLink from:(void*)this withDeviceId:uniqueIdentifier withData:transaction.transactionReceipt];	
}

void CStoreFacade::updateStoreItem(SKProduct* product)
{
	DEBUG_OUT_STORE(@"CStoreFacade::updateStoreItem\n");
	
	NSSet* localeCC = [[NSSet alloc] initWithObjects:@"AU",@"CA",@"DK",@"JP",@"MX",@"NZ",@"NO",@"SE",@"CH",@"GB",@"US",nil];
	NSSet* USCC = [[NSSet alloc] initWithObjects:@"AR",@"BR",@"CL",@"CN",@"CO",@"CR",@"HR",@"DO",@"EC",@"EG",@"SV",@"GT",@"HN",@"HK",@"IN",@"ID",@"IL",@"JM",@"KZ",@"KR",@"KW",@"LB",@"MO",@"MY",@"MD",@"NI",@"PK",@"PA",@"PY",@"PE",@"PH",@"QA",@"RU",@"SA",@"SG",@"ZA",@"LK",@"TW",@"TH",@"TR",@"AE",@"UY",@"VE",@"VN",@"US",nil];
	NSSet* EuroCC = [[NSSet alloc] initWithObjects:@"AT",@"BE",@"CZ",@"EE",@"FI",@"FR",@"DE",@"GR",@"HU",@"IE",@"IT",@"LV",@"LT",@"LU",@"MT",@"NL",@"PL",@"PT",@"RO",@"SK",@"SI",@"ES",nil];
	const char* str = [product.productIdentifier UTF8String];
	//for(int i = 0; i < m_storeItemsSize; i++)
	{
		//if(strcmp(str, m_storeItems[i].uid) == 0)
		{
			//Get name
			
			//Get price
			NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
			[numberFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
			[numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
			NSString *formattedString;
			NSArray * locInfo = [[product.priceLocale localeIdentifier] componentsSeparatedByString:@"_"];
			NSArray * locInfo2 = [[locInfo objectAtIndex:([locInfo count] - 1)] componentsSeparatedByString:@"@"];
			if([localeCC member:[locInfo2 objectAtIndex:(0)]] != nil)
			{
				DEBUG_OUT_STORE(@"Local currency : %@", [product.priceLocale localeIdentifier]);
				[numberFormatter setLocale:product.priceLocale];
				formattedString = [numberFormatter stringFromNumber:product.price];
			}
			else if([EuroCC member:[locInfo2 objectAtIndex:(0)]] != nil)
			{
				DEBUG_OUT_STORE(@"Euro currency : %@", [product.priceLocale localeIdentifier]);
				NSLocale* loc = [[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"];
				[numberFormatter setLocale:loc];
				formattedString = [numberFormatter stringFromNumber:product.price];
				[loc release];
			}
			else if([USCC member:[locInfo2 objectAtIndex:(0)]] != nil)
			{
				DEBUG_OUT_STORE(@"US currency : %@", [product.priceLocale localeIdentifier]);
				NSLocale* loc = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
				[numberFormatter setLocale:loc];
				formattedString = [numberFormatter stringFromNumber:product.price];
				[loc release];
			}
			else
			{
				DEBUG_OUT_STORE(@"Invalid country code : %@", [product.priceLocale localeIdentifier]);
				formattedString = [NSString stringWithString:@""];
			}
			
			//const unsigned short* s = (unsigned short*)([formattedString cStringUsingEncoding:NSUTF8StringEncoding]);
			//DEBUG_OUT_STORE(@"s : %s", s);			
			SAFE_DEL_ARRAY(price);
			price =  NEW char[strlen([formattedString UTF8String] )+1];
			strcpy(price, [formattedString UTF8String]);
			
		
			[numberFormatter release];
			[localeCC release];
			[EuroCC release];
			[USCC release];
			
			//DEBUG_OUT_STORE(@"Store Item info\nName : %suid : %s\nDescription : %s\nPrice : %S\n", m_storeItems[i].name, m_storeItems[i].uid, m_storeItems[i].description, m_storeItems[i].price);
			//break;
		}
	}
	
}

bool CStoreFacade::sendTransactionLink()
{
	DEBUG_OUT_STORE(@"CStoreFacade::sendTransactionLink\n");
	
	UIDevice *device = [UIDevice currentDevice];
	NSString *uniqueIdentifier = [device uniqueIdentifier];
	
	char GLOBAL_FILE_PATH_APP[1024];
    getApplicationPath(GLOBAL_FILE_PATH_APP);
    char destpath[1024];
    strcpy(destpath, GLOBAL_FILE_PATH_APP);
    strcat(destpath, "/../Documents/_Items.info");
	FILE	*	pFile;
	
	int size, receiptSize;
	pFile = fopen(destpath, "rb");
	if (!pFile)
	{
		
		g_bShowPirateMessage = true;
		g_fullVersionIsAvailable = false;
		UNLOCK_DEBUG("sendTransactionLink 1\n");
		return false;	
	}
	fread(&size, sizeof(int), 1, pFile);
	
	char*	readUniqueIdentifier = NEW char[size];
	fread(readUniqueIdentifier, sizeof(char), size, pFile);
	if(strcmp(	readUniqueIdentifier, [uniqueIdentifier cStringUsingEncoding:[NSString defaultCStringEncoding]])!=0)
	{
		
		g_bShowPirateMessage = true;
		g_fullVersionIsAvailable = false;
		UNLOCK_DEBUG("sendTransactionLink 2\n");
		return false;
	}
	fread(&receiptSize, sizeof(int), 1, pFile);		
	Byte* byteData = NEW Byte[receiptSize];
	
	fread(byteData, 1, (int)receiptSize, pFile);
	fclose(pFile);
	
	NSData * receiptData = [NSData dataWithBytes:byteData length:receiptSize];
	
	//ceg RTS
	if(!checkWifi())
	{
		return true;
	}
//	[m_store cancelProductsRequest];
//	[m_store requestProductData];
	//end CEG RTS
	
	if(m_request != nil)
		[m_request release];	
	m_request = [[StorekitLinkGrabber alloc]init];
	[m_request getContentLink:callbackContentLink from:(void*)this withDeviceId:uniqueIdentifier withData:receiptData];
	
	DEBUG_OUT_STORE(@"CStoreFacade::sendTransactionLink DONE\n");
	return true;
}
bool CStoreFacade::sendValidationLink()
{
	DEBUG_OUT_STORE(@"CStoreFacade::sendValidationLink\n");
	
	UIDevice *device = [UIDevice currentDevice];
	NSString *uniqueIdentifier = [device uniqueIdentifier];
	
	char GLOBAL_FILE_PATH_APP[1024];
    getApplicationPath(GLOBAL_FILE_PATH_APP);
    char destpath[1024];
    strcpy(destpath, GLOBAL_FILE_PATH_APP);
    strcat(destpath, "/../Documents/_Items.info");
	FILE	*	pFile;
	
	int size, receiptSize;
	pFile = fopen(destpath, "rb");
	if (!pFile)
	{
		g_bShowPirateMessage = true;
		g_fullVersionIsAvailable = false;
		UNLOCK_DEBUG("sendValidationLink 1\n");
		return false;	
	}
	fread(&size, sizeof(int), 1, pFile);
	
	char*	readUniqueIdentifier = NEW char[size];
	fread(readUniqueIdentifier, sizeof(char), size, pFile);
	if(strcmp(	readUniqueIdentifier, [uniqueIdentifier cStringUsingEncoding:[NSString defaultCStringEncoding]])!=0)
	{
		g_bShowPirateMessage = true;
		g_fullVersionIsAvailable = false;
		UNLOCK_DEBUG("sendValidationLink 2\n");
		return false;
	}
	fread(&receiptSize, sizeof(int), 1, pFile);		Byte* byteData = NEW Byte[receiptSize];
	
	fread(byteData, 1, (int)receiptSize, pFile);
	fclose(pFile);
	
	NSData * receiptData = [NSData dataWithBytes:byteData length:receiptSize];
	if(!checkWifi())
	{
		return false;
	}
	
	if(m_request != nil)
		[m_request release];	
	m_request = [[StorekitLinkGrabber alloc]init];
	[m_request getValidationLink:callbackContentLink from:(void*)this withDeviceId:uniqueIdentifier withData:receiptData];		
	return true;
}

long long CStoreFacade::getDownloadSize()
{
	if(m_currentDL != nil)
		return [m_currentDL getDownloadSize];
	else
		return -1;
}

long long CStoreFacade::getDownloadedSize()
{
	if(m_currentDL != nil)
		return [m_currentDL getDownloadedSize];
	else
		return -1;
}

void  CStoreFacade::confirmTransationCompleted(bool setState /*= true*/)
{
	int count = getPendingStoreItem();
	[m_storeObserver confirmTransactionCompleted];
	m_state = CSTORE_FACADE_ENUMS::STATE_WAITING;
}

int CStoreFacade::getPendingStoreItem()
{
	if(![m_storeObserver hasPendingTransaction])
		return 0;
	
	SKPaymentTransaction* pendingTransaction = [m_storeObserver getCurrentTransaction];
	const char* cstr = [pendingTransaction.payment.productIdentifier UTF8String];
	DEBUG_OUT_STORE(@"Getting pending item %s from store\n", cstr);
	
	return 1;
}

bool CStoreFacade::hasPendingTransaction()
{
	return [m_storeObserver hasPendingTransaction];
}

void CStoreFacade::restoreAllTransactions()
{
	if(!checkWifi())
	{
		return;
	}	
	//g_bIsApplicationValidating = false;
	[[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}

int CStoreFacade::getQueuedTransationsCount()
{
	NSArray* transArray = [[SKPaymentQueue defaultQueue] transactions];
	if (!transArray)
		return 0;
	return [transArray count];
}

bool CStoreFacade::okToClear()
{
	NSArray* transArray = [[SKPaymentQueue defaultQueue] transactions];
	
	if (!transArray)
		return true;
	
	for (SKPaymentTransaction *transaction in transArray)
	{
		if (transaction.transactionState == SKPaymentTransactionStatePurchasing)
			return false;
	}
	
	return true;
}

void CStoreFacade::clearQueuedTransations()
{
	NSArray* transArray = [[SKPaymentQueue defaultQueue] transactions];
	if (!transArray)
		return;
	for (SKPaymentTransaction *transaction in transArray)
	{
		[[SKPaymentQueue defaultQueue] finishTransaction: transaction];	
	}
}

void CStoreFacade::setError(int errorCode)
{
	m_state = CSTORE_FACADE_ENUMS::STATE_ERROR;
	m_error = errorCode;
}

bool CStoreFacade::checkWifi()
{
NSString* texts[2][9] = {
{@"OK",@"OK",@"OK",@"Acep.",@"OK",@"Ok",@"Ok",@"확인",@"Ok"},
{@"You need an internet connection to buy this game.",@"Vous devez disposer d'une connexion Internet pour acheter ce jeu.",@"Du brauchst eine Internetverbindung, um dieses Spiel zu kaufen.",@"Necesitas una conexión a internet para comprar este juego.",@"Devi essere connesso a internet per comprare questo gioco.",@"このゲームを購入するにはインターネット接続が必要です。",@"Você precisa de uma conexão à internet para comprar este jogo.",@"이 게임을 구입하려면 인터넷 연결이 필요합니다",@"您需要接入互联网购买此游戏。"},
};
	if(!IsCurrentNetworkConnectionWIFI())
	{
		DEBUG_OUT_STORE(@"No WIFI");
		m_state = CSTORE_FACADE_ENUMS::STATE_ERROR;
		m_error = CSTORE_FACADE_ENUMS::ERROR_DL_NO_WIFI;
		if (!g_fullVersionIsAvailable)
		{
			g_fullVersionIsAvailableHasChanged = 1;
		}
		UNLOCK_DEBUG("checkWifi - g_fullVersionIsAvailableHasChanged 1\n");
		if(!g_bAlertWasDisplayed&& !g_fullVersionIsAvailable)
		{
			g_alertLanguage = languageSelectedNumber; 
			int msgIdx = 5;
			NSNumber* param = [[NSNumber alloc] initWithInt:msgIdx];
			[[AppController sharedInstance] performSelectorOnMainThread:@selector(showAlertMessage:) withObject:param waitUntilDone:NO];
			g_bAlertWasDisplayed = true;
		}
		return false;
	}
	
	return true;
}
bool CStoreFacade::checkWifiNoMessage()
{
	if(!IsCurrentNetworkConnectionWIFI())
	{
		return false;
	}
	return true;
}

bool CStoreFacade::checkSecurity()
{
	if(m_error != 0)
		return false;
	return true;
}
void CStoreFacade::checkStore()
{
	if(!(m_state == CSTORE_FACADE_ENUMS::STATE_ERROR && m_error == CSTORE_FACADE_ENUMS::ERROR_CONTENT_LIST_RETRIEVAL))
	{
		if(m_state == CSTORE_FACADE_ENUMS::STATE_ERROR)
		{
			m_state =  CSTORE_FACADE_ENUMS::STATE_WAITING;
			m_error = CSTORE_FACADE_ENUMS::ERROR_OK;
			if ( _activityStore != nil )
			{
				[_activityStore removeFromSuperview];
				[_activityStore release];
				_activityStore = nil;
			}
		}
		checkWifi();
	}
}

/*************** STATIC CALLBACK ****************/
void CStoreFacade::callbackDownload(int result, void* caller)
{
	DEBUG_OUT_STORE(@"download result %d\n", result);
	// TODO use caller to free CDownload object and change state
	((CStoreFacade*)caller)->freeDownload();

	switch(result)
	{
		case CDOWNLOAD_ENUMS::ERROR_DL_OTHER:
			((CStoreFacade*)caller)->setError(CSTORE_FACADE_ENUMS::ERROR_DL_OTHER);
			g_fullVersionIsAvailableHasChanged = 1;
			((CStoreFacade*)caller)->clearQueuedTransations();
			UNLOCK_DEBUG("callbackDownload 1 - g_fullVersionIsAvailableHasChanged 1\n");
			break;
		case CDOWNLOAD_ENUMS::ERROR_DL_SRC_FILE:
			((CStoreFacade*)caller)->setError(CSTORE_FACADE_ENUMS::ERROR_DL_SRC_FILE);
			g_fullVersionIsAvailableHasChanged = 1;
			((CStoreFacade*)caller)->clearQueuedTransations();
			UNLOCK_DEBUG("callbackDownload 2 - g_fullVersionIsAvailableHasChanged 1\n");
			break;
		case CDOWNLOAD_ENUMS::ERROR_DL_DEST_FILE:
			((CStoreFacade*)caller)->setError(CSTORE_FACADE_ENUMS::ERROR_DL_DEST_FILE);
			g_fullVersionIsAvailableHasChanged = 1;
			((CStoreFacade*)caller)->clearQueuedTransations();
			UNLOCK_DEBUG("callbackDownload 3 - g_fullVersionIsAvailableHasChanged 1\n");
			break;	
		case CDOWNLOAD_ENUMS::ERROR_DL_NO_WIFI:
			((CStoreFacade*)caller)->setError(CSTORE_FACADE_ENUMS::ERROR_DL_NO_WIFI);
			if (!g_fullVersionIsAvailable)
			{
				g_fullVersionIsAvailableHasChanged = 1;
				((CStoreFacade*)caller)->clearQueuedTransations();
			}
			UNLOCK_DEBUG("callbackDownload 4 - g_fullVersionIsAvailableHasChanged 1\n");
			break;	
		case CDOWNLOAD_ENUMS::ERROR_WRONG_USER:
			((CStoreFacade*)caller)->setError(CSTORE_FACADE_ENUMS::ERROR_SECURITY_CRASH);
			g_fullVersionIsAvailableHasChanged = 1;
			((CStoreFacade*)caller)->clearQueuedTransations();
			UNLOCK_DEBUG("callbackDownload 5 - g_fullVersionIsAvailableHasChanged 1\n");
			break;
	}
}

void CStoreFacade::callbackContentLink(char* contentLink, void* caller)
{
	if (contentLink <= 0)
	{
		((CStoreFacade*)caller)->setError(CSTORE_FACADE_ENUMS::ERROR_DL_OTHER);
		return;
	}
	DEBUG_OUT_STORE(@"ContentLink response : %s\n", contentLink);
	if (g_bIsApplicationValidatingFirst)
	{
		if(contentLink[0] == '1')
		{
			g_fullVersionIsAvailableHasChanged = 4; // received correct response
			UNLOCK_DEBUG("callbackContentLink 4 - g_fullVersionIsAvailableHasChanged 4\n");
			return;
		}
		else
		{
			g_fullVersionIsAvailable = false;
			g_bIsApplicationValidatingSecond = true;
			g_bIsApplicationValidatingFirst = false;
		
			UNLOCK_DEBUG("callbackContentLink 1\n");
				
			//g_fullVersionIsAvailableHasChanged = 2;
			((CStoreFacade*)caller)->restoreAllTransactions();
			return;
		}
	}
	
	((CStoreFacade*)caller)->downloadFile(contentLink);
	// TODO use caller to free CDownload object and change state
}

void CStoreFacade::callbackStoreObserver(SKPaymentTransaction *transaction, void* caller)
{
	DEBUG_OUT_STORE(@"Dl request for : %@\n", transaction.payment.productIdentifier);
	((CStoreFacade*)caller)->requestContentLink(transaction);
}
void CStoreFacade::callbackStoreProduct(SKProduct* product, void* caller)
{
	if(product == 0) //last product
	{
		//((CStoreFacade*)caller)->cleanUpInvalidItem();
	}
	else
	{
		DEBUG_OUT_STORE(@"Update info for : %@\n", product.productIdentifier);
		DEBUG_OUT_STORE(@"Price for product is : %@\n", product.price);
		((CStoreFacade*)caller)->updateStoreItem(product);
	}
}		

void CStoreFacade::setNetworkError()
{
	m_state = CSTORE_FACADE_ENUMS::STATE_ERROR;
	m_error = CSTORE_FACADE_ENUMS::ERROR_DL_NO_WIFI;
	g_fullVersionIsAvailableHasChanged = 1;
	clearQueuedTransations();
	UNLOCK_DEBUG("setNetworkError 1\n");
}
