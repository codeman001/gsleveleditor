#ifndef _CSTORE_OBSERVER_H_
#define _CSTORE_OBSERVER_H_

#import <StoreKit/StoreKit.h>
#import <UIKit/UIKit.h>

typedef void (*TransactionCallback) (SKPaymentTransaction *transaction, void* caller);

@interface CStoreObserver:NSObject <SKPaymentTransactionObserver>{
	int					m_status;
	int					m_error;
	long long			bytesReceived;
	NSURLResponse*		downloadResponse;
	NSMutableData*		receivedData;
	TransactionCallback	callback;
	void*				caller;
	NSMutableArray*		m_transactions;
}

- (void) setCallback:(TransactionCallback)method from:(void*)sender;
- (void) completeTransaction: (SKPaymentTransaction *)transaction;
- (void) restoreTransaction: (SKPaymentTransaction *)transaction;
- (void) failedTransaction: (SKPaymentTransaction *)transaction;
- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error;
- (void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue;

- (void) confirmTransactionCompleted;
- (SKPaymentTransaction*) getCurrentTransaction;
- (bool) hasPendingTransaction;
@end
#endif