#ifndef _ISTORE_FACADE_H_
#define _ISTORE_FACADE_H_
#if defined(TARGET_IPHONE_SIMULATOR) || defined(TARGET_OS_IPHONE)
#import <StoreKit/SKProduct.h>
#endif


namespace CSTORE_FACADE_ENUMS
{
	enum
	{
		STATE_ERROR = -1,
		STATE_WAITING,
		STATE_INIT,
		STATE_DOWNLOADING,
		STATE_PROCESSING_PAYMENT,
		STATE_WAITING_CONFIRM,
	};
	enum
	{
		ERROR_SECURITY_CRASH = -7,
		ERROR_DL_NO_WIFI = -6,
		ERROR_PAYMENT = -5,
		ERROR_CONTENT_LIST_RETRIEVAL = -4,
		ERROR_DL_OTHER = -3,
		ERROR_DL_DEST_FILE = -2,
		ERROR_DL_SRC_FILE = -1,
		ERROR_OK = 0,
	};
	enum
	{
		STATE_ITEM_NORMAL,
		STATE_ITEM_NEW_PREVIEW,
		STATE_ITEM_NEW,
		STATE_ITEM_BOUGHT,
	};
};

class IStoreFacade
	{
	public:
		virtual ~IStoreFacade(){};
		
		virtual void init()=0;
		virtual void checkStore()=0;

		virtual void downloadFile(char* src, char* dest)=0;
		virtual int getState()=0;
		virtual int getError()=0;
		virtual void resetError()=0;
		virtual void buy(char* content)=0;
		
		
		virtual bool hasPendingTransaction()=0;
		virtual void resumePendingTransaction(char* dest)=0;
		virtual int getPendingStoreItem()=0;
		virtual long long getDownloadSize()=0;
		virtual long long getDownloadedSize()=0;
		virtual void confirmTransationCompleted(bool setState = true)=0;
		virtual void restoreAllTransactions()=0;
		virtual const char* getPriceItem()=0;
		
		virtual void cancelCurrentDownload()=0;
		virtual void setNetworkError()=0;
		
	};

#endif