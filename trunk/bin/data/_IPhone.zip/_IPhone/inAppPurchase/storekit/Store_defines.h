#ifndef _STORE_DEFINES_H_
#define _STORE_DEFINES_H_

#ifndef DISTRIBUTION
#define _DEBUG_STORE
#define USE_SANDBOX
#endif

#ifdef _DEBUG_STORE
  #define DEBUG_OUT_STORE NSLog
#else
  #define DEBUG_OUT_STORE
#endif


//#ifdef USE_SANDBOX
//	#define BASE_POST_REQUEST @"http://confirmation.gameloft.com/partners/igcontents_test/"
//#else
	#define BASE_POST_REQUEST @"http://confirmation.gameloft.com/partners/igcontents/"
//#endif

// Bogdan - variables, moved to AppController - they depend on the BundleID
//#define TRANSACTION_POST_REQUEST @"action=transaction&content=com.gameloft.SpaceFracture.fullversion&udid=3126&did=DEVICE_ID&v=1.0&rdata="
//#define TRANSACTION_POST_REQUEST_NO_CHECK @"action=transaction&content=com.gameloft.SpaceFracture.fullversion&udid=3126&v=1.0&skipvalidation=1&rdata="

extern NSString* TRANSACTION_POST_REQUEST;
//extern NSString* TRANSACTION_POST_REQUEST_NO_CHECK;

#define TRANSACTION_POST_REQUEST_PRE @"action=transaction&content="
#define TRANSACTION_POST_REQUEST_POST @"&udid=3126&did=DEVICE_ID&v=1.0&rdata="

//#define TRANSACTION_POST_REQUEST_NO_CHECK_PRE @"action=transaction&content="
//#define TRANSACTION_POST_REQUEST_NO_CHECK_POST @"&udid=3126&v=1.0&skipvalidation=1&rdata="


#define VALIDATION_POST_REQUEST @"action=validation&vk=VALIDATION_KEY&v=1.0&rdata="
#endif