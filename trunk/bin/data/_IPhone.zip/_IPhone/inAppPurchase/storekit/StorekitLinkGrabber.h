//
//  IGPUpdater.h
//  IGP
//
//  Created by Fernando.Mazzon on 20/06/08.
//  Copyright 2008 Gameloft. All rights reserved.
//

#ifndef __STORELINKGRABBER_H__
#define __STORELINKGRABBER_H__

/*#define	STATE_FAIL		-1
#define	STATE_IDLE		0
#define	STATE_WORKING	1
#define	STATE_SUCCESS	2
#define	STATE_POKE		3*/
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
typedef void (*StorekitCallback) (char* contentList, void* caller);

@interface StorekitLinkGrabber:NSObject {
	
	long long			bytesReceived;
	NSMutableData*		receivedData;
	StorekitCallback	m_callback;
	NSURLConnection*	m_connection;
	void*				m_caller;
}


-(int)getContentLink:(StorekitCallback)callback from:(void*)caller withDeviceId:(NSString*)_id withData:(NSData*)rdata;
-(int)getValidationLink:(StorekitCallback)callback from:(void*)caller withDeviceId:(NSString*)_id withData:(NSData*)rdata;

@end
#endif