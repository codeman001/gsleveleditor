﻿#import "StorekitLinkGrabber.h"
#import "AppController.h"
#import <CommonCrypto/CommonDigest.h>
#include "Store_defines.h"
#include "base64.h"
//#include "../../../GX_Device.h" //Only needed for gll_new/SAFE_DEL

extern bool g_ShowDownloadMessage;
extern UIAlertView *_myAlert;
int languageSelectedNumber;
extern int g_alertLanguage;
@implementation StorekitLinkGrabber

-(id)init
{
	self = [super init];
	receivedData = nil;
	m_connection = nil;
	return self;
}

-(void) dealloc
{
	if(receivedData != nil)
		[receivedData release];
	
	if(m_connection != nil)
	{
		[m_connection cancel];
		[m_connection release];
	}
	
	[super dealloc];
}

//id = deviceID
-(int)getContentLink:(StorekitCallback)callback from:(void*)caller withDeviceId:(NSString*)_id withData:(NSData*)rdata
{
	DEBUG_OUT_STORE(@"Storelink grabber : getContentLink callback\n");
	
	m_callback = callback;
	m_caller = caller;

	if (!g_ShowDownloadMessage)
	{
		DEBUG_OUT_STORE(@"Storelink grabber : getContentLink callback !g_ShowDownloadMessage\n");
		
		/*NSString* texts[2][9] = {
		{@"OK",@"OK",@"OK",@"Acep.",@"OK",@"Ok",@"OK",@"확인",@"OK"},
		{@"Please wait until the transaction is complete and the content is unlocked.",@"Veuillez attendre que la transaction soit terminée et que le contenu soit débloqué.",@"Warte bitte, bis der Vorgang abgeschlossen ist und der Inhalt aktiviert wurde.",@"Por favor, espera a que la transacción se haya completado y el contenido esté desbloqueado.",@"Attendi fino al termine dell'operazione, quando il contenuto sarà sbloccato.",@"処理が完了し、コンテンツが解除されるまでお待ちください。",
		@"Favor aguardar até que a transação seja efetuada e o conteúdo desbloqueado.",@"처리가 완료되어 콘텐츠가 해제될 때까지 잠시만 기다려 주세요",@"请等待处理完成及内容解锁。"},
		};
		g_ShowDownloadMessage = true;
		
		//if(_myAlert)
		//{
		//	[_myAlert dismissWithClickedButtonIndex:0 animated:YES];
		//	[_myAlert release];
		//}
		UIAlertView *_myAlert = [[UIAlertView alloc] initWithTitle:@"" message:texts[1][languageSelectedNumber] delegate:self cancelButtonTitle:texts[0][0]otherButtonTitles:nil];
		[_myAlert show];*/
		g_alertLanguage = languageSelectedNumber; 
		int msgIdx = 4;
		NSNumber* param = [[NSNumber alloc] initWithInt:msgIdx];
		[[AppController sharedInstance] performSelectorOnMainThread:@selector(showAlertMessage:) withObject:param waitUntilDone:NO];
		
		
	}
	receivedData = [[NSMutableData alloc]init]; 
	
	NSURL *url = [[NSURL alloc]initWithString:BASE_POST_REQUEST];
	NSMutableData *data = [[NSMutableData alloc] init];
	NSString* str = [NSString stringWithString:TRANSACTION_POST_REQUEST];
	str = [str stringByReplacingOccurrencesOfString:@"DEVICE_ID" withString:_id];
	[data appendData:[str dataUsingEncoding:NSUTF8StringEncoding]];
	CBase64::encode(rdata, data);
		
	NSMutableURLRequest * myURLRequest = [[NSMutableURLRequest alloc] initWithURL: url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:12.0];

	[myURLRequest setHTTPMethod:@"POST"];
	[myURLRequest setHTTPBody:data];
	[myURLRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	//[myURLRequest setValue:[NSString stringWithFormat:@"%ld", [data length]] forHTTPHeaderField:@"Content-Length"];
	
	m_connection = [[NSURLConnection alloc] initWithRequest:myURLRequest delegate:self];
	
	[myURLRequest release];
	[data release];
	[url release];
	
	//Check connection was created
	if(!m_connection)
	{
		DEBUG_OUT_STORE(@"Storelink grabber : getContentLink callback !m_connection\n");
		
		m_connection = nil;
		m_callback(0, m_caller); //send error
		[receivedData release];
		receivedData = nil;
	}
	
	return 0;
}

NSString* md5( NSString *strParam ) 
{
  const char *cStr = [strParam UTF8String];
  unsigned char result[CC_MD5_DIGEST_LENGTH];

  CC_MD5( cStr, strlen(cStr), result );
      
  NSMutableString * str = [[NSMutableString alloc] initWithCapacity: 33];
  int i;
  for ( i = 0; i < 16; i++ )
  {
    [str appendFormat: @"%02x", result[i]];
  }
  NSString * output = [str copy];
 [str release];
 return ( [output autorelease] );

}

- (NSData *) MD5Sum
{
unsigned char hash[CC_MD5_DIGEST_LENGTH];
(void) CC_MD5( [self bytes], (CC_LONG)[self length], hash );
return ( [NSData dataWithBytes: hash length: CC_MD5_DIGEST_LENGTH] );
}

-(int)getValidationLink:(StorekitCallback)callback from:(void*)caller withDeviceId:(NSString*)_id withData:(NSData*)rdata
{
	DEBUG_OUT_STORE(@"Storelink grabber : getValidationLink callback\n");
	
	m_callback = callback;
	m_caller = caller;

	receivedData = [[NSMutableData alloc]init]; 
	
	NSURL *url = [[NSURL alloc]initWithString:BASE_POST_REQUEST];
	NSMutableData *data = [[NSMutableData alloc] init];
	NSMutableData *dataKey = [[NSMutableData alloc] initWithCapacity:[rdata length]];
	NSString* str = [NSString stringWithString:VALIDATION_POST_REQUEST];
	
	CBase64::encode(rdata, dataKey);
	//[dataKey appendBytes:rdata length:[rdata length]];
	[dataKey appendData:[_id dataUsingEncoding:NSUTF8StringEncoding]];
	unsigned char hash[CC_MD5_DIGEST_LENGTH];
	(void) CC_MD5( [dataKey bytes], (CC_LONG)[dataKey length], hash );
	
	NSMutableString * hashStrTemp = [[NSMutableString alloc] initWithCapacity: 33];
	int i;
	for ( i = 0; i < 16; i++ )
	{
		[hashStrTemp appendFormat: @"%02x", hash[i]];
	}
	NSString * strHash = [hashStrTemp copy];
  
	str = [str stringByReplacingOccurrencesOfString:@"VALIDATION_KEY" withString:strHash];
	[data appendData:[str dataUsingEncoding:NSUTF8StringEncoding]];
	CBase64::encode(rdata, data);
	
	NSMutableURLRequest * myURLRequest = [[NSMutableURLRequest alloc] initWithURL: url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:12.0];

	[myURLRequest setHTTPMethod:@"POST"];
	[myURLRequest setHTTPBody:data];
	[myURLRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	//[myURLRequest setValue:[NSString stringWithFormat:@"%ld", [data length]] forHTTPHeaderField:@"Content-Length"];
	
	m_connection = [[NSURLConnection alloc] initWithRequest:myURLRequest delegate:self];
	
	[myURLRequest release];
	[data release];
	[url release];
	
	//Check connection was created
	if(!m_connection)
	{
		m_connection = nil;
		m_callback(0, m_caller); //send error
		[receivedData release];
		receivedData = nil;
	}
	
	return 0;
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	DEBUG_OUT_STORE(@"Storelink grabber : didReceiveResponse\n");
    DEBUG_OUT_STORE(@"Storelink grabber : didReceiveResponse header = %@\n", [response allHeaderFields]);
    DEBUG_OUT_STORE(@"Storelink grabber : didReceiveResponse MIMEType = %@\n", [response MIMEType]);
	DEBUG_OUT_STORE(@"Storelink grabber : didReceiveResponse URL = %@\n", [response URL]);
	bytesReceived = 0;
	[receivedData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	DEBUG_OUT_STORE(@"Storelink grabber : didReceiveData\n");
    bytesReceived = bytesReceived + [data length];
	[receivedData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	DEBUG_OUT_STORE(@"\nError link grabber : %@\n", [error localizedDescription]);
    [m_connection release];
	m_connection = nil;
	[receivedData release];
	receivedData = nil;
	//callback ?
	m_callback(0, m_caller);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	char* receivedBytes = (char*)[receivedData mutableBytes];
	char* rchar = NEW char[[receivedData length]+1];
	memcpy(rchar, receivedBytes, [receivedData length]);
	rchar[[receivedData length]] = 0;
	DEBUG_OUT_STORE(@"Received Message :\n%s\n", rchar);
	NSString* str = [[NSString alloc] initWithBytes:[receivedData bytes] length:[receivedData length] encoding:NSUTF8StringEncoding];
	DEBUG_OUT_STORE(str);
	m_callback(rchar, m_caller);
	
	SAFE_DEL_ARRAY(rchar);
	[m_connection release];
	m_connection = nil;
	[receivedData release];
	receivedData = nil;
}



@end