#ifndef _BASE64_H_
#define _BASE64_H_
#import <Foundation/Foundation.h>
class CBase64
{
public:
	static bool encode(NSData* src, NSMutableData* dest);
	static bool encodeBlob(NSData* src, NSMutableData* dest);
	static bool decodeBlob(NSData* src, NSMutableData* dest);
private:
	static char SSEncDec_GetKeyFromChar(char nChar);
	static char * SSEncDec_String2Blob(char* s);
	static char * SSEncDec_ByteArray2Blob(unsigned char* s, int len);
	static char SSEncDec_GetCharFromKeyByIndex(int nKeyIndex);
};

#endif