
#include "base64.h"

char* base64EncodeTable = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
char* blobEncodeTable = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-";

/******************************************************************************************************
 *	Method :	encode
 *	Params :	NSData*	src				Data to encode to base64
 *				NSMutableData * dest	Encoded data will be *appended* to dest
 *	Return :	true if the conversion was successful (a zero byte conversion is considered successful)
 *	
 *	Desciption :	Will encode binary data into base64
 *					We skip the line CR/LF after 76 bytes tp avoid a conversion problem in NSURLRequest
 *******************************************************************************************************/
bool CBase64::encode(NSData* src, NSMutableData* dest) /*static*/
{
	//We skip the line CR/LF after 76 bytes tp avoid a conversion problem in NSURLRequest
	if(src == nil || dest == nil)
		return false;
	
	int length = [src length];
	
	char* data = (char*)[src bytes];
	
	int baseLength = length - (length%3); //encode by group of 3 chars
	
	char codedChar[4];
	for(int i = 0; i < baseLength; i+=3)
	{
		codedChar[0] = base64EncodeTable[data[i] >> 2];
		codedChar[1] = base64EncodeTable[((data[i] & 0x03) << 4) + (data[i+1] >> 4)];
		codedChar[2] = base64EncodeTable[((data[i+1] & 0x0f) << 2) + ((data[i+2] & 0xC0) >> 6)];
		codedChar[3] = base64EncodeTable[data[i+2] & 0x3f];
		[dest appendBytes:(const void*)codedChar length:4];
	}
	
	if(baseLength != length)
	{
		memset(codedChar, '=', 4); //Pad with =
		if(length - baseLength == 1)
		{
			codedChar[0] = base64EncodeTable[data[baseLength] >> 2];
			codedChar[1] = base64EncodeTable[((data[baseLength] & 0x03) << 4)];
		}
		else //2
		{
			codedChar[0] = base64EncodeTable[data[baseLength] >> 2];
			codedChar[1] = base64EncodeTable[((data[baseLength] & 0x03) << 4) + (data[baseLength+1] >> 4)];
			codedChar[2] = base64EncodeTable[((data[baseLength+1] & 0x0f) << 2)];
		}
		[dest appendBytes:(const void*)codedChar length:4];		
	}
	return true;
}

bool CBase64::encodeBlob(NSData* src, NSMutableData* dest)
{
	if(src == nil || dest == nil)
		return false;
	
	/*unsigned char * data = (unsigned char *)[src bytes];
	char* bdata = SSEncDec_ByteArray2Blob(data, [src length]);
	[dest appendBytes:bdata length:strlen(bdata)];
	return true;*/
	
	int length = [src length];
	
	unsigned char* data = (unsigned char*)[src bytes];

	int baseLength = length - (length%3); //encode by group of 3 chars
	
	char codedChar[4];
	for(int i = 0; i < baseLength; i+=3)
	{
		codedChar[0] = blobEncodeTable[data[i] & 0x03f];
		codedChar[1] = blobEncodeTable[(data[i] >> 6) + ((data[i+1] & 0x0f) << 2)];
		codedChar[2] = blobEncodeTable[((data[i+1] & 0xf0) >> 4) + ((data[i+2] & 0x03) << 4)];
		codedChar[3] = blobEncodeTable[((data[i+2] & 0xfc) >> 2)];
		[dest appendBytes:(const void*)codedChar length:4];
	}
	
	if(baseLength != length)
	{
		//memset(codedChar, 'a', 4); //Pad with =
		if(length - baseLength == 1)
		{
			codedChar[0] = blobEncodeTable[data[baseLength] & 0x03f];
			codedChar[1] = blobEncodeTable[(data[baseLength] >> 6)];
			[dest appendBytes:(const void*)codedChar length:2];
		}
		else //2
		{
			codedChar[0] = blobEncodeTable[data[baseLength] & 0x03f];
			codedChar[1] = blobEncodeTable[(data[baseLength] >> 6) + ((data[baseLength+1] & 0x0f) << 2)];
			codedChar[2] = blobEncodeTable[((data[baseLength+1] & 0xf0) >> 4)];
			[dest appendBytes:(const void*)codedChar length:3];
		}
		//[dest appendBytes:(const void*)codedChar length:4];		
	}
	
	return true;
}

bool CBase64::decodeBlob(NSData* src, NSMutableData* dest)
{
	if(src == nil || dest == nil)
		return false;
	
	int length = [src length];
	
	char* data = (char*)[src bytes];
	
	int baseLength = length - (length%4); //decode by group of 4 chars
	
	char codedChar[4];
	char decodedChar[3];

	for(int i = 0; i < baseLength; i+=4)
	{
		codedChar[0] = SSEncDec_GetKeyFromChar(data[i]);
		codedChar[1] = SSEncDec_GetKeyFromChar(data[i+1]);
		codedChar[2] = SSEncDec_GetKeyFromChar(data[i+2]);
		codedChar[3] = SSEncDec_GetKeyFromChar(data[i+3]);
		
		decodedChar[0] = codedChar[0] + (codedChar[1] << 6);
		decodedChar[1] = (codedChar[1] >> 2) + (codedChar[2] << 4);
		decodedChar[2] = (codedChar[2] >> 4) + (codedChar[3] << 2);
		
		[dest appendBytes:(const void*)decodedChar length:3];
	}	
	
	if(baseLength != length)
	{
		if(length - baseLength == 1) //should never happen ...
		{
			codedChar[0] = SSEncDec_GetKeyFromChar(data[baseLength]);
			
			decodedChar[0] = codedChar[0];
			
			[dest appendBytes:(const void*)decodedChar length:1];
			
		}
		else if(length - baseLength == 2) //encoded %3 + 1 (only 8 bits valid)
		{
			codedChar[0] = SSEncDec_GetKeyFromChar(data[baseLength]);
			codedChar[1] = SSEncDec_GetKeyFromChar(data[baseLength + 1]);
			
			decodedChar[0] = codedChar[0] + (codedChar[1] << 6);
			
			[dest appendBytes:(const void*)decodedChar length:1];
		}
		else //encoded %3 + 2  (only 16 bits valid)
		{
			codedChar[0] = SSEncDec_GetKeyFromChar(data[baseLength]);
			codedChar[1] = SSEncDec_GetKeyFromChar(data[baseLength + 1]);
			codedChar[2] = SSEncDec_GetKeyFromChar(data[baseLength + 2]);
			
			decodedChar[0] = codedChar[0] + (codedChar[1] << 6);
			decodedChar[1] = (codedChar[1] >> 2) + (codedChar[2] << 4);
			
			[dest appendBytes:(const void*)decodedChar length:2];			
		}
	}
	
	return true;
}
	
char CBase64::SSEncDec_GetKeyFromChar(char nChar)
{
	if(nChar == '-')
	{
		return 63;
	}
	else if(nChar == '_')
	{
		return 62;
	}
	else if(nChar < 58)
	{//48-57 is '0'-'9', index is 52-61
		return (char)(nChar + 4);
	}
	else if(nChar < 91)
	{//65-91 is 'A'-'Z', index is 26-51
		return (char)(nChar - 39);
	}
	else
	{//97-122 is 'a'-'z', index is 0-25
		return (char)(nChar - 97);
	}
} 

#define XP_API_STRLEN strlen
#define XP_API_NEW new
#define XP_API_MEMSET memset
#define BYTE unsigned char

char * CBase64::SSEncDec_String2Blob(char* s)
{
	char *sBlob;          //blob buffer
	int  nBlobPos     = 0; //current index of blob
	int  nSPos        = 0; //current index of string
	int  nBitsNotUsed = 8; //how many bits not used in the current s[nSPos]
	int  nKeyIndex;        //the index of key calcualted using s
	
	//calculate blob length and allocate memory
	int nBlobLength = XP_API_STRLEN(s)*8/6;
	if(XP_API_STRLEN(s)*8%6)
	{//has remainder, need one more char to hold it
		nBlobLength += 2; //remainder + ending 0
	}
	else
	{
		nBlobLength ++; //need space for ending 0
	}
	sBlob = XP_API_NEW char[nBlobLength+1];//brew 0's MALLOC'ed mem
	XP_API_MEMSET(sBlob, 0, nBlobLength+1);
	if(!sBlob)
	{//error allocating mem for blob
		return NULL;
	}
	
	// -> go though each char in s, calculate a key index using 6 of its bits at a time,
	//   use that index to get a char from key, these chars will form the blob
	// -> go though s from left to right, but get bits from each char in s from right to left
	int size = XP_API_STRLEN(s);
	while( nSPos < size)
	{
		//get next 6 not used bits from s
		
		//first shift not used bits in current pos all the way to right
		nKeyIndex = s[nSPos] >> (8 - nBitsNotUsed);
		
		if(nBitsNotUsed < 6)
		{//not enough bits in current pos
			if(++nSPos < size)
			{//there's still char in the next pos, so use its bits (nSPos points to next pos now)
				//get 6-nBitsNotUsed number of bits from next char
				//to do so, we first shift the char in next pos to left nBitsNotUsed times
				//then | with leftover bits to form a 6 bit number
				nKeyIndex |= (s[nSPos] << nBitsNotUsed);
				nBitsNotUsed += 2; //since 6-nBitsNotUsed bits is used from next char, 8-(6-nBitsNotUsed) will be left there
			}
			//else
			//there's no next char, just use what we have left in the current pos (nSPos is now pointing pass the end of s)
		}
		else
		{//enough bits not used in current pos
			nBitsNotUsed -= 6; //we used 6 more bits from current pos
			
			if(nBitsNotUsed==0)
			{//used up all the bits in current pos, so go to next
				nBitsNotUsed = 8;
				nSPos ++;
			}
		}
		
		//use right most 6 bits as key index
		nKeyIndex &= 63;   //& with 00111111(63) to take only the right most 6 bits
		
		//then use index to get a char from key to fill the blob
		sBlob[nBlobPos++] = SSEncDec_GetCharFromKeyByIndex(nKeyIndex);
	}
	
	return sBlob;
} 

char * CBase64::SSEncDec_ByteArray2Blob(BYTE* s, int len)
{
	char *sBlob;          //blob buffer
	int  nBlobPos     = 0; //current index of blob
	int  nSPos        = 0; //current index of string
	int  nBitsNotUsed = 8; //how many bits not used in the current s[nSPos]
	int  nKeyIndex = 0;        //the index of key calcualted using s
	//calculate blob length and allocate memory     
	int nBlobLength = len*8/6;
	if(nBlobLength)
	{//has remainder, need one more char to hold it
		nBlobLength += 2; //remainder + ending 0
	}
	else
	{
		nBlobLength ++; //need space for ending 0
	}
	sBlob = XP_API_NEW char[nBlobLength+1];//brew 0's MALLOC'ed mem
	XP_API_MEMSET(sBlob, 0, nBlobLength+1);
	if(!sBlob)
	{//error allocating mem for blob
		return NULL;
	}
	
	// -> go though each char in s, calculate a key index using 6 of its bits at a time,
	//   use that index to get a char from key, these chars will form the blob
	// -> go though s from left to right, but get bits from each char in s from right to left
	
	while( nSPos < len)
	{
		//get next 6 not used bits from s
		
		//first shift not used bits in current pos all the way to right
		nKeyIndex = s[nSPos] >> (8 - nBitsNotUsed);
		
		if(nBitsNotUsed < 6)
		{//not enough bits in current pos
			if(++nSPos < len)
			{//there's still char in the next pos, so use its bits (nSPos points to next pos now)
				//get 6-nBitsNotUsed number of bits from next char
				//to do so, we first shift the char in next pos to left nBitsNotUsed times
				//then | with leftover bits to form a 6 bit number
				nKeyIndex |= (s[nSPos] << nBitsNotUsed);
				nBitsNotUsed += 2; //since 6-nBitsNotUsed bits is used from next char, 8-(6-nBitsNotUsed) will be left there
			}
			//else
			//there's no next char, just use what we have left in the current pos (nSPos is now pointing pass the end of s)
		}
		else
		{//enough bits not used in current pos
			nBitsNotUsed -= 6; //we used 6 more bits from current pos
			
			if(nBitsNotUsed==0)
			{//used up all the bits in current pos, so go to next
				nBitsNotUsed = 8;
				nSPos ++;
			}
		}
		
		//use right most 6 bits as key index
		nKeyIndex &= 63;   //& with 00111111(63) to take only the right most 6 bits
		
		//then use index to get a char from key to fill the blob
		sBlob[nBlobPos++] = SSEncDec_GetCharFromKeyByIndex(nKeyIndex);
	}
	
	return sBlob;
} 

char CBase64::SSEncDec_GetCharFromKeyByIndex(int nKeyIndex)
{
	if(nKeyIndex<26)
	{//key index 0-25 is a-z
		return nKeyIndex + 97; //convert 0...25 to a...z
	}
	else if(nKeyIndex<52)
	{//key index 26-51 is A-Z
		return nKeyIndex + 39; //convert 26...51 to A...Z
	}
	else if(nKeyIndex<62)
	{//key index 52-61 is 0-9
		return nKeyIndex - 4; //convert 52...61 to 0...9
	}
	else if(nKeyIndex==62)
	{//key index 62 is '_'
		return '_';
	}
	else
	{//key index 63 is '-'
		return '-';
	}
	
	//should never get here
	return 0;
} 

