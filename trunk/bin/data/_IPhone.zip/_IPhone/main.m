
#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
	NSAutoreleasePool*		pool = [NSAutoreleasePool new];

	UIApplicationMain(argc, argv, nil, @"AppController");
	
	[pool release];
	
	return 0;
}
 