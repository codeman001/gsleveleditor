//
//  substView.h
//  Driver_iphone
//
//  Created by Timur Losev on 08.09.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@interface substView : UIView {

	UILabel   *m_label;
	UILabel   *m_shadowLabel;
	UIButton  *m_btnSubtitles;                  // show / hide subtitles
	UIButton  *m_btnSkip;                       // skip video
	CGFloat    m_btnsTimeBeforeFade;            // time before start fading of shown buttons
	
	#ifdef _ENABLE_TIMING_OUT_
		UILabel *m_timing;
	#endif
}

@property (nonatomic, retain) UIButton* m_btnSkip;
@property (nonatomic, retain) UIButton* m_btnSubtitles;

-(void) SetSubstText: (NSString* ) subtString;
#ifdef _ENABLE_TIMING_OUT_
-(void) SetTimingText;
#endif
@end
