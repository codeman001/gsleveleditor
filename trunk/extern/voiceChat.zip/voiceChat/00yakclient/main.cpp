#include <server/yak_server.h>
#include "yak_client_example.h"

void onInit();
void onQuit();

int main( int argc, char **argv )
{
	onInit();

	char  ip[32]				= {"127.0.0.1"};
	short port					= D_YAK_P2P_SERVER_PORT;
	int memberId				= 0;

	for (int i = 1; i < argc; ++i)
	{
		if (strcmp("-i", argv[i]) == 0) {
			memberId = atoi( argv[ ++i ] );
		}
		if (strcmp("-s", argv[i]) == 0) {
			sscanf( argv[ ++i ], "%s", ip );
		}
		if (strcmp("-p", argv[i]) == 0) {
			port = atoi( argv[ ++i ] );
		}
	}

	yak::Codec::EContext outCtx = yak::Codec::eContextAdpcm4Bit;
	yak::Codec::EContext inCtx	= yak::Codec::eContextAdpcm4Bit;
	yak::SetArchitecture( yak::eArchitectureServer );

	YakExample dg;

	dg.Initialize( outCtx, inCtx, inet_addr( ip ), port );
	//dg.Initialize( outCtx, inCtx, inet_addr( "127.0.0.1" ), port );
	//dg.Initialize( outCtx, inCtx, inet_addr( "208.71.187.10" ), port ); // alpha01
	//dg.Initialize( outCtx, inCtx, inet_addr( "10.58.8.52" ), port ); // tardis
	//dg.Initialize( outCtx, inCtx, inet_addr( "10.58.8.73" ), port ); // bucwks0187

	dg.Join( memberId );


	// main app routine
	// TRICK: for debugging and tests, the server is instantiated and 
	// updated in the main loop, instead of a game application.
	// Note that it should be running as a daemon on a separate machine
	{
		yak::Server server( D_YAK_P2P_SERVER_PORT, true );
		while( true )
		{
			static int counter = 0;
			static unsigned int lt = 0;
			unsigned int now = yak::S_GetTime();
			if( now - lt > 1000 )
			{
				printf("\nbwIN: %.2f, bwOut:%.2f", dg.GetBwIn(), dg.GetBwOut() );
				lt = now;

				++counter;
			}

			if( counter > 60 )
				break;

			server.Update();
			server.Wait();
		}
	}
	//
	dg.Leave();

	dg.Terminate();

	onQuit();

	return 0;
}

void onInit()
{
#if defined( WIN32 )
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	//_crtBreakAlloc = 349;
	timeBeginPeriod( 1 );

	WSADATA wsaData;
	yak::Socket::Init( &wsaData );
#endif // WIN32

	vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
	vox.Initialize();
}

void onQuit()
{
	vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
	vox.DestroyVoxEngine();

#if defined( WIN32 )
	yak::Socket::Term();

	timeEndPeriod( 1 );
#endif // WIN32
}
