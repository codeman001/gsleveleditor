#include "yak_client_example.h"

YakExample::YakExample()
{
	m_client		= NULL;
}

YakExample::~YakExample()
{
	yakdel( m_client );
}

void YakExample::Initialize( yak::Codec::EContext outCtx, yak::Codec::EContext inCtx, int serverIP, unsigned short serverPort )
{
	m_client = new yak::Client( outCtx, inCtx, this );
	m_client->Init( serverIP, serverPort );
}

void YakExample::Terminate()
{
	yakdel( m_client );
}

void YakExample::Join( unsigned short clientId )
{
	if( m_client ) {
		m_client->Join( clientId );
	}
}

void YakExample::Leave()
{
	if( m_client ) {
		m_client->Leave();
	}
}

void YakExample::Pause()
{
	if( m_client ) {
		m_client->Mute( true );
	}
}

void YakExample::Resume()
{
	if( m_client ) {
		m_client->Mute( false );
	}
}

void YakExample::OnPeerConnect( yak::Peer *peer )
{
	printf( "\n========= EVENT: CYakDelegate::OnPeerConnect ========" );
}

void YakExample::OnPeerDisconnect( yak::Peer *peer )
{
	printf( "\n========= EVENT: CYakDelegate::OnPeerDisconnect ========" );
}

void YakExample::OnPeerHolePunchFail( yak::Peer *peer )
{
	// P2P connection failed for peer, fallbacks to client-server
	printf( "\n========= EVENT: CYakDelegate::OnPeerConnectFail ========" );
}

void YakExample::OnClientConnect( const int memberId )
{
	printf( "\n========= EVENT: CYakDelegate::OnClientConnect ========" );
}

void YakExample::OnClientError( const int error )
{
	printf( "\n========= EVENT: CYakDelegate::OnClientError ========" );
}