#ifndef __YAK_EXAMPLE_H
#define __YAK_EXAMPLE_H

#include "../yakidi/src/yak_client.h"

class YakExample : public yak::Singleton< YakExample >, yak::Client::Listener
{
protected:
	yak::Client		*m_client;

public:
	YakExample();
	~YakExample();

	void			Initialize( yak::Codec::EContext outCtx, yak::Codec::EContext inCtx, int serverIP, unsigned short serverPort );
	void			Terminate();

	void			Join( unsigned short clientId );
	void			Leave();

	void			Pause();
	void			Resume();

	virtual void	OnPeerConnect( yak::Peer *peer );
	virtual void	OnPeerDisconnect( yak::Peer *peer );
	virtual void	OnPeerHolePunchFail( yak::Peer *peer );

	virtual void	OnClientConnect( const int roomId );
	virtual void	OnClientError( const int error );
	
    bool            IsConnected() { return m_client && m_client->IsConnected(); }
    
	float			GetBwIn() { return m_client ? m_client->GetBwIn() : 0.0f; }
	float			GetBwOut(){ return m_client ? m_client->GetBwOut() : 0.0f; }
};

#endif __YAK_EXAMPLE_H