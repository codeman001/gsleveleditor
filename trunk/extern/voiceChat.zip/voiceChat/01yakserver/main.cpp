#include <server/yak_server.h>

#include <stdlib.h>
#include <string.h>

void onInit()
{
#if defined( WIN32 )
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	//_crtBreakAlloc = 132;

	timeBeginPeriod( 1 );

	WSADATA wsaData;
	yak::Socket::Init( &wsaData );
#endif // WIN32
}

void onQuit()
{
#if defined( WIN32 )
	yak::Socket::Term();

	timeEndPeriod( 1 );
#endif // WIN32
}

int main( int argc, char **argv )
{
	unsigned short port = D_YAK_P2P_SERVER_PORT;
	//unsigned short port = 0;
	
	bool list = true;

	for (int i = 1; i < argc; ++i)
	{
		if (strcmp("-l", argv[i]) == 0)
		{
			list = false;
			yakout("Server using http inteface\n");
		}

		if (strcmp("-p", argv[i]) == 0)
		{
			port = atoi(argv[++i]);
		}
	}

	onInit();

	yak::Server server(port, list);
	yakout("Server listening on port: %d\n", server.GetPort());

	while( server.IsRunning() )
	{
		server.Update();
		server.Wait();
	}

	onQuit();

	return 0;
}

