#import <UIKit/UIKit.h>

#import "yak_client_example.h"

@interface ViewController : UIViewController
{
    BOOL animating;
	BOOL isConnecting;
    NSInteger animationFrameInterval;
    CADisplayLink *displayLink;
    
	YakExample m_voiceChatClient;	    
}

@property (readonly, nonatomic, getter=isAnimating) BOOL animating;
@property (nonatomic) NSInteger animationFrameInterval;

@property (nonatomic, retain) IBOutlet UITextField* addressInput;
@property (nonatomic, retain) IBOutlet UITextField* portInput;
@property (nonatomic, retain) IBOutlet UITextField* memberInput;
@property (nonatomic, retain) IBOutlet UIButton* connectButton;


- (IBAction) actionConnect;
- (IBAction) removeAddressKeyboard;
- (IBAction) removePortKeyboard;
- (IBAction) removeMemberKeyboard;

- (void)startAnimation;
- (void)stopAnimation;

@end
