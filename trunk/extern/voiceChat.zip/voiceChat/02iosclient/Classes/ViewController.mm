#import <QuartzCore/QuartzCore.h>

#include <vox.h>
#include <stdio.h>

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, assign) CADisplayLink *displayLink;
@end

@implementation ViewController

@synthesize animating, displayLink, addressInput, portInput, memberInput, connectButton;


- (void)awakeFromNib
{
    isConnecting = FALSE;
    animating = FALSE;
    animationFrameInterval = 1;
    self.displayLink = nil;
    
    vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
    vox.Initialize();
}

- (void)dealloc
{
    vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
    vox.DestroyVoxEngine();
    
    [super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{
    [self startAnimation];
    
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [self stopAnimation];
    
    [super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
	[super viewDidUnload];
}

- (NSInteger)animationFrameInterval
{
    return animationFrameInterval;
}

- (void)setAnimationFrameInterval:(NSInteger)frameInterval
{
    /*
	 Frame interval defines how many display frames must pass between each time the display link fires.
	 The display link will only fire 30 times a second when the frame internal is two on a display that refreshes 60 times a second. The default frame interval setting of one will fire 60 times a second when the display refreshes at 60 times a second. A frame interval setting of less than one results in undefined behavior.
	 */
    if (frameInterval >= 1)
    {
        animationFrameInterval = frameInterval;
        
        if (animating)
        {
            [self stopAnimation];
            [self startAnimation];
        }
    }
}

- (void)startAnimation
{
    if (!animating)
    {
        CADisplayLink *aDisplayLink = [[UIScreen mainScreen] displayLinkWithTarget:self selector:@selector(drawFrame)];
        [aDisplayLink setFrameInterval:animationFrameInterval];
        [aDisplayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        self.displayLink = aDisplayLink;
        
        animating = TRUE;
    }
}

- (void)stopAnimation
{
    if (animating)
    {
        [self.displayLink invalidate];
        self.displayLink = nil;
        animating = FALSE;
    }
}

- (void)drawFrame
{
    if( isConnecting )
    {
        if( m_voiceChatClient.IsConnected() )
        {
            isConnecting = false;
            [connectButton setTitle:@"Disconnect" forState:UIControlStateNormal];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (IBAction) actionConnect 
{
    if( !isConnecting )
    {
        if( !m_voiceChatClient.IsConnected() )
        {
            yak::Codec::EContext inCtx = yak::Codec::eContextAdpcm4Bit;
            yak::Codec::EContext outCtx = yak::Codec::eContextAdpcm4Bit;
            
            
            m_voiceChatClient.Initialize(outCtx, inCtx, 
                                         inet_addr( [[addressInput text] UTF8String] ),
                                         atoi( [[portInput text] UTF8String] ) );
            m_voiceChatClient.Join( atoi( [[memberInput text] UTF8String] ) );
            
            isConnecting = true;
            
            [connectButton setTitle:@"Cancel" forState:UIControlStateNormal];
        }
        else
        {
            m_voiceChatClient.Leave();
            m_voiceChatClient.Terminate();
            
            isConnecting = false;
            
            [connectButton setTitle:@"Connect" forState:UIControlStateNormal];
        }
    }
    else
    {
        m_voiceChatClient.Leave();
        m_voiceChatClient.Terminate();
        
        isConnecting = false;
        
        [connectButton setTitle:@"Connect" forState:UIControlStateNormal];  
    }
}

- (IBAction) removeAddressKeyboard
{
	[addressInput resignFirstResponder];
}

- (IBAction) removeMemberKeyboard
{
	[memberInput resignFirstResponder];
}

- (IBAction) removePortKeyboard
{
	[portInput resignFirstResponder];	
}

@end
