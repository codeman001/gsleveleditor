#include <iostream>
#include <list>

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

#ifdef WIN32
#	include "dirent.h"
#else
#	include <dirent.h>
#endif

bool compare_file( std::string first, std::string second );

char *dirName	= NULL;
char *prefix	= NULL;
char *outName	= NULL;

int main( int argc, char **argv )
{
	if( argc != 4 )
	{
		printf( "\nUSAGE:\n\tfilecat [ DIR ] [ PREFIX ] [ OUTPUT ]\n" );
		return  0;
	}

	dirName	= argv[ 1 ];
	prefix	= argv[ 2 ];
	outName	= argv[ 3 ];

	DIR *dir = opendir( dirName );

	switch( errno )
	{
	case ENOENT:
		{
			printf( "\nERROR: directory \"%s\" does not exist", dirName );
			return 1;
		}
	case EINVAL:
		{
			printf( "\nERROR: Invalid argument or directory name \"%s\"", dirName );
			return 1;
		}
	case ENOMEM:
		{
			printf( "\nERROR:not enough memory available" );
			return 1;
		}
	}

	std::list<std::string> fileList;

	dirent *nextFile = NULL;

	for(;;)
	{
		nextFile = readdir( dir );
		
		switch( errno )
		{
		case EBADF:
			{
				printf( "\nERROR: Invalid directory stream. " );
				closedir( dir );
				return 2;
			}
		case ENOENT:
			break;
		}

		if( nextFile == NULL )
			break;

		char *fileName = nextFile->d_name;

		if( strstr( fileName, prefix ) ) {
			fileList.push_back( fileName );
		}
	}

	if( fileList.size() == 0 )
	{
		printf( "\nERROR: No files matching PREFIX \"%s\" found.", prefix );
		closedir( dir );
		return 3;
	}
	
	FILE *fou = fopen( outName, "wb" );
	if( fou == NULL )
	{
		printf( "\nERROR: Can't open destination file \"%s\".", outName );
		closedir( dir );
		return 4;	
	}

	fileList.sort( compare_file );

	std::list<std::string>::iterator k;
	for( k = fileList.begin(); k != fileList.end(); k++ )
	{
		FILE *f = fopen( (*k).c_str(), "rb" );

		if( !f )
		{
			printf( "\nWARNING: Couldn't open file \"%s\". Skip...", (*k).c_str() );
			continue;
		}

		int inSize = 0;

		fseek( f, 0, SEEK_END );
		inSize = ftell( f );
		fseek( f, 0, SEEK_SET );

		char *inBuffer = new char[ inSize ];

		fread( inBuffer, inSize, 1, f );
		fwrite( inBuffer, inSize, 1, fou );

		delete inBuffer;

		fclose( f );
	}

	fclose( fou );

	closedir( dir );

	return 0;
}

bool compare_file( std::string first, std::string second )
{
	// sort on timestamps
	int prefixLen = strlen( prefix );

	char time1Name[ 64 ];
	char time2Name[ 64 ];

	const char* str1 = first.c_str();
	const char* str2 = second.c_str();

	const char *ext1 = strchr( str1, '.' );
	const char *ext2 = strchr( str2, '.' );

	int time1Len = (size_t)( ext1 - str1 ) - prefixLen;
	int time2Len = (size_t)( ext2 - str2 ) - prefixLen;

	memcpy( time1Name, &str1[ prefixLen ], time1Len );
	time1Name[ time1Len ] = '\0';

	memcpy( time2Name, &str2[ prefixLen ], time2Len );
	time2Name[ time2Len ] = '\0';


	int t1 = atoi( time1Name );
	int t2 = atoi( time2Name );

	return t1 < t2;
}
