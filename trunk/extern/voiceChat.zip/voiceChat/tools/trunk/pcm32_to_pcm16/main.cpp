#include <stdio.h>

#define USHORT_MAX      ( ( unsigned short )( ~0U ) )
#define SHORT_MAX       ( ( short )( USHORT_MAX >> 1 ) )
#define SHORT_MIN       ( -SHORT_MAX - 1 )

int main( int argc, char **argv )
{
	if( argc != 3 )
	{
		printf( "\nUSAGE:\n\tpcm32_to_pcm16 [ path_to_source_raw_pcm32 ] [ path_to_destination_raw_pcm16 ]\n" );
		return  0;
	}


	FILE *fin = fopen( argv[ 1 ], "rb" );

	if( !fin )
	{
		printf( "\nError: opening source file \"%s\"", argv[ 1 ] );	
		return 1;
	}

	FILE *fou = fopen( argv[ 2 ], "wb" );
	if( !fou )
	{
		printf( "\nError: opening destination file \"%s\"", argv[ 2 ] );	

		fclose( fin );
		return 1;
	}

	int inSize = 0;

	fseek( fin, 0, SEEK_END );
	inSize = ftell( fin );
	fseek( fin, 0, SEEK_SET );

	if( inSize % sizeof( int ) != 0 )
	{
		printf( "\nError: file \"%s\" does not seem to be a pcm32 raw file.", argv[ 1 ] );	
		return 3;	
	}

	int nSamples		= inSize / sizeof( int );

	int *inSamples		= new int[ nSamples ];
	if( inSamples == NULL )
	{
		printf( "\nError: allocating memory %d bytes.", inSize );	
		return 2;	
	}

	short *outSamples	= new short[ nSamples ];
	if( outSamples == NULL )
	{
		printf( "\nError: allocating memory %d bytes.", inSize / 2 );	
		return 2;	
	}
	

	fread( inSamples, inSize, 1, fin );
	
	for( int k = 0; k < nSamples; k++ )
	{
		int sample = inSamples[ k ];

		if( sample < SHORT_MIN )
		{
			printf( "\nWARNING: LOW clamp sample[%d]=%d to %d", k, sample, SHORT_MIN );
			sample = SHORT_MIN;
		}
		else if( sample > SHORT_MAX )
		{
			printf( "\nWARNING: HIGH clamp sample[%d]=%d to %d", k, sample, SHORT_MAX );
			sample = SHORT_MAX;
		}
		
		outSamples[ k ] = ( short ) sample;
	}

	fwrite( outSamples, inSize / 2, 1, fou );

	delete outSamples;
	delete inSamples;

	fclose( fin );
	fclose( fou );

	return 0;
}
