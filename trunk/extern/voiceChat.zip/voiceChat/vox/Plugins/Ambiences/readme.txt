////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Plugin                            //
//                                                                            //
//                              Ambience plugin                               //
//                                                                            //
//                               Robert Houde                                 //
//                             (c)2011 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

------------
INTRODUCTION
------------

The Ambience plugin simply consists of a mechanism providing applications with a
randomly-timed callback each time a sound (or event) has to be triggered. The
main procedure when using Ambiences is the following:

1) Load the .vxa file containing (most) parameters of the available ambiences
   by a call to static method Ambience::LoadAmbiences(const c8 *fileName).
   This file is generated with the help of the VoxAmbienceCreator tool (a task
   usually done by a sound designer).

2) Create a callback function (whose address is passed to the Ambience constructor)
   to manage the sounds (or events) associated with the Ambiences. The callback
   function is called when its time to trigger a sound (or event) and provides
   the application with a random position offset to apply to the sound position.
   The actual sound playback (data source and emitter management) is left to the
   application. When using Vox XML SoundPack, the emitter information of the sound
   to play can be obtained by calling VoxSoundPackXML::GetEmitterInfoFromSoundOrEvent().
   For more details, see the CODE SAMPLE section.

3) Construct an Ambience object. See the AMBIENCE CONSTRUCTION section for a
   description of the parameters needed by the constructor.

4) Update regularly (e.g. at each game update) the Ambience object by calling
   its Ambience::Update() method. The Ambience objects don't have their own update
   thread.
  
5) Destroy the Ambience objects when you're done with them. When you do not need
   ambiences anymore, call static method Ambience::UnloadAmbiences() to release
   the AmbienceFileReader reader used by the Ambience class to import 'vxa' files.
   
---------------------
AMBIENCE CONSTRUCTION
---------------------

The Ambience constructor takes a pointer to a AmbienceParams structure containing
the following infos:

1) const c8* m_label : The label of the ambience to create.
2) bool m_isRelativeToListener : True if the event position is relative to the listener.
   This value is simply sent back by the callback function for convenience.
3) VoxAmbienceCallbackFunc m_ambienceCallback : Address of the callback function that will
   be called by the Ambience object when a sound or event has to be triggered.
4) void *m_callbackCustomParam : The custom parameter passed to the Ambience constructor.
   This is merely a convenient way for the application to get access to custom
   parameters (such as the name of the ambience triggering the sound and/or a game object
   associated with the event to trigger). 

-----------------
CALLBACK FUNCTION
-----------------

The callback function has the following prototype:

typedef void (*VoxAmbienceCallbackFunc) (const c8* label, f32 x, f32 y, f32 z, bool relativeToListener, void *customParam);

where:

1) label : Label of the sound (or event) to trigger.

2) (x,y,z) : A random position offset that the application adds to the position
   of the sound (or event) to be triggered.

3) relativeToListener : A boolean stating if the position of the triggered sound is
   relative to the listener. This value is simply the one passed to the Ambience
   constructor. This is merely a convenient way for the application to get access
   to this value within the callback function.

4) customParam : The custom parameter passed to the Ambience constructor. This
   is merely a convenient way for the application to get access to a custom parameter
   (such as the name of the ambience triggering the sound and/or a game object associated
   with the sound to trigger) within the callback.

--------------------------------------------------------
CODE SAMPLE (case where game is using Vox XML SoundPack)
--------------------------------------------------------

Solution TestAmbience.sln located in folder VoxAmbienceCreator/TestAmbiences of repository
https://terminus.mdc.gameloft.org/vc/vox/maintenance/1_0/vox_dev_tools contains a sample
application to test ambiences. The tool associated with this solution is located in folder
Tools/VoxAmbienceCreator/TestAmbience.exe of the vox repository (located at
https://terminus.mdc.gameloft.org/vc/vox/official_release/1_0/vox).


Notes
=====

1) The Ambience plugin only provides the application with the (random) times at which
   sounds (or events) must be triggered and a random position offset to apply to the
   actual sound. Other parameters (such as volume or pitch) must be controlled by the
   application (e.g. through information from the SDD when using the Vox XML SoundPack).
2) Since the application is responsible for creating and managing data sources and
   emitters, the Ambience playback methods (Play, Stop, Pause, Resume) do not have
   any effect on the actual sounds. For example, calling the Ambience::Pause() method
   doesn't pause the sounds. The Ambience object merely dismisses the time span between
   a Pause() and a Resume() call so that if an event was supposed to be triggered in 10
   seconds and a Pause occurs 6 seconds later, then the event will be triggered 4 seconds
   after a Resume() call.
3) It is possible to use the Ambience plugin without the Vox XML SoundPack.
  

History
=======

September 28, 2011
by Robert Houde
- Initial release

October 5, 2011
by Robert Houde
- Added content related to .vxa files (vox ambience files)

October 26, 2011
by Robert Houde
- Changed content in relation to version 2.0 of the plugin.
- Removed 'sample code' and forwarded reader to the location of a sample
  application used to test ambiences.
