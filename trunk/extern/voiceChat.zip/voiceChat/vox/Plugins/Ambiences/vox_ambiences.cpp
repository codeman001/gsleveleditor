#include "vox_ambiences_internal.h"
#include "vox_macro.h"
#include <math.h>

#define MAX_ANGLE				6.28318530718f	// 2 * PI
#define TIME_RESOLUTION			0.000001f		// Interval under which two time values are considered equal.

extern vox::f64 _GetTime();

namespace vox
{

bool c8stringcompare::operator() (const c8* lhs, const c8* rhs) const
{
#if defined(_WIN32)
	if(_stricmp(lhs, rhs) < 0)
#else
	if(strcasecmp(lhs, rhs) < 0)		
#endif
		return true;
	return false;
}

//*** AmbienceFileParams ***//

AmbienceFileParams::AmbienceFileParams()
:m_backgroundSoundLabel(0)
{
}

AmbienceFileParams::AmbienceFileParams(const AmbienceFileParams &ambienceParams)
:m_backgroundSoundLabel(0)
{
	// Allocate memory for background sound label
	if(ambienceParams.m_backgroundSoundLabel)
	{
		m_backgroundSoundLabel = (c8*) VOX_ALLOC(strlen(ambienceParams.m_backgroundSoundLabel) + 1);

		if(m_backgroundSoundLabel)
		{
			strcpy(m_backgroundSoundLabel, ambienceParams.m_backgroundSoundLabel);
		}
		else
		{
			VOX_WARNING_LEVEL_2("Could not allocate memory to handle background sound label %s.", ambienceParams.m_backgroundSoundLabel);
		}
	}

	m_randomNoRepeatCount = ambienceParams.m_randomNoRepeatCount;
	m_randomMinTime = ambienceParams.m_randomMinTime;
	m_randomMaxTime = ambienceParams.m_randomMaxTime;
	m_minDistance = ambienceParams.m_minDistance;
	m_maxDistance = ambienceParams.m_maxDistance;

	// Copy (labels, timeOffset) map
	VOX_MAP<c8*, f32, c8stringcompare, SAllocator<std::pair<const c8*,f32> > >::const_iterator it = ambienceParams.m_labels.begin();
	VOX_MAP<c8*, f32, c8stringcompare, SAllocator<std::pair<const c8*,f32> > >::const_iterator end = ambienceParams.m_labels.end();

	for(; it != end; it++)
	{
		s32 labelLength = strlen(it->first);
		c8* label = (c8*) VOX_ALLOC(labelLength + 1);
		if(label)
		{
			strcpy(label, it->first);
			label[labelLength] = 0;
			m_labels[label] = it->second;
		}
		else
		{
			VOX_WARNING_LEVEL_2("Could not allocate memory to handle sfx label %s.", it->first);
		}
	}
}

AmbienceFileParams::~AmbienceFileParams()
{
#if defined(_NN_CTR)
	VOX_MAP<c8*, f32, c8stringcompare>::iterator it = m_labels.begin();
	VOX_MAP<c8*, f32, c8stringcompare>::iterator end = m_labels.end();
#else
	VOX_MAP<c8*, f32, c8stringcompare, SAllocator<std::pair<const c8*,f32> > >::iterator it = m_labels.begin();
	VOX_MAP<c8*, f32, c8stringcompare, SAllocator<std::pair<const c8*,f32> > >::iterator end = m_labels.end();
#endif

	// Release memory used for label strings	
	for(; it != end; it++)
	{
		VOX_FREE(it->first);
	}

	m_labels.clear();

	// Release memory used for background sound label
	if(m_backgroundSoundLabel)
	{
		VOX_FREE(m_backgroundSoundLabel);
		m_backgroundSoundLabel = 0;
	}
}

//*** AmbienceInternal ***//

AmbienceFileReader *AmbienceInternal::s_pAmbienceReader = 0;
bool AmbienceInternal::s_isFileValid = false;

bool AmbienceInternal::LoadAmbiences(const c8 *fileName)
{
	s_isFileValid = false;

	if(!s_pAmbienceReader)
	{
		s_pAmbienceReader = VOX_NEW AmbienceFileReader();
	}

	if(s_pAmbienceReader)
	{
		s_pAmbienceReader->Unload();
		s_isFileValid = s_pAmbienceReader->Load(fileName);
	}

	return s_isFileValid;
}

void AmbienceInternal::UnloadAmbiences(void)
{
	if(s_pAmbienceReader)
	{
		VOX_DELETE(s_pAmbienceReader);
		s_pAmbienceReader = 0;
	}
	s_isFileValid = false;
}

AmbienceInternal::AmbienceInternal(AmbienceParams *pParams):
m_pFileParams(0)
,m_currentLabel(0)
,m_isValid(false)
,m_currentState(AMBIENCE_STATE_INITIAL)
,m_bypassMinTime(true)
,m_lastPositionOffsetX(0.0f)
,m_lastPositionOffsetY(0.0f)
,m_lastPositionOffsetZ(0.0f)
{	
	if(s_isFileValid)
	{
		if(pParams->m_label)
		{
			m_isRelativeToListener = pParams->m_isRelativeToListener;
			m_ambienceCallback = pParams->m_ambienceCallback;
			m_pCallbackCustomParam = pParams->m_callbackCustomParam;

			// Get the ambience file parameters
			AmbienceFileParams *pFileParams = s_pAmbienceReader->GetParameters(pParams->m_label);
			if(pFileParams)
			{
				m_pFileParams = VOX_NEW AmbienceFileParams(*pFileParams);

				size_t maxLabelLength = 0;
				size_t currentLabelLength;
				if(m_pFileParams)
				{
					// Fill active elements vector with all ambience labels (except for the backgroud sound).
					VOX_MAP<c8*, f32, c8stringcompare, SAllocator<std::pair<const c8*,f32> > >::iterator it = m_pFileParams->m_labels.begin();
					VOX_MAP<c8*, f32, c8stringcompare, SAllocator<std::pair<const c8*,f32> > >::iterator end = m_pFileParams->m_labels.end();

					for(; it != end; it++)
					{	
						m_activeElements.push_back(it->first);
						currentLabelLength = strlen(it->first);
						if(currentLabelLength > maxLabelLength)
						{
							maxLabelLength = currentLabelLength;
						}
					}
					
					// Allocate memory to contain current label
					m_currentLabel = (c8*) VOX_ALLOC(maxLabelLength + 1);
					if(!m_currentLabel)
					{
						VOX_WARNING_LEVEL_2("Could not allocate memory to handle current label of ambience %s.", pParams->m_label);
						return;
					}

					m_isValid = true;
				}
			}
		}
	}
}

AmbienceInternal::~AmbienceInternal()
{
	// Clear data structures used for random selection of labels
	m_activeElements.clear();
	m_usedElements.clear();

	// Release file informations
	if(m_pFileParams)
	{
		VOX_DELETE(m_pFileParams);
		m_pFileParams = 0;
	}

	if(m_currentLabel)
	{
		VOX_FREE(m_currentLabel);
		m_currentLabel = 0;
	}
}

void AmbienceInternal::GetLastPositionOffset(f32 &x, f32 &y, f32 &z)
{
	x = m_lastPositionOffsetX;
	y = m_lastPositionOffsetY;
	z = m_lastPositionOffsetZ;
}

bool AmbienceInternal::IsValid()
{
	return m_isValid;
}

void AmbienceInternal::Pause()
{
	ScopeMutex sm(&m_mutex);

	if(!m_isValid)
		return;

	if(m_currentState == AMBIENCE_STATE_PLAYING)
	{
		m_currentState = AMBIENCE_STATE_PAUSED;
		m_pauseTime = _GetTime();
	}
}

void AmbienceInternal::Play()
{
	ScopeMutex sm(&m_mutex);

	if(!m_isValid)
		return;

	// Get start time of ambience
	m_previousTriggerTime = _GetTime();

	// Set min time for next trigger to 0.0f and calculate time interval before next trigger
	m_bypassMinTime = true;
	SetNextTriggerTimeInterval();

	if(m_currentState == AMBIENCE_STATE_INITIAL)
	{
		if(m_pFileParams->m_backgroundSoundLabel)
		{
			m_ambienceCallback(m_pFileParams->m_backgroundSoundLabel, 0.0f, 0.0f, 0.0f, m_isRelativeToListener, m_pCallbackCustomParam);
		}
	}
	else if(m_currentState == AMBIENCE_STATE_PAUSED)
	{
		Resume();
	}

	m_currentState = AMBIENCE_STATE_PLAYING;
}

void AmbienceInternal::Stop()
{
	ScopeMutex sm(&m_mutex);

	if(!m_isValid)
		return;

	if(m_currentState == AMBIENCE_STATE_PLAYING || m_currentState == AMBIENCE_STATE_PAUSED)
	{
		m_currentState = AMBIENCE_STATE_STOPPED;
	}
}

void AmbienceInternal::Resume()
{
	ScopeMutex sm(&m_mutex);

	if(!m_isValid)
		return;

	if(m_currentState == AMBIENCE_STATE_PAUSED)
	{
		m_currentState = AMBIENCE_STATE_PLAYING;

		// Update the previous trigger time to account for time during which Ambience was paused. 
		m_previousTriggerTime += _GetTime() - m_pauseTime;
	}
}

void AmbienceInternal::Update()
{
	ScopeMutex sm(&m_mutex);

	if(!m_isValid)
		return;

	// Trigger event when time interval is done.
	if(m_currentState == AMBIENCE_STATE_PLAYING)
	{
		f64 currentTime = _GetTime();
		if(currentTime - m_previousTriggerTime > (f64) m_interTriggerTime)
		{
			f32 x, y, z;

			// Get the label of the sound (or event) to be triggered.
			c8 *randomLabel = GetRandomLabel();

			if(!randomLabel)
				return;

			strcpy(m_currentLabel, randomLabel);

			// Get a random position offset for the sound (or event) to be triggered.
			GetRandomPositionOffset(x, y, z);

			// Call the user callback function so that it can trigger actual sound (or event)
			m_ambienceCallback(m_currentLabel, x, y, z, m_isRelativeToListener, m_pCallbackCustomParam);

			// Determine the time interval between now and the next triggering of a sound (or event).
			SetNextTriggerTimeInterval();
			m_previousTriggerTime = currentTime;
		}
	}
}

c8* AmbienceInternal::GetRandomLabel()
{
	c8 *randomLabel;

	u32 nbActiveElements = m_activeElements.size();

	if(nbActiveElements <= 0)
		return 0;

	u32 position = rand() % nbActiveElements;
	randomLabel = m_activeElements[position];

	if(m_pFileParams->m_randomNoRepeatCount > 0)
	{
		// Send the element in "penalty"
		m_usedElements.push_back(m_activeElements[position]);
		m_activeElements[position] = m_activeElements[nbActiveElements-1];
		m_activeElements.pop_back();

		// If penalty box full, sent the oldest back to active elements
		if((s32)m_usedElements.size() > m_pFileParams->m_randomNoRepeatCount)
		{
			m_activeElements.push_back(m_usedElements.front());
			m_usedElements.pop_front();
		}
	}

	return randomLabel;
}

void AmbienceInternal::SetNextTriggerTimeInterval()
{
	f32 randomMinTime = m_pFileParams->m_randomMinTime;
	f32 timeOffset = 0.0f;

	// TODO : Account for current label time offset to fix next time interval
#if defined(_NN_CTR)
	VOX_MAP<c8*, f32, c8stringcompare>::iterator it = m_pFileParams->m_labels.find(m_currentLabel);
#else
	VOX_MAP<c8*, f32, c8stringcompare, SAllocator<std::pair<const c8*,f32> > >::iterator it = m_pFileParams->m_labels.find(m_currentLabel);
#endif

	if(it != m_pFileParams->m_labels.end())
	{
		timeOffset = m_pFileParams->m_labels[m_currentLabel];
	}

	// When Ambience is played, the minimum time before triggering an event is forced to 0.
	if(m_bypassMinTime)
	{
		randomMinTime = 0.0f;
		m_bypassMinTime = false;
	}

	f32 timeInterval = m_pFileParams->m_randomMaxTime - randomMinTime;

	// Get the time interval before the next trigger
	if(timeInterval >= TIME_RESOLUTION)
	{
		f32 randomValue = (f32) rand() / (f32) RAND_MAX;				// Random value between 0.0f and 1.0f.
		m_interTriggerTime = timeOffset + randomMinTime + timeInterval * randomValue;
	}
	else // Min and max times are considered equal.
	{
		m_interTriggerTime = timeOffset + randomMinTime;
	}
}

void AmbienceInternal::GetRandomPositionOffset(f32 &x, f32 &y, f32 &z)
{
	if(m_pFileParams->m_maxDistance > 0.0f)
	{
		// Calculate random distance from origin
		f32 randomValue = (f32) rand() / (f32) RAND_MAX;							// Random between 0.0f and 1.0f.
		f32 radius = m_pFileParams->m_minDistance + randomValue * (m_pFileParams->m_maxDistance - m_pFileParams->m_minDistance);

		// Calculate random angle
		randomValue = (f32) rand() / (f32) RAND_MAX;
		f32 angle = randomValue * MAX_ANGLE;

		// Convert random position in cartesian coordinates
		x = radius * cos(angle);
		y = radius * sin(angle);
	}
	else // Maximum distance is 0.
	{
		x = 0.0f;
		y = 0.0f;
	}
	
	z = 0.0f; // Random position offsets are located on a plane.

	m_lastPositionOffsetX = x;
	m_lastPositionOffsetY = y;
	m_lastPositionOffsetZ = z;
}


//*** AmbienceFileReader ***//

AmbienceFileReader::AmbienceFileReader()
{
}

AmbienceFileReader::~AmbienceFileReader()
{
	Unload();
}

bool AmbienceFileReader::Load(const c8* fileName)
{
	FileSystemInterface *pFileSystem = FileSystemInterface::GetInstance();

	if(!pFileSystem)
		return false;

	FileInterface *pFile = pFileSystem->OpenFile((c8 *) fileName, k_nReadBinary);

	if(!pFile)
		return false;

	c8 tempString[64];

	// Get the chunk header name
	pFile->Read((void *) tempString, 4, 1);
	tempString[4] = 0;

	if(strcmp(tempString, "voxa") != 0)
	{
		VOX_WARNING_LEVEL_2("File %s has incorrect format.", fileName);
		pFileSystem->CloseFile(pFile);
		return false;
	}
	
	// Get the chunk header size
	s32 intValue;
	pFile->Read(&intValue, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
	ChangeIntEndianness(intValue);
#endif

	// Get the file version number
	pFile->Read((void *) tempString, intValue, 1);
	tempString[intValue] = 0;

	if(strcmp(tempString, "v2.0.0") != 0)
	{
		VOX_WARNING_LEVEL_2("File %s is of an unsupported version.", fileName);
		pFileSystem->CloseFile(pFile);
		return false;
	}

	// Get the data header name
	pFile->Read((void *) tempString, 4, 1);
	tempString[4] = 0;

	if(strcmp(tempString, "data") != 0)
	{
		VOX_WARNING_LEVEL_2("Data chunk not found. File %s is invalid !", fileName);
		pFileSystem->CloseFile(pFile);
		return false;
	}

	// Get the data chunk size
	intValue;
	pFile->Read(&intValue, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
	ChangeIntEndianness(intValue);
#endif

	// Get the number of ambiences in the data chunk
	s32 nbAmbiences;
	pFile->Read(&nbAmbiences, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
	ChangeIntEndianness(nbAmbiences);
#endif

	for(s32 i = 0; i < nbAmbiences; i++)
	{
		AmbienceFileParams *pAmbienceFileParams = VOX_NEW AmbienceFileParams();

		// Get the length of the ambience label
		intValue;
		pFile->Read(&intValue, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(intValue);
#endif

		// Get the ambience label
		c8* ambienceLabel = (c8*) VOX_ALLOC(intValue + 1);
		if(ambienceLabel)
		{
			pFile->Read(ambienceLabel, intValue, 1);
			ambienceLabel[intValue] = 0;
		}
		else
		{
			VOX_DELETE(pAmbienceFileParams);
			pFileSystem->CloseFile(pFile);
			VOX_WARNING_LEVEL_2("%s", "Could not allocate memory to handle label for some ambiences");
			return false;
		}

		// Get the length of the background sound label
		intValue;
		pFile->Read(&intValue, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(intValue);
#endif

		// Get the background sound label
		if(intValue > 0)
		{
			// Allocate memory for background sound label
			pAmbienceFileParams->m_backgroundSoundLabel = (c8*) VOX_ALLOC(intValue + 1);
			if(pAmbienceFileParams->m_backgroundSoundLabel)
			{
				pFile->Read(pAmbienceFileParams->m_backgroundSoundLabel, intValue, 1);
				pAmbienceFileParams->m_backgroundSoundLabel[intValue] = 0;
			}
			else // Seek passed the background label in file
			{
				pFile->Seek(intValue, k_nSeekCur);
				VOX_WARNING_LEVEL_2("Could not allocate memory to handle background sound label for ambience %s.", ambienceLabel);
			}
		}

		// Get the random no repeat count
		pFile->Read(&pAmbienceFileParams->m_randomNoRepeatCount, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(pAmbienceFileParams->m_randomNoRepeatCount);
#endif

		// Get the ambience inter event minimum time.
		pFile->Read(&pAmbienceFileParams->m_randomMinTime, sizeof(f32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(pAmbienceFileParams->m_randomMinTime);
#endif

		// Get the ambience inter event maximum time.
		pFile->Read(&pAmbienceFileParams->m_randomMaxTime, sizeof(f32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(pAmbienceFileParams->m_randomMaxTime);
#endif

		// Get the ambience minimum distance offset.
		pFile->Read(&pAmbienceFileParams->m_minDistance, sizeof(f32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(pAmbienceFileParams->m_minDistance);
#endif

		// Get the ambience maximum distance offset.
		pFile->Read(&pAmbienceFileParams->m_maxDistance, sizeof(f32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(pAmbienceFileParams->m_maxDistance);
#endif

		// Get the number of labels in current ambience
		int nbLabels;
				pFile->Read(&nbLabels, sizeof(s32), 1);
		#if VOX_BIG_ENDIAN
				ChangeIntEndianness(nbLabels);
		#endif

		// Limit no repeat count to the number of labels - 1
		if(pAmbienceFileParams->m_randomNoRepeatCount >= nbLabels)
		{
			pAmbienceFileParams->m_randomNoRepeatCount = nbLabels - 1;
		}

		// Get ambience labels and their time offset
		float floatValue;
		for(s32 k = 0; k < nbLabels; k++)
		{
			// Get the length of the label
			intValue;
			pFile->Read(&intValue, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
			ChangeIntEndianness(intValue);
#endif

			if(intValue > 0)
			{
				// Get the sound (or event) label
				c8* label = (c8*)VOX_ALLOC(intValue + 1);
				if(label)
				{
					pFile->Read((void *) label, intValue, 1);
					label[intValue] = 0;

					// Get the time offset
					pFile->Read(&floatValue, sizeof(f32), 1);
#if VOX_BIG_ENDIAN
					ChangeIntEndianness(floatValue);
#endif

					pAmbienceFileParams->m_labels[label] = floatValue;
				}
				else // Seek passed the current label and its time offset
				{
					pFile->Seek(intValue + sizeof(f32), k_nSeekCur);
					VOX_WARNING_LEVEL_2("Could not allocate memory to handle some sound labels for ambience %s.", ambienceLabel);
				}
			}
		}

		// Add ambience infos into map
		m_ambienceInfos[ambienceLabel] = pAmbienceFileParams;
	}

	pFileSystem->CloseFile(pFile);

	return true;
}

void AmbienceFileReader::Unload(void)
{
#if defined(_NN_CTR)
	VOX_MAP<c8*, AmbienceFileParams*, c8stringcompare>::iterator it = m_ambienceInfos.begin();
	VOX_MAP<c8*, AmbienceFileParams*, c8stringcompare>::iterator end = m_ambienceInfos.end();
#else
	VOX_MAP<c8*, AmbienceFileParams*, c8stringcompare, SAllocator<std::pair<const c8*,AmbienceFileParams*> > >::iterator it = m_ambienceInfos.begin();
	VOX_MAP<c8*, AmbienceFileParams*, c8stringcompare, SAllocator<std::pair<const c8*,AmbienceFileParams*> > >::iterator end = m_ambienceInfos.end();
#endif

	for(; it != end; it++)
	{
		VOX_FREE(it->first);	// Release memory used for the ambience label.
		VOX_DELETE(it->second);	// Release memory used for the ambience file parameters.
	}

	m_ambienceInfos.clear();
}

AmbienceFileParams *AmbienceFileReader::GetParameters(const c8 *ambienceLabel)
{
	if(ambienceLabel)
	{
#if defined(_NN_CTR)
	VOX_MAP<c8*, AmbienceFileParams*, c8stringcompare>::iterator it = m_ambienceInfos.find((c8*)ambienceLabel);
#else
	VOX_MAP<c8*, AmbienceFileParams*, c8stringcompare, SAllocator<std::pair<const c8*,AmbienceFileParams*> > >::iterator it = m_ambienceInfos.find((c8*)ambienceLabel);
#endif
	if(it != m_ambienceInfos.end())
		return  it->second;
	}

	return 0;
}


Ambience::Ambience(vox::AmbienceParams *pParams)
{
	data = VOX_NEW AmbienceInternal(pParams);
}

Ambience::~Ambience()
{
	if(data)
		VOX_DELETE(data);
	data = 0;
}

bool Ambience::LoadAmbiences(const c8 *fileName)
{
	return AmbienceInternal::LoadAmbiences(fileName);
}

void Ambience::UnloadAmbiences()
{
	return AmbienceInternal::UnloadAmbiences();
}

void Ambience::GetLastPositionOffset(f32 &x, f32 &y, f32 &z)
{
	if(!data)
	{
		x = 0; // Set to 0 to make sure user doesn't end up with NaN and stuff like that
		y = 0;
		z = 0;
		VOX_WARNING_LEVEL_2("Ambiences internal class missing!", 0);
		return;		
	}

	data->GetLastPositionOffset(x, y, z);
}

bool Ambience::IsValid()
{
	if(!data)
		return false;
	return data->IsValid();
}

void Ambience::Pause()
{
	if(!data)
	{
		VOX_WARNING_LEVEL_2("Ambiences internal class missing!", 0);
		return;
	}
	data->Pause();
}

void Ambience::Play()
{
	if(!data)
	{
		VOX_WARNING_LEVEL_2("Ambiences internal class missing!", 0);
		return;
	}
	data->Play();
}

void Ambience::Stop()
{
	if(!data)
	{
		VOX_WARNING_LEVEL_2("Ambiences internal class missing!", 0);
		return;
	}
	data->Stop();
}

void Ambience::Resume()
{
	if(!data)
	{
		VOX_WARNING_LEVEL_2("Ambiences internal class missing!", 0);
		return;
	}
	data->Resume();
}

void Ambience::Update()
{
	if(!data)
	{
		VOX_WARNING_LEVEL_2("Ambiences internal class missing!", 0);
		return;
	}
	data->Update();
}

} // namespace vox
