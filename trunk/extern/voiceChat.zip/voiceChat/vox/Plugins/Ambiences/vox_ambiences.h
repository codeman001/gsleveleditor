#pragma once
#ifndef _VOX_AMBIENCES_H_
#define _VOX_AMBIENCES_H_

#include "vox_types.h"

namespace vox
{

class AmbienceInternal;

typedef void (*VoxAmbienceCallbackFunc) (const c8* label, f32 x, f32 y, f32 z, bool relativeToListener, void *customParam); 

// Contains Ambience parameters provided by user
struct AmbienceParams
{
	const c8* m_label;							// Label of the ambience to create.
	bool m_isRelativeToListener;				// Info passed back to the callback.
	VoxAmbienceCallbackFunc m_ambienceCallback;	// Address of callback function called to trigger event or sound.
	void *m_callbackCustomParam;				// Info passed back to the callback.
};

class Ambience
{
public:
	Ambience(AmbienceParams *pParams);
	~Ambience();

	static bool LoadAmbiences(const c8 *fileName);
	static void UnloadAmbiences(void);

	void GetLastPositionOffset(f32 &x, f32 &y, f32 &z);
	bool IsValid();
	void Pause();
	void Play();
	void Stop();
	void Resume();
	void Update();

private:
	AmbienceInternal *data;
	
};

} // namespace vox

#endif // _VOX_AMBIENCES_H_
