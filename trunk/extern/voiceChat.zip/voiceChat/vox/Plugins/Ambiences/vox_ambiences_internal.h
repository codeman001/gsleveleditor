#pragma once
#ifndef _VOX_AMBIENCES_INTERNAL_H_
#define _VOX_AMBIENCES_INTERNAL_H_

#include "vox_ambiences.h"

#define VOX_INTERNAL_CODE

#include "vox_default_config.h"
#include "vox_mutex.h"
#include "vox_filesystem.h"
#include VOX_MAP_INCLUDE
#include VOX_VECTOR_INCLUDE
#include VOX_LIST_INCLUDE

#define BACKGROUND_LABEL_MAX_LENGTH 64

namespace vox
{


struct c8stringcompare
{
  bool operator() (const c8* lhs, const c8* rhs) const;
};

// Contains Ambience parameters provided by vxa file
struct AmbienceFileParams
{
	c8 *m_backgroundSoundLabel;	// Label of a sound to trigger at Play() time.
	s32 m_randomNoRepeatCount;	// Nb of triggers during which a sound is in penalty after playing (between 0 and nbLabels-1).
	f32 m_randomMinTime;		// Minimum time between current and previous sfx triggering.
	f32 m_randomMaxTime;		// Maximum time between current and previous sfx triggering.
	f32 m_minDistance;			// Minimum distance of the random position offset from origin.
	f32 m_maxDistance;			// Maximum distance of the random position offset from origin.

	VOX_MAP<c8*, f32, c8stringcompare, SAllocator<std::pair<const c8*,f32> > > m_labels;

	AmbienceFileParams();
	AmbienceFileParams(const AmbienceFileParams &ambienceParams);
	~AmbienceFileParams();
};


class AmbienceFileReader
{
 public:
	 AmbienceFileReader();
	~AmbienceFileReader();

	AmbienceFileParams *GetParameters(const c8 *ambienceLabel);
	bool Load(const c8* fileName);
	void Unload(void);					// Unloads current file
 private:
	VOX_MAP<c8*, AmbienceFileParams*, c8stringcompare, SAllocator<std::pair<const c8*,AmbienceFileParams*> > > m_ambienceInfos;

	inline void ConvertUnsignedIntToBE(u32 &value)
	{
		value = (value >> 24) | ((value >> 8) & 0x0000FF00) | ((value << 8) & 0x00FF0000) | (value << 24);
	}

	inline void ChangeIntEndianness(s32 &value)
	{
		u32 unsignedValue = static_cast<u32> (value);
		ConvertUnsignedIntToBE(unsignedValue);
		value = static_cast<s32> (unsignedValue);
	}
};

class AmbienceInternal
{
 public:
	AmbienceInternal(AmbienceParams *pParams);
	~AmbienceInternal();

	static bool LoadAmbiences(const c8 *fileName);
	static void UnloadAmbiences(void);

	void GetLastPositionOffset(f32 &x, f32 &y, f32 &z);
	bool IsValid();
	void Pause();
	void Play();
	void Stop();
	void Resume();
	void Update();
 private:
	enum
	{
		AMBIENCE_STATE_ERROR = -1,
		AMBIENCE_STATE_INITIAL,
		AMBIENCE_STATE_PLAYING,
		AMBIENCE_STATE_PAUSED,
		AMBIENCE_STATE_STOPPED
	};
	
	static AmbienceFileReader *s_pAmbienceReader;
	static bool s_isFileValid;

	AmbienceFileParams *m_pFileParams; // Ambience parameters gotten from the .vxa file.

	VOX_VECTOR<c8*, SAllocator<c8*> > m_activeElements; // Labels that can be chosen by random selection.
	VOX_LIST<c8*, SAllocator<c8*> > m_usedElements;		// Labels that cannot be chosen by random selection.

	c8 *m_currentLabel;				// Label of the sound (or event) to trigger
	bool m_isValid;					// True if ambience has been created correctly.
	s32 m_currentState;				// Playback state (AMBIENCE_STATE_PLAYING, ...)
	bool m_bypassMinTime;			// True -> use m_randomMinTime = 0 on first trigger (after Play)

	// Position parameters
	bool m_isRelativeToListener;	// Just passes back in callback the value transmitted by application.
	f32 m_lastPositionOffsetX;		// 'x' position value generated during last sound (or event) triggering.
	f32 m_lastPositionOffsetY;		// 'y' position value generated during last sound (or event) triggering.
	f32 m_lastPositionOffsetZ;		// 'z' position value generated during last sound (or event) triggering.

	// Time parameters
	f64 m_previousTriggerTime;		// Time at which the last event was triggered
	f64 m_pauseTime;				// Current time at which ambience was paused
	f32 m_interTriggerTime;			// Time interval before triggering next sfx.

	// Callback function
	VoxAmbienceCallbackFunc m_ambienceCallback; // Address of callback function called to trigger event or sound.
	void *m_pCallbackCustomParam;				// Param gotten from application and returned in callback function.

	Mutex m_mutex;

	c8* GetRandomLabel();
	void GetRandomPositionOffset(f32 &x, f32 &y, f32 &z);
	void SetNextTriggerTimeInterval();
};


}

#endif // _VOX_AMBIENCES_H_
