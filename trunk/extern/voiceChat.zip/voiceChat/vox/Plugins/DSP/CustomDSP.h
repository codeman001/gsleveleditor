#pragma once
#ifndef _CUSTOM_DSP_H_
#define _CUSTOM_DSP_H_


#include "vox_custom_dsp.h"

namespace vox
{

// **************************************************************************************** //
// ************************************* ReverbHQ class *********************************** //
// **************************************************************************************** //

class FileInterface;

class ReverbHQParameters
{
public:
	// Density: Affects density of the late reverb impulse response. A smaller value provides a greater
	// density in the sense that more impulses are present in the impulse response.
	float Density;

	// Diffusion: Affects the intensity of impulses in late reverb impulse response (but not their position).
	// A small value attenuates most of the impulses while increasing a few (leading to an echo-like effect).
	// Values greater than cubic root of 3 make no sense. Default value is 1.0.
	float Diffusion;

	float GainHF;		// Gain of the master lowpass filter
	float HFReference;	// Cutoff frequency of the master lowpass filter (in Hz)
	float DecayTime;	// Time interval (in seconds) at which late reverb drops at -60dB from signal. 

	// DecayHFRatio: Affects the response of the high frequency response of the late reverb. A smaller value
	// means less high frequency content.
	float DecayHFRatio;

	// DecayHFLimit: When true, the HFRatio is limited to a value dependent upon AirAbsorptionGainHF. Value
	// provided by DecayHFRatio then has no impact.
	bool DecayHFLimit;

	// AirAbsorptionGainHF: When DecayHFLimit is true, this parameter is used to set the value of the HFRatio.
	// A smaller value decreases the high frequency response of the late reverb. Valid values : [0.0, 1.0[
	float AirAbsorptionGainHF;

	float Gain;						// Gain common to early reflections and late reverb (applied on their respective gains).
	float EarlyReflectionsGain;		// Early reflections gain factor (the effective gain also involves parameter Gain).
	float EarlyReflectionsDelay;	// Time between signal and first reflection (in seconds)
	float LateReverbGain;			// Late reverb gain factor (the effective gain also involves parameter Gain and a mix coefficient factor).
	float LateReverbDelay;			// Time between first reflection and start of late reverb (in seconds)

	float Dry;
	float Wet;

	char Name[29];

	ReverbHQParameters(void);
	~ReverbHQParameters(void);
	bool loadReverbSettings(vox::FileInterface *pFile);

};

class ReverbHQPresetBank
{
public:
	ReverbHQPresetBank();
	bool loadBank(const char *filename);
	~ReverbHQPresetBank();
	bool getPreset(int index, ReverbHQParameters *output);
	bool getPresetByName(const char *name, ReverbHQParameters *output);

private:
	int numPatches;
	ReverbHQParameters *patches;

};


class ReverbHQC;
class ReverbHQNeon;

class ReverbHQ : public vox::CustomDSP
{
private:
	ReverbHQC *reverbC;
	ReverbHQNeon *reverbNeon;

public:
	ReverbHQ();
	virtual ~ReverbHQ(void);

	virtual bool ConnectToBus(float sampleRate, int channels, int flags);
	virtual void Update(const int *input, int *output, int nbSamples);
	virtual bool WillOutput(bool hasInput);
	void SetParameters(ReverbHQParameters *parameters, float fadeTime);
	bool LoadParameterBank(const char *filename);
	bool SetBankPresetByName(const char *name, float fadeTime);

};


} // namespace vox


#endif // _CUSTOM_DSP_H_
