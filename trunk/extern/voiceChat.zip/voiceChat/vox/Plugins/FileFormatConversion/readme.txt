////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Plugin                            //
//                                                                            //
//                             File Format Converter                          //
//                                                                            //
//                                Robert Houde                                //
//                             (c)2011 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This plugin is a basic audio file format converter. It can convert Wav PCM, 
Wav ADPCM, MPC and Ogg-Vorbis files into a Wav PCM file format. It doesn't
perform resampling however and only works on little endian platforms. This
implementation has been tested on Windows XP with Visual Studio and on iPhone.

The following path must be added to the include paths of the project including
the plugin.

{path to vox}\Plugins\FileFormatConversion

The plugin is composed of a single static method ConvertToWavPCM(), converting a
single file at a time and taking the input and output (full path) filenames as
(char*) arguments. A code sample is provided below:

[Code Sample]

[...]
#include "vox_file_format_conversion.h"
[...]
	vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
	vox.Initialize();

	int error = vox::FileFormatConversion::ConvertToWavPCM(inputFile, outputFile);
	if(error < 0)
	{
			printf("Error in file conversion, %d\n", error);
      if(error == VOX_FILE_CONVERSION_OUTFILE_INVALID)
			{
        // PUT CODE HERE TO DELETE THE OUTPUT FILE
      }
	}			
  
[...]

[\Code Sample]

Method ConvertToWavPCM() returns 0 on success and a negative value on failure.
The returned value is taken from the VOX_FILE_CONVERSION... error codes defined
in file_format_conversion.h .

IMPORTANT NOTE: The application is responsible of deleting output files that
                have not been constructed correctly. When this happens, the plugin
                invalidates the file (it won't play) and returns the negative
                value VOX_FILE_CONVERSION_OUTFILE_INVALID, but doesn't delete
                the file. If the return value is negative but different from
                VOX_FILE_CONVERSION_OUTFILE_INVALID, then the output file has
                not been created at all, so there is no need to delete it.
  
  
History
=======

March 11th, 2011
by Robert Houde
- Initial release
