#include "vox_file_format_conversion.h"

#define VOX_INTERNAL_CODE

#include <vox_stream_cfile.h>
#include <vox_decoder_mswav.h>
#include <vox_decoder_mpc8.h>
#include <vox_decoder_stbvorbis.h>

#define TRANSFER_BUFFER_SIZE (64*1024)

namespace vox
{

s32 FileFormatConversion::ConvertToWavPCM(char *infile, char *outfile)
{
	// Generate buffer for data transfer
	u32 bufferSize = TRANSFER_BUFFER_SIZE;
	s16 *pBuffer = (s16*) VOX_ALLOC(bufferSize);

	if(!pBuffer)
	{
		return VOX_FILE_CONVERSION_BUFFER_NOT_CREATED;
	}

	// Get stream for input file
	StreamCFile stream(infile);
	StreamCursorInterface* psCursor = stream.CreateNewCursor();

	if(!psCursor)
	{
		VOX_FREE(pBuffer);
		return VOX_FILE_CONVERSION_INFILE_NOT_OPENED;
	}
	
	// Get input file extension
	const c8* ext = strrchr(infile, '.');
	if(ext == 0)
	{
		VOX_FREE(pBuffer);
		stream.DestroyCursor(psCursor);
		return VOX_FILE_CONVERSION_UNSUPPORTED_FORMAT;
	}
		
	ext++;						//skip '.'
	VOX_STRING fileext(ext);

	for(u32 i = 0; i < strlen(ext); i++)
	{
		fileext[i] = fileext[i] < 97 ? fileext[i] + 32 : fileext[i];
	}

	// Get appropriate decoder (depending on input file extension)
	DecoderInterface *pDecoder = 0;

	if(fileext == "wav")
	{
		pDecoder = DecoderMSWavFactory(0);
	}
	else if(fileext == "ogg")
	{
		pDecoder = DecoderStbVorbisFactory(0);
	}
	else if(fileext == "mpc")
	{
		pDecoder = DecoderMPC8Factory(0);
	}

	if(!pDecoder)
	{
		VOX_FREE(pBuffer);
		stream.DestroyCursor(psCursor);
		return VOX_FILE_CONVERSION_UNSUPPORTED_FORMAT;
	}

	// Get decoder cursor to decode input file
	DecoderCursorInterface* pdCursor = pDecoder->CreateNewCursor(psCursor);

	if(!pdCursor)
	{
		VOX_FREE(pBuffer);
		stream.DestroyCursor(psCursor);
		return VOX_FILE_CONVERSION_INFILE_PARSING_PROBLEM;
	}

	// Get input file parameters
	s32 bitsPerSample = pdCursor->GetBitsPerSample();
	s32 nbChannels = pdCursor->GetNumChannels();
	s32 nbSamples = pdCursor->GetNumSamples();
	s32 sampleRate = pdCursor->GetSamplingRate();
	s32 nbBytes = nbSamples * nbChannels * 2;
	
	// Get file system and create/open the output file
	FileSystemInterface* pFS = FileSystemInterface::GetInstance();
	if(!pFS)
	{
		VOX_FREE(pBuffer);
		pDecoder->DestroyCursor(pdCursor);
		stream.DestroyCursor(psCursor);
		return VOX_FILE_CONVERSION_OUTFILE_NOT_CREATED;
	}

	FileInterface* pFile = pFS->OpenFile(outfile, k_nCreateReadWriteBinary);

	if(!pFile)
	{
		VOX_FREE(pBuffer);
		pDecoder->DestroyCursor(pdCursor);
		stream.DestroyCursor(psCursor);
		return VOX_FILE_CONVERSION_OUTFILE_NOT_CREATED;
	}

	// Seek at beginning of output file
	pFile->Seek(0, k_nSeekSet);

	s32 writeCount;

	// Write riff block to output file
	RiffHeader riffHeader;
	memcpy(riffHeader.chunkId, "RIFF", 4);
	riffHeader.filesize = nbBytes + 4 + sizeof(FormatHeader) + sizeof(DataHeader);
	memcpy(riffHeader.riffType, "WAVE", 4);
	writeCount = pFile->Write(&riffHeader, sizeof(RiffHeader), 1);
	
	// If write has not succeeded, invalidate file, release ressources and return with error code.
	if(writeCount != 1)
	{
		VOX_FREE(pBuffer);
		pDecoder->DestroyCursor(pdCursor);
		stream.DestroyCursor(psCursor);
		pFile->Seek(0, k_nSeekSet);
		pFile->Write("NULL", 4, 1);
		pFS->CloseFile(pFile);
		return VOX_FILE_CONVERSION_OUTFILE_INVALID;
	}

	// Write fmt block to output file
	FormatHeader formatHeader;
	memcpy(formatHeader.chunkId, "fmt ", 4);
	formatHeader.chunkDataSize = 16;
	formatHeader.compressionCode = 1;						// Pcm format
	formatHeader.numChannels = nbChannels;
	formatHeader.sampleRate = sampleRate;
	formatHeader.significantBitsPerSample = 16;
	formatHeader.avgBytesPerSample = (sampleRate * nbChannels * formatHeader.significantBitsPerSample) >> 3;
	formatHeader.blockAlign = nbChannels << 1;
	writeCount = pFile->Write(&formatHeader, sizeof(FormatHeader), 1);

	// If write has not succeeded, invalidate file, release ressources and return with error code.
	if(writeCount != 1)
	{
		VOX_FREE(pBuffer);
		pDecoder->DestroyCursor(pdCursor);
		stream.DestroyCursor(psCursor);
		pFile->Seek(0, k_nSeekSet);
		pFile->Write("NULL", 4, 1);
		pFS->CloseFile(pFile);
		return VOX_FILE_CONVERSION_OUTFILE_INVALID;
	}

	// Write data header to output file
	DataHeader dataHeader;
	memcpy(dataHeader.chunkId, "data", 4);
	dataHeader.chunkSize = nbBytes;
	writeCount = pFile->Write(&dataHeader, sizeof(DataHeader), 1);

	// If write has not succeeded, invalidate file, release ressources and return with error code.
	if(writeCount != 1)
	{
		VOX_FREE(pBuffer);
		pDecoder->DestroyCursor(pdCursor);
		stream.DestroyCursor(psCursor);
		pFile->Seek(0, k_nSeekSet);
		pFile->Write("NULL", 4, 1);
		pFS->CloseFile(pFile);
		return VOX_FILE_CONVERSION_OUTFILE_INVALID;
	}
	
	// Decode input file in 64k blocks and write data to output file.
	s32 decodedBytes;
	s32 totalBytesRead = 0;
	do
	{
		decodedBytes = pdCursor->Decode((void*) pBuffer, bufferSize);
		writeCount = pFile->Write((void*) pBuffer, sizeof(c8), decodedBytes);
		totalBytesRead += decodedBytes;

		// If write has not succeeded, invalidate file, release ressources and return with error code.
		if(writeCount != decodedBytes)
		{
			VOX_FREE(pBuffer);
			pDecoder->DestroyCursor(pdCursor);
			stream.DestroyCursor(psCursor);
			s32 seekValue = pFile->Seek(0, k_nSeekSet);
			pFile->Write("NULL", 4, 1);
			pFS->CloseFile(pFile);
			return VOX_FILE_CONVERSION_OUTFILE_INVALID;
		}
	}
	while(decodedBytes == bufferSize);

	// If nb of bytes decoded is different from nbBytes gotten from input file infos, rewrite header size infos.
	if(totalBytesRead != nbBytes)
	{
		// Seek to riff chunk size position and rewrite size.
		pFile->Seek(4, k_nSeekSet);
		s32 riffChunkSize = nbBytes + 4 + sizeof(FormatHeader) + sizeof(DataHeader);
		writeCount = pFile->Write(&riffChunkSize, 4, 1);

		// If write has not succeeded, invalidate file, release ressources and return with error code.
		if(writeCount != 1)
		{
			VOX_FREE(pBuffer);
			pDecoder->DestroyCursor(pdCursor);
			stream.DestroyCursor(psCursor);
			pFile->Seek(0, k_nSeekSet);
			pFile->Write("NULL", 4, 1);
			pFS->CloseFile(pFile);
			return VOX_FILE_CONVERSION_OUTFILE_INVALID;
		}

		// Seek to data chunk size position
		pFile->Seek(sizeof(RiffHeader) + sizeof(FormatHeader) + 4, k_nSeekSet);
		writeCount = pFile->Write(&totalBytesRead, 4, 1);

		// If write has not succeeded, invalidate file, release ressources and return with error code.
		if(writeCount != 1)
		{
			VOX_FREE(pBuffer);
			pDecoder->DestroyCursor(pdCursor);
			stream.DestroyCursor(psCursor);
			pFile->Seek(0, k_nSeekSet);
			pFile->Write("NULL", 4, 1);
			pFS->CloseFile(pFile);
			return VOX_FILE_CONVERSION_OUTFILE_INVALID;
		}
	}

	// Destroy cursors, close file and free buffer memory.
	VOX_FREE(pBuffer);
	pDecoder->DestroyCursor(pdCursor);
	stream.DestroyCursor(psCursor);
	pFile->Seek(0, k_nSeekEnd);
	pFS->CloseFile(pFile);

	return VOX_FILE_CONVERSION_NO_ERROR;
}

} // namespace vox
