#pragma once
#ifndef _VOX_FILE_FORMAT_CONVERSION_H_
#define _VOX_FILE_FORMAT_CONVERSION_H_

#include "vox_types.h"

// Error code values
#define VOX_FILE_CONVERSION_OUTFILE_INVALID				-6
#define VOX_FILE_CONVERSION_OUTFILE_NOT_CREATED			-5
#define VOX_FILE_CONVERSION_INFILE_PARSING_PROBLEM		-4
#define VOX_FILE_CONVERSION_UNSUPPORTED_FORMAT			-3
#define VOX_FILE_CONVERSION_INFILE_NOT_OPENED			-2
#define VOX_FILE_CONVERSION_BUFFER_NOT_CREATED			-1
#define VOX_FILE_CONVERSION_NO_ERROR					0

namespace vox
{

class FileFormatConversion
{
 public:
	FileFormatConversion();
	~FileFormatConversion();

	static s32 ConvertToWavPCM(char *infile, char *outfile); // Returns 0 on success and a negative error code on failure.
};

}
#endif // _VOX_FILE_FORMAT_CONVERSION_H_