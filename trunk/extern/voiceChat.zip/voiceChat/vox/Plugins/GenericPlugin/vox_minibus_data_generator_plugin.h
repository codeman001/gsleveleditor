#pragma once
#ifndef _VOX_MINIBUS_DATA_GENERATOR_PLUGIN_H_
#define _VOX_MINIBUS_DATA_GENERATOR_PLUGIN_H_

#include "vox.h"
#include "vox_filter.h"

#define MDGP_MAX_DOPPLER_PITCH		2.9f	// Limit so user*data*doppler max pitch = (2 * (44100 / 32000) * 2.9) * 2^28 doesn't overflow s32.
#define MDGP_MIN_DOPPLER_PITCH		0.001f
#define MDGP_ANGLE_180_DEGREES		180
#define MDGP_NOMINAL_RAMP_INTERVAL	0.003f	// Volume ramping time span when volume changes or starving

#ifndef MDGP_PI
	#define MDGP_PI	3.14159265358979323846264f
#endif

#define MDGP_ENHANCED_3D_DELAY_LENGTH 128

namespace vox
{

class MinibusDataGeneratorPlugin : public MinibusDataGeneratorInterface
{
 public:
	MinibusDataGeneratorPlugin();
	virtual ~MinibusDataGeneratorPlugin();

	virtual void GetData(s32* buffer, s32 nbSample, s32 sampleRate)=0;
};

struct Mdgp3DEnvironmentParams
{
	u32 m_distanceModel;
	f32	m_dopplerFactor;			
	f32	m_speedOfSound;
	u32 m_enhanced3D;		// Used to set (or unset) enhanced3D at runtime.

	Mdgp3DEnvironmentParams();
};

struct Mdgp3DListenerPositioning
{
	VoxVector3f m_position;
	VoxVector3f m_velocity;
	VoxVector3f m_atOrientation;
	VoxVector3f m_upOrientation;

	Mdgp3DListenerPositioning()
	{
		m_position.x = 0.0f;
		m_position.y = 0.0f;
		m_position.z = 0.0f;

		m_velocity.x = 0.0f;
		m_velocity.y = 0.0f;
		m_velocity.z = 0.0f;

		m_atOrientation.x = 0.0f;
		m_atOrientation.y = 0.0f;
		m_atOrientation.z = -1.0f;

		m_upOrientation.x = 0.0f;
		m_upOrientation.y = 1.0f;
		m_upOrientation.z = 0.0f;
	}
};

struct Mdgp3DSourcePositioning
{
	VoxVector3f	m_position;
	VoxVector3f	m_velocity;
	VoxVector3f	m_direction;

	Mdgp3DSourcePositioning()
	{
		m_position.x = 0.0f;
		m_position.y = 0.0f;
		m_position.z = 0.0f;

		m_velocity.x = 0.0f;
		m_velocity.y = 0.0f;
		m_velocity.z = 0.0f;

		m_direction.x = 0.0f;
		m_direction.y = 0.0f;
		m_direction.z = 0.0f;
	}
};

struct Mdg3DParameters
{
	Vox3DEmitterParameters		m_sourceParams;
	Mdgp3DListenerPositioning	m_listenerPositioning;
	Mdgp3DSourcePositioning		m_sourcePositioning;
};

struct Enhanced3dTweakParametersMBDG
{
	f32 enhanced3dStereoPanningPower;
	f32 enhanced3dStereoMaxDelayFront;
	f32 enhanced3dStereoMaxDelayBack;

	f32 enhanced3dNotchDepth;
	f32 enhanced3dNotchDepthSide;
	f32 enhanced3dNotchDepthBack;
	f32 enhanced3dNotchDepthDistance;

	f32 enhanced3dNotchWidth;
	f32 enhanced3dNotchWidthSide;
	f32 enhanced3dNotchWidthBack;
	f32 enhanced3dNotchWidthDistance;

	f32 enhanced3dDistanceWidthMinimum;
	f32 enhanced3dDistanceWidthMaximum;
	f32 enhanced3dDistanceWidthCurve;
	f32 enhanced3dDistanceWidthSide;
	f32 enhanced3dDistanceWidthBack;
	f32 enhanced3dDistanceFrequency;

	f32 enhanced3dRolloffFactor;
};


class MinibusDataGenerator3DPlugin : public MinibusDataGeneratorPlugin
{
 public:
	MinibusDataGenerator3DPlugin();
	virtual ~MinibusDataGenerator3DPlugin();

	static void Get3DGeneralParameters(Vox3DGeneralParameters &parameters);
	static void Set3DGeneralParameters(const Vox3DGeneralParameters &parameters);
	static void SetEnhanced3D(bool isActivated);

	virtual void GetData(s32* buffer, s32 nbSample, s32 sampleRate)=0;

	virtual void Get3DSourceParameters(Vox3DEmitterParameters &sourceParams);
	virtual void Get3DListenerPositioning(Mdgp3DListenerPositioning &positioning);
	virtual void Get3DSourcePositioning(Mdgp3DSourcePositioning &positioning);
	virtual void Set3DSourceParameters(const Vox3DEmitterParameters &sourceParams);
	virtual void Set3DListenerPositioning(const Mdgp3DListenerPositioning &positioning);
	virtual void Set3DSourcePositioning(const Mdgp3DSourcePositioning &positioning);
 protected:
	static Mdgp3DEnvironmentParams s_environmentParams;			// General 3D environment parameters
	static Enhanced3dTweakParametersMBDG s_enhanced3DParameters;	// Enhanced 3D parameters

	Vox3DEmitterParameters m_sourceParams;				// Source 3D general parameters
	Mdgp3DListenerPositioning m_listenerPositioning;	// Listener positioning parameters
	Mdgp3DSourcePositioning m_sourcePositioning;		// Source positioning parameters

// #if VOX_ENHANCED_3D
	VoxFilter m_filter[4]; 
	s32 m_leftSideDelay;
	s32 m_delayBuffer[MDGP_ENHANCED_3D_DELAY_LENGTH];
	s32 m_delayWriteCounter;
	s32 m_delayReadCounter;
// #endif

	fx1814 GetDirectionalGain(void);
	fx1814 GetDistanceGain(void);
	fx1814 GetDopplerPitch(void);
	void GetStereoPanning(fx1814 *leftPan, fx1814 *rightPan);
	void GetNormalizedPosition(f32 *resultX, f32 *resultY, f32 *resultZ);
	
};

} // namespace vox

#endif // _VOX_MINIBUS_DATA_GENERATOR_PLUGIN_H_