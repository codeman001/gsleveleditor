////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Plugin                            //
//                                                                            //
//                             ModPlug Decoder                                //
//                                                                            //
//                            Alexandre B�langer                              //
//                             (c)2011 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This plugin is an external decoder that allow the use of tracker files with 
embeded samples/instruments.  This implementation of the decoder support .it, 
.xm, .mod and .s3m files. This implementation has been tested with on Windows XP 
with Visual Studio and iPhone.  However, it should work on any little endian
platform with GCC.

To configure the plugin, the following preprocessor MUST be added to the project
including the plugin.

MODPLUG_NO_FILESAVE
MODPLUG_BASIC_SUPPORT

The following paths must be added to the include paths of the project including
the plugin.

{path to vox}\Plugins\ModPlug\modplug
{path to vox}\Plugins\ModPlug\

To use this plugin, you must add the decoder factory to VoxEngine after 
initialization.  Then you can created data source using the decoder id returned
on registration.

[Code Sample]

[...]
#include "vox_decoder_mod.h"
[...]
	vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
	vox.Initialize();

	//Registering the new decoder 
	const int k_nDecoderTypeMod = vox.RegisterDecoderType( vox::DecoderModFactory );
	VOX_ASSERT( -1 != k_nDecoderTypeMod );

	//
	// Defining sound sources
	//

	vox::c8 _path[256];
	strcpy(_path, "../CommonData/m_intro.it");
	
	// Loading a data source to ram with default rendering option
	/*
	vox::DataHandle m_musicSources =  vox::VoxUtils::LoadDataSourceFromFileEx( _path, k_nModDecoderId, vox::k_nLoadToRam, vox::k_nVoxGroupId_bgm);
  */
  
  // Loading a data source with custom rendering option
  /*
 	vox::DecoderModParams modParams;
	modParams.resamplingMode = MODPLUG_RESAMPLE_FIR;
	modParams.sampleRate = 44100;

	vox::DataHandle dhmod = vox.LoadDataSource(vox::k_nStreamTypeCFile, _path, k_nModDecoderId, &modParams, vox::k_nVoxGroupId_bgm);
  */
  
[...]

[\Code Sample]

There are defines in vox_decoder_mod.h to set the default rendering option.

Notes
=====

- This decoder may not give the exact duration of the file
- Since the decoder may not give the exact duration of the file, converting a
  data source of this type to "raw", may cause issue (mainly the end of the file
  missing)
- This decoder support both streaming from a file or ram buffer, however when
  streaming from a file, it needs to copy the whole file to ram.  It is more
  efficient to directly use a stream of memory buffer type than a file.
- For a more complete example on using external decoder, please refer to the 
  sample in {vox}/samples/HowTo/ExternalDecoder.
- Allocation from this plugin are not handled by Vox allocator.
  
  
History
=======

February 24th, 2011
by Alexandre Belanger
- Initial release
