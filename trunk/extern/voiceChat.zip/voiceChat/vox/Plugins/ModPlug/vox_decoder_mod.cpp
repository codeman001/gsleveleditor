#include "vox.h"
#include "vox_decoder_mod.h"

#define VOX_INTERNAL_CODE

#include "vox_profiler.h"
#include "vox_memory.h"
#include "vox_stream.h"
#include "vox_macro.h"


namespace vox {

DecoderInterface* DecoderModFactory(void* params)
{
	return VOX_NEW DecoderMod(params  ); 
}

///

bool DecoderMod::m_isFirst = true;

DecoderMod::DecoderMod(void* params )
:m_data(0)
,m_hasParams(false)
{
	if(m_isFirst)
	{
		ModPlug_Settings settings;
		ModPlug_GetSettings(&settings);
		settings.mBits = VOX_DECODER_MOD_DEFAULT_BIT_PER_SAMPLE;
		settings.mFrequency = VOX_DECODER_MOD_DEFAULT_SAMPLE_RATE;
		settings.mResamplingMode = VOX_DECODER_MOD_DEFAULT_RESAMPLING_MODE;
		settings.mChannels = VOX_DECODER_MOD_DEFAULT_CHANNEL;
		ModPlug_SetSettings(&settings);	
		m_isFirst = false;
	}

	if(params)
	{
		m_params = *((DecoderModParams*)params);
		m_hasParams = true;
	}
}

DecoderMod::~DecoderMod()
{
	if(m_data)
		VOX_FREE(m_data);
}

u8* DecoderMod::GetData()
{
	return m_data;
}

void DecoderMod::PushData(u8* data)
{
	m_data = data;
}

DecoderCursorInterface* DecoderMod::CreateNewCursor( StreamCursorInterface* pStreamCursor )
{
	return VOX_NEW DecoderModCursor(this,pStreamCursor);
}

void DecoderMod::DestroyCursor(DecoderCursorInterface* pDecoderCursor)
{
	VOX_DELETE( (DecoderModCursor*)pDecoderCursor);
}
///

DecoderModCursor::DecoderModCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor)
: DecoderCursorInterface( pDecoder, pStreamCursor )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderModCursor::DecoderModCursor", vox::VoxThread::GetCurThreadId());
	
	m_modPlugFile = 0;
	m_hasData = false;

	//if(!pStreamCursor->AllowBufferReference())
	//{
	//	VOX_ASSERT_MSG(false, "DecoderModCursor needs reference to complete data, current stream doesn't allow reference");
	//	return;
	//}

	Init();
}

DecoderModCursor::~DecoderModCursor()
{
	if(m_modPlugFile)
	{
		Shutdown();
	}	
}

void DecoderModCursor::Init()
{
	ModPlug_Settings settings;
	ModPlug_GetSettings(&settings);

	DecoderModParams* params = (DecoderModParams*)m_pDecoder->GetParam();
	if(params)//push local settings
	{
		ModPlug_Settings localSettings;
		localSettings = settings;
		localSettings.mChannels = params->nChannel;
		localSettings.mBits = params->bitPerSample;
		localSettings.mFrequency = params->sampleRate;
		localSettings.mResamplingMode = params->resamplingMode;
		localSettings.mLoopCount = -1;
		ModPlug_SetSettings(&localSettings);
	}

	s32 dataSize = m_pStreamCursor->Size();
	u8* data;	
	
	if(m_pStreamCursor->AllowBufferReference())
	{
		m_pStreamCursor->ReadRef(data, dataSize);
	}
	else
	{
		data = ((DecoderMod*)m_pDecoder)->GetData();
		if(!data)
		{
			data = (u8*)VOX_ALLOC(dataSize);
			if(data)
			{
				m_pStreamCursor->Read(data, dataSize);
				((DecoderMod*)m_pDecoder)->PushData(data);//decoder will take ownership of the buffer
			}
		}
	}

	if(data)
	{
		m_modPlugFile = ModPlug_Load((const void*) data, dataSize);
	}

	if(params)//restore global settings
	{
		ModPlug_SetSettings(&settings);
	}

	if(m_modPlugFile)
	{
		VOX_WARNING_LEVEL_5("IT Volume : %u", ModPlug_GetMasterVolume(m_modPlugFile));
		ModPlug_SetMasterVolume(m_modPlugFile, 256);
		m_hasData = true;
		if(params)
		{
			m_trackParams.bitsPerSample = params->bitPerSample;
			m_trackParams.numChannels = params->nChannel;
			m_trackParams.samplingRate = params->sampleRate;
		}
		else
		{
			m_trackParams.bitsPerSample = settings.mBits;
			m_trackParams.numChannels = settings.mChannels;
			m_trackParams.samplingRate = settings.mFrequency;
		}
		m_trackParams.numSamples = ModPlug_GetLength(m_modPlugFile) * m_trackParams.samplingRate / 1000; // ms * 32000 / 1000
	}
	else
	{	
		m_trackParams.Reset();
	}
}

void DecoderModCursor::Shutdown()
{
	ModPlug_Unload(m_modPlugFile);
}

s32 DecoderModCursor::Decode( void* outputBuffer, s32 nbBytes )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderRawCursor::Decode", vox::VoxThread::GetCurThreadId());
	s32 totalBytesRead = 0;

	if(m_modPlugFile)
	{
		totalBytesRead = ModPlug_Read(m_modPlugFile, outputBuffer, nbBytes);
		if(totalBytesRead == 0)
		{
			if(m_loop)
			{
				Seek(0);
				totalBytesRead = ModPlug_Read(m_modPlugFile, outputBuffer, nbBytes);
				if(totalBytesRead == 0)
					m_hasData = false;
			}
			else
			{
				m_hasData = false;
			}
		}
	}

	return totalBytesRead;
}

s32 DecoderModCursor::Seek(u32 sampleNum )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderRawCursor::Seek", vox::VoxThread::GetCurThreadId());

	if(m_modPlugFile)
	{
		ModPlug_Seek(m_modPlugFile, 1000 * sampleNum / m_trackParams.samplingRate);
		return 0; //may or may not have seek a the correct position
	}

	return -1;
}

bool DecoderModCursor::HasData()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderRawCursor::HasData", vox::VoxThread::GetCurThreadId());
	
	if(m_modPlugFile)
	{
		return m_hasData;
	}

	return false;
}

} //namespace vox