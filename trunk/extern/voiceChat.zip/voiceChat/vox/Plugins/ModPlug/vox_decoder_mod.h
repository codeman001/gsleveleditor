#pragma once
#ifndef _VOX_DECODER_MOD_H_
#define _VOX_DECODER_MOD_H_

#include "vox.h"

#include <vox_decoder.h>
#include "modplug/modplug.h"

// Target sample rate for the rendering
#ifndef VOX_DECODER_MOD_DEFAULT_SAMPLE_RATE
#define VOX_DECODER_MOD_DEFAULT_SAMPLE_RATE 44100
#endif

// Rendering is done in stereo, but can be merge to mono
#ifndef VOX_DECODER_MOD_DEFAULT_CHANNEL
#define VOX_DECODER_MOD_DEFAULT_CHANNEL 2
#endif

// How many bit per sample (Most of Vox driver only support 16 bits)
#ifndef VOX_DECODER_MOD_DEFAULT_BIT_PER_SAMPLE
#define VOX_DECODER_MOD_DEFAULT_BIT_PER_SAMPLE 16
#endif

/* Resampling mode 
enum _ModPlug_ResamplingMode
{
	MODPLUG_RESAMPLE_NEAREST = 0,  // No interpolation (very fast, extremely bad sound quality) //Fast
	MODPLUG_RESAMPLE_LINEAR  = 1,  // Linear interpolation (fast, good quality) // Fastest
	MODPLUG_RESAMPLE_SPLINE  = 2,  // Cubic spline interpolation (high quality) // Slow
	MODPLUG_RESAMPLE_FIR     = 3   // 8-tap fir filter (extremely high quality) // Very slow
};
*/
#ifndef VOX_DECODER_MOD_DEFAULT_RESAMPLING_MODE
#define VOX_DECODER_MOD_DEFAULT_RESAMPLING_MODE MODPLUG_RESAMPLE_LINEAR
#endif

namespace vox 
{

DecoderInterface* DecoderModFactory(void* params);
struct DecoderModParams
{
	DecoderModParams():sampleRate(VOX_DECODER_MOD_DEFAULT_SAMPLE_RATE),nChannel(VOX_DECODER_MOD_DEFAULT_CHANNEL),bitPerSample(VOX_DECODER_MOD_DEFAULT_BIT_PER_SAMPLE),resamplingMode(VOX_DECODER_MOD_DEFAULT_RESAMPLING_MODE){}
	s32 sampleRate;
	s32 nChannel;
	s32 bitPerSample;
	s32 resamplingMode;
};

static const s32 k_nDecoderTypeMod = 100;

class DecoderMod : public DecoderInterface 
{
public:
	DecoderMod(void* params);
	virtual ~DecoderMod();
public:
	virtual void Init(){}
	virtual void Shutdown() {}
	virtual DecoderCursorInterface* CreateNewCursor( StreamCursorInterface* pStreamCursor );
	virtual void DestroyCursor(DecoderCursorInterface* pDecoderCursor);
	virtual s32 GetType(){return k_nDecoderTypeMod;}
	virtual void* GetParam(){return m_hasParams ? &m_params : 0;}

	u8* GetData();
	void PushData(u8* data);

private:
	bool m_hasParams;
	static bool m_isFirst;
	DecoderModParams m_params;
	u8* m_data;
};

class DecoderModCursor : public DecoderCursorInterface
{
protected:
	DecoderModCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor );
public:
	virtual ~DecoderModCursor();

public:
	virtual void Init();
	virtual void Shutdown();
	virtual s32  Decode( void* outputBuffer, s32 nbBytes );
	virtual s32  DecodeRef( void* &outputBuffer, s32 nbBytes ){return Decode(outputBuffer, nbBytes);}//{VOX_ASSERT_MSG(false, "DecoderModCursor doesn't support data reference");return 0;}
	virtual bool HasData();
	virtual void Reset(void){Seek(0);}
	virtual s32  Seek(u32 sampleNum );
	virtual void SetLoop(bool loop){m_loop = loop;}

	virtual StreamCursorInterface* GetStreamCursor(){return m_pStreamCursor;}

	virtual bool AllowBufferReference(){ return false; }

private:
	ModPlugFile* m_modPlugFile;
	bool m_hasData;

	friend class DecoderMod;
};

} //namespace

#endif