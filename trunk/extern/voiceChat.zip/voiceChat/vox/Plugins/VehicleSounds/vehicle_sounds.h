#pragma once
#ifndef _VOX_VEHICLE_SOUNDS_H_
#define _VOX_VEHICLE_SOUNDS_H_

#include "../GenericPlugin/vox_minibus_data_generator_plugin.h"
// Define default sleep time value for thread providing sound data.
#define VS_DATASOURCE_THREAD_SLEEP_TIME_MS	5

namespace vox
{

namespace vs
{

enum VSState
{
	VSS_STATE_INITIAL,	// No call to VehicleSounds::Play() has been done yet.
	VSS_STATE_STARTUP,	// During startup, user must keep rpm values at idle sound nominal rpm.
	VSS_STATE_RUNNING,	// User can change rpm values.
	VSS_STATE_PAUSING,	// Vehicle is in the process of pausing. Pause is not achieve yet.
	VSS_STATE_PAUSED,	// Vehicle is paused.
	VSS_STATE_STOPPING,	// Vehicle is in the process of stopping. Stop is not achieve yet.
	VSS_STATE_STOPPED	// Vehicle is stopped.
};

struct VSGeneralInitParams
{
	s32 m_nbDecodedDataBuffers;			// Nb of buffers containing decoded data.
	s32 m_decodedDataBufferSize;		// Size of buffer containing decoded data.
	s32 m_dataSourceThreadSleepTimeMs;	// Sleep time (in ms) of thread used to fill sound buffers.

	VSGeneralInitParams(): m_nbDecodedDataBuffers(0), m_decodedDataBufferSize(0),
						   m_dataSourceThreadSleepTimeMs(VS_DATASOURCE_THREAD_SLEEP_TIME_MS) {}
};

// Structure that game uses to update VehicleSounds parameters
class VSUpdateParameters
{
 public:
	s32	m_engineRpm;
	s32	m_currentGear;
	Mdgp3DListenerPositioning	m_listenerPositioning;
	Mdgp3DSourcePositioning		m_sourcePositioning;
	
	VSUpdateParameters(): m_engineRpm(0), m_currentGear(-1) {}
};

class VehicleSoundsInternal;

class VehicleSounds : public MinibusDataGeneratorInterface
{
public:
	 VehicleSounds();
	~VehicleSounds();

	static void Clean();

	// GetData is the rendering callback, don't call this from the game (unless you like explosions)
	virtual void GetData(s32* buffer, s32 nbSample, s32 sampleRate);

	virtual void Get3DSourceParameters(Vox3DEmitterParameters &sourceParams);
	virtual void Get3DListenerPositioning(Mdgp3DListenerPositioning &positioning);
	virtual void Get3DSourcePositioning(Mdgp3DSourcePositioning &positioning);
	virtual void Set3DSourceParameters(const Vox3DEmitterParameters &sourceParams);
	virtual void Set3DListenerPositioning(const Mdgp3DListenerPositioning &positioning);
	virtual void Set3DSourcePositioning(const Mdgp3DSourcePositioning &positioning);

	static void Get3DGeneralParameters(Vox3DGeneralParameters &parameters);
	static void Set3DGeneralParameters(const Vox3DGeneralParameters &parameters);
	static void SetEnhanced3D(bool isActivated);

	s32 GetLimiterRpm();
	s32 GetMinEngineRpm();
	s32 GetMaxEngineRpm();
	VSState GetState();
	bool Init(c8 *filename, c8 *configurationLabel, Mdg3DParameters *p3DParameters = 0, VSGeneralInitParams *pGeneralParams = 0);
	void Play(bool isStartupAllowed = true);
	void Stop();
	void Pause();
	void Resume();
	void SetGain(f32 gain);
	void SetPitch(f32 pitch);
	VSState Update(const VSUpdateParameters &parameters);

private:
	VehicleSoundsInternal *m_internal;
};

} // namespace vox

} // namespace vs

#endif // _VOX_VEHICLE_SOUNDS_H_
