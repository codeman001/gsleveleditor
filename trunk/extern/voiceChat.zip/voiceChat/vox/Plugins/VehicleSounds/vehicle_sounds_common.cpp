#include "vehicle_sounds_common.h"

#define VOX_INTERNAL_CODE

#include "vox_profiler.h"
#include "vox_macro.h"
#include VOX_MAP_INCLUDE


namespace vox
{

namespace vs
{

//*** VSVersions ***//

u32 VSVersions::k_nbValidVersions = 2;
const c8* VSVersions::k_vsValidVersions[] = {"0.0.1", "0.0.2"};

const c8* VSVersions::GetVersion001Label()
{
	return k_vsValidVersions[0];
}

const c8* VSVersions::GetVersion002Label()
{
	return k_vsValidVersions[1];
}

bool VSVersions::IsVersionValid(const c8 *version)
{
	for(u32 i = 0; i < k_nbValidVersions; i++)
	{
		if(strcmp(version, k_vsValidVersions[i]) == 0)
		{
			return true;
		}
	}

	return false;
}

//*** VSBufferPool ***//

VSBufferPool* VSBufferPool::s_pInstance = 0;
s32 VSBufferPool::s_nextId = 0;

VSBufferPool* VSBufferPool::GetInstance()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "VSBufferPool::GetInstance", vox::VoxThread::GetCurThreadId());

	if(!s_pInstance)
	{
		s_pInstance = VOX_NEW VSBufferPool();
	}

	return s_pInstance;
}

void VSBufferPool::Release()
{
	if(s_pInstance)
	{
		VOX_DELETE(s_pInstance);
		s_pInstance = 0;
	}
}

VSBufferPool::VSBufferPool()
{
	m_buffers = (void *)VOX_NEW VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > >;
}

VSBufferPool::~VSBufferPool()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferPool::~VSBufferPool", vox::VoxThread::GetCurThreadId());

	// Release buffer pool
	if(m_buffers!=0)
	{
		VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > > *m_buffersC =
			(VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > > *)m_buffers;
		VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > >::iterator buffer_it = m_buffersC->begin();
		VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > >::iterator buffer_end = m_buffersC->end();

		for(; buffer_it != buffer_end; buffer_it++)
		{
			VOX_FREE((buffer_it->second).m_pBuffer);
		}

		m_buffersC->clear();
		VOX_DELETE(m_buffersC);
		m_buffers = 0;
	}
}

s32 VSBufferPool::CreateBuffer(s32 bufferSize)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferPool::CreateBuffer", vox::VoxThread::GetCurThreadId());

	VSStreamBuffer streamBuffer;
	
	streamBuffer.m_pBuffer = static_cast<u8*> (VOX_ALLOC(bufferSize));

	if(streamBuffer.m_pBuffer && m_buffers)
	{
		s32 bufferId = s_nextId++;

		VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > > *m_buffersC =
			(VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > > *)m_buffers;
		(*m_buffersC)[bufferId] = streamBuffer;
		return bufferId;
	}
	return -1;
}

u8 *VSBufferPool::GetBuffer(s32 bufferId)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferPool::GetBuffer", vox::VoxThread::GetCurThreadId());

	if(!m_buffers)
		return 0;
	VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > > *m_buffersC =
			(VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > > *)m_buffers;

	VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > >::iterator it = m_buffersC->find(bufferId);

	if(it != m_buffersC->end())
	{
		(it->second).m_referenceCount++;
		return (it->second).m_pBuffer;
	}

	return 0;
}

s32 VSBufferPool::ReleaseBuffer(s32 bufferId)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferPool::ReleaseBuffer", vox::VoxThread::GetCurThreadId());

	if(!m_buffers)
		return -1;

	VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > > *m_buffersC =
		(VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > > *)m_buffers;

	VOX_MAP<s32, VSStreamBuffer, VSIntComp, SAllocator<std::pair<s32,VSStreamBuffer> > >::iterator buffer_it = m_buffersC->find(bufferId);

	if(buffer_it != m_buffersC->end())
	{
		// Decrease reference count on buffer
		(buffer_it->second).m_referenceCount--;

		if((buffer_it->second).m_referenceCount == 0)
		{
			// Free buffer memory
			VOX_FREE((buffer_it->second).m_pBuffer);

			// Remove buffer from map
			m_buffersC->erase(buffer_it);
		}
	}

	// Return -1 so that caller is dereferenced from buffer
	return -1;
}

///

StreamInterface* VSStreamFactory(void* params)
{
	return VOX_NEW VSStream((VSStreamParams*) params);
}


//*** VSStream ***//

VSStream::VSStream(VSStreamParams *parameters)
:m_pFile(0)
,m_isValid(false)
,m_streamMode(parameters->m_streamMode)
,m_streamSize(0)
,m_cursorPosition(0)
,m_pBuffer(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::VSStream", vox::VoxThread::GetCurThreadId());

	if(parameters->m_filename)
	{
		FileSystemInterface* pFS = FileSystemInterface::GetInstance();

		if(parameters->m_streamMode == k_nVSRead)
		{
			m_pFile = pFS->OpenFile(parameters->m_filename); // Open in binary read mode

			if(m_pFile)
			{
				// If there is an extension, seek to its start.
				if(ParseHeader())
				{
					m_isValid = true;
				}
				else // File is invalid
				{
					pFS->CloseFile(m_pFile);
					VOX_WARNING_LEVEL_2( "File %s is not a valid vxvs file.\n", parameters->m_filename);
				}
			}
		}
		else if(parameters->m_streamMode == k_nVSWrite)
		{
			/*m_fp = pFS->OpenFile((c8*)filename, k_nReadWriteBinary);

			if(m_fp)
			{
				// If there is already an extension, do not allow writing in file
				if(ParseExtensionHeader())
				{
					Close();
				}
				else // No extension, file can be opened for writing. Seek to end of file
				{
					m_fp->Seek(0, k_nSeekEnd);
				}
			}*/
		}
		else if(parameters->m_streamMode == k_nVSCreateWrite)
		{
			m_pFile = pFS->OpenFile(parameters->m_filename, k_nCreateReadWriteBinary);
		}
	}

	if(!m_pFile)
		VOX_WARNING_LEVEL_2( "Could not load file %s\n", parameters->m_filename);
}

VSStream::~VSStream()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::~VSStream", vox::VoxThread::GetCurThreadId());

	if(m_pFile)
	{
		FileSystemInterface* pFS = vox::FileSystemInterface::GetInstance();
		pFS->CloseFile(m_pFile);
	}

	if(m_pBuffer)
	{
		VOX_FREE(m_pBuffer);
		m_pBuffer = 0;
	}
}

VSStreamCursor* VSStream::CreateNewCursor(s32 segmentStart, s32 segmentSize, bool isBuffered)
{
	if(m_streamSize > 0)
	{
		if(isBuffered)
		{
			return VOX_NEW VSBufferStreamCursor(this, segmentStart, segmentSize);
		}
		else
		{
			return VOX_NEW VSFileStreamCursor(this, segmentStart, segmentSize);
		}
	}
	return 0;
}

void VSStream::DestroyCursor(StreamCursorInterface* pStreamCursor)
{
	VOX_DELETE(pStreamCursor);
}

void VSStream::Close()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::Close", vox::VoxThread::GetCurThreadId());

	if(m_pFile)
	{
		FileSystemInterface* pFS = vox::FileSystemInterface::GetInstance();
		pFS->CloseFile(m_pFile);
		m_pFile = 0;
	}
}

const c8* VSStream::GetVersion()
{
	return m_fileInfos.m_version;
}

bool VSStream::ParseHeader(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::ParseExtensionHeader", vox::VoxThread::GetCurThreadId());

	VSChunkHeader chunkHeader;
	s32 configurationStart = -1;
	s32 idChunkSize = 0;

	// Go to start of file if not already there
	if(m_pFile->Tell() != 0)
	{
		m_pFile->Seek(0, k_nSeekSet);
	}

	// Read the id chunk header
	s32 readsize = m_pFile->Read(&chunkHeader.m_id, sizeof(s32), 1);
	if(!readsize)
		return false;

	readsize = m_pFile->Read(&chunkHeader.m_size, sizeof(s32), 1);
	if(!readsize)
		return false;

#if VOX_BIG_ENDIAN
	chunkHeader.SwitchEndian();
#endif

	// If id chunk is present, read its content
	if(chunkHeader.m_id == k_vsIdChunkName)
	{
		// Verify the version number
		m_pFile->Read(&m_fileInfos.m_version, VS_VERSION_SIZE, 1);

		// Validate version
		if(!VSVersions::IsVersionValid(m_fileInfos.m_version))
		{
			VOX_WARNING_LEVEL_2("Invalid version %s for vxvs file\n", m_fileInfos.m_version);
			return false;
		}

		// Get the position of the data section start
		m_pFile->Read(&m_fileInfos.m_dataStart, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(m_fileInfos.m_dataStart);
#endif

		// Get the file size
		m_pFile->Read(&m_fileInfos.m_fileSize, sizeof(s32), 1);
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(m_fileInfos.m_fileSize);
#endif

		// Get the size of all chunks located between start of file and 'data' chunk
		m_streamSize = m_fileInfos.m_dataStart;

		// Create a buffer and read all chunks located between the 'id' and 'data' chunk into it.
		m_pBuffer = (u8 *) VOX_ALLOC(m_streamSize);

		if(!m_pBuffer)
		{
			VOX_WARNING_LEVEL_2("%s", "Could not allocate buffer to contain chunks from vxvs file.\n");
			return false;
		}

		// Go back to start of file and read the non-data portion into buffer
		m_pFile->Seek(0, k_nSeekSet);
		m_pFile->Read(m_pBuffer, m_streamSize, 1);
		return true;
	}
	
	return false;
}

s32 VSStream::Read(void* buffer, s32 size)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::Read", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer && m_streamMode == k_nVSRead)
	{
		if(m_cursorPosition + size <= m_streamSize)
		{
			memcpy(buffer, m_pBuffer + m_cursorPosition, size);
			m_cursorPosition += size;
			return size;
		}
	}
	return 0;
}

s32 VSStream::ReadByte(u8 &byteValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::ReadByte", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer && m_streamMode == k_nVSRead)
	{
		if(m_cursorPosition + 1 <= m_streamSize)
		{
			byteValue = m_pBuffer[m_cursorPosition];
			m_cursorPosition++;
			return 1;
		}
	}
	return 0;
}

s32 VSStream::ReadChunkHeader(VSChunkHeader &chunkHeader)
{
	s32 readSize = ReadUnsignedInt(chunkHeader.m_id);

	if(!readSize)
		return 0;

	return ReadInt(chunkHeader.m_size);
}

s32 VSStream::ReadFloat(f32 &floatValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::ReadFloat", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer && m_streamMode == k_nVSRead)
	{
		if(m_cursorPosition + 4 <= m_streamSize)
		{
			f32 *pFloatCursor = reinterpret_cast<f32*> (m_pBuffer + m_cursorPosition);
			floatValue = *pFloatCursor;
#if VOX_BIG_ENDIAN
			ConvertFloatToBE(floatValue);
#endif
			m_cursorPosition += 4;
			return 1;
		}
	}

	return 0;
}

s32 VSStream::ReadInt(s32 &intValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::ReadInt", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer && m_streamMode == k_nVSRead)
	{
		if(m_cursorPosition + 4 <= m_streamSize)
		{
			intValue	= (m_pBuffer[m_cursorPosition])
						+ (m_pBuffer[m_cursorPosition+1] << 8)
						+ (m_pBuffer[m_cursorPosition+2] << 16)
						+ (m_pBuffer[m_cursorPosition+3] << 24);
			m_cursorPosition += 4;
			return 1;
		}
	}

	return 0;
}

s32 VSStream::ReadShort(s16 &shortValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::ReadShort", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer && m_streamMode == k_nVSRead)
	{
		if(m_cursorPosition + 2 <= m_streamSize)
		{
			shortValue	= (m_pBuffer[m_cursorPosition])
						+ (m_pBuffer[m_cursorPosition+1] << 8);
			m_cursorPosition += 2;
			return 1;
		}
	}

	return 0;
}

s32 VSStream::ReadUnsignedInt(u32 &unsignedIntValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::ReadUnsignedInt", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer && m_streamMode == k_nVSRead)
	{
		if(m_cursorPosition + 4 <= m_streamSize)
		{
			unsignedIntValue	= (m_pBuffer[m_cursorPosition])
								+ (m_pBuffer[m_cursorPosition+1] << 8)
								+ (m_pBuffer[m_cursorPosition+2] << 16)
								+ (m_pBuffer[m_cursorPosition+3] << 24);
			m_cursorPosition += 4;
			return 1;
		}
	}

	return 0;
}



s32 VSStream::Write(const void* buffer, s32 size)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::Write", vox::VoxThread::GetCurThreadId());

	// TODO : See if correct (all write methods have not been verified)
	if((m_streamMode == k_nVSWrite || m_streamMode == k_nVSCreateWrite))
	{
		s32 written = m_pFile->Write(buffer, 1, size);
		if(written == size)
		{
			m_cursorPosition += size;
			return size;
		}
	}
	return 0;
}

s32 VSStream::WriteByte(u8 byteValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::WriteByte", vox::VoxThread::GetCurThreadId());

  if((m_streamMode == k_nVSWrite || m_streamMode == k_nVSCreateWrite))
	{
		s32 written = m_pFile->Write(&byteValue, 1, 1);
		if(written == 1)
		{
			m_cursorPosition++;
			return 1;
		}
	}
	return 0;
}

s32 VSStream::WriteInt(s32 intValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::WriteInt", vox::VoxThread::GetCurThreadId());

  if((m_streamMode == k_nVSWrite || m_streamMode == k_nVSCreateWrite))
	{
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(intValue);
#endif

		s32 written = m_pFile->Write(&intValue, sizeof(s32), 1);
		if(written == 1)
		{
			m_cursorPosition += sizeof(s32);
			return 1;
		}
	}

	return 0;
}

s32 VSStream::WriteShort(s16 shortValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSStream::WriteShort", vox::VoxThread::GetCurThreadId());

	if((m_streamMode == k_nVSWrite || m_streamMode == k_nVSCreateWrite))
	{
#if VOX_BIG_ENDIAN
		ChangeShortEndianness(shortValue);
#endif

		s32 written = m_pFile->Write(&shortValue, sizeof(s16), 1);
		if(written == 1)
		{
			m_cursorPosition += sizeof(s16);
			return 1;
		}
	}

	return 0;
}

s32 VSStream::Seek(s32 offset, VoxFileSeekOrigin origin)
{
	s32 desiredPosition;

	switch(origin)
	{	
		case k_nSeekSet:
		{
			desiredPosition = offset;
			break;
		}
		case k_nSeekCur:
		{
			desiredPosition = m_cursorPosition + offset;
			break;
		}
		case k_nSeekEnd:
		{
			desiredPosition = m_streamSize - offset - 1;
			break;
		}
	}

	if(desiredPosition >= 0 &&  desiredPosition < m_streamSize)
	{
		m_cursorPosition = desiredPosition;
		return 0;
	}

	return 1;
}

s32 VSStream::GetDataStartPosition()
{
	return m_fileInfos.m_dataStart;
}

bool VSStream::IsValid()
{
	return m_isValid;
}


//*** VSStreamCursor ***//

VSStreamCursor::VSStreamCursor(StreamInterface* pStream, s32 segmentStart, s32 segmentSize)
:StreamCursorInterface(pStream)
,m_position(0) 
,m_segmentSize(segmentSize)
{
	m_segmentStart = ((VSStream*) pStream)->GetDataStartPosition() + segmentStart;
}

s32 VSStreamCursor::Size(void)
{
	return m_segmentSize;
}

//*** VSFileStreamCursor ***//

VSFileStreamCursor::VSFileStreamCursor(StreamInterface* pStream, s32 segmentStart, s32 segmentSize) 
:VSStreamCursor(pStream, segmentStart, segmentSize)
{
}

void VSFileStreamCursor::Shutdown()
{
	// TODO : See what to do here
}

s32 VSFileStreamCursor::Seek(s32 pos, s32 origin)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSFileStreamCursor::Seek", vox::VoxThread::GetCurThreadId());
	
	FileInterface *pFile = ((VSStream*)m_pStream)->GetFileInterface();

	if(pFile)
	{
		s32 desiredPosition;

		switch(origin)
		{
			case ORIGIN_START:
			{
				desiredPosition = pos;
				break;
			}
			case ORIGIN_CURRENT:
			{
				//if(m_position < 0)
				//	m_position = pFile->Tell();
				desiredPosition = m_position + pos;
				break;
			}
			case ORIGIN_END:
			{
				desiredPosition = m_segmentSize - pos - 1;
				break;
			}
		}
	
		if(desiredPosition < 0 || desiredPosition > m_segmentSize)
		{
			return -1;
		}
		else
		{
			// Get the position of the file cursor
			s32 filePosition = pFile->Tell();

			m_position = desiredPosition;
			return pFile->Seek(m_segmentStart + desiredPosition - filePosition, vox::k_nSeekCur);
		}
	}
	return -1;
}

s32 VSFileStreamCursor::Tell()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSFileStreamCursor::Tell", vox::VoxThread::GetCurThreadId());
	
	FileInterface *pFile = ((VSStream*)m_pStream)->GetFileInterface();

	if(pFile)
	{
		return m_position;
	}

	return -1;
}

s32 VSFileStreamCursor::Read(u8* buff, s32 len)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSFileStreamCursor::Read", vox::VoxThread::GetCurThreadId());
	
	FileInterface *pFile = ((VSStream*)m_pStream)->GetFileInterface();

	if(pFile && (len > 0))
	{
		s32 desiredReadSize;

		// Determine the number of bytes to read (without going out of stream)
		if(m_position + len >= 0 && m_position + len < m_segmentSize)
		{
			desiredReadSize = len;
		}
		else
		{
			desiredReadSize = m_segmentSize - m_position;
		}

		// Get the position of the file cursor
		s32 filePosition = pFile->Tell();

		// Seek to current position
		pFile->Seek(m_segmentStart + m_position - filePosition, vox::k_nSeekCur);

		s32 readSize = pFile->Read(buff, 1, desiredReadSize);
		m_position += readSize;
		return readSize;
	}
	return 0;
}

bool VSFileStreamCursor::EndOfStream()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSFileStreamCursor::EndOfStream", vox::VoxThread::GetCurThreadId());
	
	FileInterface *pFile = ((VSStream*)m_pStream)->GetFileInterface();

	if(pFile)
	{
		if(m_position < 0)
			m_position = Tell();
		s32 pos = m_position;
		return pos >= (m_segmentSize -1);
	}
	return true;
}

void VSFileStreamCursor::Copy(VSStreamCursor *pStreamCursor)
{
	VSFileStreamCursor *pFileStreamCursor = static_cast<VSFileStreamCursor*> (pStreamCursor);

	// Copy start and size of segment
	m_segmentStart = pFileStreamCursor->m_segmentStart;
	m_segmentSize = pFileStreamCursor->m_segmentSize;

	// Reset position
	m_position = 0;
}

//*** VSBufferStreamCursor ***//

VSBufferStreamCursor::VSBufferStreamCursor(StreamInterface* pStream, s32 segmentStart, s32 segmentSize) 
:VSStreamCursor(pStream, segmentStart, segmentSize)
,m_pBuffer(0)
,m_bufferId(0)
{
	Init();
}

void VSBufferStreamCursor::Init()
{
	// Create buffer with segment content size
	VSBufferPool *pBufferPool = VSBufferPool::GetInstance();
	s32 bufferId = pBufferPool->CreateBuffer(m_segmentSize);

	if(bufferId < 0)
		return;

	m_pBuffer = pBufferPool->GetBuffer(bufferId);

	if(m_pBuffer)
	{
		FileInterface *pFile = ((VSStream*)m_pStream)->GetFileInterface();

		if(pFile)
		{
			// Seek to segment position in file
			pFile->Seek(m_segmentStart, k_nSeekSet);

			// Fill buffer with segment content
			s32 count = pFile->Read(m_pBuffer, sizeof(u8), m_segmentSize);

			if(count == m_segmentSize)
			{
				m_bufferId = bufferId;
			}
			else
			{
				m_bufferId = pBufferPool->ReleaseBuffer(bufferId);
				m_pBuffer = 0;
				VOX_WARNING_LEVEL_2("%s", "Could not create buffer stream from file segment.\n");
			}
		}
	}
}

void VSBufferStreamCursor::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferStreamCursor::Shutdown", vox::VoxThread::GetCurThreadId());

	// Dereference from buffer in the VSBufferPool
	VSBufferPool *pBufferPool = VSBufferPool::GetInstance();

	if(pBufferPool && m_bufferId >= 0)
	{
		m_bufferId = pBufferPool->ReleaseBuffer(m_bufferId);
		m_pBuffer = 0;
	}
}

s32 VSBufferStreamCursor::Seek(s32 pos, s32 origin)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferStreamCursor::Seek", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer)
	{
		s32 desiredPosition;

		switch(origin)
		{
			case ORIGIN_START:
			{
				desiredPosition = pos;
				break;
			}
			case ORIGIN_CURRENT:
			{
				desiredPosition = m_position + pos;
				break;
			}
			case ORIGIN_END:
			{
				desiredPosition = m_segmentSize - pos - 1;
				break;
			}
		}

		if(desiredPosition >= 0 && desiredPosition <= m_segmentSize)
		{
			m_position = desiredPosition;
			return 0;
		}
	}
	return -1;
}

s32 VSBufferStreamCursor::Tell()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferStreamCursor::Tell", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer)
	{
		return m_position;
	}

	return -1;
}

s32 VSBufferStreamCursor::Read(u8* buff, s32 len)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferStreamCursor::Read", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer && (len > 0))
	{
		s32 desiredReadSize;

		// Determine the number of bytes to read (without going out of stream)
		if(m_position + len >= 0 && m_position + len < m_segmentSize)
		{
			desiredReadSize = len;
		}
		else
		{
			desiredReadSize = m_segmentSize - m_position;
		}

		memcpy(buff, m_pBuffer + m_position, desiredReadSize);
		m_position += desiredReadSize;
		return desiredReadSize;
	}
	return 0;
}

bool VSBufferStreamCursor::EndOfStream()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "VSBufferStreamCursor::EndOfStream", vox::VoxThread::GetCurThreadId());

	if(m_pBuffer)
	{
		return m_position >= (m_segmentSize -1);
	}
	return true;
}

void VSBufferStreamCursor::Copy(VSStreamCursor *pStreamCursor)
{
	VSBufferStreamCursor *pBufferStreamCursor = static_cast<VSBufferStreamCursor*> (pStreamCursor);

	if(!pBufferStreamCursor)
		return;

	// Copy start and size of segment
	m_segmentStart = pBufferStreamCursor->m_segmentStart;
	m_segmentSize = pBufferStreamCursor->m_segmentSize;

	// Reset position
	m_position = 0;

	VSBufferPool *pBufferPool = VSBufferPool::GetInstance();

	if(pBufferPool)
	{
		// Release current buffer
		if(m_bufferId >= 0)
		{
			m_bufferId = pBufferPool->ReleaseBuffer(m_bufferId);
		}

		// Get a reference on the same buffer as the stream cursor being copied
		m_pBuffer = pBufferPool->GetBuffer(pBufferStreamCursor->m_bufferId);
		if(m_pBuffer)
		{
			m_bufferId = pBufferStreamCursor->m_bufferId;
		}
	}
}

} // namespace vs
} // namespace vox