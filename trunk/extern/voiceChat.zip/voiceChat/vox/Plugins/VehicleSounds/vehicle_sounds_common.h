#pragma once
#ifndef _VOX_VEHICLE_SOUNDS_COMMON_H_
#define _VOX_VEHICLE_SOUNDS_COMMON_H_

#include "vox_types.h"
#include "vox_filesystem.h"
#include "vox_stream.h"

#define VS_FILENAME_LENGTH		256
#define VS_CHUNK_HEADER_SIZE	8
#define VS_VERSION_SIZE			8
#define VS_LABEL_SIZE			32


namespace vox
{

namespace vs
{

// Definitions of chunk names
const u32 k_vsIdChunkName = 0x73767856;				// Vxvs (for vox vehicle sounds)
const u32 k_vsSegmentsChunkName = 0x6D676553;		// Segm
const u32 k_vsConfigurationsChunkName = 0x73676643;	// Cfgs
const u32 k_vsConfigurationChunkName = 0x666E6F43;	// Conf
const u32 k_vsDataChunkName = 0x61746144;			// Data

enum VSEventType
{
	k_nVSEventInvalid = -1,
	k_nVSEventClutch,
	k_nVSEventTurboDump,
	k_nVSEventStartup,
	k_nVSEventCount			// This one is not an event. Used as enum count.
};

enum VSEventParamType
{
	k_nVSEventParamInvalid = -1,
	k_nVSEventParamStartupLength,
	k_nVSEventParamNbSounds,
	k_nVSEventParamRandomNoRepeat,
	k_nVSEventParamTurboDumpVelocityLimit,
	k_nVSEventParamTurboGainThreshold,
	k_nVSEventParamDeltaTurboGainThreshold,
	k_nVSEventParamLayerId,
	k_nVSEventParamCount	// This one is not an event param type. Used as enum count.
};

enum VSStreamMode
{
	k_nVSRead,
	k_nVSWrite,
	k_nVSCreateWrite
};

enum VSCrossFadeType
{
	k_nCrossFadeLinear,
	k_nCrossFadeSine,
	k_nCrossFadeFlatEnded,	// TODO : see if we keep that one
	k_nCrossFadeLimit		// To get the number the different cross-fade types.
};

enum VSEncoding
{
	k_nVsInvalid = -1,
	k_nVsRaw,					// Segment in vxvs file is raw data (not header of any kind)
	k_nVsPcm,
	k_nVsImaAdpcm,
	k_nVsMsAdpcm,
	k_nVsMpc,
	k_nVsStbVorbis,
	k_nVsEncodingCount
};

enum VSEnvelopeControl
{
	k_nVsEnvelopeControlInvalid = -1,
	k_nVsEnvelopeControlRpm,
	k_nVsEnvelopeControlLoad,
	k_nVsEnvelopeControlCount
};

enum VSEnvelopeParameter
{
	k_nVsEnvelopeParamInvalid = -1,
	k_nVsEnvelopeParamGain,
	k_nVsEnvelopeParamPitch,
	k_nVsEnvelopeParamCount
};

enum VSEnvelopeCurve
{
	k_nVsCurveInvalid = -1,
	k_nVsCurveLinear,
	k_nVsCurveFlatEnded,
	k_nVsCurveFlatMiddle,
	k_nVsCurveLog,
	k_nVsCurveCount
};

class VSVersions
{
 public:
	static bool IsVersionValid(const c8 *version);
	static const c8* GetVersion001Label();
	static const c8* GetVersion002Label();
 private:
	static u32 k_nbValidVersions;
	static const c8* k_vsValidVersions[];
};

struct VSChunkHeader
{
	u32 m_id;	// One of the constants k_vs... defined earlier in this file.
	s32	m_size;	// Size (in bytes) of the data portion of the chunk

	void SwitchEndian()
	{
		// Convert chunk id
		char *tmp = (char*)&m_id;
		m_id = tmp[3] + (tmp[2] << 8) + (tmp[1] << 16) + (tmp[0] << 24);

		// Convert chunk size
		tmp = (char*)&m_size;
		m_size = tmp[3] + (tmp[2] << 8) + (tmp[1] << 16) + (tmp[0] << 24);
	}
};

struct VSFileInfos
{
	char	m_version[VS_VERSION_SIZE];	// Native file format version.
	s32		m_fileSize;					// File size in bytes.
	s32		m_dataStart;				// Position of first data byte from start of file (in bytes).

	VSFileInfos():m_dataStart(0), m_fileSize(0) {}
};

// Must be first chunk in file
struct VSIdChunk
{
	VSChunkHeader	m_header;
	VSFileInfos		m_fileInfos;
};

struct VSAudioSegment
{
	s32 m_id;
	s32 m_encoding;
	s32 m_sampleRate;
	u32 m_start;		// Offset (in bytes) relative to beginning of data section of 'Data' chunk.
	u32 m_size;			// Size of segment (in bytes)
	u32 m_nbSamples;	// Nb of samples per channel of audio segment
	s32 m_loadingFlags;

	VSAudioSegment():m_id(-1), m_encoding(k_nVsInvalid), m_sampleRate(0), m_start(0), m_size(0), m_nbSamples(0), m_loadingFlags(0) {}

	void Reset(void)
	{
		m_id = -1;
		m_encoding = k_nVsInvalid;
		m_sampleRate = 0;
		m_start = 0;
		m_size = 0;
		m_nbSamples = 0;
		m_loadingFlags = 0;
	}
};

struct VSStreamParams
{
	c8*				m_filename;
	VSStreamMode	m_streamMode;
};

struct VSStreamBuffer
{
	u8*	m_pBuffer;
	s32 m_referenceCount;

	// TODO : Put some more information to avoid creating buffers with same content

	VSStreamBuffer() : m_pBuffer(0), m_referenceCount(0) {}
};

struct VSIntComp
{
  bool operator() (const s32& lhs, const s32& rhs) const
  {
	  return lhs < rhs;
  }
};

class VSStreamCursor;

///

class VSBufferPool
{
 public:
	VSBufferPool(); 
	~VSBufferPool();
	
	static VSBufferPool* GetInstance();
	static void Release();

	s32 CreateBuffer(s32 bufferSize);
	u8 *GetBuffer(s32 bufferId);
	s32 ReleaseBuffer(s32 bufferId);
 private:
	static VSBufferPool* s_pInstance;
	static s32 s_nextId;
	void *m_buffers;
};

///

// TODO : Implement cached stream with the file stream 
class VSStream : public StreamInterface
{
 public:
	VSStream(VSStreamParams *parameters);
	virtual ~VSStream();

	virtual StreamCursorInterface* CreateNewCursor(){return 0;};
	virtual void DestroyCursor(StreamCursorInterface* pStreamCursor);
	virtual s32 GetType() {return -1;} // TODO : See if correct

	s32 GetDataStartPosition();
	bool IsValid();
	FileInterface* GetFileInterface() {return m_pFile;};

	VSStreamCursor* CreateNewCursor(s32 segmentStart, s32 segmentSize, bool isBuffered = false);

	void Close();							// Used to close file without writing extension.
	const c8* GetVersion();

	// Read methods
	s32 Read(void* buffer, s32 size);
	s32 ReadByte(u8 &byteValue);
	s32 ReadChunkHeader(VSChunkHeader &chunkHeader);
	s32 ReadFloat(f32 &floatValue);
	s32 ReadInt(s32 &intValue);
	s32 ReadShort(s16 &shortValue);
	s32 ReadUnsignedInt(u32 &unsignedIntValue);

	// Write methods
	s32 Write(const void* buffer, s32 size);
	s32 WriteByte(u8 byteValue);
	s32 WriteInt(s32 intValue);
	s32 WriteShort(s16 shortValue);

	s32 Seek(s32 offset, VoxFileSeekOrigin origin);

protected:
	FileInterface* m_pFile;
	bool m_isValid;
	VSStreamMode m_streamMode;				// Reading or writing (in new or existing file)
	s32 m_streamSize;						// Size of stream.
	s32 m_cursorPosition;					// Cursor position into stream

	u8 *m_pBuffer;							// Pointer to cached data

	VSFileInfos	m_fileInfos;

	bool ParseHeader(void);

	inline void ConvertUnsignedShortToBE(u16 &value)
	{
		value = (value >> 8) | (value << 8);
	}

	inline void ConvertUnsignedIntToBE(u32 &value)
	{
		value = (value >> 24) | ((value >> 8) & 0x0000FF00) | ((value << 8) & 0x00FF0000) | (value << 24);
	}

	// TODO : See if correct
	inline void ConvertFloatToBE(f32 &value)
	{
		//value = (value >> 24) | ((value >> 8) & 0x0000FF00) | ((value << 8) & 0x00FF0000) | (value << 24);
	}

	inline void ChangeIntEndianness(s32 &value)
	{
		u32 unsignedValue = static_cast<u32> (value);
		ConvertUnsignedIntToBE(unsignedValue);
		value = static_cast<s32> (unsignedValue);
	}

	inline void ChangeShortEndianness(s16 &value)
	{
		u16 unsignedValue = static_cast<u16> (value);
		ConvertUnsignedShortToBE(unsignedValue);
		value = static_cast<s16> (unsignedValue);
	}
};

StreamInterface* VSStreamFactory(void* params);

///

class VSStreamCursor : public StreamCursorInterface
{
 public:
	VSStreamCursor(StreamInterface* pStream, s32 segmentStart, s32 segmentSize); 
	virtual ~VSStreamCursor(){}

	virtual s32 Seek(s32 pos, s32 origin = ORIGIN_START)=0;
	virtual bool IsSeekable(){return true;}
	virtual s32 Tell()=0;
	virtual s32 Read(u8* buff, s32 len)=0;
	virtual bool EndOfStream()=0;
	
	virtual void Copy(VSStreamCursor *pStreamCursor)=0;
	virtual s32 Size(void);
 protected:
	s32 m_position;
	s32 m_segmentStart;
	s32 m_segmentSize;
};

class VSFileStreamCursor : public VSStreamCursor
{
 public:
	VSFileStreamCursor(StreamInterface* pStream, s32 segmentStart, s32 segmentSize); 
	virtual ~VSFileStreamCursor(){Shutdown();}
	
	virtual void Shutdown();
	virtual s32 Seek(s32 pos, s32 origin = ORIGIN_START);
	virtual s32 Tell();
	virtual s32  Read(u8* buff, s32 len);
	virtual bool EndOfStream();

	virtual void Copy(VSStreamCursor *pStreamCursor);
protected:

};


class VSBufferStreamCursor : public VSStreamCursor
{
public:
	VSBufferStreamCursor(StreamInterface* pStream, s32 segmentStart, s32 segmentSize); 
	virtual ~VSBufferStreamCursor(){Shutdown();}
	
	virtual void Init();
	virtual void Shutdown();
	virtual s32 Seek(s32 pos, s32 origin = ORIGIN_START);
	virtual s32 Tell();
	virtual s32  Read(u8* buff, s32 len);
	virtual bool EndOfStream();

	virtual void Copy(VSStreamCursor *pStreamCursor);
protected:
	u8 *m_pBuffer;	// Pointer to a buffer from the VSBufferPool (not owned by the stream cursor)
	s32 m_bufferId;	// Id (from the VSBufferPool) of the buffer currently used.
};

} // End of namespace vs
} // End of namespace vox


#endif // _VOX_VEHICLE_SOUNDS_COMMON_H_