#pragma once
#ifndef _VOX_VEHICLE_SOUNDS_INTERNAL_H_
#define _VOX_VEHICLE_SOUNDS_INTERNAL_H_

#include "vehicle_sounds_common.h"
#include "vehicle_sounds.h"

#define VOX_INTERNAL_CODE

#include "vox_default_config.h"
#include "vox_mutex.h"
#include "vox_thread.h"
#include "vox_decoder.h"
#include "vox_macro.h"

#include VOX_VECTOR_INCLUDE
#include VOX_LIST_INCLUDE

// Define parameters history length for linear extrapolation
#define VS_PARAMETER_HISTORY_LENGTH 2

namespace vox
{

namespace vs
{


enum VSPlaybackState
{
  k_nStateInitial,
  k_nStatePlay,
  k_nStateStop,
  k_nStatePause
};

struct c8compare
{
  bool operator() (const c8* lhs, const c8* rhs) const;
};	

class VSRandomGenerator
{
 public:
	 VSRandomGenerator();
	 void Init(u32 seed);
	 u32 GetValue(void);
 private:
	u32 m_seed;
	u32 m_currentValue;
};


struct VSParamSnapshot
{
	s32 m_rpm;
	VoxVector3f m_sourcePosition;
	VoxVector3f m_sourceVelocity;
	VoxVector3f m_listenerPosition;
	VoxVector3f m_listenerVelocity;
	f64 m_time;

	VSParamSnapshot():m_rpm(-1), m_time(0.0) {}

	void Reset()
	{
		m_rpm = -1;
		m_time = 0.0f;
	}
};

struct VSBuffer
{
	s32 m_size;
	u8* m_buffer;
	VSBuffer():m_size(0), m_buffer(0){}
};

struct VSInterpolationBuffer
{
	u8* m_data;
	s32 m_usedSize;			// In bytes.
	s32 m_totalSize;		// In bytes.
	fx1814 m_cursorPos;		// Contains fractional part of cursor position (on the 14 lsb).
	u32 m_cursorOffset;		// Contains integer part of cursor position
	volatile bool free;		// True if buffer can be written into.

	VSInterpolationBuffer(): m_data(0), m_usedSize(0), m_totalSize(0), m_cursorPos(0), m_cursorOffset(0),
							 free(true) {}
};

struct VSRamp
{
	fx1814 m_target;
	s32 m_nbSamples;			// Total ramp length (since it can span over 2 buffers)
	s32 m_nbCurrentSamples;		// Length of ramp in current buffer;
	s32 m_nbSamplesRemaining;	
	s64 m_increment;
	s64 m_currentGain;

	VSRamp(): m_target(-1), m_nbSamples(0), m_nbCurrentSamples(0), m_nbSamplesRemaining(0),
			  m_increment(0), m_currentGain(0) {}

	void Reset()
	{
		m_target = -1;
		m_nbSamples = 0;
		m_nbCurrentSamples = 0;
		m_nbSamplesRemaining = 0;
		m_increment = 0;
		m_currentGain = 0;
	}
};

struct VSStartupSpecificUpdateParams
{
	bool m_hasStarted;		// True when startup has started playing. 
	f32 m_soundLength;		// Period in seconds during which event must mute.
	f32 m_crossFadeTime;	// Cross-fade time in seconds between startup and other sounds.

	VSStartupSpecificUpdateParams(): m_hasStarted(false), m_soundLength(0.0f), m_crossFadeTime(0.0f) {}

	void Reset()
	{
		m_hasStarted = false;
		m_soundLength = 0.0f;
		m_crossFadeTime = 0.0f;
	}
};

struct VSStartupUpdateParams
{
	bool m_isAllowed;
	s32 m_crossFadeLength;	// In samples
	s32 m_remainingSamples;	// Excluding cross-fade time.

	VSStartupUpdateParams(): m_isAllowed(true), m_crossFadeLength(0), m_remainingSamples(-1) {}

	void Reset()
	{
		m_isAllowed = true;
		m_crossFadeLength = 0;
		m_remainingSamples = -1;
	}
};

struct VSSoundCommonInitParams
{
	c8 m_label[VS_LABEL_SIZE];
	s32 m_loop;						// 0 = no, any other value = true
	VSAudioSegment m_audioSegment;
	VSStream *m_pStream;			// Pointer (owned by VehicleSoundsInternal object) to the data stream.
	VSEventType m_eventType;		// Type of event controlling the sound.
	s32 m_nbBuffers;
	s32 m_bufferSize;

	VSSoundCommonInitParams(): m_loop(false), m_pStream(0), m_nbBuffers(0), m_bufferSize(0) {}
};

struct VSEventCommonInitParams
{
	s32 m_id;
	VSEventType m_type;
	c8 m_label[VS_LABEL_SIZE];
	f32 m_nominalGain;
};

struct VSClutchEventInitParams
{
	VSEventCommonInitParams m_eventCommonParams;
	s32 m_reverseGearId;
	s32 m_neutralGearId;
	s32 m_initialGear;
	u32 m_nbSounds;
	u32 m_randomNoRepeatCount;

	VSClutchEventInitParams(): m_nbSounds(0), m_randomNoRepeatCount(0) {}
};

struct VSTurboDumpEventInitParams
{
	VSEventCommonInitParams m_eventCommonParams;
	s32 m_nbSounds;
	f32 m_dumpVelocityLimits[10];	// Actual nb of limits is m_nbSounds + 1.
	f32 m_turboGainThreshold;
	f32 m_deltaTurboGainThreshold;
	s32 m_layerId;					// Layer id from which to get (rpm,gain) and (load,gain) envelopes.
};

struct VSStartupEventInitParams
{
	VSEventCommonInitParams m_eventCommonParams;
	f32 m_soundLength;									// Length of startup sound in seconds.
};

struct VSLayerSoundInitParams
{
	VSSoundCommonInitParams m_commonParams;
	s32	m_nominalRpm;		// Rpm value at which engine has been recorded.
	s32	m_minRpm;			// Rpm below which the sound should not be heard.
	s32	m_maxRpm;			// Rpm over which the sound should not be heard.
	s32 m_lowRpm;			// Lowest rpm value at which sound gets full gain
	s32 m_highRpm;			// Highest rpm value at which sound gets full gain
	s32 m_autopitch;		// If true, sound is pitched according to rpm.
	s32 m_lowCrossFadeType;	// Cross-fade type with sound overlapping at the current sound's lower edge.
	s32 m_highCrossFadeType;// Cross-fade type with sound overlapping at the current sound's higher edge.
	f32 m_maxLayerPitch;	// Max pitch the layer can provide (excluding the part forwarded from the vehicle).
	
	VSLayerSoundInitParams(): m_nominalRpm(0), m_minRpm(0), m_maxRpm(0), m_lowRpm(0), m_highRpm(0),
						    m_lowCrossFadeType(-1), m_highCrossFadeType(-1), m_maxLayerPitch(1.0f) {}

	void Reset(void)
	{
		m_nominalRpm = 0;
		m_minRpm = 0;
		m_maxRpm = 0;
		m_lowRpm = 0;
		m_highRpm = 0;
		m_lowCrossFadeType = -1;
		m_highCrossFadeType = -1;
		m_maxLayerPitch = 1.0f;
	}
};

struct VSLayerSoundUpdateParams
{
	VSPlaybackState m_desiredPlaybackState;
	s32 m_effectiveRpm;
	f32 m_layerGain;
	fx1814 *m_pBuffer;
	s32 m_nbSamples;
	s32 m_sampleRate;							// Sample rate of buffer to fill
	fx1814 m_vehiclePitch;
	VSStartupUpdateParams m_startupParameters;
};

struct VSEventSoundInitParams
{
	VSSoundCommonInitParams m_commonParams;
};

// Update parameters passed from a VSEvent to an VSEventSound
struct VSEventSoundUpdateParams
{
	VSPlaybackState m_desiredPlaybackState;
	f32 m_eventGain;
	bool m_isRampInAllowed;
	fx1814 *m_pBuffer;
	s32 nbSamples;
	s32 m_sampleRate;
	fx1814 m_vehiclePitch;
	VSStartupUpdateParams m_startupParameters;
};

// Update parameters passed from VSVehicleSounds to VSEvent object
struct VSEventCommonUpdateParams
{
	VSPlaybackState m_desiredPlaybackState;	// Vehicle playback state (not event state !).
	f32	m_vehicleGain;						// Master volume for all parts of vehicle.
	fx1814 m_vehiclePitch;					// User and doppler pitch (same for all components of vehicle)
	fx1814 *m_pBuffer;						// Mixer buffer used for all components of vehicle.
	s32 m_nbSamples;						// Nb of samples needed in mixer buffer for current update.	
	s32 m_sampleRate;						// Sample rate of buffer to fill
	VSStartupUpdateParams m_startupParameters;
};

struct VSClutchUpdateSpecificParams
{
	s32 m_currentGear;			// In parameter. The current gear id.
	s32 m_gearChangeDirection;	// Out parameter. -1 : downside change, 1 : upside change, 0 : no change
};

struct VSTurboDumpUpdateSpecificParams
{
	s32 m_engineRpm;
	f32 m_engineLoad;
};

struct VSLayerInitParams
{
	s32 m_id;
	c8 m_label[VS_LABEL_SIZE];
	f32 m_nominalVolume;
	s32	m_nbEnvelopes;

	VSLayerInitParams(): m_id(-1), m_nominalVolume(1.0f), m_nbEnvelopes(0) {}
};

struct VSLayerUpdateParams
{
	VSPlaybackState m_desiredPlaybackState;
	s32 m_effectiveRpm;
	f32 m_engineLoad;
	f32	m_vehicleGain;						// Master volume for all parts of car supported in VehicleSounds.
	fx1814 m_vehiclePitch;					// User and doppler pitch (same for all components of vehicle)
	fx1814 *m_pBuffer;
	s32 m_nbSamples;
	s32 m_sampleRate;
	VSStartupUpdateParams m_startupParameters;
};


struct VSEnvelopePoint
{
	VSEnvelopeCurve m_curve;	// Curve from current point to next point
	f32 m_controlValue;			// Value of control parameter (e.g. load, rpm, ...)
	f32 m_parameterValue;		// Value of controlled parameter (e.g. gain, pitch, ...)
};

struct VSEnvelopeInitParams
{
	s32 m_id;
	c8 m_label[VS_LABEL_SIZE];
	VSEnvelopeControl m_control;
	VSEnvelopeParameter m_parameter;
};

class VSEnvelope
{
 public:
	VSEnvelope(VSEnvelopeInitParams *pParameters);
	VSEnvelope(VSEnvelope *pEnvelope);
	~VSEnvelope(void);

	void AddPoint(const VSEnvelopePoint &point);
	s32 GetId(void);
	VSEnvelopeControl GetControlType();
	VSEnvelopeParameter GetParameterType();
	f32 GetEnvelopeValueEx(f32 currentControlValue, f32 previousControlValue, bool &isMonotonic, f32 &intermediateMin);
	f32 GetEnvelopeValue(f32 controlValue);	// Returns the parameter value associated to the control value.
	f32 GetMaximumValue(void);
 protected:
	s32 m_id;
	c8 m_label[VS_LABEL_SIZE];
	VSEnvelopeControl m_control;
	VSEnvelopeParameter m_parameter;

	VOX_VECTOR<VSEnvelopePoint, SAllocator<VSEnvelopePoint> > m_points;
};

class VSSound
{
 public:
	virtual ~VSSound(void);

	static void Clean();
	static void SetDriverParameters(s32 sampleRate, fx1814 callbackPeriod);

	virtual void Reset();
	virtual void Update(void *pParams)=0;

	void GetData(void);
	bool IsDone();
	
 protected:
	VSSound(VSSoundCommonInitParams *pParameters);
	static s32 s_driverSampleRate;
	static fx1814 s_driverCallbackPeriod;

	static VSBuffer s_workBuffer;	// Work buffer used for interpolation

	c8	m_label[VS_LABEL_SIZE];
	VSEventType m_eventType;		// Type of event controlling the sound.

	// Stream parameters
	VSStream *m_pStream;
	VSStreamCursor *m_pStreamCursor;

	// Decoder parameters
	DecoderInterface *m_pDecoder;
	DecoderCursorInterface *m_pDecoderCursor;
	s32 m_totalSamplesDecoded;

	// Audio segment information
	VSAudioSegment m_audioSegment;
	
	// Volume ramping parameters
	bool m_isRampInAllowed;			// False when an event sound is triggered. Otherwise always true.
	bool m_rampOut;					// True when pausing, stopping or getting out of rpm range.
	s32 m_rampInOffset;				// Nb of samples in mixing buffer before ramp-in.
	VSRamp m_inRamp;				// Parameters for ramp-in section.
	s32 m_constantGainLength;		// Nb of samples in constant gain section following ramp-in.
	VSRamp m_outRamp;				// Parameters of volume change ramp-out section.
	s32 m_startUpCrossFadeLength;	// Cross-fade length between startup and other sounds (in samples)
	VSRamp m_starvingOutRamp;		// Parameters of starving ramp-out section.
	
	// Startup parameters
	s32 m_startupRemainingSamples;	// Excluding cross-fade time.

	// Gain parameters
	fx1814 m_gain;					// User target gain (updated at each Update() call).
	fx1814 m_previousGain;			// Used for gain ramping (sample per sample)

	// Pitch parameters
	fx1814 m_pitch;

	// Playback parameters
	VSPlaybackState m_playbackState;
	bool m_isDone;					// True when a sound has done one loop.
	bool m_loop;
	bool m_hasSoundPlayed;

	// Buffers containing non-interpolated decoded data (and interpolation position information).
	VOX_VECTOR<VSInterpolationBuffer, SAllocator<VSInterpolationBuffer> > m_bufferList;
	s32 m_nbBuffers;
	s32 m_currentReadBuffer;
	s32 m_currentWriteBuffer;
	s32 m_lastSoundBuffer;		// Index of buffer containing end of sound. Doesn't need mutex.

	// Mutexes
	Mutex m_mutex;		// For concurrence between decoding thread (GetData()) and filling buffer thread (Update()).
	Mutex m_resetMutex; // For concurrence between Reset() and GetData().

	static void GetWorkBuffer(s32 size); // See if should be in this class

	virtual void GetDefaultBufferConfiguration(s32 &nbBuffers, s32 &bufferSize)=0;

	s32 DecodeSegment(u8** ppBuffer);
	DecoderInterface* GetDecoder(void);
	void FillBuffer(fx1814* buffer, s32 nbSamples, s32 sampleRate); 
	s32 GetWorkData(u8* outbuf, s32 nbBytes, fx1814 nbSamples);
	void Init(VSSoundCommonInitParams *pParameters);
};

class VSLayerSound : public VSSound
{
 public:
	VSLayerSound(VSLayerSoundInitParams *pParameters);
	~VSLayerSound(void);

	virtual void Reset();
	virtual void Update(void *pParams);
 private:
	// Rpm parameters
	s32	m_nominalRpm;		// Rpm value at which engine has been recorded.
	s32	m_minRpm;			// Rpm below which the sound should not be heard.
	s32	m_maxRpm;			// Rpm over which the sound should not be heard.
	s32 m_lowRpm;			// Lowest rpm value at which sound gets full gain
	s32 m_highRpm;			// Highest rpm value at which sound gets full gain

	bool m_autopitch;		// If true, sound pitch is calculated according to rpm value.
	f32 m_maxLayerPitch;	// Max pitch the layer can provide (excluding the part forwarded from the vehicle).

	VSCrossFadeType m_lowCrossFadeType;		// Cross-fade type with sound overlapping at the current sound's lower edge.
	VSCrossFadeType m_highCrossFadeType;	// Cross-fade type with sound overlapping at the current sound's higher edge.

	virtual void GetDefaultBufferConfiguration(s32 &nbBuffers, s32 &bufferSize);

	VSCrossFadeType ConvertCrossFadeType(s32 crossFadeType);
};

class VSEventSound : public VSSound
{
 public:
	VSEventSound(VSEventSoundInitParams *pParameters);
	~VSEventSound(void);

	virtual void Reset();
	virtual void Update(void *pParams);

	void SetAsExtraSound(VSEventSound *pSound);
 protected:
    virtual void GetDefaultBufferConfiguration(s32 &nbBuffers, s32 &bufferSize);
};

// Class to manage punctual events such as clutch, turbo dumps, ..
class VSEvent
{
  public:
	virtual ~VSEvent(void){};

	virtual void AddSound(VSEventSoundInitParams *pParameters)=0;
	virtual void Reset();
	virtual void Update(VSEventCommonUpdateParams *pParameters, void *pEventSpecificParams)=0;
	
	void GetData(void);
	s32 GetId(void){return m_id;}
	VSEventType GetType(void) {return m_type;}
 protected:
	VSEventType m_type;
	s32 m_id;
	c8 m_label[VS_LABEL_SIZE];
	
	float	m_nominalGain;
	VSPlaybackState m_playbackState;
	bool m_hasAlreadyPlayed;				// False on the first update when desiredState gets to Play.

	VOX_VECTOR<VSEventSound*, SAllocator<VSEventSound*> > m_sounds;

	VSEvent(VSEventCommonInitParams *pParameters);
};

class VSClutchEvent : public VSEvent
{
  public:
	VSClutchEvent(VSClutchEventInitParams *pParameters);
	virtual ~VSClutchEvent(void);

	virtual void AddSound(VSEventSoundInitParams *pParameters);
	virtual void Reset();
	virtual void Update(VSEventCommonUpdateParams *pParameters, void *pEventSpecificParams);
 private:
	// Gear parameters
	s32	m_reverseGearId;
	s32	m_neutralGearId;
	s32	m_previousGear;

	// Random playback parameters
	u32 m_nbSounds;				// Number of sounds (excluding the extra sound)
	u32 m_randomNoRepeatCount;	// 0 : random, n : sound cannot be selected the next 'n' times.
	s32 *m_pActiveSounds;		// Buffer containing indexes of sounds that can be chosen at random.
	u32 m_nbActiveSounds;		// Current number of sounds that can be chosen at random.
	s32 *m_pUsedSounds;			// A circular buffer containing indexes of sounds that cannot be chosen at random.
	u32 m_nbUsedSounds;			// Current number of sounds that cannot be chosen at random.
	s32 m_usedSoundsStart;		// Start index in m_pUsedSounds buffer.
	s32 m_usedSoundsEnd;		// End index in m_pUsedSounds buffer.
	VSRandomGenerator m_randomGenerator;

	// Extra sound management parameters
	VSEventSound *m_pCurrentSound;	// Pointer to the dump sound currently playing (if any).
	u32 *m_pSoundMapping;
	s32 m_playingSoundIndex;	// Index of playing sound in m_pSoundMapping array.
	s32 m_extraSoundIndex;		// Index of extra sound in m_pSoundMapping array.

	u32 GetRandomSound();
};

class VSTurboDumpEvent : public VSEvent
{
  public:
	VSTurboDumpEvent(VSTurboDumpEventInitParams *pParameters);
	virtual ~VSTurboDumpEvent(void);

	virtual void AddSound(VSEventSoundInitParams *pParameters);
	virtual void Reset();
	virtual void Update(VSEventCommonUpdateParams *pParameters, void *pEventSpecificParams);

	void AddEnvelope(VSEnvelope *pEnvelope);
	s32 GetLayerId(void);
 private:
	u32 m_nbSounds;
	s32 m_layerId;
	VSEventSound *m_pCurrentSound;	// Pointer to the dump sound currently playing (if any).
	f32 m_previousTurboGain;
	f32 m_previousLoad;
	s32 m_previousRpm;

	// Sound triggering threshold parameters
	f32 m_turboGainThreshold;
	f32 m_deltaTurboGainThreshold;
	f32 *m_pTurboDumpVelocityLimits;
	f32 m_dumpVelocityFactor;

	// Extra sound management parameters
	u32 *m_pSoundMapping;
	s32 m_playingSoundIndex;	// Index of playing sound in m_pSoundMapping array.
	s32 m_extraSoundIndex;		// Index of extra sound in m_pSoundMapping array.

	VOX_LIST<VSEnvelope*, SAllocator<VSEnvelope*> > m_envelopes;
};

class VSStartupEvent : public VSEvent
{
  public:
	VSStartupEvent(VSStartupEventInitParams *pParameters);
	virtual ~VSStartupEvent(void);

	virtual void AddSound(VSEventSoundInitParams *pParameters);
	virtual void Update(VSEventCommonUpdateParams *pParameters, void *pEventSpecificParams);
 private:
	f32 m_soundLength;	// Length of startup sound in seconds.
	VSPlaybackState m_previousVehicleState;
};

// Class to manage layers of sounds that are controlled by rpm and load (e.g. ON, OFF, rumble, turbo sounds)
class VSLayer
{
 public:
	VSLayer(VSLayerInitParams *pParameters);
	~VSLayer(void);

	void AddSound(VSLayerSoundInitParams *pParameters);
	void AddEnvelope(VSEnvelopeInitParams *pParams);
	void GetData(void);
	f32 GetMaximumPitch(void);
	VSEnvelope *GetEnvelope(s32 envelopeId);
	VSEnvelope *GetEnvelope(VSEnvelopeControl controlType, VSEnvelopeParameter parameterType);
	s32 GetId(void);
	void Reset(void);
	void SetMaximumPitch(f32 pitch);
	void Update(VSLayerUpdateParams *pParameters);
 protected:
	c8 m_label[VS_LABEL_SIZE];
	s32 m_id;
	VSPlaybackState m_playbackState;
	f32 m_nominalVolume;
	f32 m_maximumPitch;						// Max pitch (from control->pitch) a layer can apply to a sound.

	VOX_LIST<VSSound*, SAllocator<VSSound*> > m_sounds;
	VOX_LIST<VSEnvelope*, SAllocator<VSEnvelope*> > m_envelopes;
};

class VehicleSoundsInternal : public MinibusDataGenerator3DPlugin
{
 public:
	 VehicleSoundsInternal();
	~VehicleSoundsInternal();

	static void Clean();

	virtual void GetData(s32* buffer, s32 nbSample, s32 sampleRate);
	virtual void Get3DSourceParameters(Vox3DEmitterParameters &sourceParams);
	virtual void Get3DListenerPositioning(Mdgp3DListenerPositioning &positioning);
	virtual void Get3DSourcePositioning(Mdgp3DSourcePositioning &positioning);
	virtual void Set3DSourceParameters(const Vox3DEmitterParameters &sourceParams);
	virtual void Set3DListenerPositioning(const Mdgp3DListenerPositioning &positioning);
	virtual void Set3DSourcePositioning(const Mdgp3DSourcePositioning &positioning);

	s32 GetLimiterRpm(void);
	s32 GetMinEngineRpm(void);
	s32 GetMaxEngineRpm(void);
	VSState GetState(void);
	bool Init(c8 *filename, c8 *configurationLabel, Mdg3DParameters *p3DParameters = 0, VSGeneralInitParams *pGeneralParams = 0);
	void Play(bool isStartupAllowed = true);
	void Stop(void);
	void Pause(void);
	void Resume(void);
	void SetGain(f32 gain);
	void SetPitch(f32 pitch);
	VSState Update(const VSUpdateParameters &parameters);
 private:
	static VSBuffer s_mixingBuffer;	// Work buffer to get mixed data from all sounds
	static f64 s_callbackPeriod;	// = MinibusDataGeneratorInterface::_driverCallbackPeriod as a f64 value

	c8 m_vsFileName[VS_FILENAME_LENGTH];
	VSStream *m_pVsStream;

	s32 m_configurationId;					// Id of configuration used for the current vehicle.
	c8 m_configurationLabel[VS_LABEL_SIZE];	// Label of configuration used for the current vehicle.

	VSFileInfos	m_fileInfos;
	VOX_VECTOR<VSAudioSegment, SAllocator<VSAudioSegment> > m_audioSegments;

	// State parameters.
	VSPlaybackState	m_desiredPlaybackState;	// Playback state of the vehicle before a FillBuffer()
	VSPlaybackState	m_playbackState;		// Previous playback state of the vehicle

	// Volume parameters
	f32	m_gain;						// Volume multiplier affecting all vehicle sounds.
	s32 m_nominalRampLength;		// In samples (constant length in time).
	fx1814 m_previousLeftGain;		// 3D left gain from previous callback.
	fx1814 m_previousRightGain;		// 3D right gain from previous callback.
	VSRamp m_leftRamp;				// Parameters for ramp-in section.
	VSRamp m_rightRamp;				// Parameters for ramp-out section

	bool m_isFirstBufferFilled;		// To avoid ramping on first buffer of event sounds.
	bool m_isFirstUpdateDone;		// To avoid buffer filling before a game update has been done.

	// Rpm related parameters
	s32	m_minEngineRpm;				// Minimal limit for RPM values.
	s32	m_maxEngineRpm;				// Maximal limit for RPM values.
	s32 m_limiterRpm;				// Starting rpm value for the limiter.
	s32 m_effectiveRpm;				// Rpm target at current FillBuffer() (for pitch fading).
	s32 m_previousRpm;				// Value of m_effectiveRpm at last driver callback.
	f64 m_rpmTime;					// Time stamp of m_effectiveRpm value.
	f64 m_previousRpmTime;			// Time stamp of m_previousRpm value.
	s32 m_rpmDirection;				// = 1 if rpm goes up, -1 if it goes down, 0 otherwise.
	s32 m_previousRpmDirection;		// Value of m_rpmDirection at last update frame.

	// Parameters history (used for extrapolation)
	VSParamSnapshot m_paramHistory[VS_PARAMETER_HISTORY_LENGTH]; // Index 0 = oldest rpm. Largest index = current rpm.

	// Load factor parameters
	f32	m_engineLoad;				// Measure of movement resistance.
	f32	m_previousLoad;
	f32 m_rpmSmooth;				// Presently not used !
	f32	m_loadSmooth;				// Highpass factor (near 1 = wideband, near 0 = narrowband).
	f32	m_loadScale;				// Highpass dividor for rpm delta.
	f32	m_loadFilterOutput;			// Output of the load filter.

	// Gear parameters
	s32	m_currentGear;			// ID of currently selected gear.
	bool m_isGearChangeUp;		// True if last gear change was upside.

	// Pitch parameters
	fx1814 m_userPitch;
	fx1814 m_effectivePitch;	// Combination of user and doppler pitch.

	// Turbo parameters
	bool m_hasTurboDumpEvent;

	// Startup parameters
	bool m_hasStartupEvent;
	bool m_isStartupAllowed;
	bool m_isStartingUp;
	VSStartupUpdateParams m_startupUpdateParams;

	// Extrapolation parameters
	bool m_isExtrapolationSmooth;
	f64 m_extrapolationFactor;		// Extrapolation smooth factor in ]0.0, 1.0]
	
	// Layer parameters
	VOX_LIST<VSLayer*, SAllocator<VSLayer*> > m_soundLayers;

	// Event parameters
	VOX_LIST<VSEvent*, SAllocator<VSEvent*> > m_events;

	// Thread parameters
	VoxThread*	m_dataSourceThread;		// Thread used to get data from audio segments
	s32 m_dataSourceThreadSleepTimeMs;	// In miliseconds
	bool m_isThreadRunning;

	Mutex m_mutex;

	static void UpdateThreaded(void* caller, void* param);

	VSEnvelopeCurve ConvertEnvelopeCurveType(s32 type);
	VSEnvelopeControl ConvertEnvelopeControlType(s32 type);
	VSEventParamType ConvertEventParamType(s32 type);
	VSEventType ConvertEventType(s32 type);
	VSEnvelopeParameter ConvertEnvelopeParameterType(s32 type);
	VSEncoding ConvertSegmentEncoding(s32 encoding);
	void DownloadData();
	void ExtrapolateParameters();									// Linear extrapolation
	void FillBuffer(fx1814* buffer, s32 nbSamples, s32 sampleRate);
	void Apply3D(fx1814* buffer, s32 nbSamples);
#if VOX_ENHANCED_3D
	void ApplyEnhanced3D(fx1814* buffer, s32 nbSamples);
#endif
	void GetAudioSegment(s32 id, VSAudioSegment& audioSegment);
	void GetLoad();
	VSState _GetState(void);
	void GetTurboDumpEnvelopes();
	VSEvent *GetVehicleEvent(s32 id);
	VSLayer *GetVehicleSoundLayer(s32 id);
	bool ParseSoundPackage(c8* filename, VSGeneralInitParams *pUserInitParams);
	void Reset();
	void UpdateExtrapolationMode();
	void UpdateParametersHistory(const VSUpdateParameters &parameters);
};

} // namespace vs
} // namespace vox

#endif // _VOX_VEHICLE_SOUNDS_INTERNAL_H_
