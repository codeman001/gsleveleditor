
#include "external_media_player.h"
#include "media_player_common.h"

namespace vox
{
	
namespace media_player
{
	
ExternalMediaPlayer *ExternalMediaPlayer::s_pInstance = 0;


ExternalMediaPlayer::~ExternalMediaPlayer()
{
}


ExternalMediaPlayer *ExternalMediaPlayer::Create(CreationErrorCode &outCode)
{
	outCode = CEC_ERROR;

	if(s_pInstance) // Instance was already created,
	{
		outCode = CEC_ALREADY_CREATED;
		return 0;
	}
	else 
	{
		s_pInstance = CreatePlayer();
		if(s_pInstance)
		{
			outCode = CEC_SUCCESS;
		}
	}

	return s_pInstance;
}
  
	   
void ExternalMediaPlayer::Destroy(void)
{	
	DestroyPlayer();
	s_pInstance = 0;
}
	   

ExternalMediaPlayer *ExternalMediaPlayer::GetInstance()
{
	return s_pInstance;
}


} // media_player namespace
	
} // vox namespace
