#pragma once
#ifndef _VOX_EXTERNAL_MEDIA_PLAYER_H
#define _VOX_EXTERNAL_MEDIA_PLAYER_H

#include "vox_types.h"

#define VOX_ENUM_FLAGS_DECLARE_OPERATION(X)	inline X operator|(X lhs, X rhs){u32 l = lhs; u32 r = rhs; return static_cast<X>(l | r);}\
											inline X operator&(X lhs, X rhs){u32 l = lhs; u32 r = rhs; return static_cast<X>(l & r);}\
											inline X operator^(X lhs, X rhs){u32 l = lhs; u32 r = rhs; return static_cast<X>(l ^ r);}\
											inline X operator|=(X& lhs, X rhs){u32 l = lhs; u32 r = rhs; lhs = static_cast<X>(l | r); return lhs;}\
											inline X operator&=(X& lhs, X rhs){u32 l = lhs; u32 r = rhs; lhs = static_cast<X>(l & r); return lhs;}\
											inline X operator^=(X& lhs, X rhs){u32 l = lhs; u32 r = rhs; lhs = static_cast<X>(l ^ r); return lhs;}\
											inline X operator~(X lhs){u32 l = lhs; return static_cast<X>(~l);}

// Prototype of user callbacks
typedef void (*ExternalMediaPlayerCallback) (void *pUserData);

// Prototype of callbacks player registers upon playback server
typedef void (*InternalMediaPlayerCallback) (void);


namespace vox
{

namespace media_player
{
	
//! External Media Player user interface
/*!
	This class is the user interface to External Media Player. Usage basically follows the steps:
	1) Create a player (with a call to static method Create())
	2) Set the location of the user's media files (with a call to SetMediaPath()).
	3) Register user's callbacks (to be informed of song changes, state changes, etc.)
	4) Open the player (with a call to Open())
	5) Loop through the items between here and 'End of loop' (not inclusive)
	6) Set a media category (with a call to SetMediaItemCategory()).
	7) Get the number of the media items in the current category (with a call to GetMediaItemsCount()).
	8) Get the names of the media items in the current category (with calls to GetMediaItemName()).
	9) Set a playback queue with one media item from the current category (with a call to SetMediaItem()).
	10) Start playback and other playback related calls (next, shuffle, repeat, etc.).
	11) End of loop
	12) Close the player (with a call to Close())
	13) Destroy the player (with a call to static method Destroy()).
*/
class ExternalMediaPlayer
{
public:
	virtual ~ExternalMediaPlayer();
	
	//! Error codes returned upon player creation
	enum CreationErrorCode
	{
		CEC_SUCCESS = 0,			//!< Media player has been created successfully.
		CEC_ERROR = -1,				//!< Media player failed to be created.
		CEC_ALREADY_CREATED = -2,	//!< Media player was already created.
	};
	
	// Note : MediaItemCategory values should be a power of two in order to use masks on each platform.
	//! Media item categories
	enum MediaItemCategory
	{
		MI_UNKNOWN = 0,		//!< Unknow category.
		MI_PLAYLIST = 1,	//!< Playlist.
		MI_ARTIST = 2,		//!< Artist.
		MI_ALBUM = 4,		//!< Album.
		MI_SONG = 8,		//!< Song.
	};
	
	//! Playback shuffle modes
	enum ShuffleMode
	{
		SM_DEFAULT,			//!< Queued items are played in the order obtained from the query.
		SM_OFF,				//!< Queued items are played in the order obtained from the query.
		SM_SONGS,			//!< Random song playback. A song cannot be played twice until all songs have been played.
		SM_ALBUMS,			//!< Randomly sorted by album. Albums content is in the original order.
	};
	
	//! Playback repeat modes
	enum RepeatMode
	{
		RM_DEFAULT,			//!< Playback queue is played once without repetition.
		RM_NONE,			//!< Playback queue is played once without repetition.
		RM_ONE,				//!< Current song is repeated over and over.
		RM_ALL,				//!< Playback queue is repeated over and over (each repetition follows the shuffle mode).
	};
	
	//! User callback function types
	enum CallbackType
	{
		CT_STATE_CHANGED,		//!< The callback function is called when the state of the playback queue has changed.
		CT_NOW_PLAYING_CHANGED, //!< The callback function is called when the current playing song has changed.
		CT_LIBRARY_CHANGED,		//!< The callback function is called when the library has been changed.
	};
	
	//! Query state of asynchronous methods
	enum QueryState
	{
		QS_SUCCESS = 0,		//!< The requested task has finished successfully.
		QS_ERROR = -1,		//!< There was a problem during execution of the requested task.
		QS_RUNNING = -2,	//!< The requested task is still under execution.
		QS_DISABLED = -3,	//!< The requested task is disabled.
	};
	
	//! Media player's playback states
	enum PlaybackState
	{
		PS_PLAYING,			//!< The playback queue is in playing mode.
		PS_PAUSED,			//!< The playback queue is paused.
		PS_STOPPED,			//!< The playback queue is either stopped or there is currently no playback queue.
		PS_OTHER,			//!< Unknown playback state (e.g. returned by the null player).
		PS_PENDING,			//!< An asynchronous query is ongoing. A valid state will be available at the end of query.
	};

	//! Create an external media player
	/*!
		Creates an external media player for the current platform. If there is no player for the platform,
		a null player (responding to full API methods but doing nothing) is returned. If the player was
		already created (by a previous call to Create()), a null pointer is returned and outCode is set
		to CEC_ALREADY_CREATED. Note that the player becomes operational only after (facultative)
		RegisterCallback() calls and (mandatory) Open() call.
		\param outCode An error code stating if creation has succeeded, failed or player was already created.
		\return A pointer to an ExternalMediaPlayer object
	*/
	static ExternalMediaPlayer *Create(CreationErrorCode &outCode);

	//! Destroy an external media player
	/*!
		Destroys the external media player created with Create().
	*/
	static void Destroy(void);

	//! Get the (unique) external media player instance
	/*!
		Returns a pointer to the unique instance of the external media player. Note that this method cannot
		be used to create the media player. Create() has to be called explicitely. If GetInstance() is called
		without the player having been created, a null pointer is returned.
		\return A pointer to the unique ExternalMediaPlayer instance (or null if not already created).
	*/
	static ExternalMediaPlayer *GetInstance();
	
	//! Register user's callback functions.
	/*!
		Registers one user callback function with signature void (*ExternalMediaPlayerCallback) (void *pUserData);
		The method has to be called for each callback the user wants to register (the list of all possible
		callbacks are listed in enum CallbackType). The calls have to be done prior to the Open() call. The
		method returns 'false' if the player doesn't support the requested callback type or if the call has been
		done after the Open() call.
		\param callbackType The callback type to be registered (e.g. CT_STATE_CHANGED).
		\param callback A pointer to the callback function to register.
		\param pUserData A pointer to data that the user wants back when the callback function is called.
		\return False if the player doesn't support the requested callback type or if the call has been done after the Open() call.
	*/
	virtual bool RegisterCallback(CallbackType callbackType, ExternalMediaPlayerCallback callback, void *pUserData) = 0;

	//! Inform the media player of the root location of the user's media files
	/*!
		Informs the media player of the root location of the user's media files. The path provided
		must be relative to glf's data path (which can be overriden by a call to method
		glf::Fs::Win32OverrideDataPath()). Not all platforms need to have this information.
		As for now, this is only used on Windows.
		\param path The path to the root of the user's media files (relative to glf's data path).
	*/
	virtual void SetMediaPath(const char *path){};

	//! Open the media player
	/*!
		Opens the media player. This method has to be called after Create() in order for the player to
		operate.
	*/
	virtual bool Open() = 0;

	//! Close the media player
	/*!
		Closes the media player opened with Open().
	*/
	virtual void Close() = 0;

	//! Suspend operation of the media player
	/*!
		Suspends operation of the media player. Any running query is dropped and player doesn't respond
		to user request. However, playback may continue (this is the case for example on iPhone).
	*/
	virtual void Suspend() = 0;

	//! Resume operation of the media player
	/*!
		Resumes operation of the media player.
	*/
	virtual void Resume() = 0;

	//! Start playback of the media player
	/*!
		Starts playback of queued songs on the media player. Songs are queued for playback using SetMediaItem().
	*/
	virtual void Play() = 0;

	//! Stop playback of the media player
	/*!
		Stops playback of the media player. The playback queue remains valid and a subsequent Play() call
		will restart playback at the beginning of the queue.
	*/
	virtual void Stop() = 0;

	//! Pause playback of the media player
	/*!
		Pauses playback of the media player. Playback is resumed by a Play() call.
	*/
	virtual void Pause() = 0;

	//! Go to the next song in the playback queue.
	/*!
		Goes to the next song in the playback queue. If calling Next() while the current song is the last
		of the queue, order is ignored unless repeat mode is set to RM_ALL, in which case the first song
		of the queue becomes the current song.
	*/
	virtual void Next() = 0;

	//! Go to the previous song in the playback queue.
	/*!
		Goes to the previous song in the playback queue. If calling Previous() while the current song is the
		first of the queue, order is ignored unless repeat mode is set to RM_ALL, in which case the last song
		of the queue becomes the current song.
	*/
	virtual void Previous() = 0;

	//! Get the current shuffle mode.
	/*!
		Gets the value of the current shuffle mode. Shuffle mode values are defined in the ShuffleMode enum.
		\return The value of the current shuffle mode.
	*/
	virtual ShuffleMode GetShuffleMode() = 0;

	//! Get the current repeat mode.
	/*!
		Gets the value of the current repeat mode. Repeat mode values are defined in the RepeatMode enum.
		\return The value of the current repeat mode.
	*/
	virtual RepeatMode GetRepeatMode() = 0;

	//! Get the current media item category.
	/*!
		Gets the value of the current media item category (whose values are defined in the MediaItemCategory enum).
		\return The value of the current media item category.
	*/
	virtual MediaItemCategory GetMediaItemCategory(void) = 0;
	
	//! Get the number of items of the current media item category in the library.
	/*!
		Provides the number of items of the current media item category in the library. This method generates
		an asynchronous query so may not provide the actual count on first call. It returns QS_RUNNING if
		the query is still running (in which case the count isn't valid). A valid count is provided when
		the call returns QS_SUCCESS.
		\param outItemCount The number of items of the current media item category in the library.
		\return The state of the query. Query states are defined in the QueryState enum.
	*/
	virtual QueryState GetMediaItemsCount(s32 &outItemCount) = 0;

	//! Get the name of a media item from the current media item category.
	/*!
		Provides the name of item with index = itemIndex in the query carried out by the last
		GetMediaItemsCount() call. This method generates an asynchronous query so may not provide
		the actual name on first call. It returns QS_RUNNING if	the query is still running (in which
		case the name isn't valid). A valid name is provided when the call returns QS_SUCCESS.
		\param outItemName Index of the item gotten from the last GetMediaItemsCount() query.
		\param outItemName Name of the item identified by parameter 'itemIndex'.
		\return The state of the query. Query states are defined in the QueryState enum.
	*/
	virtual QueryState GetMediaItemName(s32 itemIndex, const char *&outItemName) = 0;

	//! Get information about the currently playing song.
	/*!
		Provides the names of the song, artist and album of the currently playing song. It also provides
		the duration and cursor position of the song in seconds. This method generates an asynchronous
		query so may not provide the actual information on first call. It returns QS_RUNNING if	the query
		is still running (in which case the information isn't valid). Valid information is provided when
		the call returns QS_SUCCESS.
		\param outTitle Name of the currently playing song.
		\param outArtist Name of the composer of the currently playing song.
		\param outAlbum Name of album from which the currently playing song is taken.
		\param outCursorPosition Playback position in the currently playing song (in seconds).
		\param outPlaybackDuration Duration of the currently playing song (in seconds).
		\return The state of the query. Query states are defined in the QueryState enum.
	*/
	virtual QueryState GetNowPlayingItemData(const char *&outTitle, const char *&outArtist, const char *&outAlbum, f32* outCursorPosition, f32* outPlaybackDuration) = 0;

	//! Get the playback state of the media player.
	/*!
		Provides the playback state of the media player. This method generates an asynchronous
		query so may not provide the actual playback state on first call. It returns QS_RUNNING
		if	the query is still running (in which case the playback state isn't valid). A valid
		playback state is provided when	the call returns QS_SUCCESS.
		\param outPlaybackState Playback state of the media player (as defined in the PlaybackState enum).
		\return The state of the query. Query states are defined in the QueryState enum.
	*/
	virtual QueryState GetPlaybackState(PlaybackState &outPlaybackState) = 0;
	
	//! Set the shuffle mode in which songs from the playback queue are played.
	/*!
		Sets the shuffle mode in which songs from the playback queue are played. Shuffle mode values are
		defined in the ShuffleMode enum.
		\param shuffleMode The shuffle mode to set (as defined in the ShuffleMode enum).
		\return False if the shuffle mode could not be set to the desired value (e.g. when not supported by the media player).
	*/
	virtual bool SetShuffleMode(ShuffleMode shuffleMode) = 0;

	//! Set the repeat mode for the playback queue.
	/*!
		Sets the repeat mode in which songs from the playback queue are played. Repeat mode values are
		defined in the RepeatMode enum.
		\param repeatMode The repeat mode to set (as defined in the RepeatMode enum).
		\return False if the repeat mode could not be set to the desired value (e.g. when not supported by the media player).
	*/
	virtual bool SetRepeatMode(RepeatMode repeatMode) = 0;

	//! Set the current media item category.
	/*!
		Sets the current media item category. This will affect all subsequent player calls until the
		parameter is set to another value. For example, if category is set to MI_PLAYLIST, a call to
		GetMediaItemsCount() will return the number of playlists in the media library.
		\param category The media item category to set (as defined in the MediaItemCategory enum).
		\param params As for now, not used.
	*/
	virtual void SetMediaItemCategory(MediaItemCategory category, void *params) = 0;

	//! Create a playback queue with the songs from the requested media item.
	/*!
		Creates a playback queue with the songs from the requested media item. For example, if the
		current media category is MI_ARTIST and a call to GetMediaItemsCount() returns N, then the call
		SetMediaItem(i) will create a playback queue with all songs from the artist whose name can be
		retrieved from the call	GetMediaItemName(i, name), where 0 <= i < N.
		\param itemIndex Index of the item gotten from the last GetMediaItemsCount() query.
	*/
	virtual void SetMediaItem(s32 itemIndex) = 0;
protected:
	static ExternalMediaPlayer *s_pInstance;
	
	ShuffleMode			m_shuffleMode;
	RepeatMode			m_repeatMode;
	MediaItemCategory	m_mediaItemCategory;
};
	
VOX_ENUM_FLAGS_DECLARE_OPERATION(ExternalMediaPlayer::MediaItemCategory);	
} // media_player namespace
	
} // vox namespace

#endif // _VOX_EXTERNAL_MEDIA_PLAYER_H