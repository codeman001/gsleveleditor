#pragma once
#ifndef _VOX_IPOD_PLAYER_H
#define _VOX_IPOD_PLAYER_H

#include "vox.h"

#define VOX_INTERNAL_CODE

#include "vox_thread.h"
#include "vox_mutex.h"

#include "external_media_player.h"
#include "media_player_common.h"

#if VOX_USE_IPOD_MEDIA_PLAYER

#import <MediaPlayer/MediaPlayer.h>

#include VOX_LIST_INCLUDE


@class NSArray;
@class NSAutoreleasePool;

@interface DummyNSThreadClass : NSObject 
{
}
- (void) dummy;
@end

// Prototype of internal (i.e. not user) callback functions
typedef void (*iPodNotificationCallback) (void);

// Notification handler definitions
@interface IPodNotificationHandler : NSObject 
{
	iPodNotificationCallback m_stateCallback;
	iPodNotificationCallback m_songCallback;
	iPodNotificationCallback m_libraryCallback;
}

-(void) initHandler;
-(void) reset;
-(void) setStateCallback:(iPodNotificationCallback) stateCallback;
-(void) setSongCallback:(iPodNotificationCallback) songCallback;
-(void) setLibraryCallback:(iPodNotificationCallback) libraryCallback;
-(void) handle_stateChanged:(NSNotification*) aNotification;
-(void) handle_songChanged:(NSNotification*) aNotification;
-(void) handle_libraryChanged:(NSNotification*)aNotification;

@end

namespace vox
{

namespace media_player
{

const s32 IpodMediaCategoriesMask = ExternalMediaPlayer::MI_PLAYLIST | ExternalMediaPlayer::MI_ARTIST | ExternalMediaPlayer::MI_ALBUM | ExternalMediaPlayer::MI_SONG;
	

struct ControllerQueryData
{
	ControllerQueryData(){}
	ControllerQueryData(void* _array, Mutex* pQueryMutex):m_array(_array), m_pQueryMutex(pQueryMutex){}
	void* m_array;
	Mutex* m_pQueryMutex;
};	


class AsyncQuery
{
public:
	AsyncQuery();
	~AsyncQuery();
		
	bool GetMediaItems(ExternalMediaPlayer::MediaItemCategory category, ControllerQueryData queryData);
		
	static bool m_isRunning;
	static bool m_dropResult;
private:		
	bool Cancel();
	
	static void* _QueryMediaItems(void *arg);
		
	static ExternalMediaPlayer::MediaItemCategory s_mediaItemCategory;
	ControllerQueryData m_queryData;
	pthread_t m_thread;
};
	

class IpodPlayer : public ExternalMediaPlayer
{
private:
	IpodPlayer();
public:
	virtual ~IpodPlayer();

	virtual bool RegisterCallback(CallbackType callbackType, ExternalMediaPlayerCallback callback, void *pUserData);

	virtual bool Open();
	virtual void Close();

	virtual void Suspend();
	virtual void Resume();

	virtual void Play();
	virtual void Stop();
	virtual void Pause();
	virtual void Next();
	virtual void Previous();
	
	virtual ShuffleMode GetShuffleMode();
	virtual RepeatMode GetRepeatMode();
	virtual MediaItemCategory GetMediaItemCategory(void);
	virtual QueryState GetMediaItemsCount(s32 &outItemCount);
	virtual QueryState GetMediaItemName(s32 itemIndex, const char *&outItemName);
	virtual QueryState GetNowPlayingItemData(const char *&outTitle, const char *&outArtist, const char *&outAlbum, f32* outCursorPosition, f32* outPlaybackDuration);
	virtual QueryState GetPlaybackState(PlaybackState &outPlaybackState);
	
	virtual bool SetShuffleMode(ShuffleMode shuffleMode);
	virtual bool SetRepeatMode(RepeatMode repeatMode);
	virtual void SetMediaItemCategory(MediaItemCategory category, void *params);
	virtual void SetMediaItem(s32 itemIndex);
private:
	VoxThread *m_thread;
	
	void Initialize();
	void Shutdown();

	void ProcessQueue();
    void QueueCommand(controllercommand::Type commandType, s32 param = 0, bool isHighPrio = false);

	//Playback control
	void _Play();
	void _Pause();
	void _Stop();
	void _Next();
	void _Previous();
	
	void _SetRepeatMode(RepeatMode repeatMode);
	void _SetShuffleMode(ShuffleMode shuffleMode);

	void _SetPlaylist(s32 index);
	void _SetArtist(s32 index);
	void _SetAlbum(s32 index);
	void _SetSong(s32 index);
	
	QueryState ConvertiPodState(s32 iPodNativeState, PlaybackState &outPlaybackState);
	s32 _GetPlaybackState();
	void _GetPlaybackStateAsync();
	void _GetNowPlayingItemData();
	void _GetMediaItems();
	
	static void _LibraryChangedHandler();
	static void _SongChangedHandler();
	static void _StateChangedHandler();
	
	void _ProcessLibraryChanged();
	void _ProcessStateChanged();
	void _ProcessSongChanged();
	
	void _PollIpod();
	
	static void RunCallback(void *caller, void *param);
	void Run(void);	// Changed so it uses vox native threads instead of GLF ones.

	static bool	s_isInstanceUsed;
	static bool	s_keepInstanceAlive;
	
	static IPodNotificationHandler *s_iPodStateNotificationHandler;

	ExternalMediaPlayerCallback	m_externalStateCallback;
    ExternalMediaPlayerCallback	m_externalSongCallback;
    ExternalMediaPlayerCallback	m_externalLibraryCallback;

	AsyncQuery m_iPodQuery;
	bool m_isQueryEnabled;
    bool m_isNowPlayingItemValid;
    bool m_isNowPlayingItemUpdating;
    bool m_isStateValid;
    bool m_isStateUpdating;
	bool m_isQueryPending;
    bool m_isPollingIpod;
	bool m_isSuspended;
	bool m_isOpened;
	
	s32	m_playerInternalState;	// State as provided by iPod player.
	
	f64 m_nextPoll;
	s32 m_lastPollState;
	MPMediaItem* m_lastPollItem;
	
	void *m_pUserStateCallbackData;
	void *m_pUserSongCallbackData;
	void *m_pUserLibraryCallbackData;

	VOX_LIST<ControllerCommand, SAllocator<ControllerCommand> > m_commandQueue;
	
	Mutex m_processQueueMutex;
	Mutex m_commandQueueMutex;
	Mutex m_queryMutex;
	Mutex m_nowPlayingItemMutex;
	
	NSArray	**m_pItems;			// Container for query results (for Playlist, Artist, Album and Song)
	s32		m_category;			// Index of sub-array in m_pItems double array.
	s32		m_nbItemCategories;

	NSString	*m_pItemName;
	
	// Now playing parameters
	MPMediaItem*	m_nowPlayingItem;
	f32				m_nowPlayingItemPosition;
	NSString*		m_pNowPlayingAlbum;
	NSString*		m_pNowPlayingArtist;
	NSString*		m_pNowPlayingTitle;
    
    Class mpc;

	friend ExternalMediaPlayer *CreatePlayer(void);
};

} // media_player namespace

} // vox namespace

#endif // VOX_USE_IPOD_MEDIA_PLAYER

#endif // _VOX_IPOD_PLAYER_H