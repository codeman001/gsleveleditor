#include "vox.h"

#include "ipod_player.h"

#if VOX_USE_IPOD_MEDIA_PLAYER

#include <mach/mach_time.h>

@implementation DummyNSThreadClass

-(void) dummy
{
}

@end


@implementation IPodNotificationHandler

-(id) alloc
{
	self = [super init];
	m_stateCallback = 0;
	return self;
}

-(void) dealloc
{
	if(m_stateCallback || m_songCallback)
	{
		MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
		if(iPod)
			[iPod endGeneratingPlaybackNotifications];
	}
	
	if(m_songCallback)
	{
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMusicPlayerControllerPlaybackStateDidChangeNotification object:nil];
	}
	
	if(m_stateCallback)
	{
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification object:nil];
	}
	
	if(m_libraryCallback)
	{
		MPMediaLibrary* library = [MPMediaLibrary defaultMediaLibrary];
		if(library)
			[library beginGeneratingLibraryChangeNotifications];
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMediaLibraryDidChangeNotification  object:library];
	}
	
	[super dealloc];
}

-(void) initHandler
{
	m_stateCallback = 0;
	m_songCallback = 0;
	m_libraryCallback = 0;
}

-(void) reset
{
	if(m_stateCallback || m_songCallback)
	{
		MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
		if(iPod)
			[iPod endGeneratingPlaybackNotifications];
	}
	
	if(m_songCallback)
	{
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMusicPlayerControllerPlaybackStateDidChangeNotification object:nil];
	}
	
	if(m_stateCallback)
	{
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification object:nil];
	}
	
	if(m_libraryCallback)
	{
		MPMediaLibrary* library = [MPMediaLibrary defaultMediaLibrary];
		if(library)
			[library endGeneratingLibraryChangeNotifications];
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMediaLibraryDidChangeNotification  object:library];
	}	
	
	[self setStateCallback:m_stateCallback];
	[self setSongCallback:m_songCallback];
	[self setLibraryCallback:m_libraryCallback];	
}

-(void) setStateCallback:(iPodNotificationCallback) stateCallback
{
	if(m_stateCallback) //already registered
	{
		m_stateCallback = stateCallback;
	}
	else
	{
		MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
		if(iPod)
		{
			m_stateCallback = stateCallback;
			if(m_stateCallback)
			{			
				[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handle_stateChanged:) name:MPMusicPlayerControllerPlaybackStateDidChangeNotification object:nil];
			}

			if(!m_songCallback)
			{
				[iPod beginGeneratingPlaybackNotifications];
			}
		}
	}
}

-(void) setSongCallback:(iPodNotificationCallback) songCallback
{
	if(m_songCallback) //already registered
	{
		m_songCallback = songCallback;
	}
	else
	{
		MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
		if(iPod)
		{
			m_songCallback = songCallback;
			if(m_songCallback)
			{			
				[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handle_songChanged:) name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification object:nil];
			}
			
			if(!m_stateCallback)
			{
				[iPod beginGeneratingPlaybackNotifications];
			}	
		}
	}
}

-(void) setLibraryCallback:(iPodNotificationCallback) libraryCallback
{
	if(m_libraryCallback) //already registered
	{
		m_libraryCallback = libraryCallback;
	}
	else
	{
		MPMediaLibrary* library = [MPMediaLibrary defaultMediaLibrary];
		if(library)
		{	
			m_libraryCallback = libraryCallback;
			if(m_libraryCallback)
			{
				[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handle_libraryChanged:) name:MPMediaLibraryDidChangeNotification  object:library];
				[library beginGeneratingLibraryChangeNotifications];
			}
		}
	}
}

-(void) handle_stateChanged:(NSNotification*) aNotification
{
	if(m_stateCallback)
	{
		m_stateCallback();
	}
}

-(void) handle_songChanged:(NSNotification*) aNotification
{
	if(m_songCallback)
	{
		m_songCallback();
	}	
}

-(void) handle_libraryChanged:(NSNotification*) aNotification
{
	if(m_libraryCallback)
	{
		m_libraryCallback();
	}
}

@end


namespace vox
{
	
namespace media_player
{


ExternalMediaPlayer::MediaItemCategory AsyncQuery::s_mediaItemCategory = ExternalMediaPlayer::MI_UNKNOWN;
bool AsyncQuery::m_isRunning = false;	
bool AsyncQuery::m_dropResult = false;

AsyncQuery::AsyncQuery()
{
}

	
AsyncQuery::~AsyncQuery()
{
	if(m_isRunning)
	{
		Cancel();
	}
}


bool AsyncQuery::GetMediaItems(ExternalMediaPlayer::MediaItemCategory category, ControllerQueryData queryData)
{
	if(m_isRunning)
		return false;
		
	s_mediaItemCategory = category;
	m_isRunning = true;
	
	m_queryData = queryData;

	// TODO : Put this thread a glf thread if there is a Cancel() method for glf threads
	// TODO(2) : Except glf threads are not used anymore. Hm.
	s32 result = pthread_create(&m_thread, 0, &AsyncQuery::_QueryMediaItems, static_cast<void*> (&m_queryData));
	
	if(result != 0)
	{
		VOX_WARNING_LEVEL_1("%s", "Error in Creating thread\n");
		m_isRunning = false;
		return false;
	}	
		
	return true;
}
	
	
bool AsyncQuery::Cancel()
{
	if(m_isRunning)
	{
		VOX_WARNING_LEVEL_5("Canceling thread %d\n", (int)m_thread);
		if(pthread_cancel(m_thread) != 0)
			return false;
		VOX_WARNING_LEVEL_5("Canceled thread %d\n", (int)m_thread);
		m_isRunning = false;
	}
		
	return true;
}
	

void* AsyncQuery::_QueryMediaItems(void* arg)
{
	NSAutoreleasePool* ap = [[NSAutoreleasePool alloc] init];
	NSArray* returnArray;
	MPMediaQuery *pMediaQuery = 0;
	
	switch(s_mediaItemCategory)
	{
		case ExternalMediaPlayer::MI_PLAYLIST:
		{
			pMediaQuery = [MPMediaQuery playlistsQuery];
			break;
		}
		case ExternalMediaPlayer::MI_ARTIST:
		{
			pMediaQuery = [MPMediaQuery artistsQuery];
			break;
		}
		case ExternalMediaPlayer::MI_ALBUM:
		{
			pMediaQuery = [MPMediaQuery albumsQuery];
			break;
		}
		case ExternalMediaPlayer::MI_SONG:
		{
			pMediaQuery = [MPMediaQuery songsQuery];
			break;
		}
		default:
		{
		}
	}

	if(!m_dropResult && pMediaQuery)
	{
		returnArray = [pMediaQuery collections];
		if(returnArray != nil)
		{
			[returnArray retain];
			ControllerQueryData *pQueryData = static_cast<ControllerQueryData*> (arg);
			ScopeMutex sm(pQueryData->m_pQueryMutex);
			*(static_cast<NSArray**> (pQueryData->m_array)) = returnArray;
		}
	}
		
	m_isRunning = false;	
	m_dropResult = false;
		
	[ap release];
	return 0;
}
	
	
////
	

ExternalMediaPlayer *CreatePlayer(void)
{
	return VOX_NEW IpodPlayer();
}

	
void DestroyPlayer(void)
{
	IpodPlayer *pPlayer = static_cast<IpodPlayer*> (ExternalMediaPlayer::GetInstance());
	if(pPlayer)
	{
		VOX_DELETE(pPlayer);
	}
}
	

inline vox::f64 _GetCurTime()
{
	static mach_timebase_info_data_t info; // info.numer / info.denom = tick period in nanoseconds.
	static vox::f64 tickPeriodInSeconds;
	static bool isFirstTime = true;
	
	if(isFirstTime)
	{
		mach_timebase_info(&info);
		tickPeriodInSeconds = static_cast<f64> (info.numer) / static_cast<f64> (info.denom) * 0.000000001;
		isFirstTime = false;
	}
    
    return (static_cast<f64> (mach_absolute_time()) ) * tickPeriodInSeconds;
}

// Static variables
bool IpodPlayer::s_isInstanceUsed = false;
bool IpodPlayer::s_keepInstanceAlive = false;
IPodNotificationHandler* IpodPlayer::s_iPodStateNotificationHandler = 0;

IpodPlayer::IpodPlayer()
{
	m_thread = 0;
	
	m_isOpened = false;

	mpc = NSClassFromString(@"MPMusicPlayerController");
	
	//Test if Cocoa is in multi-threaded mode
	if([NSThread isMultiThreaded] == NO)
	{
		VOX_WARNING_LEVEL_2("%s", "Cocoa not in multithreaded mode, trying to force");
		DummyNSThreadClass* dummyThreadClass = [DummyNSThreadClass alloc];
		[NSThread detachNewThreadSelector:@selector(dummy) toTarget:dummyThreadClass withObject:nil];
		[dummyThreadClass release];
	}
	
	if(mpc)
	{
		
		// Initialize iPodMusicPlayer to take control of the iPod player
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		VOX_ASSERT_MSG(m_player, "Could not get iPod Music PLayer instance");
		
		if(!s_iPodStateNotificationHandler)
		{
			s_iPodStateNotificationHandler = [IPodNotificationHandler alloc];
			
			if(s_iPodStateNotificationHandler)
			{
				[s_iPodStateNotificationHandler initHandler];
				
				// Register internal callbacks
				[s_iPodStateNotificationHandler setStateCallback:&IpodPlayer::_StateChangedHandler];
				[s_iPodStateNotificationHandler setSongCallback:&IpodPlayer::_SongChangedHandler];
				[s_iPodStateNotificationHandler setLibraryCallback:&IpodPlayer::_LibraryChangedHandler];
			}
		}
		
		s_keepInstanceAlive = true;
		
		// Calculate number of media categories from IpodMediaCategoriesMask
		m_nbItemCategories = 0;
		s32 nbBits = 8 * sizeof(s32);
		s32 mask = IpodMediaCategoriesMask;
		for(s32 i = 0; i < nbBits; i++)
		{
			m_nbItemCategories += mask & 1;
			mask >>= 1;
		}
		
		m_pItems = (NSArray	**) VOX_ALLOC(m_nbItemCategories);
		for(s32 i = 0; i < m_nbItemCategories; i++)
		{
			m_pItems[i] = nil;
		}
		m_category = -1;
	}
}

IpodPlayer::~IpodPlayer()
{
	Shutdown();
}


void IpodPlayer::Initialize()
{
	m_playerInternalState = -1;
	m_nowPlayingItem = 0;
	m_nowPlayingItemPosition = 0.f;
	m_pNowPlayingAlbum = 0;
	m_pNowPlayingArtist = 0;
	m_pNowPlayingTitle = 0;
	m_isNowPlayingItemValid = false;
	m_isNowPlayingItemUpdating = false;
	m_isStateValid = false;
	m_isStateUpdating = false;
	m_isQueryPending = false;
	m_externalLibraryCallback = 0;
	m_pItemName = 0;
	m_isQueryEnabled = true;
	m_isPollingIpod = false;
	m_nextPoll = 0.0;
	m_lastPollState = -1;
	m_lastPollItem = 0;
	m_pUserStateCallbackData = 0;
	m_pUserSongCallbackData = 0;
	m_pUserLibraryCallbackData = 0;
	m_isSuspended = false;
}


void IpodPlayer::Shutdown()
{
	// Prevent code from executing critical code within the '_...ChangedHandler()' callbacks
	s_keepInstanceAlive = false;
	
	// Wait until all the '_...ChangedHandler()' callbacks have stopped if one was already running
	while(s_isInstanceUsed)
	{
		VoxThread::Sleep(1);
	}

	// Release the object that called the '_...ChangedHandler()' callbacks
	if(s_iPodStateNotificationHandler)
	{
		[s_iPodStateNotificationHandler release];
		s_iPodStateNotificationHandler = 0;
	}

	// If queue processing thread is running, stop it.
	if(m_isOpened)
	{
		Close();
	}
	
	// Release principal array only (sub-arrays have been released in Suspend(), via Close())
	if(m_pItems)
	{
		VOX_FREE(m_pItems);
		m_pItems = 0;
	}
	
	if(m_thread)
	{
		VOX_DELETE(m_thread);
		m_thread = 0;
	}
}


bool IpodPlayer::Open()
{
	Initialize();

	// Start thread used to process command queue
	m_thread = VOX_NEW VoxThread(RunCallback, this, 0, "Vox External Player (IPod Player)");
	m_isOpened = true;
	
	// Queue commands to send callbacks to inform user that process has begun.
	QueueCommand(controllercommand::T_PROCESS_SONG_CHANGED, 0, true);
	QueueCommand(controllercommand::T_PROCESS_STATE_CHANGED, 0, true);

	return true;
}
	

void IpodPlayer::Close()
{	
	m_isOpened = false;
	ScopeMutex sm(&m_processQueueMutex);
	
	// Stop the current playing song
	_Stop();

	// Stop thread processing command queue
	if(m_thread)
	{
		VOX_DELETE(m_thread);
		m_thread = 0;
	}
	Suspend();
}
	

bool IpodPlayer::RegisterCallback(CallbackType callbackType, ExternalMediaPlayerCallback callback, void *pUserData)
{
	if(s_iPodStateNotificationHandler && !m_isOpened)
	{
		switch(callbackType)
		{
			case ExternalMediaPlayer::CT_STATE_CHANGED:
			{
				m_externalStateCallback = callback;
				m_pUserStateCallbackData = pUserData;
				return true;
			}
			case ExternalMediaPlayer::CT_NOW_PLAYING_CHANGED:
			{
				m_externalSongCallback = callback;
				m_pUserSongCallbackData = pUserData;
				return true;
			}
			case ExternalMediaPlayer::CT_LIBRARY_CHANGED:
			{
				m_externalLibraryCallback = callback;
				m_pUserLibraryCallbackData = pUserData;
				return true;
			}
		}
	}
	return false;
}
	
	
void IpodPlayer::Suspend()
{
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	
	m_isSuspended = true;
	
	// Clear the command queue
	{
		ScopeMutex sm(&m_commandQueueMutex);
		m_commandQueue.clear();
	}
	
	// Drop any query presently running
	if(m_iPodQuery.m_isRunning) 
		m_iPodQuery.m_dropResult = true;	
	
	// Release object used to keep query results
	{
		ScopeMutex sm(&m_queryMutex);
	
		if(m_pItems)
		{
			for(s32 i = 0; i < m_nbItemCategories; i++)
			{
				[m_pItems[i] release];
				m_pItems[i] = nil;
			}
		}
	}
	
	m_isNowPlayingItemValid = false;
	m_isStateValid = false;
}
	
	
void IpodPlayer::Resume()
{
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	
	m_isSuspended = false;
	
	QueueCommand(controllercommand::T_PROCESS_SONG_CHANGED, 0, true);
	QueueCommand(controllercommand::T_PROCESS_STATE_CHANGED, 0, true);
}
	

void IpodPlayer::Play()
{
	QueueCommand(controllercommand::T_PLAY);
}
	

void IpodPlayer::Stop()
{
	QueueCommand(controllercommand::T_STOP);
}
	

void IpodPlayer::Pause()
{
	QueueCommand(controllercommand::T_PAUSE);
}
	
	
void IpodPlayer::Next()
{
	QueueCommand(controllercommand::T_NEXT);
}
	

void IpodPlayer::Previous()
{
	QueueCommand(controllercommand::T_PREVIOUS);
}	



ExternalMediaPlayer::ShuffleMode IpodPlayer::GetShuffleMode()
{
	return m_shuffleMode;
}


ExternalMediaPlayer::RepeatMode IpodPlayer::GetRepeatMode()
{
	return m_repeatMode;
}
	
	
ExternalMediaPlayer::MediaItemCategory IpodPlayer::GetMediaItemCategory(void)
{
	return m_mediaItemCategory;
}



ExternalMediaPlayer::QueryState IpodPlayer::GetMediaItemsCount(s32 &outItemCount)
{
	outItemCount = -1;

	if(m_mediaItemCategory & IpodMediaCategoriesMask)
	{
		if(m_isQueryPending || m_iPodQuery.m_isRunning)
		{
			return QS_RUNNING;
		}

		ScopeMutex sm(&m_queryMutex);
	
		if(m_pItems[m_category] == nil)
		{
			_GetMediaItems();
			return QS_RUNNING;
		}
	
		if(m_pItems[m_category] != nil)
		{
			s32 count = [m_pItems[m_category] count];
			if(count == 0)
			{
				[m_pItems[m_category] release];
				m_pItems[m_category] = nil;
			}
		
			outItemCount = count;
			return QS_SUCCESS;
		}
	}

	return QS_ERROR;
}




ExternalMediaPlayer::QueryState IpodPlayer::GetMediaItemName(s32 itemIndex, const char *&outItemName)
{
	outItemName = 0;

	if(m_mediaItemCategory & IpodMediaCategoriesMask)
	{
		if(m_isQueryPending || m_iPodQuery.m_isRunning)
		{
			return QS_RUNNING;
		}
	
		ScopeMutex sm(&m_queryMutex);
	
		if(m_pItems[m_category] == nil)
		{
			return QS_ERROR;
		}
	
		s32 count = [m_pItems[m_category] count];

		if(count <= itemIndex || itemIndex < 0)
		{
			return QS_ERROR;
		}
		
		if(m_pItemName)
		{
			[m_pItemName release];
			m_pItemName = 0;
		}
		
		switch(m_mediaItemCategory)
		{
			case ExternalMediaPlayer::MI_PLAYLIST:
			{
				MPMediaPlaylist *pItem = [m_pItems[m_category] objectAtIndex:itemIndex];
				if(pItem)
				{
					m_pItemName = [pItem valueForProperty: MPMediaPlaylistPropertyName];
				}
				break;
			}
			case ExternalMediaPlayer::MI_ARTIST:
			{
				MPMediaItemCollection *pItem = [m_pItems[m_category] objectAtIndex:itemIndex];
				if(pItem)
				{
					MPMediaItem *representativeItem = [pItem representativeItem];
					m_pItemName = [representativeItem valueForProperty: MPMediaItemPropertyArtist];
				}
				break;
			}
			case ExternalMediaPlayer::MI_ALBUM:
			{
				MPMediaItemCollection *pItem = [m_pItems[m_category] objectAtIndex:itemIndex];
				if(pItem)
				{
					MPMediaItem *representativeItem = [pItem representativeItem];
					m_pItemName = [representativeItem valueForProperty: MPMediaItemPropertyAlbumTitle];
				}
				break;
			}
			case ExternalMediaPlayer::MI_SONG:
			{
				MPMediaItemCollection *pItem = [m_pItems[m_category] objectAtIndex:itemIndex];
				if(pItem)
				{
					MPMediaItem *representativeItem = [pItem representativeItem];
					m_pItemName = [representativeItem valueForProperty: MPMediaItemPropertyTitle];
				}
				break;
			}
			default:
			{
				// Cannot come here because of condition with IpodMediaCategoriesMask
			}
		}
	
		if(m_pItemName)
		{
			[m_pItemName retain];
			outItemName = [m_pItemName UTF8String];
			if(outItemName)
			{
				return QS_SUCCESS;
			}
		}
	}

	return QS_ERROR;
}


ExternalMediaPlayer::QueryState IpodPlayer::GetNowPlayingItemData(const char *&outTitle, const char *&outArtist, 
																  const char *&outAlbum, f32* outCursorPosition, 
																  f32* outPlaybackDuration)
{
	outTitle = 0;
	outArtist = 0;
	outAlbum = 0;
	QueryState errorCode = QS_ERROR;
	
	if(m_isNowPlayingItemValid)
	{
		ScopeMutex sm(&m_nowPlayingItemMutex);
		
		if(m_nowPlayingItem != nil)
		{
			errorCode = QS_SUCCESS;
			
			// Get song title name
			if(m_pNowPlayingTitle)
			{
				[m_pNowPlayingTitle release];
				m_pNowPlayingTitle = 0;
			}
			m_pNowPlayingTitle = [m_nowPlayingItem valueForProperty: MPMediaItemPropertyTitle];
			if(m_pNowPlayingTitle)
			{
				[m_pNowPlayingTitle retain];
				outTitle = [m_pNowPlayingTitle UTF8String];
			}
			
			// Get artist name
			if(m_pNowPlayingArtist)
			{
				[m_pNowPlayingArtist release];
				m_pNowPlayingArtist = 0;
			}
			m_pNowPlayingArtist = [m_nowPlayingItem valueForProperty: MPMediaItemPropertyArtist];
			if(m_pNowPlayingArtist)
			{
				[m_pNowPlayingArtist retain];
				outArtist = [m_pNowPlayingArtist UTF8String];
			}
			
			// Get album name
			if(m_pNowPlayingAlbum)
			{
				[m_pNowPlayingAlbum release];
				m_pNowPlayingAlbum = 0;
			}
			m_pNowPlayingAlbum = [m_nowPlayingItem valueForProperty: MPMediaItemPropertyAlbumTitle];
			if(m_pNowPlayingAlbum)
			{
				[m_pNowPlayingAlbum retain];
				outAlbum = [m_pNowPlayingAlbum UTF8String];
			}
			
			if(outCursorPosition)
			{
				*outCursorPosition = m_nowPlayingItemPosition;
			}
			
			if(outPlaybackDuration)
			{
				NSNumber* nsnum = [m_nowPlayingItem valueForProperty: MPMediaItemPropertyPlaybackDuration];
				if(nsnum)
					*outPlaybackDuration = static_cast<f32> ([nsnum floatValue]);
				else
					*outPlaybackDuration = 0.f;
			}
		}
		
		m_isNowPlayingItemValid = false; //Only good for one query
	}
	else // Now playing item is not valid. Queue a query.
	{
		errorCode = QS_RUNNING;
		
		if(!m_isNowPlayingItemUpdating)
		{
			m_isNowPlayingItemUpdating = true;
			QueueCommand(controllercommand::T_GET_NOW_PLAYING_ITEM_DATA);
		}
	}

    return errorCode;
}
	

ExternalMediaPlayer::QueryState IpodPlayer::GetPlaybackState(PlaybackState &outPlaybackState)
{
	if(mpc)
		return ConvertiPodState(_GetPlaybackState(), outPlaybackState);

	return QS_ERROR;
}
	


bool IpodPlayer::SetShuffleMode(ShuffleMode shuffleMode)
{
	QueueCommand(controllercommand::T_SET_SHUFFLE_MODE, shuffleMode);
	return true;
}
	
	
bool IpodPlayer::SetRepeatMode(RepeatMode repeatMode)
{
	QueueCommand(controllercommand::T_SET_REPEAT_MODE, repeatMode);
	return true;
}
	

	
void IpodPlayer::SetMediaItemCategory(MediaItemCategory category, void *params)
{
	ScopeMutex sm(&m_queryMutex);

	m_mediaItemCategory = category;
	
	switch(m_mediaItemCategory)
	{
		case ExternalMediaPlayer::MI_PLAYLIST:
		{
			m_category = 0;
			break;
		}
		case ExternalMediaPlayer::MI_ARTIST:
		{
			m_category = 1;
			break;
		}
		case ExternalMediaPlayer::MI_ALBUM:
		{
			m_category = 2;
			break;
		}
		case ExternalMediaPlayer::MI_SONG:
		{
			m_category = 3;
			break;
		}
		default:
		{
		}
	}
}


void IpodPlayer::SetMediaItem(s32 itemIndex)
{
	switch(m_mediaItemCategory)
	{
		case ExternalMediaPlayer::MI_PLAYLIST:
		{
			QueueCommand(controllercommand::T_SET_PLAYLIST, itemIndex);
			break;
		}
		case ExternalMediaPlayer::MI_ARTIST:
		{
			QueueCommand(controllercommand::T_SET_ARTIST, itemIndex);
			break;
		}
		case ExternalMediaPlayer::MI_ALBUM:
		{
			QueueCommand(controllercommand::T_SET_ALBUM, itemIndex);
			break;
		}
		case ExternalMediaPlayer::MI_SONG:
		{
			QueueCommand(controllercommand::T_SET_SONG, itemIndex);
			break;
		}
		default:
		{
		}
	}
}


void IpodPlayer::_Play()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player play];
		}
	}
}
	

void IpodPlayer::_Pause()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player pause];
		}
	}
}
	

void IpodPlayer::_Stop()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player stop];
		}
	}  
}
	

void IpodPlayer::_Next()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player skipToNextItem];
		}
	}
}
	
	
void IpodPlayer::_Previous()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player skipToPreviousItem];
		}
	}
}

	
void IpodPlayer::_SetRepeatMode(RepeatMode repeatMode)
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			switch(repeatMode)
			{
				case ExternalMediaPlayer::RM_DEFAULT:
				{
					[m_player setRepeatMode:MPMusicRepeatModeDefault];
					break;
				}
				case ExternalMediaPlayer::RM_NONE:
				{
					[m_player setRepeatMode:MPMusicRepeatModeNone];
					break;
				}
				case ExternalMediaPlayer::RM_ONE:
				{
					[m_player setRepeatMode:MPMusicRepeatModeOne];
					break;
				}
				case ExternalMediaPlayer::RM_ALL:
				{
					[m_player setRepeatMode:MPMusicRepeatModeAll];
					break;
				}
				default:
				{
				}
			}
			m_repeatMode = repeatMode;
		}
	}
}
	
	
void IpodPlayer::_SetShuffleMode(ShuffleMode shuffleMode)
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			switch(shuffleMode)
			{
				case ExternalMediaPlayer::SM_DEFAULT:
				{
					[m_player setShuffleMode:MPMusicShuffleModeDefault];
					break;
				}
				case ExternalMediaPlayer::SM_OFF:
				{
					[m_player setShuffleMode:MPMusicShuffleModeOff];
					break;
				}
				case ExternalMediaPlayer::SM_SONGS:
				{
					[m_player setShuffleMode:MPMusicShuffleModeSongs];
					break;
				}
				case ExternalMediaPlayer::SM_ALBUMS:
				{
					[m_player setShuffleMode:MPMusicShuffleModeAlbums];
					break;
				}
				default:
				{
				}
			}
			m_shuffleMode = shuffleMode;
		}
	}
}
	
	
void IpodPlayer::_SetPlaylist(s32 index)
{
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	
	if(m_pItems[m_category] == nil || m_player == nil)
	{
		return;
	}
	
	s32 count = [m_pItems[m_category] count];
	if(count <= index)
	{
		return;
	}

	if(index < 0)
	{
		VOX_WARNING_LEVEL_5("%s", "Setting whole library as playlist");

		MPMediaQuery* songQuery = [MPMediaQuery songsQuery];
		if(songQuery)
		{
			[m_player setQueueWithQuery:songQuery];
		}
	}
	else
	{
		VOX_WARNING_LEVEL_5("Setting playlist %d as current", index);
		MPMediaPlaylist *playlist = [m_pItems[m_category] objectAtIndex:index];
		
		if(playlist)
		{
			[m_player setQueueWithItemCollection:playlist];
		}	
	}
}
	
	
void IpodPlayer::_SetArtist(s32 index)
{
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	
	if(m_pItems[m_category] == nil || m_player == nil)
	{
		return;
	}
	
	s32 count = [m_pItems[m_category] count];
	if(count <= index)
	{
		return;
	}

	if(index >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting artist %d as current", index);
		MPMediaItemCollection *artist = [m_pItems[m_category] objectAtIndex:index];
		
		if(artist)
		{
			NSArray *songs = [artist items];
			if(songs)
			{
				// NOTE : The creation of 'artistCollection' from 'artist' is a work-around so that all sounds from the query could
				//        be queued for playback. When using 'artist', only one sound would be inserted in the queue.
				MPMediaItemCollection *artistCollection = [MPMediaItemCollection collectionWithItems: songs];
				
				if(artistCollection)
				{
					[m_player setQueueWithItemCollection:artistCollection];
				}
			}
		}
	}
	else
	{
		VOX_WARNING_LEVEL_2("%s", "Artist indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback");
	}
}

void IpodPlayer::_SetAlbum(s32 index)
{
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	
	if(m_pItems[m_category] == nil || m_player == nil)
	{
		return;
	}
	
	s32 count = [m_pItems[m_category] count];
	if(count <= index)
	{
		return;
	}

	if(index >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting album %d as current", index);
		MPMediaItemCollection *album = [m_pItems[m_category] objectAtIndex:index];
		
		if(album)
		{
			NSArray *songs = [album items];
			if(songs)
			{
				// NOTE : The creation of 'albumCollection' from 'album' is a work-around so that all sounds from the query could
				//        be queued for playback. When using 'album', only one sound would be inserted in the queue.
				MPMediaItemCollection *albumCollection = [MPMediaItemCollection collectionWithItems: songs];
				
				if(albumCollection)
				{
					[m_player setQueueWithItemCollection:albumCollection];
				}
			}
		}
	}
	else
	{
		VOX_WARNING_LEVEL_2("%s", "Album indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback");
	}
}
	

void IpodPlayer::_SetSong(s32 index)
{
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	
	if(m_pItems[m_category] == nil || m_player == nil)
	{
		return;
	}
	
	s32 count = [m_pItems[m_category] count];
	if(count <= index)
	{
		return;
	}

	if(index >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting song %d as current", index);

		MPMediaItemCollection *song = [m_pItems[m_category] objectAtIndex:index];
		if(song)
		{
			// Note : The creation of an array and another collection from the 'song' collection is a workaround
			// since setting queue directly with 'song' doesn't work on FW 4.3 (beta version).
			NSArray *songs = [song items];
			if(songs)
			{
				MPMediaItemCollection *songCollection = [MPMediaItemCollection collectionWithItems: songs];
						
				if(songCollection)
				{
					[m_player setQueueWithItemCollection:songCollection];
				}
			}
		}	
	}
	else
	{
		VOX_WARNING_LEVEL_2("%s", "Song indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback");
	}
}
	
ExternalMediaPlayer::QueryState IpodPlayer::ConvertiPodState(s32 iPodNativeState, PlaybackState &outPlaybackState)	
{
	if(iPodNativeState == QS_RUNNING)
	{
		outPlaybackState = PS_PENDING;
		return QS_RUNNING;
	}
		
	switch(iPodNativeState)
	{
		case MPMusicPlaybackStatePlaying:
		case MPMusicPlaybackStateSeekingForward:
		case MPMusicPlaybackStateSeekingBackward:
		{
			outPlaybackState = PS_PLAYING;
			return QS_SUCCESS;
		}
		case MPMusicPlaybackStatePaused:
		case MPMusicPlaybackStateInterrupted:
		{
			outPlaybackState = PS_PAUSED;
			return QS_SUCCESS;
		}
		case MPMusicPlaybackStateStopped:
		{
			outPlaybackState = PS_STOPPED;
			return QS_SUCCESS;
		}			
	}
	
	outPlaybackState = PS_OTHER;
	return QS_SUCCESS;
}
	

s32 IpodPlayer::_GetPlaybackState()
{
	s32 errorCode = QS_ERROR;
	 
	 if(m_isStateValid)
	 {
		 errorCode = m_playerInternalState;
		 m_isStateValid = false;			//Only good for one query
	 }
	 else
	 {
		 errorCode = QS_RUNNING;
	 
		 if(!m_isStateUpdating)
		 {
			 m_isStateUpdating = true;
			 QueueCommand(controllercommand::T_GET_PLAYBACK_STATE);			
		 }
	 }
	 
	 return errorCode;
}
	

void IpodPlayer::_GetPlaybackStateAsync()
{
	m_playerInternalState = -1;
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	if(m_player)
		m_playerInternalState = m_player.playbackState;
		
	m_isStateValid = true;
	m_isStateUpdating = false;
}

	
void IpodPlayer::_GetNowPlayingItemData()
{
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	MPMediaItem* nowPlayingItem = nil;
	f32 curPos = 0.f;
	
	if(m_player)
	{
		curPos = static_cast<f32> (m_player.currentPlaybackTime);
		nowPlayingItem = m_player.nowPlayingItem;
	}
	
	ScopeMutex sm(&m_nowPlayingItemMutex);
	
	m_nowPlayingItemPosition = curPos;
	
	if(m_nowPlayingItem)
	{
		[m_nowPlayingItem release];
	}
	
	m_nowPlayingItem = nowPlayingItem;
	
	if(m_nowPlayingItem)
		[m_nowPlayingItem retain];
	
	m_isNowPlayingItemValid = true;
	m_isNowPlayingItemUpdating = false;
}


void IpodPlayer::_GetMediaItems()
{
	if(m_pItems[m_category] != nil)
	{
		[m_pItems[m_category] release];
		m_pItems[m_category] = nil;
	}
	
	m_isQueryPending = true;
	
	switch(m_mediaItemCategory)
	{
		case ExternalMediaPlayer::MI_PLAYLIST:
		{
			QueueCommand(controllercommand::T_PLAYLIST_QUERY);
			break;
		}
		case ExternalMediaPlayer::MI_ARTIST:
		{
			QueueCommand(controllercommand::T_ARTIST_QUERY);
			break;
		}
		case ExternalMediaPlayer::MI_ALBUM:
		{
			QueueCommand(controllercommand::T_ALBUM_QUERY);
			break;
		}
		case ExternalMediaPlayer::MI_SONG:
		{
			QueueCommand(controllercommand::T_SONG_QUERY);
			break;
		}
		default:
		{
			// Cannot get there because of mask condition in GetMediaItemsCount().
		}
	}
}
	
	
void IpodPlayer::_LibraryChangedHandler()
{
	s_isInstanceUsed = true; // Prevents object destruction during execution of the present callback.

	if(s_keepInstanceAlive) // Prevents execution of the enclosed code if Shutdown() has begun.
	{
		IpodPlayer *pIpodPlayerInstance = static_cast<IpodPlayer*> (ExternalMediaPlayer::s_pInstance);
		if(pIpodPlayerInstance)
		{
			pIpodPlayerInstance->m_iPodQuery.m_dropResult = true;
			pIpodPlayerInstance->QueueCommand(controllercommand::T_PROCESS_LIBRARY_CHANGED, 0, true);
		}
	}
	
	s_isInstanceUsed = false;
}
	
	
void IpodPlayer::_SongChangedHandler()
{
	s_isInstanceUsed = true; // Prevents object destruction during execution of the present callback.

	if(s_keepInstanceAlive) // Prevents execution of the enclosed code if Shutdown() has begun.
	{
		IpodPlayer *pIpodPlayerInstance = static_cast<IpodPlayer*> (ExternalMediaPlayer::s_pInstance);
		if(pIpodPlayerInstance)
		{
			pIpodPlayerInstance->QueueCommand(controllercommand::T_PROCESS_SONG_CHANGED, 0, true);
		}
	}

	s_isInstanceUsed = false;
}
	

void IpodPlayer::_StateChangedHandler()
{
	s_isInstanceUsed = true; // Prevents object destruction during execution of the present callback.

	if(s_keepInstanceAlive) // Prevents execution of the enclosed code if Shutdown() has begun.
	{
		IpodPlayer *pIpodPlayerInstance = static_cast<IpodPlayer*> (ExternalMediaPlayer::s_pInstance);
		if(pIpodPlayerInstance)
		{
			pIpodPlayerInstance->QueueCommand(controllercommand::T_PROCESS_STATE_CHANGED, 0, true);
		}
	}
	
	s_isInstanceUsed = false;
}
	

void IpodPlayer::_ProcessLibraryChanged()
{
	{
		ScopeMutex sm(&m_queryMutex);
	
		if(m_pItems)
		{
			for(s32 i = 0; i < m_nbItemCategories; i++)
			{
				if(m_pItems[m_category])
				{
					[m_pItems[m_category] release];
					m_pItems[m_category] = nil;
				}
			}
		}
	}
	
	if(s_iPodStateNotificationHandler)
	{
		[s_iPodStateNotificationHandler reset];		 
	}
	
	if(m_externalLibraryCallback)
		m_externalLibraryCallback(m_pUserLibraryCallbackData);
	
	m_isPollingIpod = true;
	VOX_WARNING_LEVEL_5("%s", "User sync his device starting periodic polling");
}
	

void IpodPlayer::_ProcessStateChanged()
{
	m_isStateValid = false;
	
	if (m_externalStateCallback)
		m_externalStateCallback(m_pUserStateCallbackData);
}
	

void IpodPlayer::_ProcessSongChanged()
{
	m_isNowPlayingItemValid = false;
	
	if(m_externalSongCallback)
		m_externalSongCallback(m_pUserSongCallbackData);
}

	
void IpodPlayer::_PollIpod()
{
	//state
	if (m_externalStateCallback)
	{
		s32 iPodState = -1;
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
			iPodState = m_player.playbackState;	
		
		if ( iPodState != m_lastPollState)
		{
			m_isStateValid = false;
			m_lastPollState = iPodState;
			m_externalStateCallback(m_pUserStateCallbackData);
		}		
	}	
	
	//Song
	if(m_externalSongCallback)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		MPMediaItem* nowPlayingItem = nil;
		
		if(m_player)
		{
			nowPlayingItem = m_player.nowPlayingItem;
		}
		
		if(nowPlayingItem != nil && m_lastPollItem != nil)
		{
			NSNumber* oldid = 0;
			NSNumber* newid = 0;
			
			newid = [nowPlayingItem valueForProperty:MPMediaItemPropertyPersistentID];
			oldid = [m_lastPollItem valueForProperty:MPMediaItemPropertyPersistentID];	
			
			if(oldid != nil && newid != nil)
			{
				if([oldid longLongValue] != [newid longLongValue])
				{
					[m_lastPollItem release];
					m_lastPollItem = nowPlayingItem;
					[m_lastPollItem retain];
					
					m_externalSongCallback(m_pUserSongCallbackData);
				}
			}
		}
		if(nowPlayingItem == nil || m_lastPollItem == nil)
		{
			if(m_lastPollItem == nil && nowPlayingItem != nil)
			{
				m_lastPollItem = nowPlayingItem;
				[m_lastPollItem retain];
				m_externalSongCallback(m_pUserSongCallbackData);
			}
			else if(nowPlayingItem == nil && m_lastPollItem != nil)
			{
				[m_lastPollItem release];
				m_lastPollItem = nil;
				m_externalSongCallback(m_pUserSongCallbackData);
			}
		}
	}
}
	
void IpodPlayer::RunCallback(void *caller, void *param)
{
	((IpodPlayer *)caller)->Run();
}
	
void IpodPlayer::Run()
{		
	while(m_isOpened)
	{
		ProcessQueue();
		VoxThread::Sleep(33);
	}
	
}


void IpodPlayer::ProcessQueue()
{
	ScopeMutex sm(&m_processQueueMutex);

	if(m_iPodQuery.m_isRunning)
        return;
	
    ControllerCommand command;
    bool isEmpty;
    
	if(m_isPollingIpod)
	{
		f64 curtime = _GetCurTime();
		if(curtime >= m_nextPoll)
		{
			QueueCommand(controllercommand::T_POLL_IPOD);
			m_nextPoll = curtime + VOX_IPOD_POLLING_DT;
		}
	}
	
	{
		ScopeMutex sm(&m_commandQueueMutex);
		isEmpty = m_commandQueue.size() <= 0;
		if(!isEmpty)
		{
			command = m_commandQueue.front();
			m_commandQueue.pop_front();
		}
	}
    
    if(isEmpty || command.m_type == controllercommand::T_CANCELLED)
        return;
	
	NSAutoreleasePool* ap = [[NSAutoreleasePool alloc] init];

    switch(command.m_type)
    {
        case controllercommand::T_PLAY:
        {
            _Play();
			break;
        }
        case controllercommand::T_PAUSE:
        {
            _Pause();
            break;
        }
        case controllercommand::T_STOP:
        {
            _Stop();
            break;
        }
        case controllercommand::T_NEXT:
        {
            _Next();
            break;
        }
        case controllercommand::T_PREVIOUS:
        {
            _Previous();
            break;
        }
        case controllercommand::T_SET_SHUFFLE_MODE:
        {
            _SetShuffleMode(static_cast<ShuffleMode> (command.m_param));
            break;
        }
        case controllercommand::T_SET_REPEAT_MODE:
        {
            _SetRepeatMode(static_cast<RepeatMode> (command.m_param));
            break;
        }
        case controllercommand::T_SET_PLAYLIST:
        {
            _SetPlaylist(command.m_param);
            break;
        }
        case controllercommand::T_SET_ARTIST:
        {
            _SetArtist(command.m_param);
            break;
        }
        case controllercommand::T_SET_ALBUM:
        {
            _SetAlbum(command.m_param);
            break;
        }
        case controllercommand::T_SET_SONG:
        {
            _SetSong(command.m_param);
            break;
        }
		case controllercommand::T_GET_NOW_PLAYING_ITEM_DATA:
        {
            _GetNowPlayingItemData();
            break;
        }
        case controllercommand::T_GET_PLAYBACK_STATE:
        {
            _GetPlaybackStateAsync();
            break;
        }	
		case controllercommand::T_PLAYLIST_QUERY:
        {
			m_iPodQuery.GetMediaItems(ExternalMediaPlayer::MI_PLAYLIST, ControllerQueryData(static_cast<void*> (&m_pItems[m_category]), &m_queryMutex));
			m_isQueryPending = false;
            break;
        }
		case controllercommand::T_ARTIST_QUERY:
        {
            m_iPodQuery.GetMediaItems(ExternalMediaPlayer::MI_ARTIST, ControllerQueryData(static_cast<void*> (&m_pItems[m_category]), &m_queryMutex));
			m_isQueryPending = false;
            break;
        }
		case controllercommand::T_ALBUM_QUERY:
		{
            m_iPodQuery.GetMediaItems(ExternalMediaPlayer::MI_ALBUM, ControllerQueryData(static_cast<void*> (&m_pItems[m_category]), &m_queryMutex));
			m_isQueryPending = false;
            break;
        }
		case controllercommand::T_SONG_QUERY:
        {
			m_iPodQuery.GetMediaItems(ExternalMediaPlayer::MI_SONG, ControllerQueryData(static_cast<void*> (&m_pItems[m_category]), &m_queryMutex));
			m_isQueryPending = false;
            break;
        }
		case controllercommand::T_PROCESS_SONG_CHANGED:
        {
            _ProcessSongChanged();
            break;
        }	
		case controllercommand::T_PROCESS_STATE_CHANGED:
        {
            _ProcessStateChanged();
            break;
        }	
		case controllercommand::T_PROCESS_LIBRARY_CHANGED:
        {
            _ProcessLibraryChanged();
            break;
        }
		case controllercommand::T_POLL_IPOD:
        {
            _PollIpod();
            break;
        }
        default:
        {
            VOX_WARNING_LEVEL_2("Unknown iPod controller command : %d", command.m_type);
            break;
        }
    }
	
	[ap release];
}
	
	
void IpodPlayer::QueueCommand(controllercommand::Type commandType, s32 param, bool isHighPrio)
{
	if(!m_isOpened)
	{
		VOX_WARNING_LEVEL_4("Media player is not opened, cannot queue command %d", commandType);
		return;
	}

	if(m_isSuspended)
		return;

	ScopeMutex sm(&m_commandQueueMutex);
		
	if(commandType == controllercommand::T_PROCESS_SONG_CHANGED|| commandType == controllercommand::T_PROCESS_STATE_CHANGED ||
	   commandType == controllercommand::T_PROCESS_LIBRARY_CHANGED || commandType == controllercommand::T_POLL_IPOD)
	{
		//Need to cancel other command of the same type to avoid processing same callback twice
		VOX_LIST<ControllerCommand, SAllocator<ControllerCommand> >::iterator iter = m_commandQueue.begin();
		VOX_LIST<ControllerCommand, SAllocator<ControllerCommand> >::iterator end = m_commandQueue.end();
			
		for(;iter != end; iter++)
		{
			if((*iter).m_type == commandType)
				(*iter).m_type = controllercommand::T_CANCELLED;
		}
	}

	if(isHighPrio)
	{
		m_commandQueue.push_front(ControllerCommand(commandType, param));
	}
	else
	{
		m_commandQueue.push_back(ControllerCommand(commandType, param));
	}
}
	
} // media_player namespace

} // vox namespace

#endif // VOX_USE_IPOD_MEDIA_PLAYER

