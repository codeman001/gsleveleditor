#pragma once
#ifndef _VOX_MEDIA_PLAYER_COMMON_H
#define _VOX_MEDIA_PLAYER_COMMON_H

#if defined(__APPLE__)
#include "TargetConditionals.h"
#endif

#if (defined(TARGET_OS_IPHONE))
	#define VOX_USE_IPOD_MEDIA_PLAYER 1
	#define VOX_USE_WINDOWS_MEDIA_PLAYER 0
	#define VOX_USE_NULL_MEDIA_PLAYER 0

#elif (defined(_WIN32))
	#define VOX_USE_IPOD_MEDIA_PLAYER 0
	#define VOX_USE_WINDOWS_MEDIA_PLAYER 1
	#define VOX_USE_NULL_MEDIA_PLAYER 0

#else // not IPHONE or WIN32 - no media player available
	#define VOX_USE_IPOD_MEDIA_PLAYER 0
	#define VOX_USE_WINDOWS_MEDIA_PLAYER 0
	#define VOX_USE_NULL_MEDIA_PLAYER 1

#endif

namespace vox
{
	
namespace media_player
{

class ExternalMediaPlayer;

namespace controllercommand
{
	enum Type
	{
		T_CANCELLED,
		T_PLAY,
		T_PAUSE,
		T_STOP,
		T_NEXT,
		T_PREVIOUS,
		T_SET_SHUFFLE_MODE,
		T_SET_REPEAT_MODE,
		T_SET_PLAYLIST,
		T_SET_ARTIST,
		T_SET_ALBUM,
		T_SET_SONG,    
		T_GET_NOW_PLAYING_ITEM_DATA,
		T_GET_PLAYBACK_STATE,
		T_PLAYLIST_QUERY,
		T_ARTIST_QUERY,
		T_ALBUM_QUERY,
		T_SONG_QUERY,
		T_PROCESS_SONG_CHANGED,
		T_PROCESS_STATE_CHANGED,
		T_PROCESS_LIBRARY_CHANGED,
		T_POLL_IPOD
	};
}

struct ControllerCommand
{
	ControllerCommand():m_type(controllercommand::T_CANCELLED), m_param(0){}
	ControllerCommand(controllercommand::Type commandType, s32 param):m_type(commandType), m_param(param){}
	
	controllercommand::Type	m_type;
	s32	m_param;
};

// These methods should implemented for each platform and be friend of the classes implementing the platform's media player
extern "C++" ExternalMediaPlayer *CreatePlayer(void);
extern "C++" void DestroyPlayer(void);
	
} // media_player namespace
	
} // vox namespace	

#endif // _VOX_MEDIA_PLAYER_COMMON_H

