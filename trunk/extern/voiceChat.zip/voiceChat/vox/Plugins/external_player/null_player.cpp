#include "vox.h"
#include "null_player.h"

#if VOX_USE_NULL_MEDIA_PLAYER

namespace vox
{
	
namespace media_player
{


ExternalMediaPlayer *CreatePlayer(void)
{
	return VOX_NEW NullPlayer();
}

void DestroyPlayer(void)
{
	NullPlayer *pNullPlayerInstance = static_cast<NullPlayer*> (ExternalMediaPlayer::GetInstance());
	if(pNullPlayerInstance)
	{
		VOX_DELETE(pNullPlayerInstance);
	}
}
	
/////
	

ExternalMediaPlayer::RepeatMode NullPlayer::GetRepeatMode()
{
	return m_repeatMode;
}


ExternalMediaPlayer::ShuffleMode NullPlayer::GetShuffleMode()
{
	return m_shuffleMode;
}


ExternalMediaPlayer::MediaItemCategory NullPlayer::GetMediaItemCategory(void)
{
	return m_mediaItemCategory;
}


ExternalMediaPlayer::QueryState NullPlayer::GetMediaItemsCount(s32 &outItemCount)
{
	outItemCount = 0;
	return QS_SUCCESS;
}
	
	
ExternalMediaPlayer::QueryState NullPlayer::GetMediaItemName(s32 itemIndex, const char *&outItemName)
{
	outItemName = 0;
	return QS_SUCCESS;
}
	

ExternalMediaPlayer::QueryState NullPlayer::GetNowPlayingItemData(const char *&outTitle, const char *&outArtist,
																  const char *&outAlbum, f32* outCursorPosition,
																  f32* outPlaybackDuration)
{
	outTitle = 0;
	outArtist = 0;
	outAlbum = 0;
	*outCursorPosition = 0.0f;
	*outPlaybackDuration = 0.0f;

	return QS_SUCCESS;
}

	
ExternalMediaPlayer::QueryState NullPlayer::GetPlaybackState(PlaybackState &outPlaybackState)
{
	outPlaybackState = PS_OTHER;
	return QS_SUCCESS;
}


void NullPlayer::SetMediaItemCategory(MediaItemCategory category, void *params)
{
	m_mediaItemCategory = category;
}


bool NullPlayer::SetRepeatMode(RepeatMode repeatMode)
{
	m_repeatMode = repeatMode;
	return true;
}


bool NullPlayer::SetShuffleMode(ShuffleMode shuffleMode)
{
	m_shuffleMode = shuffleMode;
	return true;
}

} // media_player namespace
	
} // vox namespace

#endif // VOX_USE_NULL_MEDIA_PLAYER
