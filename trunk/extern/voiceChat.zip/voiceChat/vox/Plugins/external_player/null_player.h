#pragma once
#ifndef _VOX_NULL_PLAYER_H
#define _VOX_NULL_PLAYER_H

#include "vox.h"

#include "external_media_player.h"
#include "media_player_common.h"

#ifdef VOX_USE_NULL_MEDIA_PLAYER

namespace vox
{

namespace media_player
{
	
class NullPlayer : public ExternalMediaPlayer
{
 private:
	NullPlayer(){};
 public:
	virtual ~NullPlayer(){};
 
	virtual bool Open(){return true;};
	virtual void Close(){};
	 
	virtual bool RegisterCallback(CallbackType callbackType, ExternalMediaPlayerCallback callback, void *pUserData){return true;};
	virtual void Suspend(){};
	virtual void Resume(){};
	 
	virtual void Play(){};
	virtual void Stop(){};
	virtual void Pause(){};
	virtual void Next(){};
	virtual void Previous(){};
	 
	virtual ShuffleMode GetShuffleMode();
	virtual RepeatMode GetRepeatMode();
	virtual MediaItemCategory GetMediaItemCategory(void);
	virtual QueryState GetMediaItemsCount(s32 &outItemCount);
	virtual QueryState GetMediaItemName(s32 itemIndex, const char *&outItemName);
	virtual QueryState GetNowPlayingItemData(const char *&outTitle, const char *&outArtist, const char *&outAlbum, f32* outCursorPosition, f32* outPlaybackDuration);
	virtual QueryState GetPlaybackState(PlaybackState &outPlaybackState);
	 
	virtual bool SetShuffleMode(ShuffleMode shuffleMode);
	virtual bool SetRepeatMode(RepeatMode repeatMode);
	virtual void SetMediaItemCategory(MediaItemCategory category, void *params);
	virtual void SetMediaItem(s32 itemIndex){};
	
 private:
	friend ExternalMediaPlayer *CreatePlayer(void);
};

} // media_player namespace

} // vox namespace

#endif // VOX_USE_NULL_MEDIA_PLAYER

#endif // _VOX_NULL_PLAYER_H