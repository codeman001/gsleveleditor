#include "vox.h"

#include <windows_media_player.h>
#include "vox_filesystem.h"
#include "vox_thread.h"

#if VOX_USE_WINDOWS_MEDIA_PLAYER

#include <windows.h>
#include <algorithm>		// For STL sorting functions
#include <direct.h>			// For _getcwd()
#include <mmsystem.h>		// For MCI API functions

namespace vox
{

namespace media_player
{

void CheckMCIError(MCIERROR err)
{
	char mcidata[129];

	if(err != 0)
	{
		mciGetErrorString(err, mcidata, 128);
		printf("Error %s\n", mcidata);
	}
}


////


AudioFile::AudioFile():m_filepath(0)
{
	
}


AudioFile::AudioFile(const char* workingDirRelativePath, const char* dataRelativePath)
{
	if(workingDirRelativePath)
	{
		m_filepath = (char *) VOX_ALLOC(strlen(workingDirRelativePath) + 1);
		if(m_filepath)
		{
			strcpy(m_filepath, workingDirRelativePath);
		}
	}
	else
	{
		m_filepath = 0;
	}

	if(dataRelativePath)
	{
		FileSystemInterface *fsi = FileSystemInterface::GetInstance();
		FileInterface *fs = fsi->OpenFile((c8*) dataRelativePath);

		if(fs)
		{
			char buf[128];
			fs->Seek(-128, k_nSeekEnd);
			fs->Read(buf, 1, 128);
			fsi->CloseFile(fs);			

			if(_strnicmp(buf, "TAG", 3) == 0)
			{
				strncpy(m_title, buf + 3, 30);
				m_title[30] = 0;
				strncpy(m_artist, buf + 33, 30);
				m_artist[30] = 0;
				strncpy(m_album, buf + 63, 30);
				m_album[30] = 0;
			}
			else
			{
				const char* filename = strrchr(m_filepath, '/');
				strncpy( m_title, filename+1, 31);
				m_title[31] = 0;
				strcpy( m_artist, "");
				strcpy( m_album, "");
			}
		}
		else
		{
			VOX_DELETE(m_filepath);
			m_filepath = 0;
		}
	}
}


AudioFile::AudioFile(const AudioFile &audioFile)
{
	if(&audioFile != this)
	{
		m_filepath = (char *) VOX_ALLOC(strlen(audioFile.m_filepath) + 1);
		if(m_filepath)
		{
			strcpy(m_filepath, audioFile.m_filepath);
		}
		memcpy(m_title, audioFile.m_title, 32);
		memcpy(m_artist, audioFile.m_artist, 32);
		memcpy(m_album, audioFile.m_album, 32);
	}
}


AudioFile::~AudioFile()
{
	if(m_filepath)
	{
		VOX_FREE(m_filepath);
		m_filepath = 0;
	}
}


////


Playlist::Playlist():
m_path(0)
,m_name(0)
{
	
}


Playlist::Playlist(const char* fullpath):
m_path(0)
,m_name(0)
{
	if(fullpath)
	{
		char buffer[1024];
		strcpy(buffer, fullpath);

		// Get a pointer to the last slash in fullpath
		char *nameStart = strrchr(buffer, '/');

		// If there is a slash, separate path from filename
		if(nameStart)
		{
			*nameStart = 0;
			nameStart++;

			// Get playlist path (without file name and not ended with a slash)
			s32 pathLength = strlen(buffer) + 2;
			m_path = (char *) VOX_ALLOC(pathLength);
			if(m_path)
			{
				strcpy(m_path, buffer);
				m_path[pathLength-2] = '/'; // Keep a slash at the end of path
				m_path[pathLength-1] = 0;
			}

			// Get playlist name (stripped of path and ".m3u" extension)
			char *dotPosition = strrchr(nameStart, '.');
			*dotPosition = 0;
			m_name = (char *) VOX_ALLOC(strlen(nameStart) + 1);

			if(m_name)
			{
				strcpy(m_name, nameStart);
			}
		}
		else // No slash in fullpath -> only file name, not path.
		{
			m_path = "";
			m_name = (char *) VOX_ALLOC(strlen(nameStart) + 1);
			if(m_name)
			{
				strcpy(m_name, buffer);
			}
		}
	}
}


Playlist::~Playlist()
{
	if(m_path)
	{
		VOX_FREE(m_path);
		m_path = 0;
	}

	if(m_name)
	{
		VOX_FREE(m_name);
		m_name = 0;
	}
}


////


// Comparison functions used to sort queries according to query type.

bool ComparePlaylists(Playlist *pFirst, Playlist *pSecond)
{
	return (strcmp(pFirst->m_name, pSecond->m_name) < 0);
}

bool CompareArtists(VOX_VECTOR<AudioFile*> first, VOX_VECTOR<AudioFile*> second)
{
	return (strcmp(first[0]->m_artist, second[0]->m_artist) < 0);
}

bool CompareAlbums(VOX_VECTOR<AudioFile*> first, VOX_VECTOR<AudioFile*> second)
{
	return (strcmp(first[0]->m_album, second[0]->m_album) < 0);
}

bool CompareSongs(AudioFile *pFirst, AudioFile *pSecond)
{
	return (strcmp(pFirst->m_title, pSecond->m_title) < 0);
}

////


WindowsMediaQueryServer::WindowsMediaQueryServer(const char *mediaPath)
{
	m_thread = 0;

	m_availableQueryIndex = 0;
	m_isQueryPending = false;
	m_dropResult = false;

	// Get available media items
	Initialize(mediaPath);

	// Start query thread
	
	m_isRunning = true;		//
	m_thread = VOX_NEW VoxThread(RunCallback, this, 0, "External media player: Windows Media Query Server");
}


WindowsMediaQueryServer::~WindowsMediaQueryServer()
{
	ScopeMutex sm(&m_queryMutex);

	// Stop glf thread (see if there should be a mutex here)
	m_isRunning = false;
	VOX_DELETE(m_thread);
	m_thread = 0;

	// Release playlists vector
	s32 playlistSize = static_cast<s32> (m_playlists.size());
	for(s32 i = 0; i < playlistSize; i++)
	{
		VOX_DELETE(m_playlists[i]);
	}
	m_playlists.clear();
	
	// Release the two double vectors containing query results
	VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pPrincipalVector;
	VOX_VECTOR<AudioFile*> *pSubVector;
	AudioFile *pAudioFile;
	u32 principalVectorSize;
	u32 subVectorSize;

	for(s32 i = 0; i < 2; i++)
	{
		pPrincipalVector = &m_pQueryResults[i];
		principalVectorSize = pPrincipalVector->size();

		// Release subvectors and audio files that they point to.
		for(u32 j = 0; j < principalVectorSize; j++)
		{
			pSubVector = &(*pPrincipalVector)[j];
			subVectorSize = pSubVector->size();

			for(u32 k = 0; k < subVectorSize; k++)
			{
				pAudioFile = (*pSubVector)[k];
				//if(pAudioFile)
				//{
				//	VOX_DELETE(pAudioFile);
				//}
			}
			pSubVector->clear();
		}

		// Release principal vector
		pPrincipalVector->clear();
	}

	// Release library
	m_library.clear();
}


void WindowsMediaQueryServer::DropResult(void)
{
	m_dropResult = true;
}


const char *WindowsMediaQueryServer::GetPlaylistName(s32 playlistIndex)
{
	if(playlistIndex >= 0 && playlistIndex < static_cast<s32> (m_playlists.size()))
	{
		return m_playlists[playlistIndex]->m_name;
	}
	return "";
}


s32 WindowsMediaQueryServer::GetFilePositionInLibrary(char *filepath)
{
	s32 librarySize = static_cast<s32> (m_library.size());
	s32 i = 0;

	while(i < librarySize)
	{
		if(strcmp(filepath, m_library[i].m_filepath) == 0)
		{
			return i;
		}
		i++;
	}

	return -1;
}


bool WindowsMediaQueryServer::IsQueryPending(void)
{
	return m_isQueryPending;
}


void WindowsMediaQueryServer::Initialize(const char *mediaPath)
{
	m_pUserQuery = 0;
	m_pUserQueryCount = 0;
	m_mediaItemCategory = ExternalMediaPlayer::MI_UNKNOWN;

	// Get working directory
	_getcwd(m_pWorkingDirectory, 512);
	NormalizePathName(m_pWorkingDirectory);

	// Create temporary vectors to contain playlist paths relative to data directory and working directory.
	VOX_VECTOR<VOX_STRING> playlistDataRelativePaths;
	VOX_VECTOR<VOX_STRING> playlistWorkingDirRelativePaths;

	// Get media infos (only paths for playlists)
	FindMedia(mediaPath, playlistDataRelativePaths, playlistWorkingDirRelativePaths);

	// Get playlists infos
	AddPlaylists(playlistDataRelativePaths, playlistWorkingDirRelativePaths);
}

void WindowsMediaQueryServer::RunCallback(void *caller, void *param)
{
	((WindowsMediaQueryServer *)caller)->Run();
}

void WindowsMediaQueryServer::Run()
{
	while(m_isRunning)
	{
		// Execute current query
		if(m_isQueryPending)
		{
			ScopeMutex sm(&m_queryMutex);

			// Get available vector to perform query
			VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults = &m_pQueryResults[m_availableQueryIndex];

			// Release available query vector from previous results
			s32 querySize = pQueryResults->size();
			for(s32 i = 0; i < querySize; i++)
			{
				(*pQueryResults)[i].clear();
			}
			pQueryResults->clear();

			switch(m_mediaItemCategory)
			{
				case ExternalMediaPlayer::MI_PLAYLIST:
				{
					GetItemsByPlaylists(pQueryResults);
					m_availableQueryIndex = 1 - m_availableQueryIndex;
					break;
				}
				case ExternalMediaPlayer::MI_ARTIST:
				{
					GetItemsByArtists(pQueryResults);
					m_availableQueryIndex = 1 - m_availableQueryIndex;
					break;
				}
				case ExternalMediaPlayer::MI_ALBUM:
				{
					GetItemsByAlbums(pQueryResults);
					m_availableQueryIndex = 1 - m_availableQueryIndex;
					break;
				}
				case ExternalMediaPlayer::MI_SONG:
				{
					GetItemsBySongs(pQueryResults);
					m_availableQueryIndex = 1 - m_availableQueryIndex;
					break;
				}
				default:
				{
				}
			}

			m_dropResult = false;
			m_isQueryPending = false;
		}
		VoxThread::Sleep(5);
	}
}


void WindowsMediaQueryServer::QueryMediaItems(ExternalMediaPlayer::MediaItemCategory category, void *pItems,
											  Mutex* pQueryMutex, void *pOutItemCount)
{
	m_mediaItemCategory = category;
	m_pQueryTransferMutex = pQueryMutex;
	m_pUserQuery = static_cast<VOX_VECTOR<VOX_VECTOR<AudioFile*>>**> (pItems);
	m_pUserQueryCount = static_cast<s32*> (pOutItemCount);
	m_isQueryPending = true;
}


void WindowsMediaQueryServer::GetItemsByPlaylists(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults)
{
	s32 nbPlaylists = 0;
	s32 mediaLibrarySize = static_cast<s32> (m_library.size());

	if(mediaLibrarySize > 0)
	{
		Playlist *pCurrentPlaylist;
		s32 currentPlaylistElement;
		nbPlaylists = static_cast<s32> (m_playlists.size());
	
		// Search in all playlists
		for(s32 i = 0; i < nbPlaylists; i++)
		{
			VOX_VECTOR<AudioFile*> newPlaylist;
			(*pQueryResults).push_back(newPlaylist);

			pCurrentPlaylist = m_playlists[i];
			s32 nbPlaylistElements = pCurrentPlaylist->m_positions.size();

			if(nbPlaylistElements > 0)
			{
				// Put every song from the current playlist in the associated query subvector
				for(s32 j = 0; j < nbPlaylistElements; j++)
				{
					currentPlaylistElement = pCurrentPlaylist->m_positions[j];
					(*pQueryResults)[i].push_back(&(m_library[currentPlaylistElement]));
				}
			}
		}

		// Add an extra playlist containing all library songs (used with SetMediaItem(-1) for playlists).
		VOX_VECTOR<AudioFile*> fullLibraryPlaylist;
		(*pQueryResults).push_back(fullLibraryPlaylist);

		// Put every song from the library in the last query subvector
		for(s32 j = 0; j < mediaLibrarySize; j++)
		{
			(*pQueryResults)[nbPlaylists].push_back(&(m_library[j]));
		}
	}

	if(!m_dropResult && pQueryResults)
	{
		ScopeMutex sm(m_pQueryTransferMutex);
		*m_pUserQuery = pQueryResults;
		*m_pUserQueryCount = nbPlaylists;
	}
}


void WindowsMediaQueryServer::GetItemsByArtists(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults)
{
	s32 nbArtists = 0;
	bool isArtistFound;
	s32 mediaLibrarySize = static_cast<s32> (m_library.size());

	if(mediaLibrarySize > 0)
	{
		// Put every Audio file having a non-null artist name in the queryResults vector
		for(int i = 0; i < mediaLibrarySize; i++)
		{
			if(strcmp(m_library[i].m_artist, "") != 0)
			{
				// Search in which subvector to put artist
				s32 j = 0;
				isArtistFound = false;
				while(!isArtistFound && j < nbArtists)
				{
					if(strcmp(m_library[i].m_artist, (*pQueryResults)[j][0]->m_artist) == 0)
					{
						isArtistFound = true;
						(*pQueryResults)[j].push_back(&(m_library[i]));
					}
					j++;
				}

				// If artist was not already in double vector, create a new subvector.
				if(!isArtistFound)
				{
					VOX_VECTOR<AudioFile*> newArtist;
					(*pQueryResults).push_back(newArtist);
					(*pQueryResults)[j].push_back(&(m_library[i]));
					nbArtists++;
				}
			}
		}

		if(pQueryResults->size() > 0)
		{
			// Sort vector according to artist name (NOTE: May be problematic if VOX_VECTOR != std::vector)
			std::sort(pQueryResults->begin(), pQueryResults->end(), CompareArtists);
		}
	}

	if(!m_dropResult && pQueryResults)
	{
		ScopeMutex sm(m_pQueryTransferMutex);
		*m_pUserQuery = pQueryResults;
		*m_pUserQueryCount = nbArtists;
	}
}


void WindowsMediaQueryServer::GetItemsByAlbums(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults)
{
	s32 nbAlbums = 0;
	bool isAlbumFound;
	s32 mediaLibrarySize = static_cast<s32> (m_library.size());

	if(mediaLibrarySize > 0)
	{
		// Put every Audio file having a non-null album name in the queryResults vector
		for(int i = 0; i < mediaLibrarySize; i++)
		{
			if(strcmp(m_library[i].m_album, "") != 0)
			{
				// Search in which subvector to put album
				s32 j = 0;
				isAlbumFound = false;
				while(!isAlbumFound && j < nbAlbums)
				{
					if(strcmp(m_library[i].m_album, (*pQueryResults)[j][0]->m_album) == 0)
					{
						isAlbumFound = true;
						(*pQueryResults)[j].push_back(&(m_library[i]));
					}
					j++;
				}

				// If album was not already in double vector, create a new subvector.
				if(!isAlbumFound)
				{
					VOX_VECTOR<AudioFile*> newAlbum;
					(*pQueryResults).push_back(newAlbum);
					(*pQueryResults)[j].push_back(&(m_library[i]));
					nbAlbums++;
				}
			}
		}

		if(pQueryResults->size() > 0)
		{
			// Sort vector according to album name (NOTE: May be problematic if VOX_VECTOR != std::vector)
			std::sort(pQueryResults->begin(), pQueryResults->end(), CompareAlbums);
		}
	}

	if(!m_dropResult && pQueryResults)
	{
		ScopeMutex sm(m_pQueryTransferMutex);
		*m_pUserQuery = pQueryResults;
		*m_pUserQueryCount = nbAlbums;
	}
}


void WindowsMediaQueryServer::GetItemsBySongs(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults)
{
	s32 nbSongs = 0;
	s32 mediaLibrarySize = static_cast<s32> (m_library.size());

	if(mediaLibrarySize > 0)
	{
		// Create the only subvector (containing all songs)
		VOX_VECTOR<AudioFile*> songContainer;
		(*pQueryResults).push_back(songContainer);

		// Put every Audio file having a non-null song name in the queryResults vector
		for(int i = 0; i < mediaLibrarySize; i++)
		{
			if(strcmp(m_library[i].m_title, "") != 0)
			{
				(*pQueryResults)[0].push_back(&(m_library[i]));
				nbSongs++;
			}
		}

		// Sort vector according to song title name (NOTE: May be problematic if VOX_VECTOR != std::vector)
		std::sort((*pQueryResults)[0].begin(), (*pQueryResults)[0].end(), CompareSongs);
	}

	if(!m_dropResult && pQueryResults)
	{
		ScopeMutex sm(m_pQueryTransferMutex);
		*m_pUserQuery = pQueryResults;
		*m_pUserQueryCount = nbSongs;
	}
}


void WindowsMediaQueryServer::FindMedia(const char* mediaPath, VOX_VECTOR<VOX_STRING> &playlistDataRelativePaths,
										VOX_VECTOR<VOX_STRING> &playlistWorkingDirRelativePaths)
{
	// Get a directory handle to the media folder
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;
	char dataRelativePath[1024];
	
	sprintf(dataRelativePath, "%s/*", mediaPath);
	NormalizePathName(dataRelativePath);
	hFind = FindFirstFile(dataRelativePath, &FindFileData);
	if (hFind == INVALID_HANDLE_VALUE) 
	{
		// No files found
		return;
	}


	do
	{
		if(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) // Directory
		{	
			// Go into folder if other than ".." or "."
			s32 size = strlen(FindFileData.cFileName);

			if(FindFileData.cFileName[size-1] != '.')
			{
				sprintf(dataRelativePath, "%s/%s/", mediaPath, FindFileData.cFileName);
				NormalizePathName(dataRelativePath);
				FindMedia(dataRelativePath, playlistDataRelativePaths, playlistWorkingDirRelativePaths);
			}
		}
		else // File
		{
			strcpy(dataRelativePath, mediaPath);
			strcat(dataRelativePath, "/");
			strcat(dataRelativePath, FindFileData.cFileName);

			// Normalize fullpath name (fullpath is relative to working directory)
			NormalizePathName(dataRelativePath);

			const char* ext = strrchr(dataRelativePath, '.');
			if(ext)
			{
				if(_stricmp(ext, ".mp3") == 0)
				{
					AddMedia(dataRelativePath, dataRelativePath);
				}
				else if(_stricmp(ext, ".m3u") == 0)	// Playlist files.
				{
					playlistDataRelativePaths.push_back(VOX_STRING(dataRelativePath));
					playlistWorkingDirRelativePaths.push_back(VOX_STRING(dataRelativePath));
				}
			}

		}
	}
	while(FindNextFile(hFind, &FindFileData));

	FindClose(hFind);

}


void WindowsMediaQueryServer::AddMedia(const char* workingDirRelativePath, const char* dataRelativePath)
{
	m_library.push_back(AudioFile(workingDirRelativePath, dataRelativePath));
}


void WindowsMediaQueryServer::AddPlaylist(const char* playlistDataRelativePath, const char* playlistWorkingDirRelativePaths)
{
	if(playlistDataRelativePath)
	{
		char *pBuffer = 0;
		char playlistEntry[1024];
		Playlist *pPlaylist = VOX_NEW Playlist(playlistWorkingDirRelativePaths);

		FileSystemInterface *fsi = FileSystemInterface::GetInstance();
		FileInterface *fs = fsi->OpenFile((c8*)playlistDataRelativePath);
		if(fs)
		{
			// Put all file content in a buffer
			fs->Seek(0, k_nSeekEnd);
			u32 fileSize = fs->Tell();
			fs->Seek(0, k_nSeekSet);

			pBuffer = (char *) VOX_ALLOC(fileSize);
			fs->Read(pBuffer, 1, fileSize);
			fsi->CloseFile(fs);

			// Parse buffer
			s32 entryLength = 0;
			u32 i = 0;
			s32 fileIndex = 0;
			s32 entryStart = 0;		// Position of current entry in playlist buffer.
			s32 positionInLibrary;

			// Search every entry (one line, one entry) in the playlist file
			while(i < fileSize)
			{
				entryLength++;

				// When separator is found, get 
				if(pBuffer[i] == 13 || pBuffer[i] == 10)
				{
					pBuffer[i] = 0;
					strcpy(playlistEntry, pBuffer + entryStart);
					NormalizePathName(playlistEntry);
					ReferenceToWorkingDir(playlistEntry, pPlaylist->m_path);
					
					// Get position of current media file in media query server library
					positionInLibrary = GetFilePositionInLibrary(playlistEntry);
					if(positionInLibrary >= 0)
					{
						pPlaylist->m_positions.push_back(positionInLibrary);
					}
					// Step over a potential second separator
					if(pBuffer[i+1] == 13 || pBuffer[i+1] == 10)
					{
						i++;
					}
					entryStart = i + 1;
					entryLength = 0;
				}
				i++;
			}
		}
		m_playlists.push_back(pPlaylist);
		if(pBuffer)
			VOX_FREE(pBuffer);
	}
}


void WindowsMediaQueryServer::AddPlaylists(VOX_VECTOR<VOX_STRING> &playlistDataRelativePaths, 
										   VOX_VECTOR<VOX_STRING> &playlistWorkingDirRelativePaths)
{
	// Fill playlists vector
	s32 nbPlaylists = static_cast<s32> (playlistDataRelativePaths.size());

	if(nbPlaylists > 0)
	{
		for(s32 i = 0; i < nbPlaylists; i++)
		{
			AddPlaylist(playlistDataRelativePaths[i].data(), playlistWorkingDirRelativePaths[i].data());
		}

		// NOTE: May be problematic if VOX_VECTOR != std::vector
		std::sort(m_playlists.begin(), m_playlists.end(), ComparePlaylists);
	}
}


void WindowsMediaQueryServer::NormalizePathName(char *path)
{
	char pathTemp[1024];
	strcpy(pathTemp, path);

	s32 inIndex = 0;				// Index of 'pathTemp' string.
	s32 outIndex = 0;				// Index of 'path' string.
	bool wasLastCharSlash = false;
	char currentChar = pathTemp[0];

	while(currentChar != 0)
	{
		// Step over certain input characters
		if(currentChar == '"') 
		{
			inIndex++;
			currentChar = pathTemp[inIndex];
		}

		if(currentChar == '/')
		{
			// Step over consecutive slashes (except the first)
			if(wasLastCharSlash)
			{
				inIndex++;
				currentChar = pathTemp[inIndex];
			}
			wasLastCharSlash = true;
		}
		else
		{
			wasLastCharSlash = false;
		}

		// Replace backslashes
		if(currentChar == 92) 
		{
			pathTemp[inIndex] = '/';
		}
		else if(currentChar >= 'A' && currentChar <= 'Z') // Put all letters in lower case
		{
			pathTemp[inIndex] = currentChar + 32;
		}

		path[outIndex] = pathTemp[inIndex];
		inIndex++;
		outIndex++;
		currentChar = pathTemp[inIndex];
	}
	path[outIndex] = 0;
}


void WindowsMediaQueryServer::ReferenceToWorkingDir(char *path, const char *pathReference)
{
	char pathEnd[1024];
	char pathTemp[1024];
	char workingDirTemp[1024];
	char pathReferenceTemp[1024];
	char *pathCursor;
	char *workingDirCursor;
	char *previousPathCursor;
	char *previousWorkingDirCursor;
	char *pathSeparator;
	char *workingDirSeparator;
	bool isPathAbsolute = false;
	bool isWorkingDirFound = false;
	bool arePathSectionsIdentical = true;
	s32 pathLength;
	s32 workingDirLength;

	strcpy(pathTemp, path);
	pathLength = strlen(pathTemp);
	pathCursor = pathTemp;
	previousPathCursor = pathCursor;

	strcpy(workingDirTemp, m_pWorkingDirectory);
	workingDirLength = strlen(workingDirTemp);
	workingDirCursor = workingDirTemp;
	previousWorkingDirCursor = workingDirCursor;

	// Compare path and working directory path until one of them has not '/' separator
	while(arePathSectionsIdentical)
	{
		pathSeparator = strchr(pathCursor, '/');
		workingDirSeparator = strchr(workingDirCursor, '/');

		if(pathSeparator != 0 && workingDirSeparator != 0)
		{
			// End string at separator so that 'pathCursor' and 'workingDirCursor' be folder or file names.
			*pathSeparator = 0;
			*workingDirSeparator = 0;
		}
		else // One or both partial paths doesn't contain a separator. Stop comparing strings.
		{
			break;
		}

		// Determine if path is absolute or relative (criteria : match with working dir until first slash).
		if(strcmp(pathCursor, workingDirCursor) == 0)
		{
			isPathAbsolute = true;
		}
		else // A section from path and working directory is different
		{
			arePathSectionsIdentical = false;
		}

		if(workingDirSeparator < workingDirTemp + workingDirLength - 1)
		{
			previousWorkingDirCursor = workingDirCursor;
			workingDirCursor = workingDirSeparator + 1;
		}

		if(pathSeparator < pathTemp + pathLength - 1)
		{
			strcpy(pathEnd, pathCursor);
			pathCursor = pathSeparator + 1;
			strcat(pathEnd, "/");
			strcat(pathEnd, pathCursor);
		}
	}

	if(isPathAbsolute)
	{
		if(workingDirSeparator == 0) // Got to the end of working directory path
		{
			if(strncmp(pathCursor, workingDirCursor, strlen(workingDirCursor)) == 0)
			{
				pathSeparator = strchr(pathCursor, '/');
				pathSeparator++;							// Step over the '/'
				strcpy(path, pathSeparator);
			}
			else
			{
				strcpy(path, "../");
				strcat(path, pathCursor);
			}
		}
		else // Got to the end of path but not of working directory path
		{
			strcpy(path, "../");
			
			// For each folder remaining in the working directory cursor, add ".." to the path
			while(1)
			{
				workingDirSeparator = strchr(workingDirCursor, '/');
				if(workingDirSeparator)
				{
					strcat(path, "../");
					if(workingDirSeparator < workingDirTemp + workingDirLength - 1)
					{
						workingDirCursor = workingDirSeparator + 1;
					}
				}
				else
				{
					if(strlen(workingDirCursor) > 0)
					{
						strcat(path, "../");
					}
					break;
				}
			}
			strcat(path, pathEnd);
		}
	}
	else // Path is relative
	{
		if(path[0] == '.')
		{
			char *pathReferenceSeparator;
			strcpy(pathReferenceTemp, pathReference);

			// Strip slash at end of pathReference string (if any)
			s32 pathReferenceSize = strlen(pathReferenceTemp);
			if(pathReferenceTemp[pathReferenceSize - 1] == '/')
			{
				pathReferenceTemp[pathReferenceSize - 1] = 0;
			}

			strcpy(pathCursor, path);
			while(1)
			{
				pathSeparator = strchr(pathCursor, '/');
				if(pathSeparator)
				{
					// End string at separator so that 'pathCursor' is folder or file name.
					*pathSeparator = 0;
				}
				else
				{
					break;
				}
				if(strcmp(pathCursor, "..") == 0)
				{
					pathReferenceSeparator = strrchr(pathReferenceTemp, '/');
					*(pathReferenceSeparator+1) = 0;
				}
				if(pathSeparator < pathTemp + pathLength - 1)
				{
					pathCursor = pathSeparator + 1;
				}
			}
			strcpy(path, pathReferenceTemp);
			strcat(path, pathCursor);
		}
		else
		{
			strcpy(path, pathReference);
			strcat(path, pathTemp);
		}
	}
}


////

// Comparison functions used to sort playback queue according to shuffle mode.

bool CompareShuffleSongs(PlaybackQueueElement *pFirst, PlaybackQueueElement *pSecond)
{
	return (pFirst->m_shuffleRandomNumber < pSecond->m_shuffleRandomNumber);
}

bool CompareShuffleOff(PlaybackQueueElement *pFirst, PlaybackQueueElement *pSecond)
{
	return (pFirst->m_originalPosition < pSecond->m_originalPosition);
}

bool CompareShuffleAlbums(PlaybackQueueElement *pFirst, PlaybackQueueElement *pSecond)
{
	s32 stringsComparison = strcmp(pFirst->m_pFile->m_album, pSecond->m_pFile->m_album);

	if(stringsComparison == 0) // Same album, sort according to their original position.
	{
		return (pFirst->m_originalPosition < pSecond->m_originalPosition);
	}
	
	// Not same album, sort according to album names.
	return (stringsComparison < 0);
}

WindowsMediaPlaybackServer::WindowsMediaPlaybackServer()
{
	m_thread = 0;
	m_currentQueueIndex = -1;
	m_nextQueueIndex = 0;
	m_queueStep = 0;
	m_desiredPlaybackState = playback::S_INITIAL;
	m_playbackState = playback::S_INITIAL;
	m_songChangedCallback = 0;
	m_stateChangedCallback = 0;
	m_isNewSongNeeded = false;
	m_isMCIDeviceOpened = false;
	m_isSongStarted = false;
	m_hasQueueFinishedPlaying = false;
	m_repeatMode = ExternalMediaPlayer::RM_DEFAULT;
	m_shuffleMode = ExternalMediaPlayer::SM_DEFAULT;
	m_nowPlayingPosition[0] = 0;
	m_nowPlayingLength[0] = 0;
	m_threadReadyToDelete = false;

	// Start thread running MCI commands
	m_thread = VOX_NEW VoxThread(RunCallback, this, 0, "External media player: Windows Media Playback Server");
	m_doUpdate = true;
}

WindowsMediaPlaybackServer::~WindowsMediaPlaybackServer()
{
	{
		ScopeMutex sm(&m_mutex);

		// Release playback queue
		u32 playbackQueueSize = m_playbackQueue.size();
		for(u32 i = 0; i < playbackQueueSize; i++)
		{
			VOX_DELETE(m_playbackQueue[i]);
		}
		m_playbackQueue.clear();
	}

	m_doUpdate = false;

	if(m_thread)
	{
		bool canDelete = false;

		while(!canDelete)
		{
			VoxThread::Sleep(15);
			{
				ScopeMutex sm(&m_mutex);
				canDelete = m_threadReadyToDelete;
			}
		}
	}

	VOX_DELETE(m_thread);
	m_thread = 0;
}


playback::State WindowsMediaPlaybackServer::GetPlaybackState(void)
{
	return m_playbackState;
}


void WindowsMediaPlaybackServer::GetNowPlayingItemData(char *outTitle, char *outArtist, char *outAlbum,
													   f32* outCursorPosition, f32* outPlaybackDuration)
{
	ScopeMutex sm(&m_mutex);

	if(m_currentQueueIndex >= 0 && m_currentQueueIndex < static_cast<s32> (m_playbackQueue.size()))
	{
		AudioFile *pCurrentSong = m_playbackQueue[m_currentQueueIndex]->m_pFile;
		strcpy(outTitle, pCurrentSong->m_title);
		strcpy(outArtist, pCurrentSong->m_artist);
		strcpy(outAlbum, pCurrentSong->m_album);

		*outPlaybackDuration = ConvertMCITimeInfos(m_nowPlayingLength);
		*outCursorPosition = ConvertMCITimeInfos(m_nowPlayingPosition);
	}
}


void WindowsMediaPlaybackServer::Play()
{
	m_desiredPlaybackState = playback::S_PLAYING;
	m_hasQueueFinishedPlaying = false;
}


void WindowsMediaPlaybackServer::Pause()
{
	m_desiredPlaybackState = playback::S_PAUSED;
}


void WindowsMediaPlaybackServer::Stop()
{
	m_desiredPlaybackState = playback::S_STOPPED;
}


void WindowsMediaPlaybackServer::Next()
{
	ScopeMutex sm(&m_mutex);
	m_queueStep++;
}


void WindowsMediaPlaybackServer::Previous()
{
	ScopeMutex sm(&m_mutex);
	m_queueStep--;
}


bool WindowsMediaPlaybackServer::SetShuffleMode(ExternalMediaPlayer::ShuffleMode shuffleMode)
{
	ScopeMutex sm(&m_mutex);
	m_shuffleMode = shuffleMode;

	if(m_playbackQueue.size() > 0)
	{
		ShufflePlaybackQueue();
	}
	return true;
}


bool WindowsMediaPlaybackServer::SetRepeatMode(ExternalMediaPlayer::RepeatMode repeatMode)
{
	ScopeMutex sm(&m_mutex);

	m_repeatMode = repeatMode;

	if(repeatMode == ExternalMediaPlayer::RM_ONE)
	{
		m_nextQueueIndex = m_currentQueueIndex;
	}
	else if(m_nextQueueIndex == m_currentQueueIndex) // If player was in RM_ONE (repeat song) mode, select next song.
	{
		m_nextQueueIndex++;

		if(m_nextQueueIndex >= static_cast<s32> (m_playbackQueue.size()))
		{
			if(repeatMode == ExternalMediaPlayer::RM_ALL)
			{
				m_nextQueueIndex = 0;
			}
		}
	}

	return true;
}


void WindowsMediaPlaybackServer::RegisterStateCallback(InternalMediaPlayerCallback callback)
{
	m_stateChangedCallback = callback;
}


void WindowsMediaPlaybackServer::RegisterSongCallback(InternalMediaPlayerCallback callback)
{
	m_songChangedCallback = callback;
}


void WindowsMediaPlaybackServer::QueueSongsFromPlaylist(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pMediaItems, s32 playlistIndex)
{
	// NOTE : The 'pMediaItems's double vector contains an extra playlist with all library songs in its last entry.
	// This playlist is used when playlistIndex = -1.

	s32 querySize = pMediaItems->size();

	if(querySize > 0)
	{
		s32 nbSongs;

		// Queue all songs from subvector with index 'playlistIndex'
		if(playlistIndex >= 0 && playlistIndex < querySize - 1)
		{
			VOX_VECTOR<AudioFile*> *pPlaylist = &((*pMediaItems)[playlistIndex]);
			nbSongs = static_cast<s32> (pPlaylist->size());

			for(s32 i = 0; i < nbSongs; i++)
			{
				QueueMedia((*pPlaylist)[i], i);
			}
		}
		else if(playlistIndex == -1) // Queue all songs from the library (contained in the last subvector)
		{
			VOX_VECTOR<AudioFile*> *pFullLibraryPlaylist = &((*pMediaItems)[querySize - 1]);
			nbSongs = static_cast<s32> (pFullLibraryPlaylist->size());

			for(s32 i = 0; i < nbSongs; i++)
			{
				QueueMedia((*pFullLibraryPlaylist)[i], i);
			}
		}
	}
}


void WindowsMediaPlaybackServer::QueueSongsFromAlbum(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pMediaItems, s32 albumIndex)
{
	s32 querySize = pMediaItems->size();

	if(querySize > 0)
	{
		if(albumIndex >= 0 && albumIndex < querySize)
		{
			VOX_VECTOR<AudioFile*> *pAlbum = &((*pMediaItems)[albumIndex]);
			s32 nbSongs = static_cast<s32> (pAlbum->size());

			for(s32 i = 0; i < nbSongs; i++)
			{
				QueueMedia((*pAlbum)[i], i);
			}
		}
	}
}


void WindowsMediaPlaybackServer::QueueSongsFromArtist(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pMediaItems, s32 artistIndex)
{
	s32 querySize = pMediaItems->size();

	if(querySize > 0)
	{
		if(artistIndex >= 0 && artistIndex < querySize)
		{
			VOX_VECTOR<AudioFile*> *pArtist = &((*pMediaItems)[artistIndex]);
			s32 nbSongs = static_cast<s32> (pArtist->size());

			for(s32 i = 0; i < nbSongs; i++)
			{
				QueueMedia((*pArtist)[i], i);
			}
		}
	}
}


void WindowsMediaPlaybackServer::QueueSong(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pMediaItems, s32 songIndex)
{
	s32 querySize = (*pMediaItems)[0].size();

	if(querySize > 0 && songIndex >= 0 && songIndex < querySize)
	{
		QueueMedia((*pMediaItems)[0][songIndex], 0);
	}
}

void WindowsMediaPlaybackServer::RunCallback(void *caller, void *param)
{
	((WindowsMediaPlaybackServer *)caller)->Run();
}


void WindowsMediaPlaybackServer::Run()
{
	char command[1024];
	char mcidata[MCI_DATA_BUFFER_LENGTH];			// To get data returned by some MCI requests
	bool hasSongEnded = false;

	while(m_doUpdate)
	{
		{
			ScopeMutex sm(&m_mutex);

			if(m_playbackQueue.size() > 0 && !m_hasQueueFinishedPlaying)
			{
				if(m_desiredPlaybackState != m_playbackState)
				{
					UpdateQueuePlaybackState();
				}

				// Verify the playback state of the current playing song and get its cursor position
				if(m_isMCIDeviceOpened)
				{
					CheckMCIError(mciSendString("status MEDIAFILE mode", mcidata, MCI_DATA_LENGTH, NULL));
					hasSongEnded = m_isSongStarted && (strcmp(mcidata, "playing") != 0) && m_playbackState == playback::S_PLAYING;

					// Get the now playing position (see NOTE 1 at the end of file)
					CheckMCIError(mciSendString("status MEDIAFILE position", m_nowPlayingPosition, MCI_DATA_LENGTH, NULL));
				}

				// Verify if there should be a song change (either from user or because current song has ended).
				if(m_queueStep)
				{
					// If user has selected Next or Previous and new index is not out of bound, request a new song
					if(UpdateNextQueueIndex(QUM_NEXT_PREVIOUS))
					{
						m_isNewSongNeeded = true;
					}
				}
				else if(hasSongEnded)
				{
					// Song has naturally ended (not by user Stop() call), request a new song
					m_isNewSongNeeded = true;
				}

				if(m_isNewSongNeeded)
				{
					// Close current song
					if(m_isMCIDeviceOpened)
					{
						CheckMCIError(mciSendString("close MEDIAFILE", NULL, 0, NULL));
						m_isMCIDeviceOpened = false;
					}

					// Open next song (if any)
					if(m_nextQueueIndex >= 0 && m_nextQueueIndex < static_cast<s32> (m_playbackQueue.size()))
					{
						m_currentQueueIndex = m_nextQueueIndex;

						if(m_playbackQueue[m_currentQueueIndex]->m_pFile->m_filepath)
						{
							sprintf(command, "open %s alias MEDIAFILE", m_playbackQueue[m_currentQueueIndex]->m_pFile->m_filepath);
							CheckMCIError(mciSendString(command, NULL,0,NULL));
							UpdateNextQueueIndex(QUM_NEW_SONG);

							// Get the now playing length
							CheckMCIError(mciSendString("status MEDIAFILE length", m_nowPlayingLength, MCI_DATA_LENGTH, NULL));

							// Reinitialize songs related parameters
							m_isMCIDeviceOpened = true;
							m_isNewSongNeeded = false;
							hasSongEnded = false;
							m_isSongStarted = false;
						}
					}
					else // Queue index is out of bound, nothing else to play.
					{
						m_hasQueueFinishedPlaying = true;

						// Reinitialize the playback queue indexes
						m_currentQueueIndex = -1;
						m_nextQueueIndex = 0;
					}
				}

				if(m_playbackState == playback::S_PLAYING && !m_isSongStarted)
				{
					CheckMCIError(mciSendString("setaudio MEDIAFILE volume to 100", NULL, 0, NULL));
					CheckMCIError(mciSendString("play MEDIAFILE", NULL, 0, NULL));
					m_songChangedCallback();
					m_stateChangedCallback();
					m_isSongStarted = true;
				}
			}
		}
		VoxThread::Sleep(50);
	}
	mciSendString("close MEDIAFILE", NULL,0,NULL);
	m_isMCIDeviceOpened = false;

	{
		ScopeMutex sm(&m_mutex);
		m_threadReadyToDelete = true;
	}
}


void WindowsMediaPlaybackServer::QueueMedia(AudioFile* pAudiofile, s32 queueIndex)
{
	PlaybackQueueElement *pQueueElement = VOX_NEW PlaybackQueueElement();

	pQueueElement->m_pFile = pAudiofile;
	pQueueElement->m_originalPosition = queueIndex;
	pQueueElement->m_shuffleRandomNumber = rand();

	m_playbackQueue.push_back(pQueueElement);
}


void WindowsMediaPlaybackServer::QueueMediaItems(void *pMediaItems, ExternalMediaPlayer::MediaItemCategory itemCategory,
												 s32 index)
{
	if(pMediaItems == 0)
		return;

	ScopeMutex sm(&m_mutex);

	VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pElementsToQueue = static_cast<VOX_VECTOR<VOX_VECTOR<AudioFile*>>*> (pMediaItems);

	// Empty playback queue
	while(m_playbackQueue.size() > 0)
	{
		VOX_DELETE(m_playbackQueue.back());
		m_playbackQueue.pop_back();
	}

	// Fill playback queue with songs (according to media item category)
	switch(itemCategory)
	{
		case ExternalMediaPlayer::MI_PLAYLIST:
		{
			QueueSongsFromPlaylist(pElementsToQueue, index);
			break;
		}
		case ExternalMediaPlayer::MI_ARTIST:
		{
			QueueSongsFromArtist(pElementsToQueue, index);
			break;
		}
		case ExternalMediaPlayer::MI_ALBUM:
		{
			QueueSongsFromAlbum(pElementsToQueue, index);
			break;
		}
		case ExternalMediaPlayer::MI_SONG:
		{
			QueueSong(pElementsToQueue, index);
			break;
		}
		default:
		{
			// Cannot get there because of mask condition in GetMediaItemsCount().
		}
	}

	// Shuffle playback queue according to shuffle mode
	ShufflePlaybackQueue();
}


// NOTE: The shuffling is not exactly the same as on iPhone. On iPhone, when shuffling songs
// during playback, the current song song continues to play and all the other songs in the queue
// are shuffle and played back. The current implementation let's the song play but shuffle all the
// songs in the queue (including the current one) and plays them all after. Other behaviours may be
// different between the two implementations.

void WindowsMediaPlaybackServer::ShufflePlaybackQueue()
{
	s32 queueSize = static_cast <s32> (m_playbackQueue.size());

	if(queueSize > 0)
	{
		switch(m_shuffleMode)
		{
			case ExternalMediaPlayer::SM_SONGS:
			{
				// NOTE: May be problematic if VOX_VECTOR != std::vector
				std::sort(m_playbackQueue.begin(), m_playbackQueue.end(), CompareShuffleSongs);

				// Change the playback elements random tags so that next time sort is not the same
				for(s32 i = 0; i < queueSize; i++)
				{
					m_playbackQueue[i]->m_shuffleRandomNumber = rand();
				}

				// Reset the queue indexes
				m_currentQueueIndex = -1;
				m_nextQueueIndex = 0;
				break;
			}
			case ExternalMediaPlayer::SM_ALBUMS:
			{
				// NOTE: May be problematic if VOX_VECTOR != std::vector
				std::sort(m_playbackQueue.begin(), m_playbackQueue.end(), CompareShuffleAlbums);
				break;
			}
			case ExternalMediaPlayer::SM_OFF:
			case ExternalMediaPlayer::SM_DEFAULT:
			{
				// NOTE: May be problematic if VOX_VECTOR != std::vector
				std::sort(m_playbackQueue.begin(), m_playbackQueue.end(), CompareShuffleOff);
				break;
			}
			default:
			{
			}
		}
	}
}


void WindowsMediaPlaybackServer::ShuffleAlbums()
{
}


void WindowsMediaPlaybackServer::ShuffleSongs()
{
	u32 queueSize = m_playbackQueue.size();


}


bool WindowsMediaPlaybackServer::UpdateNextQueueIndex(QueueUpdateMode mode)
{
	bool isNextQueueItemFound = true;

	if(mode == QUM_NEW_SONG)
	{
		switch(m_repeatMode)
		{
			case ExternalMediaPlayer::RM_DEFAULT: // == RM_NONE (?)
			case ExternalMediaPlayer::RM_NONE:
			{
				m_nextQueueIndex++;
				if(m_nextQueueIndex >= static_cast<s32> (m_playbackQueue.size()))
				{
					isNextQueueItemFound = false;
				}
				break;
			}
			case ExternalMediaPlayer::RM_ONE: // Repeat song
			{
				// Do not increment queue index
				m_nextQueueIndex = m_currentQueueIndex;
				break;
			}
			case ExternalMediaPlayer::RM_ALL: // Repeat queue
			{
				m_nextQueueIndex++;
				if(m_nextQueueIndex >= static_cast<s32> (m_playbackQueue.size()))
				{
					m_nextQueueIndex = 0;
					if(m_shuffleMode == ExternalMediaPlayer::SM_ALBUMS || m_shuffleMode == ExternalMediaPlayer::SM_SONGS)
					{
						ShufflePlaybackQueue();
					}
				}
				break;
			}
			default:
			{
			}
		}
	}
	else if(mode == QUM_NEXT_PREVIOUS)
	{
		switch(m_repeatMode)
		{
			case ExternalMediaPlayer::RM_DEFAULT: // == RM_NONE (?)
			case ExternalMediaPlayer::RM_NONE:
			{
				s32 presentNextQueueIndex = m_nextQueueIndex;
				m_nextQueueIndex += m_queueStep - 1;		// -1 since queue index already points towards next song.

				// If no next or no previous, put back next queue index to its present value.
				if(m_nextQueueIndex < 0 || m_nextQueueIndex >= static_cast<s32> (m_playbackQueue.size())) 
				{
					m_nextQueueIndex = presentNextQueueIndex;
					isNextQueueItemFound = false;
				}
				break;
			}
			case ExternalMediaPlayer::RM_ONE: // Repeat song
			{
				s32 presentNextQueueIndex = m_nextQueueIndex;
				m_nextQueueIndex += m_queueStep;				// Next queue index pointed towards current song.

				// If no next or no previous, put back next queue index to its present value.
				if(m_nextQueueIndex < 0 || m_nextQueueIndex >= static_cast<s32> (m_playbackQueue.size())) 
				{
					m_nextQueueIndex = presentNextQueueIndex;
					isNextQueueItemFound = false;
				}
				break;
			}
			case ExternalMediaPlayer::RM_ALL: // Repeat queue
			{
				if(m_queueStep == 1 && m_nextQueueIndex >= static_cast<s32> (m_playbackQueue.size()))
				{
					m_nextQueueIndex = 0;
				}
				else if(m_queueStep == -1) // Search previous
				{
					if(m_currentQueueIndex > 0)
					{
						m_nextQueueIndex = m_currentQueueIndex - 1;
					}
					else
					{
						m_nextQueueIndex = m_playbackQueue.size() - 1;
					}
				}
				break;
			}
			default:
			{
			}
		}

		m_queueStep = 0;
	}

	return isNextQueueItemFound;
}


void WindowsMediaPlaybackServer::UpdateQueuePlaybackState()
{
	if(m_desiredPlaybackState == playback::S_PLAYING)
	{
		if(m_playbackState == playback::S_PAUSED)
		{
			CheckMCIError(mciSendString("setaudio MEDIAFILE volume to 100", NULL, 0, NULL));
			CheckMCIError(mciSendString("play MEDIAFILE", NULL, 0, NULL));
				
			// If this is a new song (requested by user during pause), update the queue index 
			if(!m_isSongStarted)
			{
				m_isSongStarted = true;
			}
			m_stateChangedCallback();
		}
		else if(!m_isSongStarted)
		{
			m_isNewSongNeeded = true;
		}
		m_playbackState = playback::S_PLAYING;
	}	
	else if(m_desiredPlaybackState == playback::S_STOPPED)
	{
		CheckMCIError(mciSendString("stop MEDIAFILE", NULL, 0, NULL));
		m_stateChangedCallback();
		
		// Reinitialize the playback queue indexes
		m_currentQueueIndex = -1;
		m_nextQueueIndex = 0;
	
		m_playbackState = playback::S_STOPPED;
	}
	else if(m_desiredPlaybackState == playback::S_PAUSED)
	{
		CheckMCIError(mciSendString("pause MEDIAFILE", NULL, 0, NULL));
		m_stateChangedCallback();
		m_playbackState = playback::S_PAUSED;
	}
}


// NOTE : This method assumes that MCI returns song length and cursor position with 3 decimal numbers.
f32 WindowsMediaPlaybackServer::ConvertMCITimeInfos(char *pTimeString)
{
	f32 duration = 0.0f;
	s32 stringLength = static_cast<s32> (strlen(pTimeString));
	f32 multiplier = 0.001f;

	for(s32 i = stringLength - 1; i >= 0; i--)
	{
		duration += (static_cast<f32> (pTimeString[i] - '0')) * multiplier;
		multiplier *= 10.0f;
	}

	return duration;
}
////

ExternalMediaPlayer *CreatePlayer(void)
{
	return VOX_NEW WindowsMediaPlayer();
}


void DestroyPlayer(void)
{
	WindowsMediaPlayer *pPlayer = static_cast<WindowsMediaPlayer*> (ExternalMediaPlayer::GetInstance());

	if(pPlayer)
	{
		VOX_DELETE(pPlayer);
	}
}

////

// Initialize static variables
bool WindowsMediaPlayer::s_isInstanceUsed = false;
bool WindowsMediaPlayer::s_keepInstanceAlive = false;
void *WindowsMediaPlayer::s_pUserStateCallbackData = 0;
void *WindowsMediaPlayer::s_pUserSongCallbackData = 0;
ExternalMediaPlayerCallback	WindowsMediaPlayer::s_externalStateCallback = 0;
ExternalMediaPlayerCallback	WindowsMediaPlayer::s_externalSongCallback = 0;


WindowsMediaPlayer::WindowsMediaPlayer()
{
	m_thread = 0;

	m_itemCount = 0;
	m_isQueryValid = false;
	m_mediaPath[0] = 0;
	m_isOpened = false;

	m_pPlaybackServer = VOX_NEW WindowsMediaPlaybackServer();

	// Register callbacks upon the playback server
	if(m_pPlaybackServer)
	{
		m_pPlaybackServer->RegisterSongCallback(&_SongChangedHandler);
		m_pPlaybackServer->RegisterStateCallback(&_StateChangedHandler);
	}
	s_keepInstanceAlive = true;
}


WindowsMediaPlayer::~WindowsMediaPlayer()
{
	Shutdown();
}


void WindowsMediaPlayer::_SongChangedHandler()
{
	s_isInstanceUsed = true; // Prevents object destruction during execution of the present callback.

	if(s_keepInstanceAlive) // Prevents execution of the enclosed code if Shutdown() has begun.
	{
		WindowsMediaPlayer *pPlayerInstance = static_cast<WindowsMediaPlayer*> (ExternalMediaPlayer::s_pInstance);

		if(pPlayerInstance)
		{
			pPlayerInstance->QueueCommand(controllercommand::T_PROCESS_SONG_CHANGED, 0, true);
		}
	}

	s_isInstanceUsed = false;
}


void WindowsMediaPlayer::_StateChangedHandler()
{
	s_isInstanceUsed = true; // Prevents object destruction during execution of the present callback.

	if(s_keepInstanceAlive) // Prevents execution of the enclosed code if Shutdown() has begun.
	{
		WindowsMediaPlayer *pPlayerInstance = static_cast<WindowsMediaPlayer*> (ExternalMediaPlayer::s_pInstance);

		if(pPlayerInstance)
		{
			pPlayerInstance->QueueCommand(controllercommand::T_PROCESS_STATE_CHANGED, 0, true);
		}
	}

	s_isInstanceUsed = false;

}


void WindowsMediaPlayer::ProcessSongChanged()
{
	if(s_externalSongCallback)
		s_externalSongCallback(s_pUserSongCallbackData);
}


void WindowsMediaPlayer::ProcessStateChanged()
{
	if(s_externalStateCallback)
		s_externalStateCallback(s_pUserStateCallbackData);
}


void WindowsMediaPlayer::Initialize()
{
	m_playerInternalState = -1;
	m_nowPlayingDuration = 0.0f;
	m_nowPlayingPosition = 0.0f;
	m_pNowPlayingAlbum[0] = 0;
	m_pNowPlayingArtist[0] = 0;
	m_pNowPlayingTitle[0] = 0;

	m_isNowPlayingItemValid = false;
	m_isNowPlayingItemUpdating = false;
	m_isStateValid = false;
	m_isStateUpdating = false;
	m_isSuspended = false;
	m_isQueryPending = false;
	m_pItems = 0;

	m_pQueryServer = VOX_NEW WindowsMediaQueryServer(m_mediaPath);
}


void WindowsMediaPlayer::Shutdown()
{
	// Prevent code from executing critical code within the '_...ChangedHandler()' callbacks
	s_keepInstanceAlive = false;

	// Wait until all the '_...ChangedHandler()' callbacks have stopped if one was already running
	while(s_isInstanceUsed)
	{
		VoxThread::Sleep(1);
	}

	if(m_pPlaybackServer)
	{
		ScopeMutex sm(&m_processQueueMutex);
		VOX_DELETE(m_pPlaybackServer);
		m_pPlaybackServer = 0;
	}

	// Close media player
	if(m_isOpened)
	{
		Close();
	}

	VOX_DELETE(m_thread);
	m_thread = 0;
}


void WindowsMediaPlayer::SetMediaPath(const char *path)
{
	if(path)
	{
		strcpy(m_mediaPath, path);
	}
}


bool WindowsMediaPlayer::Open()
{
	Initialize();

	// Start thread used to process command queue
	if(!m_thread)
		m_thread = VOX_NEW VoxThread(RunCallback, this, 0, "External media player: Windows Media Player");
	m_isOpened = true;

	// Queue commands to send callbacks to inform user that process has begun.
	QueueCommand(controllercommand::T_PROCESS_SONG_CHANGED, 0, true);
	QueueCommand(controllercommand::T_PROCESS_STATE_CHANGED, 0, true);

	return true;
}


void WindowsMediaPlayer::Close()
{
	m_isOpened = false;

	ScopeMutex sm(&m_processQueueMutex);

	// Stop the current playing song
	_Stop();

	Suspend();

	if(m_pQueryServer)
	{
		VOX_DELETE(m_pQueryServer);
		m_pQueryServer = 0;
	}

	// Stop thread processing command queue
	VOX_DELETE(m_thread);
	m_thread = 0;

}


bool WindowsMediaPlayer::RegisterCallback(CallbackType callbackType, ExternalMediaPlayerCallback callback, void *pUserData)
{	
	if(!m_isOpened)
	{
		switch(callbackType)
		{
			case ExternalMediaPlayer::CT_STATE_CHANGED:
			{
				s_externalStateCallback = callback;
				s_pUserStateCallbackData = pUserData;
				return true;
			}
			case ExternalMediaPlayer::CT_NOW_PLAYING_CHANGED:
			{
				s_externalSongCallback = callback;
				s_pUserSongCallbackData = pUserData;
				return true;
			}
		}
	}

	return false;
}

void WindowsMediaPlayer::RunCallback(void *caller, void *param)
{
	((WindowsMediaPlayer *)caller)->Run();
}

void WindowsMediaPlayer::Run()
{		
	while(m_isOpened)
	{
		ProcessQueue();
		VoxThread::Sleep(33);
	}
}


void WindowsMediaPlayer::ProcessQueue()
{
	ScopeMutex sm(&m_processQueueMutex);

	if(m_pQueryServer->IsQueryPending())
        return;

    ControllerCommand command;
    bool isEmpty;

	{
		ScopeMutex sm(&m_commandQueueMutex);
		isEmpty = m_commandQueue.size() <= 0;

		if(!isEmpty)
		{
			command = m_commandQueue.front();
			m_commandQueue.pop_front();
		}
	}

    if(isEmpty || command.m_type == controllercommand::T_CANCELLED)
        return;

    switch(command.m_type)
    {
        case controllercommand::T_PLAY:
        {
            _Play();
			break;
        }
        case controllercommand::T_PAUSE:
        {
            _Pause();
            break;
        }
        case controllercommand::T_STOP:
        {
            _Stop();
            break;
        }
        case controllercommand::T_NEXT:
        {
            _Next();
            break;
        }
        case controllercommand::T_PREVIOUS:
        {
            _Previous();
            break;
        }
        case controllercommand::T_SET_SHUFFLE_MODE:
        {
            _SetShuffleMode(static_cast<ShuffleMode> (command.m_param));
            break;
        }
        case controllercommand::T_SET_REPEAT_MODE:
        {
            _SetRepeatMode(static_cast<RepeatMode> (command.m_param));
            break;
        }

        case controllercommand::T_SET_PLAYLIST:
        {
            _SetPlaylist(command.m_param);
            break;
        }
        case controllercommand::T_SET_ARTIST:
        {
            _SetArtist(command.m_param);
            break;
        }
        case controllercommand::T_SET_ALBUM:
        {
            _SetAlbum(command.m_param);
            break;
        }
        case controllercommand::T_SET_SONG:
        {
            _SetSong(command.m_param);
            break;
        }
		case controllercommand::T_GET_NOW_PLAYING_ITEM_DATA:
        {
            _GetNowPlayingItemData();
            break;
        }
        case controllercommand::T_GET_PLAYBACK_STATE:
        {
            _GetPlaybackStateAsync();
            break;
        }	
		case controllercommand::T_PLAYLIST_QUERY:
		case controllercommand::T_ARTIST_QUERY:
		case controllercommand::T_ALBUM_QUERY:
		case controllercommand::T_SONG_QUERY:
        {
			m_pQueryServer->QueryMediaItems(m_mediaItemCategory, &m_pItems, &m_queryResultsMutex, &m_itemCount);
			m_isQueryValid = true;
			m_isQueryPending = false;
            break;
        }
		case controllercommand::T_PROCESS_SONG_CHANGED:
        {
            _ProcessSongChanged();
            break;
        }	
		case controllercommand::T_PROCESS_STATE_CHANGED:
        {
            _ProcessStateChanged();
            break;
        }
        default:
        {
            VOX_WARNING_LEVEL_2("Unknown Windows player controller command : %d", command.m_type);
            break;
        }
    }
}


void WindowsMediaPlayer::QueueCommand(controllercommand::Type commandType, s32 param, bool isHighPrio)
{
	if(!m_isOpened)
	{
		VOX_WARNING_LEVEL_4("Media player is not opened, cannot queue command %d", commandType);
		return;
	}

	if(m_isSuspended)
		return;

	ScopeMutex sm(&m_commandQueueMutex);

	if(commandType == controllercommand::T_PROCESS_SONG_CHANGED|| commandType == controllercommand::T_PROCESS_STATE_CHANGED ||
	   commandType == controllercommand::T_PROCESS_LIBRARY_CHANGED)
	{
		//Need to cancel other command of the same type to avoid processing same callback twice
		VOX_LIST<ControllerCommand>::iterator iter = m_commandQueue.begin();
		VOX_LIST<ControllerCommand>::iterator end = m_commandQueue.end();

		for(;iter != end; iter++)
		{
			if((*iter).m_type == commandType)
				(*iter).m_type = controllercommand::T_CANCELLED;
		}
	}

	if(isHighPrio)
	{
		m_commandQueue.push_front(ControllerCommand(commandType, param));
	}
	else
	{
		m_commandQueue.push_back(ControllerCommand(commandType, param));
	}
}


void WindowsMediaPlayer::_Play()
{
	m_pPlaybackServer->Play();
}


void WindowsMediaPlayer::_Pause()
{
	m_pPlaybackServer->Pause();
}


void WindowsMediaPlayer::_Stop()
{
	m_pPlaybackServer->Stop();
}
	

void WindowsMediaPlayer::_Next()
{
	m_pPlaybackServer->Next();
}


void WindowsMediaPlayer::_Previous()
{
	m_pPlaybackServer->Previous();
}


void WindowsMediaPlayer::_SetRepeatMode(RepeatMode repeatMode)
{
	if(m_pPlaybackServer)
	{
		if(m_pPlaybackServer->SetRepeatMode(repeatMode))
		{
			m_repeatMode = repeatMode;
		}
	}
}


void WindowsMediaPlayer::_SetShuffleMode(ShuffleMode shuffleMode)
{
	if(m_pPlaybackServer)
	{
		if(m_pPlaybackServer->SetShuffleMode(shuffleMode))
		{
			m_shuffleMode = shuffleMode;
		}
	}
}


void WindowsMediaPlayer::_SetPlaylist(s32 index)
{
	if(m_pItems == 0 || m_pQueryServer == 0)
		return;

	if(index > m_itemCount)
		return;

	if(index >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting playlist %d as current", index);
		m_pPlaybackServer->QueueMediaItems(m_pItems, MI_PLAYLIST, index);
	}
	else if(index == -1)
	{
		// Queue all songs
		VOX_WARNING_LEVEL_5("%s", "Setting whole library as playlist");
		m_pPlaybackServer->QueueMediaItems(m_pItems, MI_PLAYLIST, index);
	}
	else
	{
		VOX_WARNING_LEVEL_2("%s", "Playlist indexes lower than -1 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback");
	}
}


void WindowsMediaPlayer::_SetArtist(s32 index)
{
	if(m_pItems == 0 || m_pQueryServer == 0)
		return;

	if(index > m_itemCount)
		return;

	if(index >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting artist %d as current", index);
		m_pPlaybackServer->QueueMediaItems(m_pItems, MI_ARTIST, index);
	}
	else
	{
		VOX_WARNING_LEVEL_2("%s", "Artist indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback");
	}
}


void WindowsMediaPlayer::_SetAlbum(s32 index)
{
	if(m_pItems == 0 || m_pQueryServer == 0)
		return;

	if(m_itemCount <= index)
		return;

	if(index >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting artist %d as current", index);
		m_pPlaybackServer->QueueMediaItems(m_pItems, MI_ALBUM, index);
	}
	else
	{
		VOX_WARNING_LEVEL_2("%s", "Artist indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback");
	}
}


void WindowsMediaPlayer::_SetSong(s32 index)
{
	if(m_pItems == 0 || m_pQueryServer == 0)
		return;

	if(m_itemCount <= index)
		return;

	if(index >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting song %d as current", index);
		m_pPlaybackServer->QueueMediaItems(m_pItems, MI_SONG, index);
	}
	else
	{
		VOX_WARNING_LEVEL_2("%s", "Song indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback");
	}
}


ExternalMediaPlayer::QueryState WindowsMediaPlayer::ConvertPlaybackState(s32 nativeState, PlaybackState &outPlaybackState)
{
	if(nativeState == QS_RUNNING)
	{
		outPlaybackState = PS_PENDING;
		return QS_RUNNING;
	}

	switch(nativeState)
	{
		case playback::S_PLAYING:
		{
			outPlaybackState = PS_PLAYING;
			return QS_SUCCESS;
		}
		case playback::S_PAUSED:
		{
			outPlaybackState = PS_PAUSED;
			return QS_SUCCESS;
		}
		case playback::S_STOPPED:
		case playback::S_INITIAL:
		{
			outPlaybackState = PS_STOPPED;
			return QS_SUCCESS;
		}
	}

	outPlaybackState = PS_OTHER;
	return QS_SUCCESS;
}


s32 WindowsMediaPlayer::_GetPlaybackState()
{
	s32 errorCode = QS_ERROR;

	 if(m_isStateValid)
	 {
		 errorCode = m_playerInternalState;
		 m_isStateValid = false;			// Only good for one query
	 }
	 else
	 {
		 errorCode = QS_RUNNING;

		 if(!m_isStateUpdating)
		 {
			 m_isStateUpdating = true;
			 QueueCommand(controllercommand::T_GET_PLAYBACK_STATE);			
		 }
	 }

	 return errorCode;
}


void WindowsMediaPlayer::_GetPlaybackStateAsync()
{
	m_playerInternalState = -1;

	if(m_pPlaybackServer)
		m_playerInternalState = static_cast<s32> (m_pPlaybackServer->GetPlaybackState());

	m_isStateValid = true;
	m_isStateUpdating = false;
}


void WindowsMediaPlayer::_GetNowPlayingItemData()
{	
	ScopeMutex sm(&m_nowPlayingItemMutex);

	if(m_pPlaybackServer)
	{
		m_pPlaybackServer->GetNowPlayingItemData(m_pNowPlayingTitle, m_pNowPlayingArtist, m_pNowPlayingAlbum,
												 &m_nowPlayingPosition, &m_nowPlayingDuration);
	}
	
	m_isNowPlayingItemValid = true;
	m_isNowPlayingItemUpdating = false;
}


void WindowsMediaPlayer::_GetMediaItems()
{
	if(m_pItems)
		m_pItems = 0;

	m_isQueryPending = true;

	switch(m_mediaItemCategory)
	{
		case ExternalMediaPlayer::MI_PLAYLIST:
		{
			QueueCommand(controllercommand::T_PLAYLIST_QUERY);
			break;
		}
		case ExternalMediaPlayer::MI_ARTIST:
		{
			QueueCommand(controllercommand::T_ARTIST_QUERY);
			break;
		}
		case ExternalMediaPlayer::MI_ALBUM:
		{
			QueueCommand(controllercommand::T_ALBUM_QUERY);
			break;
		}
		case ExternalMediaPlayer::MI_SONG:
		{
			QueueCommand(controllercommand::T_SONG_QUERY);
			break;
		}
		default:
		{
			// Cannot get there because of mask condition in GetMediaItemsCount().
		}
	}
}


void WindowsMediaPlayer::_ProcessStateChanged()
{
	m_isStateValid = false;

	if (s_externalStateCallback)
		s_externalStateCallback(s_pUserStateCallbackData);
}


void WindowsMediaPlayer::_ProcessSongChanged()
{
	m_isNowPlayingItemValid = false;

	if(s_externalSongCallback)
		s_externalSongCallback(s_pUserSongCallbackData);
}

	
void WindowsMediaPlayer::Suspend()
{
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);

	m_isSuspended = true;

	// Clear the command queue
	{
		ScopeMutex sm(&m_commandQueueMutex);
		m_commandQueue.clear();
	}

	// Drop any query presently running
	if(m_pQueryServer->IsQueryPending()) 
		m_pQueryServer->DropResult();	

	// Release object used to keep query results
	{
		ScopeMutex sm(&m_queryResultsMutex);
		if(m_pItems)
			m_pItems = 0;
	}

	m_isNowPlayingItemValid = false;
	m_isStateValid = false;
}


void WindowsMediaPlayer::Resume()
{
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);

	m_isSuspended = false;

	QueueCommand(controllercommand::T_PROCESS_SONG_CHANGED, 0, true);
	QueueCommand(controllercommand::T_PROCESS_STATE_CHANGED, 0, true);
}


void WindowsMediaPlayer::Play()
{
	QueueCommand(controllercommand::T_PLAY);
}


void WindowsMediaPlayer::Stop()
{
	QueueCommand(controllercommand::T_STOP);
}


void WindowsMediaPlayer::Pause()
{
	QueueCommand(controllercommand::T_PAUSE);
}


void WindowsMediaPlayer::Next()
{
	QueueCommand(controllercommand::T_NEXT);
}


void WindowsMediaPlayer::Previous()
{
	QueueCommand(controllercommand::T_PREVIOUS);
}


ExternalMediaPlayer::ShuffleMode WindowsMediaPlayer::GetShuffleMode()
{
	return m_shuffleMode;
}


ExternalMediaPlayer::RepeatMode WindowsMediaPlayer::GetRepeatMode()
{
	return m_repeatMode;
}


ExternalMediaPlayer::MediaItemCategory WindowsMediaPlayer::GetMediaItemCategory(void)
{
	return m_mediaItemCategory;
}


ExternalMediaPlayer::QueryState WindowsMediaPlayer::GetMediaItemsCount(s32 &outItemCount)
{
	outItemCount = -1;

	if(m_mediaItemCategory & WindowsMediaItemsMask)
	{
		if(m_isQueryPending || m_pQueryServer->IsQueryPending())
		{
			return QS_RUNNING;
		}

		ScopeMutex sm(&m_queryResultsMutex);

		if(m_pItems == 0)
		{
			_GetMediaItems();
			return QS_RUNNING;
		}

		if(m_pItems)
		{
			if(m_itemCount == 0)
			{
				m_pItems = 0;
			}

			outItemCount = m_itemCount;
			return QS_SUCCESS;
		}
	}

	return QS_ERROR;
}


ExternalMediaPlayer::QueryState WindowsMediaPlayer::GetMediaItemName(s32 itemIndex, const char *&outItemName)
{
	outItemName = 0;

	if(m_mediaItemCategory & WindowsMediaItemsMask)
	{
		if(m_isQueryPending || m_pQueryServer->IsQueryPending())
		{
			return QS_RUNNING;
		}

		ScopeMutex sm(&m_queryResultsMutex);

		if(m_pItems == 0)
			return QS_ERROR;

		if(m_itemCount <= itemIndex || itemIndex < 0)
		{
			return QS_ERROR;
		}		

		switch(m_mediaItemCategory)
		{
			case ExternalMediaPlayer::MI_PLAYLIST:
			{
				outItemName = GetPlaylistName(itemIndex);
				break;
			}
			case ExternalMediaPlayer::MI_ARTIST:
			{
				outItemName = GetArtistName(itemIndex);
				break;
			}
			case ExternalMediaPlayer::MI_ALBUM:
			{
				outItemName = GetAlbumName(itemIndex);
				break;
			}
			case ExternalMediaPlayer::MI_SONG:
			{
				outItemName = (*m_pItems)[0][itemIndex]->m_title;
				break;
			}
			default:
			{
			}
		}

		if(outItemName)
			return QS_SUCCESS;		
	}

	return QS_ERROR;
}


ExternalMediaPlayer::QueryState WindowsMediaPlayer::GetNowPlayingItemData(const char *&outTitle,
																		  const char *&outArtist,
																		  const char *&outAlbum,
																		  f32* outCursorPosition,
																		  f32* outPlaybackDuration)
{
	outTitle = 0;
	outArtist = 0;
	outAlbum = 0;

	QueryState errorCode = QS_ERROR;

	if(m_isNowPlayingItemValid)
	{
		ScopeMutex sm(&m_nowPlayingItemMutex);

		outTitle = m_pNowPlayingTitle;
		outArtist = m_pNowPlayingArtist;
		outAlbum = m_pNowPlayingAlbum;
		*outCursorPosition = m_nowPlayingPosition;
		*outPlaybackDuration = m_nowPlayingDuration;
		errorCode = QS_SUCCESS;

		m_isNowPlayingItemValid = false; // Only good for one query
	}
	else // Now playing item is not valid. Queue a query.
	{
		errorCode = QS_RUNNING;

		if(!m_isNowPlayingItemUpdating)
		{
			m_isNowPlayingItemUpdating = true;
			QueueCommand(controllercommand::T_GET_NOW_PLAYING_ITEM_DATA);
		}
	}

    return errorCode;
}


ExternalMediaPlayer::QueryState WindowsMediaPlayer::GetPlaybackState(PlaybackState &outPlaybackState)
{
	return ConvertPlaybackState(_GetPlaybackState(), outPlaybackState);
}


void WindowsMediaPlayer::SetMediaItemCategory(MediaItemCategory category, void *params)
{
	ScopeMutex sm(&m_queryResultsMutex);

	m_mediaItemCategory = category;
	m_pItems = 0;
}


bool WindowsMediaPlayer::SetRepeatMode(RepeatMode repeatMode)
{
	QueueCommand(controllercommand::T_SET_REPEAT_MODE, repeatMode);
	return true;
}


bool WindowsMediaPlayer::SetShuffleMode(ShuffleMode shuffleMode)
{
	QueueCommand(controllercommand::T_SET_SHUFFLE_MODE, shuffleMode);
	return true;
}

void WindowsMediaPlayer::SetMediaItem(s32 itemIndex)
{
	switch(m_mediaItemCategory)
	{
		case MI_PLAYLIST:
		{
			QueueCommand(controllercommand::T_SET_PLAYLIST, itemIndex);
			break;
		}
		case ExternalMediaPlayer::MI_ARTIST:
		{
			QueueCommand(controllercommand::T_SET_ARTIST, itemIndex);
			break;
		}
		case ExternalMediaPlayer::MI_ALBUM:
		{
			QueueCommand(controllercommand::T_SET_ALBUM, itemIndex);
			break;
		}
		case ExternalMediaPlayer::MI_SONG:
		{
			QueueCommand(controllercommand::T_SET_SONG, itemIndex);
			break;
		}
		default:
		{
		}
	}
}


const char *WindowsMediaPlayer::GetPlaylistName(s32 playlistIndex)
{
	return m_pQueryServer->GetPlaylistName(playlistIndex);
}


const char *WindowsMediaPlayer::GetAlbumName(s32 albumIndex)
{
	s32 nbAlbums = m_pItems->size();

	if(nbAlbums > 0)
	{
		// Get album name from first entry in vector associated with albumIndex query list
		if(albumIndex >= 0 && albumIndex < nbAlbums)
		{
			return (*m_pItems)[albumIndex][0]->m_album;
		}
	}
	return 0;
}


const char *WindowsMediaPlayer::GetArtistName(s32 artistIndex)
{
	s32 nbArtists = m_pItems->size();

	if(nbArtists > 0)
	{
		// Get artist name from first entry in vector associated with artistIndex query list
		if(artistIndex >= 0 && artistIndex < nbArtists)
		{
			return (*m_pItems)[artistIndex][0]->m_artist;
		}
	}
	return 0;
}


} // media_player namespace

} // vox namespace

#endif // VOX_USE_WINDOWS_MEDIA_PLAYER && VOX_WINDOWS_MEDIA_PLAYER_PLATFORM

// NOTE 1: The now playing position is polled regularly in the Run() method since calling the
//		   mciSendString() method from another thread than the one where 'open' was called doesn't
//		   seem to work.