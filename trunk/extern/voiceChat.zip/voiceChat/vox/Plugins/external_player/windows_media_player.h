#pragma once
#ifndef _WINDOWS_MEDIA_PLAYER_H
#define _WINDOWS_MEDIA_PLAYER_H

#include "vox.h"

#define VOX_INTERNAL_CODE

#include "external_media_player.h"
#include "media_player_common.h"

#if VOX_USE_WINDOWS_MEDIA_PLAYER

#include "vox_internal.h"

#include VOX_LIST_INCLUDE
#include VOX_VECTOR_INCLUDE

#define MCI_DATA_LENGTH			128
#define MCI_DATA_BUFFER_LENGTH	129

namespace vox
{

namespace media_player
{

const s32 WindowsMediaItemsMask = ExternalMediaPlayer::MI_PLAYLIST | ExternalMediaPlayer::MI_ARTIST | ExternalMediaPlayer::MI_ALBUM | ExternalMediaPlayer::MI_SONG;

namespace playback
{
	enum State
	{
		S_INITIAL,
		S_PLAYING,
		S_PAUSED,
		S_STOPPED,
 };
}

// TODO : Ideally AudioFile should be a base class from which MP3File would inherit (as well as other audio formats)
struct AudioFile
{
	AudioFile();
	AudioFile::AudioFile(const char* workingDirRelativePath, const char* dataRelativePath);
	AudioFile(const AudioFile &audioFile);

	~AudioFile();

	char* m_filepath;	// Relative to working directory
	char m_title[32];
	char m_artist[32];
	char m_album[32];
};


struct Playlist
{
	Playlist();
	Playlist(const char* fullpath);
	~Playlist();

	char* m_path;					// Without file name
	char* m_name;					// File name stripped of path and ".m3u" extension.
	VOX_VECTOR<s32> m_positions;	// Positions of playlist's audio files in WindowsMediaQueryServer's library vector.
};


struct PlaybackQueueElement
{
	AudioFile *m_pFile;			// The PlaybackQueueElement object is not the owner of the AudioFile pointed at.
	s32 m_originalPosition;		// Element position in the queue when shuffle mode is OFF.
	s32	m_shuffleRandomNumber;	// Number used to randomize elements in the queue when shuffle mode is SM_OFF.

	PlaybackQueueElement():m_pFile(0), m_originalPosition(-1), m_shuffleRandomNumber(-1){};
};


class WindowsMediaQueryServer
{
 public:
	WindowsMediaQueryServer(const char *mediaPath);
	~WindowsMediaQueryServer();

	void DropResult(void);
	s32 GetFilePositionInLibrary(char *filepath);
	const char *GetPlaylistName(s32 playlistIndex);
	bool IsQueryPending(void);
	void QueryMediaItems(ExternalMediaPlayer::MediaItemCategory category, void *pItems, Mutex* pQueryMutex, void *pOutItemCount);
 private:
	void Initialize(const char *mediaPath);
	void Run();
	static void RunCallback(void *caller, void *param);

	void FindMedia(const char* mediaPath, VOX_VECTOR<VOX_STRING> &playlistDataRelativePaths,
				   VOX_VECTOR<VOX_STRING> &playlistWorkingDirRelativePaths);	// mediaPath relative to data directory
	void AddMedia(const char* workingDirRelativePath, const char* dataRelativePath);
	void AddPlaylist(const char* playlistFullPath, const char* playlistWorkingDirRelativePaths);
	void AddPlaylists(VOX_VECTOR<VOX_STRING> &playlistsFullPaths, VOX_VECTOR<VOX_STRING> &playlistWorkingDirRelativePaths);
	void NormalizePathName(char *inPath);
	void ReferenceToWorkingDir(char *path, const char *pathReference);

	void GetItemsByPlaylists(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults);
	void GetItemsByArtists(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults);
	void GetItemsByAlbums(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults);
	void GetItemsBySongs(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pQueryResults);

	VOX_VECTOR<AudioFile> m_library;
	VOX_VECTOR<Playlist*> m_playlists;
	VOX_VECTOR<VOX_VECTOR<AudioFile*>> m_pQueryResults[2];	// One for current query, one for user.
	s32 m_availableQueryIndex;								// Vector from m_pQueryResults[] available for query.
	VOX_VECTOR<VOX_VECTOR<AudioFile*>> **m_pUserQuery;		// Points towards one of m_pQueryResults vectors.
	s32 *m_pUserQueryCount;

	ExternalMediaPlayer::MediaItemCategory m_mediaItemCategory;
	bool m_dropResult;
	bool m_isRunning;
	bool m_isQueryPending;

	char m_pWorkingDirectory[512];

	VoxThread *m_thread;

	Mutex *m_pQueryTransferMutex;
	Mutex m_queryMutex;
};


class WindowsMediaPlaybackServer
{
 enum QueueUpdateMode
 {
	QUM_NEXT_PREVIOUS,		// User selected Next or Previous
	QUM_NEW_SONG,			// A new song is opened in MCI
 };

 public:
	WindowsMediaPlaybackServer();
	~WindowsMediaPlaybackServer();

	playback::State GetPlaybackState(void);
	void GetNowPlayingItemData(char *outTitle, char *outArtist, char *outAlbum, f32* outCursorPosition, f32* outPlaybackDuration);
	
	void QueueMediaItems(void *pMediaItems, ExternalMediaPlayer::MediaItemCategory itemCategory, s32 index);
	void Play();
	void Pause();
	void Stop();
	void Next();
	void Previous();

	bool SetShuffleMode(ExternalMediaPlayer::ShuffleMode shuffleMode);
	bool SetRepeatMode(ExternalMediaPlayer::RepeatMode repeatMode);

	void RegisterStateCallback(InternalMediaPlayerCallback callback);
	void RegisterSongCallback(InternalMediaPlayerCallback callback);
 private:
	static void RunCallback(void *caller, void *param);
	void Run();
	bool UpdateNextQueueIndex(QueueUpdateMode mode);
	void UpdateQueuePlaybackState();
	void ShufflePlaybackQueue();
	void ShuffleAlbums();
	void ShuffleSongs();

	void QueueMedia(AudioFile* audiofile, s32 queueIndex);
	void QueueSongsFromPlaylist(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pMediaItems, s32 playlistIndex);
	void QueueSongsFromAlbum(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pMediaItems, s32 albumIndex);
	void QueueSongsFromArtist(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pMediaItems, s32 artistIndex);
	void QueueSong(VOX_VECTOR<VOX_VECTOR<AudioFile*>> *pMediaItems, s32 songIndex);

	f32 ConvertMCITimeInfos(char *pTimeString);			// For position and length infos of Audio files

	bool m_doUpdate;
	Mutex m_mutex;
	VOX_VECTOR<PlaybackQueueElement*> m_playbackQueue;
	s32 m_currentQueueIndex;							// The current song playing (or paused)
	s32 m_nextQueueIndex;								// The next song to play
	s32 m_queueStep;									// + 1 for Next(), -1 for Previous(), 0 otherwise.
	playback::State m_desiredPlaybackState;
	playback::State m_playbackState;
	char m_nowPlayingPosition[MCI_DATA_BUFFER_LENGTH];
	char m_nowPlayingLength[MCI_DATA_BUFFER_LENGTH];
	bool m_isNewSongNeeded;
	bool m_isMCIDeviceOpened;
	bool m_isSongStarted;
	bool m_hasQueueFinishedPlaying;

	bool m_threadReadyToDelete;

	ExternalMediaPlayer::RepeatMode m_repeatMode;
	ExternalMediaPlayer::ShuffleMode m_shuffleMode;

	InternalMediaPlayerCallback m_songChangedCallback;
	InternalMediaPlayerCallback m_stateChangedCallback;

	VoxThread *m_thread;
};



class WindowsMediaPlayer : public ExternalMediaPlayer
{
 public:
	WindowsMediaPlayer();
	~WindowsMediaPlayer();

	virtual void SetMediaPath(const char *path);
	virtual bool RegisterCallback(CallbackType callbackType, ExternalMediaPlayerCallback callback, void *pUserData);

	virtual bool Open();
	virtual void Close();

	virtual void Suspend();
	virtual void Resume();

	virtual void Play();
	virtual void Stop();
	virtual void Pause();
	virtual void Next();
	virtual void Previous();
	
	virtual ShuffleMode GetShuffleMode();
	virtual RepeatMode GetRepeatMode();
	virtual MediaItemCategory GetMediaItemCategory(void);
	virtual QueryState GetMediaItemsCount(s32 &outItemCount);
	virtual QueryState GetMediaItemName(s32 itemIndex, const char *&outItemName);
	virtual QueryState GetNowPlayingItemData(const char *&outTitle, const char *&outArtist, const char *&outAlbum, f32* outCursorPosition, f32* outPlaybackDuration);
	virtual QueryState GetPlaybackState(PlaybackState &outPlaybackState);

	virtual void SetMediaItemCategory(MediaItemCategory category, void *params);
	virtual bool SetShuffleMode(ShuffleMode shuffleMode);
	virtual bool SetRepeatMode(RepeatMode repeatMode);
	virtual void SetMediaItem(s32 itemIndex);
 protected:
	void Initialize();
	void Shutdown();
 private:
	static void _SongChangedHandler();
	static void _StateChangedHandler();

	void ProcessSongChanged();
	void ProcessStateChanged();

	void ProcessQueue();
	void QueueCommand(controllercommand::Type commandType, s32 param = 0, bool isHighPrio = false);

	//Playback control
	void _Play();
	void _Pause();
	void _Stop();
	void _Next();
	void _Previous();

	void _SetRepeatMode(RepeatMode repeatMode);
	void _SetShuffleMode(ShuffleMode shuffleMode);

	void _SetPlaylist(s32 index);
	void _SetArtist(s32 index);
	void _SetAlbum(s32 index);
	void _SetSong(s32 index);

	QueryState ConvertPlaybackState(s32 nativeState, PlaybackState &outPlaybackState);
	s32 _GetPlaybackState();
	void _GetPlaybackStateAsync();
	void _GetNowPlayingItemData();
	void _GetMediaItems();

	void _ProcessStateChanged();
	void _ProcessSongChanged();

	const char *GetPlaylistName(s32 playlistIndex);
	const char *GetAlbumName(s32 albumIndex);
	const char *GetArtistName(s32 artistIndex);

	static void RunCallback(void *caller, void *param);
	void Run(void);	// Class does not inherit from glf thread anymore. This is called by RunCallback.

	static bool	s_isInstanceUsed;
	static bool	s_keepInstanceAlive;

	static void *s_pUserStateCallbackData;
	static void *s_pUserSongCallbackData;

	static ExternalMediaPlayerCallback	s_externalStateCallback;
    static ExternalMediaPlayerCallback	s_externalSongCallback;

	char m_mediaPath[512];	// Path of media files root (relative to glf's data path).

	// Pointer to query results. Current class does not own this vector. Class WindowsMediaQueryServer owns it.
	VOX_VECTOR<VOX_VECTOR<AudioFile*>> *m_pItems;

	WindowsMediaPlaybackServer	*m_pPlaybackServer;
	WindowsMediaQueryServer		*m_pQueryServer;

	VOX_LIST<ControllerCommand> m_commandQueue;

	Mutex m_processQueueMutex;
	Mutex m_commandQueueMutex;
	Mutex m_queryResultsMutex;
	Mutex m_nowPlayingItemMutex;

	// Now playing parameters
	f32		m_nowPlayingDuration;
	f32		m_nowPlayingPosition;
	char	m_pNowPlayingAlbum[64];
	char	m_pNowPlayingArtist[64];
	char	m_pNowPlayingTitle[64];

	bool m_isNowPlayingItemValid;
	bool m_isNowPlayingItemUpdating;
	bool m_isStateValid;
	bool m_isStateUpdating;
	bool m_isQueryPending;
	bool m_isSuspended;
	bool m_isOpened;
	bool m_isQueryValid;

	s32	m_playerInternalState;	// State as provided by WindowsMediaPlaybackServer.

	s32 m_itemCount;

	VoxThread *m_thread;
};

} // media_player namespace

} // vox namespace


#endif // VOX_USE_WINDOWS_MEDIA_PLAYER && VOX_WINDOWS_MEDIA_PLAYER_PLATFORM
#endif // _WINDOWS_MEDIA_PLAYER_H