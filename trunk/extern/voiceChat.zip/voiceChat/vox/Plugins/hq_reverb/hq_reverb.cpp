// #include "StdAfx.h"


#include "hq_reverb_internal.h"
#include <string.h>


#if defined(_WIN32)
	#define STRICMP _stricmp
#else
	#define STRICMP strcasecmp	
#endif

#if VOX_NEON_HQREVERB
#include "vox_detect_neon.h"
#endif


#ifndef VOX_HQREVERB_PI
	#define VOX_HQREVERB_PI 3.141592653589793f
#endif

#define VOX_HQREVERB_SPEEDOFSOUNDMETRESPERSEC	(343.3f)
#define VOX_HQREVERB_PRIME_TABLE_SIZE		300


namespace vox
{



// **************************************************************************************** //
// ************************************ Utility functions ********************************* //
// **************************************************************************************** //


static unsigned int NextPowerOf2(unsigned int value)
{
    unsigned int powerOf2 = 1;
	
    if(value)
    {
        value--;
        while(value)
        {
            value >>= 1;
            powerOf2 <<= 1;
        }
    }
    return powerOf2;
}




// **************************************************************************************** //
// ******************************** ReverbHQParameters class ****************************** //
// **************************************************************************************** //

ReverbHQParameters::ReverbHQParameters(void)
{
	Density = 1.0f;
	Diffusion = 1.0f;
	GainHF = 0.89f;
	HFReference = 5000.0f;
	DecayTime = 1.49f;
	DecayHFRatio = 0.83f;
	EarlyReflectionsGain = 0.0375f;		// TODO : See if shouldn't be larger
	EarlyReflectionsDelay = 0.007f;
	Gain = 0.427f;
	LateReverbGain = 0.945f;
	LateReverbDelay = 0.011f;
	AirAbsorptionGainHF = 0.994f;
	DecayHFLimit = true;

	Dry = 1;
	Wet = 0.2f;
	for(int i=0; i<29; i++)
		Name[i] = 0;
}


ReverbHQParameters::~ReverbHQParameters(void)
{
}


bool ReverbHQParameters::loadReverbSettings(vox::FileInterface *pFile)
{
	int size;

	unsigned char header[28];

	size = pFile->Read(header, 1, 28);
	bool valid = true;

	static const char expectedHeader[] = 
	{
		'C', 'c', 'n', 'K', 0, 0, 0, 0x6C,
		'F', 'x', 'C', 'k', 0, 0, 0, 0,
		'h', 'r', '1', 'V', 0, 0, 0, 1,
		0, 0, 0, 15
	};

	for(int i=0; i<4; i++)
		if(header[i] != expectedHeader[i])
			valid = false;

	// Skip version number of bytes - Ableton outputs 0 here for some reason
	for(int i=8; i<12; i++)
		if(header[i] != expectedHeader[i])
			valid = false;


	// Skip version number internal to FXP -we're using the FXB version number instead
	for(int i=16; i<28; i++)
		if(header[i] != expectedHeader[i])
			valid = false;

	if (size != 28 || !valid)
	{
		return false;
	}

	pFile->Read(Name, 1, 28);
	Name[28] = 0;

	float params[15];
	pFile->Read(params, 4, 15);

#if (!VOX_BIG_ENDIAN)
	char *buffer = (char *)params;
	char temp;
	for(int i=0; i<15; i++)
	{
		temp          = buffer[i*4];
		buffer[i*4]   = buffer[i*4+3];
		buffer[i*4+3] = temp;
		temp          = buffer[i*4+1];
		buffer[i*4+1] = buffer[i*4+2];
		buffer[i*4+2] = temp;
	}
#endif

	Density = params[0];
	Diffusion = params[1];
	GainHF = params[2];
	HFReference = (float)(pow(2, params[3]*5) / 32.0 * 24000);
	DecayTime = params[4] * 8;
	DecayHFRatio = params[5];
	DecayHFLimit = params[6] >= 0.5;
	AirAbsorptionGainHF = params[7];
	Gain = params[8];
	EarlyReflectionsGain = params[9];
	EarlyReflectionsDelay = params[10] / 10.0f;
	LateReverbGain = params[11];
	LateReverbDelay = params[12] / 10.0f;
	Dry = params[13];
	Wet = params[14];

	return true;
}

ReverbHQPresetBank::ReverbHQPresetBank()
{
	numPatches = 0;
	patches = 0;
}

ReverbHQPresetBank::~ReverbHQPresetBank()
{
	if(patches)
		VOX_FREE(patches);
}

bool ReverbHQPresetBank::loadBank(const char *filename)
{
	if(patches)
		VOX_FREE(patches);
	patches = 0;
	numPatches = 0;

	vox::FileInterface* pFile = 0;
	
	vox::FileSystemInterface* fs = vox::FileSystemInterface::GetInstance();

	if(fs)
	{
		pFile = fs->OpenFile((vox::c8*)filename);
	}

	bool valid = true;

	if(pFile)
	{
		// Load FXB header
		unsigned char header[28];
		static const char expectedHeader[] = 
		{
			'C', 'c', 'n', 'K', 0, 0, 0, 0,
			'F', 'x', 'B', 'k'
		};

		int size = pFile->Read(header,  1, 28);

		if(size != 28)
			valid = false;

		for(int i=0; i<4; i++)
			if(header[i] != expectedHeader[i])
				valid = false;
		
		for(int i=8; i<12; i++)
			if(header[i] != expectedHeader[i])
				valid = false;
		
		// int chunkSize  = (((header[4] *256 + header[5] )*256 + header[6] )*256 + header[7];
		int fxbVersion = header[12]*16777216 + header[13]*65536 + header[14]*256 + header[15];
		// int revVersion = (((header[20]*256 + header[21])*256 + header[22])*256 + header[23];
		numPatches =     header[24]*16777216 + header[25]*65536 + header[26]*256 + header[27];

		if(fxbVersion < 0 || fxbVersion > 2)
			valid = false;

		if (!valid)
		{
			HQREVERB_VOX_CONSOLE_PRINT(2, "HQReverb: fxb bank read error!\n", 0);
		}

		if(valid)
		{
			pFile->Seek(128, vox::k_nSeekCur);
			patches = (ReverbHQParameters *)VOX_ALLOC(numPatches * sizeof(ReverbHQParameters));

			for(int i=0; i<numPatches; i++)
			{
				patches[i] = ReverbHQParameters();
			}

			if(patches)
			{
				for(int i=0; i<numPatches && valid; i++)
				{
					valid = patches[i].loadReverbSettings(pFile);
				}
				if(!valid)
				{
					HQREVERB_VOX_CONSOLE_PRINT(2, "HQReverb: patch %d invalid! Aborting bank load\n", 0);
					VOX_FREE(patches);
					numPatches = 0;
				}
			}
			else
			{
				numPatches = 0;
				HQREVERB_VOX_CONSOLE_PRINT(2, "HQReverb: Cannot allocate HQReverb Bank (out of ram!)\n", 0);
			}
		}
		fs->CloseFile(pFile);
	}
	else
	{
		HQREVERB_VOX_CONSOLE_PRINT(2, "HQReverb: Could not open HQReverb bank file %s\n", filename);
		valid = false;
	}

	return(valid);
}


bool ReverbHQPresetBank::getPreset(int index, ReverbHQParameters *output)
{
	if(!patches)
	{
		*output = ReverbHQParameters(); // use default patch
		HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb: bank empty or invalid, cannot change patch\n", 0);
		return false;
	}
	if(index  >= numPatches || index < 0)
	{
		*output = ReverbHQParameters(); // use default patch
		HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb: preset index out of range! (%d, number of patches: %d)\n", index, numPatches);
		return false;
	}

	*output = patches[index];
	return true;
}

bool ReverbHQPresetBank::getPresetByName(const char *name, ReverbHQParameters *output)
{
	HQREVERB_VOX_CONSOLE_PRINT(5, "HQReverb: Setting preset %s\n", name);
	if(!patches)
	{
		*output = ReverbHQParameters(); // use default patch
		HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb bank invalid, cannot change patch by name\n", 0);
		return false;
	}

	int index;
	int diff;
	
	for(index = 0; index < numPatches; index++)
	{
		diff = STRICMP(name, patches[index].Name);
		if(diff == 0)
		{
			*output = patches[index];
			return true;
		}
	}
	// Preset not found
	*output = ReverbHQParameters();
	HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb: cannot find preset with the name %s\n", name);
	return false;

}
















// **************************************************************************************** //
// ************************************ ReverbHQC class *********************************** //
// **************************************************************************************** //


ReverbHQC::ReverbHQC()
{
    unsigned int index;

	TotalLength = 0;
    SampleBuffer = 0;

    LpFilter.coeff = 0;
    LpFilter.history[0] = 0;
    LpFilter.history[1] = 0;
    Delay.Mask = 0;
    Delay.Line = 0;

    Tap[0] = 0;
    Tap[1] = 0;
    Tap[2] = 0;
    Tap[3] = 0;
    Tap[4] = 0;

    Early.Gain = 0;
    for(index = 0; index < 4; index++)
    {
        Early.Coeff[index] = 0;
        Early.Delay[index].Mask = 0;
        Early.Delay[index].Line = 0;
        Early.Offset[index] = 0;
    }

    Late.Gain = 0;
    Late.DensityGain = 0;
    Late.ApFeedCoeff = 0;
    Late.MixCoeff = 0;

    for(index = 0; index < 4; index++)
    {
        Late.ApCoeff[index] = 0;
        Late.ApDelay[index].Mask = 0;
        Late.ApDelay[index].Line = 0;
        Late.ApOffset[index] = 0;

        Late.Coeff[index] = 0;
        Late.Delay[index].Mask = 0;
        Late.Delay[index].Line = 0;
        Late.Offset[index] = 0;

        Late.LpCoeff[index] = 0;
        Late.LpSample[index] = 0;
    }


    Offset = 0;

	TailCounter = 0;

	ReverbHQParameters defaultParameters;
	SetParameters(&defaultParameters, 0.0f);

	
}

// Connect to bus can be run multiple times!
bool ReverbHQC::ConnectToBus(float sampleRate, int channels, int specialFlags)
{
	m_sampleRate = sampleRate;
	if(channels != 2)
		return false;
	if(specialFlags)
		return false;
	
	if(!SampleBuffer)
		CreateDelayLines();
	
	return true;
}


ReverbHQC::~ReverbHQC(void)
{	
	if(SampleBuffer)
	{
        delete [] SampleBuffer;
        SampleBuffer = 0;
    }
}


unsigned int ReverbHQC::CalcLengths(unsigned int length[13], float frequency)
{
    unsigned int samples, totalLength, index;

    // All line lengths are powers of 2, calculated from their lengths, with
    // an additional sample in case of rounding errors.

    // See VerbUpdate() for an explanation of the additional calculation
    // added to the master line length.
    samples = (unsigned int)
              ((MASTER_LINE_LENGTH +
                (LATE_LINE_LENGTH[0] * (1.0f + LATE_LINE_MULTIPLIER) *
                 (DECO_FRACTION * DECO_MULTIPLIER_TOTAL))) *
               frequency) + 10; // Extra samples in case it rounds the wrong way!
    length[0] = NextPowerOf2(samples);
    totalLength = length[0];
    for(index = 0;index < 4;index++)
    {
        samples = (unsigned int)(EARLY_LINE_LENGTH[index] * frequency) + 1;
        length[1 + index] = NextPowerOf2(samples);
        totalLength += length[1 + index];
    }
    for(index = 0;index < 4;index++)
    {
        samples = (unsigned int)(ALLPASS_LINE_LENGTH[index] * frequency) + 1;
        length[5 + index] = NextPowerOf2(samples);
        totalLength += length[5 + index];
    }
    for(index = 0;index < 4;index++)
    {
        samples = (unsigned int)(LATE_LINE_LENGTH[index] *
                           (1.0f + LATE_LINE_MULTIPLIER) * frequency) + 1;
        length[9 + index] = NextPowerOf2(samples);
        totalLength += length[9 + index];
    }

    return totalLength;
}

// This updates the device-dependant reverb state.  This is called on initialization and any time
// the device parameters (eg. playback frequency, format) have been changed.

void ReverbHQC::CreateDelayLines(void)
{
    unsigned int length[13], totalLength;
    unsigned int index;

    totalLength = CalcLengths(length, m_sampleRate);
    if(totalLength != TotalLength)
	{        
        SampleBuffer = new int[totalLength];
		if(!SampleBuffer)
		{
			HQREVERB_VOX_CONSOLE_PRINT(2, "HQReverb: Out of memory for reverb delay buffer!\n",0);
		}
		if(!SampleBuffer)
		{
			HQREVERB_VOX_CONSOLE_PRINT(2, "HQReverb: Out of memory for reverb delay buffer!\n",0);
		}
        TotalLength = totalLength;

        // All lines share a single sample buffer
        Delay.Mask = length[0] - 1;
        Delay.Line = &SampleBuffer[0];
        totalLength = length[0];
        for(index = 0; index < 4; index++)
        {
            Early.Delay[index].Mask = length[1 + index] - 1;
            Early.Delay[index].Line = &SampleBuffer[totalLength];
            totalLength += length[1 + index];
        }
        for(index = 0; index < 4; index++)
        {
            Late.ApDelay[index].Mask = length[5 + index] - 1;
            Late.ApDelay[index].Line = &SampleBuffer[totalLength];
            totalLength += length[5 + index];
        }
        for(index = 0; index < 4; index++)
        {
            Late.Delay[index].Mask = length[9 + index] - 1;
            Late.Delay[index].Line = &SampleBuffer[totalLength];
            totalLength += length[9 + index];
        }
    }

    for(index = 0; index < 4; index++)
    {
        Early.Offset[index] = (unsigned int)((EARLY_LINE_LENGTH[index] * m_sampleRate));
        Late.ApOffset[index] = (unsigned int)(ALLPASS_LINE_LENGTH[index] * m_sampleRate);
    }

	if(SampleBuffer)
	{
		for(index = 0; index < TotalLength; index++)
		{
			SampleBuffer[index] = 0;
		}
	}
}


void ReverbHQC::_SetParameters(ReverbHQParameters *parameters)
{    
    unsigned int index;
    float length, mixCoeff, cw, g, coeff;
    float hfRatio = parameters->DecayHFRatio;

    // Calculate the master low-pass filter (from the master effect HF gain).
    cw = cos(2.0f * VOX_HQREVERB_PI * parameters->HFReference / m_sampleRate);
	g = parameters->GainHF;
	if(g < 0.0001f)
	{
		g = 0.0001f;
	}
    LpFilter.coeff = 0;
    if(g < 0.9999f) // 1-epsilon
	{
		LpFilter.coeff = static_cast<int> (((1 - g*cw - sqrtf(2*g*(1-cw) - g*g*(1 - cw*cw))) / (1 - g)) * VOX_FX1814_ONE);
	}

    // Calculate the initial delay taps.
    length = parameters->EarlyReflectionsDelay;
    Tap[0] = (unsigned int)(length * m_sampleRate);

    length += parameters->LateReverbDelay;

    // * The four inputs to the late reverb are decorrelated to smooth the
    // * initial reverb and reduce harsh echos.  The timings are calculated as
    // * multiples of a fraction of the smallest cyclical delay time. This
    // * result is then adjusted so that the first tap occurs immediately (all
    // * taps are reduced by the shortest fraction).
    // *
    // * offset[index] = ((FRACTION MULTIPLIER^index) - 1) delay
    // *
    for(index = 0;index < 4;index++)
    {
        length += LATE_LINE_LENGTH[0] *
            (1.0f + (parameters->Density * LATE_LINE_MULTIPLIER)) *
            (DECO_FRACTION * (pow(DECO_MULTIPLIER, (float)index) - 1.0f));
        Tap[1 + index] = (unsigned int)(length * m_sampleRate);
    }

    // Calculate the early reflections gain (from the master effect gain, and reflections gain parameters).
    Early.Gain = static_cast<int> (parameters->Gain * parameters->EarlyReflectionsGain * 0x1000);

    // Calculate the gain (coefficient) for each early delay line.
    for(index = 0;index < 4;index++)
	{
        Early.Coeff[index] = static_cast<int> (pow(2.0f, EARLY_LINE_LENGTH[index] / parameters->LateReverbDelay * (-9.9657f)) * VOX_FX1814_ONE);
	}

    // Calculate the first mixing matrix coefficient (x).
    mixCoeff = 1.0f - (0.5f * pow(parameters->Diffusion, 3.0f));

    // Calculate the late reverb gain (from the master effect gain, and late
    // reverb gain parameters).  Since the output is tapped prior to the
    // application of the delay line coefficients, this gain needs to be
    // attenuated by the 'x' mix coefficient from above.
    Late.Gain = static_cast<int> (parameters->Gain * 0x1000);
	Late.Gain *= static_cast<int> (parameters->LateReverbGain * VOX_FX1814_ONE);
	Late.Gain >>= VOX_FX1814_FRACT_SHIFT;
	Late.Gain *= static_cast<int> (mixCoeff * VOX_FX1814_ONE);
	Late.Gain >>= VOX_FX1814_FRACT_SHIFT;

    // * To compensate for changes in modal density and decay time of the late
    // * reverb signal, the input is attenuated based on the maximal energy of
    // * the outgoing signal.  This is calculated as the ratio between a
    // * reference value and the current approximation of energy for the output
    // * signal.
    // *
    // * Reverb output matches exponential decay of the form Sum(a^n), where a
    // * is the attenuation coefficient, and n is the sample ranging from 0 to
    // * infinity.  The signal energy can thus be approximated using the area
    // * under this curve, calculated as:  1 / (1 - a).
    // *
    // * The reference energy is calculated from a signal at the lowest (effect
    // * at 1.0) density with a decay time of one second.
    // *
    // * The coefficient is calculated as the average length of the cyclical
    // * delay lines.  This produces a better result than calculating the gain
    // * for each line individually (most likely a side effect of diffusion).
    // *
    // * The final result is the square root of the ratio bound to a maximum
    // * value of 1 (no amplification).
    // *
    length = (LATE_LINE_LENGTH[0] + LATE_LINE_LENGTH[1] +
              LATE_LINE_LENGTH[2] + LATE_LINE_LENGTH[3]);
    g = length * (1.0f + LATE_LINE_MULTIPLIER) * 0.25f;
    g = pow(10.0f, g * -60.0f / 20.0f);
    g = 1.0f / (1.0f - (g * g));
    length *= 1.0f + (parameters->Density * LATE_LINE_MULTIPLIER) * 0.25f;
    length = pow(10.0f, length / parameters->DecayTime * -60.0f / 20.0f);
    length = 1.0f / (1.0f - (length * length));
    Late.DensityGain = static_cast<int> (sqrtf(g / length) * VOX_FX1814_ONE);
	if(Late.DensityGain > VOX_FX1814_ONE)
	{
		Late.DensityGain = VOX_FX1814_ONE;
	}

    // Calculate the all-pass feed-back and feed-forward coefficient.
    Late.ApFeedCoeff = static_cast<int> (0.6f * pow(parameters->Diffusion, 3.0f) * 0x1000);

    // Calculate the mixing matrix coefficient (y / x).
    g = sqrtf((1.0f - (mixCoeff * mixCoeff)) / 3.0f);
    Late.MixCoeff = static_cast<int> ((g / mixCoeff) * 0x800);

    for(index = 0;index < 4;index++)
    {
        // Calculate the gain (coefficient) for each all-pass line.
        Late.ApCoeff[index] = static_cast<int> (pow(10.0f, ALLPASS_LINE_LENGTH[index] /
                                                parameters->DecayTime *
                                                -60.0f / 20.0f) * 0x1000);
    }

    // If the HF limit parameter is flagged, calculate an appropriate limit
    // based on the air absorption parameter.
    if(parameters->DecayHFLimit && parameters->AirAbsorptionGainHF < 1.0f)
    {
        float limitRatio;

        // For each of the cyclical delays, find the attenuation due to air
        // absorption in dB (converting delay time to meters using the speed
        // of sound).  Then reversing the decay equation, solve for HF ratio.
        // The delay length is cancelled out of the equation, so it can be
        // calculated once for all lines.
        limitRatio = 1.0f / (log10(parameters->AirAbsorptionGainHF) *
                             VOX_HQREVERB_SPEEDOFSOUNDMETRESPERSEC *
                             parameters->DecayTime / -60.0f * 20.0f);
        // Need to limit the result to a minimum of 0.1, just like the HF ratio parameter.
        if(limitRatio < 0.1f)
		{
			limitRatio = 0.1f;
		}

        // Using the limit calculated above, apply the upper bound to the HF ratio.
		if(hfRatio > limitRatio)
		{
			hfRatio = limitRatio;
		}
    }

    // Calculate the low-pass filter frequency.
    cw = cos(2.0f * VOX_HQREVERB_PI * parameters->HFReference / m_sampleRate);

    for(index = 0;index < 4;index++)
    {
        // Calculate the length (in seconds) of each cyclical delay line.
        length = LATE_LINE_LENGTH[index] * (1.0f + (parameters->Density * LATE_LINE_MULTIPLIER));

        // Calculate the delay offset for the cyclical delay lines.
        Late.Offset[index] = (unsigned int)(length * m_sampleRate);

        // Calculate the gain (coefficient) for each cyclical line.
        Late.Coeff[index] = static_cast<int> (pow(10.0f, length / parameters->DecayTime * -60.0f / 20.0f) * 0x1000);

        // Eventually this should boost the high frequencies when the ratio exceeds 1.
        coeff = 0.0f;
        if (hfRatio < 1.0f)
        {
            // Calculate the decay equation for each low-pass filter.
            g = pow(10.0f, length / (parameters->DecayTime * hfRatio) * -60.0f / 20.0f);
			g /=  (static_cast<float> (Late.Coeff[index]) / static_cast<float> (VOX_FX1814_ONE));
			if(g < 0.1f)
			{
				g  = 0.1f;
			}
            g *= g;

            // Calculate the gain (coefficient) for each low-pass filter.
            if(g < 0.9999f) // 1-epsilon
			{
                coeff = (1 - g*cw - sqrtf(2*g*(1-cw) - g*g*(1 - cw*cw))) / (1 - g);
			}

            // Very low decay times will produce minimal output, so apply an
            // upper bound to the coefficient.
            if(coeff > 0.98f)
			{
				coeff = 0.98f;
			}
        }
		
		Late.LpCoeff[index] = static_cast<int> (coeff * 0x1000);
		
        // Attenuate the cyclical line coefficients by the mixing coefficient (x).
        Late.Coeff[index] *= static_cast<int> (mixCoeff * VOX_FX1814_ONE);
		Late.Coeff[index] >>= VOX_FX1814_FRACT_SHIFT;
    }

	DryMix = static_cast<int> (parameters->Dry * 0x1000);
	WetMix = static_cast<int> (parameters->Wet * 0x1000);

}


void ReverbHQC::SetParameters(ReverbHQParameters *parameters, float fadeTime)
{
	vox::ScopeMutex sm(&m_mutex);
	if(fadeTime > 0.0f)
	{
		float minFadeTime;

		minFadeTime = fabs(m_paramFaders.Density.GetCurrentValue() - parameters->Density);
		minFadeTime *= 50;
		if(fadeTime > minFadeTime)
			minFadeTime = fadeTime;
		m_paramFaders.Density = vox::Fader(m_paramFaders.Density.GetCurrentValue(), parameters->Density, minFadeTime);
		m_paramFaders.Diffusion = vox::Fader(m_paramFaders.Diffusion.GetCurrentValue(), parameters->Diffusion, fadeTime);
		m_paramFaders.GainHF = vox::Fader(m_paramFaders.GainHF.GetCurrentValue(), parameters->GainHF, fadeTime);
		m_paramFaders.HFReference = vox::Fader(m_paramFaders.HFReference.GetCurrentValue(), parameters->HFReference, fadeTime);
		m_paramFaders.DecayTime = vox::Fader(m_paramFaders.DecayTime.GetCurrentValue(), parameters->DecayTime, fadeTime);
		m_paramFaders.DecayHFRatio = vox::Fader(m_paramFaders.DecayHFRatio.GetCurrentValue(), parameters->DecayHFRatio, fadeTime);
		m_paramFaders.AirAbsorptionGainHF = vox::Fader(m_paramFaders.AirAbsorptionGainHF.GetCurrentValue(), parameters->AirAbsorptionGainHF, fadeTime);

		m_paramFaders.Gain = vox::Fader(m_paramFaders.Gain.GetCurrentValue(), parameters->Gain, fadeTime);
		m_paramFaders.EarlyReflectionsGain = vox::Fader(m_paramFaders.EarlyReflectionsGain.GetCurrentValue(), parameters->EarlyReflectionsGain, fadeTime);
		minFadeTime = fabs(m_paramFaders.EarlyReflectionsDelay.GetCurrentValue() - parameters->EarlyReflectionsDelay);
		minFadeTime *= 200;
		if(fadeTime > minFadeTime)
			minFadeTime = fadeTime;
		m_paramFaders.EarlyReflectionsDelay = vox::Fader(m_paramFaders.EarlyReflectionsDelay.GetCurrentValue(), parameters->EarlyReflectionsDelay, minFadeTime);
		m_paramFaders.LateReverbGain = vox::Fader(m_paramFaders.LateReverbGain.GetCurrentValue(), parameters->LateReverbGain, fadeTime);
		minFadeTime = fabs(m_paramFaders.LateReverbDelay.GetCurrentValue() - parameters->LateReverbDelay);
		minFadeTime *= 200;
		if(fadeTime > minFadeTime)
			minFadeTime = fadeTime;
		m_paramFaders.LateReverbDelay = vox::Fader(m_paramFaders.LateReverbDelay.GetCurrentValue(), parameters->LateReverbDelay, minFadeTime);
	
		m_paramFaders.Dry = vox::Fader(m_paramFaders.Dry.GetCurrentValue(), parameters->Dry, fadeTime);
		m_paramFaders.Wet = vox::Fader(m_paramFaders.Wet.GetCurrentValue(), parameters->Wet, fadeTime);
	}
	else
	{
		m_paramFaders.Density = vox::Fader(parameters->Density, parameters->Density, 0.0f);
		m_paramFaders.Diffusion = vox::Fader(parameters->Diffusion, parameters->Diffusion, 0.0f);
		m_paramFaders.GainHF = vox::Fader(parameters->GainHF, parameters->GainHF, 0.0f);
		m_paramFaders.HFReference = vox::Fader(parameters->HFReference, parameters->HFReference, 0.0f);
		m_paramFaders.DecayTime = vox::Fader(parameters->DecayTime, parameters->DecayTime, 0.0f);
		m_paramFaders.DecayHFRatio = vox::Fader(parameters->DecayHFRatio, parameters->DecayHFRatio, 0.0f);
		m_paramFaders.AirAbsorptionGainHF = vox::Fader(parameters->AirAbsorptionGainHF, parameters->AirAbsorptionGainHF, 0.0f);
		m_paramFaders.Gain = vox::Fader(parameters->Gain, parameters->Gain, 0.0f);
		m_paramFaders.EarlyReflectionsGain = vox::Fader(parameters->EarlyReflectionsGain, parameters->EarlyReflectionsGain, 0.0f);
		m_paramFaders.EarlyReflectionsDelay = vox::Fader(parameters->EarlyReflectionsDelay, parameters->EarlyReflectionsDelay, 0.0f);
		m_paramFaders.LateReverbGain = vox::Fader(parameters->LateReverbGain, parameters->LateReverbGain, 0.0f);
		m_paramFaders.LateReverbDelay = vox::Fader(parameters->LateReverbDelay, parameters->LateReverbDelay, 0.0f);

		m_paramFaders.Dry = vox::Fader(parameters->Dry, parameters->Dry, 0.0f);
		m_paramFaders.Wet = vox::Fader(parameters->Wet, parameters->Wet, 0.0f);
	}
}

void ReverbHQC::UpdateParameters(float dt)
{
	ReverbHQParameters parameters;

	vox::ScopeMutex sm(&m_mutex);
	if( !m_paramFaders.Diffusion.IsFinished() ||
		!m_paramFaders.Density.IsFinished() ||
		!m_paramFaders.EarlyReflectionsDelay.IsFinished() ||
		!m_paramFaders.LateReverbDelay.IsFinished() )
	{
		m_paramFaders.Density.Update(dt);
		parameters.Density = m_paramFaders.Density.GetCurrentValue();
		
		m_paramFaders.Diffusion.Update(dt);
		parameters.Diffusion = m_paramFaders.Diffusion.GetCurrentValue();

		m_paramFaders.GainHF.Update(dt);
		parameters.GainHF = m_paramFaders.GainHF.GetCurrentValue();

		m_paramFaders.HFReference.Update(dt);
		parameters.HFReference = m_paramFaders.HFReference.GetCurrentValue();

		m_paramFaders.DecayTime.Update(dt);
		parameters.DecayTime = m_paramFaders.DecayTime.GetCurrentValue();

		m_paramFaders.DecayHFRatio.Update(dt);
		parameters.DecayHFRatio = m_paramFaders.DecayHFRatio.GetCurrentValue();

		m_paramFaders.AirAbsorptionGainHF.Update(dt);
		parameters.AirAbsorptionGainHF = m_paramFaders.AirAbsorptionGainHF.GetCurrentValue();

		m_paramFaders.Gain.Update(dt);
		parameters.Gain = m_paramFaders.Gain.GetCurrentValue();

		m_paramFaders.EarlyReflectionsGain.Update(dt);
		parameters.EarlyReflectionsGain = m_paramFaders.EarlyReflectionsGain.GetCurrentValue();

		m_paramFaders.EarlyReflectionsDelay.Update(dt);
		parameters.EarlyReflectionsDelay = m_paramFaders.EarlyReflectionsDelay.GetCurrentValue();

		m_paramFaders.LateReverbGain.Update(dt);
		parameters.LateReverbGain = m_paramFaders.LateReverbGain.GetCurrentValue();

		m_paramFaders.LateReverbDelay.Update(dt);
		parameters.LateReverbDelay = m_paramFaders.LateReverbDelay.GetCurrentValue();


		m_paramFaders.Dry.Update(dt);
		parameters.Dry = m_paramFaders.Dry.GetCurrentValue();

		m_paramFaders.Wet.Update(dt);
		parameters.Wet = m_paramFaders.Wet.GetCurrentValue();


		_SetParameters(&parameters);
	}
}


bool ReverbHQC::LoadParameterBank(const char *filename)
{
	return m_paramBank.loadBank(filename);
}

// Deprecated - please set presets by name
//
//bool ReverbHQC::SetBankPreset(int index, float fadeTime)
//{
//	bool value;
//	ReverbHQParameters param;
//	value = m_paramBank.getPreset(index, &param);
//	SetParameters(&param, fadeTime);
//	return value;
//}
//

bool ReverbHQC::SetBankPresetByName(const char *name, float fadeTime)
{
	bool value;
	ReverbHQParameters param;
	value = m_paramBank.getPresetByName(name, &param);
	SetParameters(&param, fadeTime);
	return value;
}


// Delay line output routine for early reflections.
int ReverbHQC::EarlyDelayLineOut(unsigned int index)
{
    return ((Early.Coeff[index] * DelayLineOut(&Early.Delay[index], Offset - Early.Offset[index])) >> VOX_FX1814_FRACT_SHIFT);
}


// Given an input sample, this function produces stereo output for early reflections.
void ReverbHQC::EarlyReflection(int in, int *out)
{
    int d[4], v, f[4];

    // Obtain the decayed results of each early delay line.
    d[0] = EarlyDelayLineOut(0);
    d[1] = EarlyDelayLineOut(1);
    d[2] = EarlyDelayLineOut(2);
    d[3] = EarlyDelayLineOut(3);

    // * The following uses a lossless scattering junction from waveguide
    // * theory.  It actually amounts to a householder mixing matrix, which
    // * will produce a maximally diffuse response, and means this can probably
    // * be considered a simple feedback delay network (FDN).
    // *          N
    // *         ---
    // *         \
    // * v = 2/N /   d_i
    // *         ---
    // *         i=1
    // *
    v = (d[0] + d[1] + d[2] + d[3]) >> 1;
    // The junction is loaded with the input here.
    v += in;

    // Calculate the feed values for the delay lines.
    f[0] = v - d[0];
    f[1] = v - d[1];
    f[2] = v - d[2];
    f[3] = v - d[3];

    // Refeed the delay lines.
    DelayLineIn(&Early.Delay[0], Offset, f[0]);
    DelayLineIn(&Early.Delay[1], Offset, f[1]);
    DelayLineIn(&Early.Delay[2], Offset, f[2]);
    DelayLineIn(&Early.Delay[3], Offset, f[3]);

    // Output the results of the junction for all four lines.
    out[0] = f[0]; //(Early.Gain * f[0]) >> VOX_FX1814_FRACT_SHIFT;
    out[1] = f[1]; //(Early.Gain * f[1]) >> VOX_FX1814_FRACT_SHIFT;
    out[2] = f[2]; //(Early.Gain * f[2]) >> VOX_FX1814_FRACT_SHIFT;
    out[3] = f[3]; //(Early.Gain * f[3]) >> VOX_FX1814_FRACT_SHIFT;
}


int ReverbHQC::LateAllPassInOut(unsigned int index, int in)
{
    int out;

    out = (Late.ApCoeff[index] *
		   DelayLineOut(&Late.ApDelay[index], Offset - Late.ApOffset[index])) >> 12;
    out -= (Late.ApFeedCoeff * in) >> 12;
    DelayLineIn(&Late.ApDelay[index], Offset, ((Late.ApFeedCoeff * out) >> 12) + in);
    return out;
}


// Delay line output routine for late reverb.
int ReverbHQC::LateDelayLineOut(unsigned int index)
{
    return (Late.Coeff[index] * DelayLineOut(&Late.Delay[index], Offset - Late.Offset[index])) >> 12;
}


// Low-pass filter input/output routine for late reverb.
int ReverbHQC::LateLowPassInOut(unsigned int index, int in)
{
    Late.LpSample[index] = in + (((Late.LpSample[index] - in) * Late.LpCoeff[index]) >> 12);
    return Late.LpSample[index];
}



int ReverbHQC::lpFilter2P(ReverbFilter *iir, unsigned int offset, int input)
{
	int *history = &iir->history[offset];
		
	history[0] = input + (((history[0]-input) * iir->coeff) >> VOX_FX1814_FRACT_SHIFT);
	history[1] = history[0] + (((history[1]-history[0]) * iir->coeff) >> VOX_FX1814_FRACT_SHIFT);
		
	return history[1];
}


void ReverbHQC::DelayLineIn(DelayLine *Delay, unsigned int offset, int in)
{
    Delay->Line[offset&Delay->Mask] = in;
}


// Basic delay line input/output routines.
int ReverbHQC::DelayLineOut(DelayLine *Delay, unsigned int offset)
{
    return Delay->Line[offset&Delay->Mask];
}



// Fixed-point implementation
void ReverbHQC::Update(const int *input, int *output, int nbSamples)
{
	int early[4], taps[4];
	const int *inputBufferCursor = input;
	const int *inputBufferEnd = inputBufferCursor + (nbSamples << 1);
	int *outputBufferCursor = output;
	DelayLine *delayLine = &Delay;
	unsigned int cursor;
	int d[4], f[4];

	// Update reverb parameters
	float dt = (float) nbSamples / m_sampleRate;
	UpdateParameters(dt);

	if(!SampleBuffer) // No delay buffers -> reverb effect impossible
	{
		memset(output, 0, nbSamples * sizeof(int) );
		return;
	}

	if(TailCounter > 1) // Signal is coming in, set the counter at 1
		TailCounter = 1;
	else
	{
		TailCounter -= (nbSamples / m_sampleRate) / GetTailDecayTime();
		if(TailCounter < 0)
			TailCounter = 0;
	}


    while(inputBufferCursor < inputBufferEnd)
	{	
		cursor = Offset;

		// Low-pass filter the incoming (left+right) sample and put it in the initial delay line.	
		DelayLineIn(delayLine, cursor, lpFilter2P(&LpFilter, 0, inputBufferCursor[0] + inputBufferCursor[1]));

		// Calculate the early reflection from the first delay tap.
		EarlyReflection(DelayLineOut(delayLine, cursor - Tap[0]), early);

		// Calculate the late reverb from the last four delay taps.
		taps[0] = DelayLineOut(delayLine, cursor - Tap[1]);
		taps[1] = DelayLineOut(delayLine, cursor - Tap[2]);
		taps[2] = DelayLineOut(delayLine, cursor - Tap[3]);
		taps[3] = DelayLineOut(delayLine, cursor - Tap[4]);

		// *************************** Late reverb section ***************************** //
    
		// Obtain the decayed results of the cyclical delay lines, and add the corresponding input channels
		// attenuated by density. Then pass the results through the low-pass filters.
		d[0] = LateLowPassInOut(0, ((Late.DensityGain * taps[0]) >> VOX_FX1814_FRACT_SHIFT) + LateDelayLineOut(0));
		d[1] = LateLowPassInOut(1, ((Late.DensityGain * taps[1]) >> VOX_FX1814_FRACT_SHIFT) + LateDelayLineOut(1));
		d[2] = LateLowPassInOut(2, ((Late.DensityGain * taps[2]) >> VOX_FX1814_FRACT_SHIFT) + LateDelayLineOut(2));
		d[3] = LateLowPassInOut(3, ((Late.DensityGain * taps[3]) >> VOX_FX1814_FRACT_SHIFT) + LateDelayLineOut(3));

		// To help increase diffusion, run each line through an all-pass filter. The order of the all-pass
		// filters is selected so that the shortest all-pass filter will feed the shortest delay line.
		d[0] = LateAllPassInOut(1, d[0]);
		d[1] = LateAllPassInOut(3, d[1]);
		d[2] = LateAllPassInOut(0, d[2]);
		d[3] = LateAllPassInOut(2, d[3]);

		// * Late reverb is done with a modified feedback delay network (FDN)
		// * topology.  Four input lines are each fed through their own all-pass
		// * filter and then into the mixing matrix.  The four outputs of the
		// * mixing matrix are then cycled back to the inputs.  Each output feeds
		// * a different input to form a circular feed cycle.
		// *
		// * The mixing matrix used is a 4D skew-symmetric rotation matrix derived
		// * using a single unitary rotational parameter:
		// *
		// *  [  d,  a,  b,  c ]          1 = a^2 + b^2 + c^2 + d^2
		// *  [ -a,  d,  c, -b ]
		// *  [ -b, -c,  d,  a ]
		// *  [ -c,  b, -a,  d ]
		// *
		// * The rotation is constructed from the effect's diffusion parameter,
		// * yielding:  1 = x^2 + 3 y^2; where a, b, and c are the coefficient y
		// * with differing signs, and d is the coefficient x.  The matrix is thus:
		// *
		// *  [  x,  y, -y,  y ]          x = 1 - (0.5 diffusion^3)
		// *  [ -y,  x,  y,  y ]          y = sqrt((1 - x^2) / 3)
		// *  [  y, -y,  x,  y ]
		// *  [ -y, -y, -y,  x ]
		// *
		// * To reduce the number of multiplies, the x coefficient is applied with
		// * the cyclical delay line coefficients.  Thus only the y coefficient is
		// * applied when mixing, and is modified to be:  y / x.
		// *

		f[0] = d[0] + ((Late.MixCoeff * ( d[1] - d[2] + d[3])) >> 11);
		f[1] = d[1] + ((Late.MixCoeff * (-d[0] + d[2] + d[3])) >> 11);
		f[2] = d[2] + ((Late.MixCoeff * ( d[0] - d[1] + d[3])) >> 11);
		f[3] = d[3] + ((Late.MixCoeff * (-d[0] - d[1] - d[2])) >> 11);

		// The delay lines are fed circularly in the order: 0 -> 1 -> 3 -> 2 -> 0 ...
		DelayLineIn(&Late.Delay[0], Offset, f[2]);
		DelayLineIn(&Late.Delay[1], Offset, f[0]);
		DelayLineIn(&Late.Delay[2], Offset, f[3]);
		DelayLineIn(&Late.Delay[3], Offset, f[1]);

		// ************************** End of late reverb section *********************** //

		// Step all delays forward one sample.
		Offset++;

		// Mix early reflections and late reverb for left channel.
		*outputBufferCursor = (DryMix * (inputBufferCursor[0])
		                    +  WetMix * ((Early.Gain * early[0] + Late.Gain * f[0]) >> 12))
							>> 12;

		outputBufferCursor++;
     
		// Mix early reflections and late reverb for right channel.
		*outputBufferCursor = (DryMix * (inputBufferCursor[1])
		                    +  WetMix * ((Early.Gain * early[1] + Late.Gain * f[1]) >> 12))
							>> 12;

		outputBufferCursor++;

		// Increment input cursor from two samples (since buffer is stereo)
		inputBufferCursor += 2;
    }

}



float ReverbHQC::GetTailDecayTime()
{
	float decayTime = m_paramFaders.DecayTime.GetCurrentValue();
	if(decayTime > 0)
		return 0.5f + decayTime * 1.6f;
	else
		return 0.5f;
}

bool ReverbHQC::WillOutput(bool hasInput)
{
	if(hasInput)
	{
		TailCounter = 2; // This signals that signal is coming in.
		return true;
	}
	else
	{
		if(TailCounter > 0) // Starts at 1 when input stops, goes down to 0
			return true;
		else
			return false;
	}
}



ReverbHQ::ReverbHQ()
{
	reverbC = new ReverbHQC;
	if(!reverbC)
	{
		HQREVERB_VOX_CONSOLE_PRINT(2, "HQReverb: Out of memory! Cannot instanciate HQReverb!\n", 0);
	}
#if VOX_NEON_HQREVERB
	else
	{
		reverbNeon = new ReverbHQNeon;
		if(!reverbNeon)
			HQREVERB_VOX_CONSOLE_PRINT(2, "HQReverb: Out of memory! Can only partially instanciate HQReverb!\n", 0);
	}
#else //VOX_NEON_HQREVERB
	reverbNeon = 0;
#endif //VOX_NEON_HQREVERB
}

ReverbHQ::~ReverbHQ(void)
{
#if VOX_NEON_HQREVERB
	if (reverbNeon)
		delete reverbNeon;
#endif
	if (reverbC)
		delete reverbC;
}

bool ReverbHQ::ConnectToBus(float sampleRate, int channels, int flags)
{
	// Give warning if block subdivide set to a wrong value
#if (VOX_HQREVERB_BLOCK_SUBDIVIDE & 0xf) 
	HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb: Block subdivide must be set to a multiple of 16, value will be rounded to %d\n", ((VOX_HQREVERB_BLOCK_SUBDIVIDE - 1) | 0xf) + 1 );
#endif
#if VOX_NEON_HQREVERB
	if(reverbC && reverbNeon)
	{
		bool useNeon = neonInstructionsPresent();

		if(useNeon)
		{
			if(reverbC)
				delete reverbC;
			reverbC = 0;
		}
		else
		{
			if(reverbNeon)
				delete reverbNeon;
			reverbNeon = 0;
		}
	}

	if(reverbNeon)
		return reverbNeon->ConnectToBus(sampleRate, channels, flags);
	else
#endif // VOX_NEON_HQREVERB
	if (reverbC)
		return reverbC->ConnectToBus(sampleRate, channels, flags);
	else
	{
		HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb: Missing HQReverb, cannot connect.\n", 0);
		return false;
	}
}


void ReverbHQ::Update(const int *input, int *output, int nbSamples)
{
    
	while(nbSamples > 0)
	{
		int samplesTodo = nbSamples;
#if (VOX_HQREVERB_BLOCK_SUBDIVIDE != 0)
		int roundedBlockSize = ((VOX_HQREVERB_BLOCK_SUBDIVIDE - 1) | 0xf) + 1;
		if(samplesTodo > roundedBlockSize)
			samplesTodo = roundedBlockSize;
#endif


#if VOX_NEON_HQREVERB    
		if(reverbNeon)
			reverbNeon->Update(input, output, samplesTodo);
		else
#endif
		if (reverbC)
			reverbC->Update(input, output, samplesTodo);


		input     += samplesTodo<<1;
		output    += samplesTodo<<1;
		nbSamples -= samplesTodo;
	}


}

bool ReverbHQ::WillOutput(bool hasInput)
{
#if VOX_NEON_HQREVERB    
	if(reverbNeon)
		return reverbNeon->WillOutput(hasInput);
	else
#endif
	if (reverbC)
		return reverbC->WillOutput(hasInput);
	else
	{
		return false;
	}

}

void ReverbHQ::SetParameters(ReverbHQParameters *parameters, float fadeTime)
{
#if VOX_NEON_HQREVERB    
	if(reverbNeon)
		reverbNeon->SetParameters(parameters, fadeTime);
#endif
	if (reverbC)
		reverbC->SetParameters(parameters, fadeTime);
	if(!reverbNeon && !reverbC)
	{
		HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb: Missing HQReverb, impossible to change parameters.\n", 0);
	}
}

bool ReverbHQ::LoadParameterBank(const char *filename)
{
	bool result = true;
#if VOX_NEON_HQREVERB    
	if(reverbNeon)
		result = result && reverbNeon->LoadParameterBank(filename);
#endif
	if (reverbC)
		result = result && reverbC->LoadParameterBank(filename);
	if(!reverbNeon && !reverbC)
	{
		HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb: Missing HQReverb, impossible to load parameter bank.\n", 0);
		result = false;
	}

	return result;
}

bool ReverbHQ::SetBankPresetByName(const char *name, float fadeTime)
{
	bool result = true;
#if VOX_NEON_HQREVERB    
	if(reverbNeon)
		result = result && reverbNeon->SetBankPresetByName(name, fadeTime);
#endif    
	if (reverbC)
		result = result && reverbC->SetBankPresetByName(name, fadeTime);
	if(!reverbNeon && !reverbC)
	{
		HQREVERB_VOX_CONSOLE_PRINT(3, "HQReverb: Missing HQReverb, impossible to load preset.\n", 0);
		result = false;
	}

	return result;
}


} // namespace vox

