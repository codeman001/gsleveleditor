
// HQ Reverb config file - should be /vox_config/hq_reverb/hq_reverb_config.h
// You must run /vox/Plugins/hq_reverb/setup.bat to copy the template in the right place

// For available options, see hq_reverb_internal.h
// Put your options here:

// 
