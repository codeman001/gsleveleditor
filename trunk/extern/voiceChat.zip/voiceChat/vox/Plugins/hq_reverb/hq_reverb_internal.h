#pragma once
#ifndef _CUSTOM_DSP_INTERNAL_H_
#define _CUSTOM_DSP_INTERNAL_H_

#include "hq_reverb.h"



#include <math.h>
#include "vox_filesystem.h"
#include "vox_detect_neon.h"
#include "vox_fader.h"
#include "vox_mutex.h"

// you must run vox/Plugins/hq_reverb/setup.bat
#include "../../vox_config/hq_reverb/hq_reverb_config.h"


// Must enable this to get debug warnings
#if HQREVERB_VOX_CONSOLE_ENABLE
#include <stdarg.h>
#include "vox_console.h"
#define HQREVERB_VOX_CONSOLE_PRINT   Console::PrintStatic
#else
#define HQREVERB_VOX_CONSOLE_PRINT(...)
#endif

// Must be a multiple of 16
// Cpu usage increases if this is too short (especially on ARM)
// Makes transition from one preset to another smoother
#ifndef VOX_HQREVERB_BLOCK_SUBDIVIDE
#define VOX_HQREVERB_BLOCK_SUBDIVIDE 128
#endif

// Turns off assembly optimized version of reverb (only available on ARM)
// Multiplies CPU usage by about 5x (from 1% to about 5%)
// Only change this if you have a bug in the asm optimized reverb
#ifndef VOX_USE_NEON_HQREVERB
#define VOX_USE_NEON_HQREVERB 1
#endif

#if defined(__ARM_NEON__)
	#if VOX_USE_NEON_HQREVERB
	#define VOX_NEON_HQREVERB 1
	#else
	#define VOX_NEON_HQREVERB 0
	#endif
#else
	#define VOX_NEON_HQREVERB 0
#endif






namespace vox
{

// **************************************************************************************** //
// ************************************* ReverbHQ class *********************************** //
// **************************************************************************************** //


typedef struct
{
    int coeff;
    int history[2];
} ReverbFilter;



struct ReverbHQParamFaders
{
	vox::Fader Density;
	vox::Fader Diffusion;
	vox::Fader GainHF;
	vox::Fader HFReference;
	vox::Fader DecayTime; 
	vox::Fader DecayHFRatio;
	vox::Fader AirAbsorptionGainHF;
	vox::Fader Gain;
	vox::Fader EarlyReflectionsGain;
	vox::Fader EarlyReflectionsDelay;
	vox::Fader LateReverbGain;
	vox::Fader LateReverbDelay;

	vox::Fader Dry;
	vox::Fader Wet;
};



typedef struct DelayLine
{
    // Delay lines use sample lengths that are powers of 2 to allow bitmasking instead of modulus wrapping.
    unsigned int   Mask;
    int *Line;
} DelayLine;

struct EarlyReflections
{
    // Total gain for early reflections.
    int   Gain;
    // Early reflections are done with 4 delay lines.
    int   Coeff[4];
    DelayLine Delay[4];
    unsigned int    Offset[4];

};

struct LateReverb
{
    // Total gain for late reverb.
    int   Gain;
    // Attenuation to compensate for modal density and decay rate.
    int   DensityGain;
    // The feed-back and feed-forward all-pass coefficient.
    int   ApFeedCoeff;
    // Mixing matrix coefficient.
    int   MixCoeff;
    // Late reverb has 4 parallel all-pass filters.
    int   ApCoeff[4];
    DelayLine ApDelay[4];
    unsigned int    ApOffset[4];
    // In addition to 4 cyclical delay lines.
    int   Coeff[4];
    DelayLine Delay[4];
    unsigned int    Offset[4];
    // The cyclical delay lines are 1-pole low-pass filtered.
    int   LpCoeff[4];
    int   LpSample[4];

};



// The lengths of the early delay lines (in seconds).
static const float EARLY_LINE_LENGTH[4] = {0.0015f, 0.0045f, 0.0135f, 0.0405f};

// The lengths of the late all-pass delay lines (in seconds).
static const float ALLPASS_LINE_LENGTH[4] = {0.0151f, 0.0167f, 0.0183f, 0.0200f};
// In Neon mode, allpass lengths are remapped to correspond to the ones in the non Neon version
static const int ALLPASS_REMAP[4] = {1, 3, 0, 2};

// The lengths of the late cyclical delay lines (in seconds).
static const float LATE_LINE_LENGTH[4] = {0.0211f, 0.0311f, 0.0461f, 0.0680f};

// The late cyclical delay lines have a variable length dependent on the
// effect's density parameter (inverted for some reason) and this multiplier.
static const float LATE_LINE_MULTIPLIER = 4.0f;

// Input into the late reverb is decorrelated between four channels. Their timings
// are dependent on a fraction and multiplier.
static const float DECO_FRACTION = 1.0f / 32.0f;
static const float DECO_MULTIPLIER = 2.0f;
static const float DECO_MULTIPLIER_TOTAL = (DECO_MULTIPLIER + DECO_MULTIPLIER*DECO_MULTIPLIER + DECO_MULTIPLIER*DECO_MULTIPLIER*DECO_MULTIPLIER - 3.f);

// The maximum length of initial delay for the master delay line (a sum of
// the maximum early reflection and late reverb delays).
static const float MASTER_LINE_LENGTH = 0.1f + 0.1f;


class ReverbHQC : public vox::CustomDSP
{
 private:
	// All delay lines are allocated as a single buffer to reduce memory fragmentation and management code.
	int			*SampleBuffer;
    unsigned int    TotalLength;

    // Master effect low-pass filter (2 chained 1-pole filters).
    ReverbFilter LpFilter;

    // Initial effect delay and decorrelation.
    DelayLine Delay;

    // The tap points for initial delay.  First tap goes to early reflections, last four decorrelate to late reverb.
    unsigned int    Tap[5];

	EarlyReflections	Early;
	LateReverb			Late;
    
    // The current read offset for all delay lines.
    unsigned int Offset;

	int DryMix;
	int WetMix;

	// Counter for auto-shutdown
	float TailCounter;

	ReverbHQParamFaders m_paramFaders;
	ReverbHQPresetBank m_paramBank;
	vox::Mutex m_mutex;

	unsigned int CalcLengths(unsigned int length[13], float frequency);
	void CreateDelayLines(void);
	__inline void DelayLineIn(DelayLine *Delay, unsigned int offset, int in);
	__inline int DelayLineOut(DelayLine *Delay, unsigned int offset);
	__inline int EarlyDelayLineOut(unsigned int index);
	__inline void EarlyReflection(int in, int *out);
	__inline int LateAllPassInOut(unsigned int index, int in);
	__inline int LateDelayLineOut(unsigned int index);
	__inline int LateLowPassInOut(unsigned int index, int in);
	__inline int lpFilter2P(ReverbFilter *iir, unsigned int offset, int input);

	void _Update(const int *input, int *output, int inputChannelIndex, int nbSamples);
	void _SetParameters(ReverbHQParameters *parameters);
	void UpdateParameters(float dt);
	float GetTailDecayTime();
public:
	ReverbHQC();
	virtual ~ReverbHQC(void);
	virtual bool ConnectToBus(float sampleRate, int channels, int flags);
	virtual void Update(const int *input, int *output, int nbSamples);
	virtual bool WillOutput(bool hasInput);

	void SetParameters(ReverbHQParameters *parameters, float fadeTime);
	
	bool LoadParameterBank(const char *filename);
	// bool SetBankPreset(int index, float fadeTime);     // Deprecated - please set presets by name
	bool SetBankPresetByName(const char *name, float fadeTime);
};


#if VOX_NEON_HQREVERB

class ReverbHQNeon : public vox::CustomDSP
{
private:
	// All delay lines are allocated as a single buffer to reduce memory fragmentation and management code.
	signed short *SampleBufferMemory; // Memory space for below
	signed short *SampleBuffer;       // Same as above but aligned, this one is used in processing
    unsigned int    TotalLength;
	signed short *SampleBufferPointer;

	unsigned int  parametersMemory[200];       // Memory space for below
	unsigned int *parameters;                  // Same as above but aligned, this one is used in processing

	// Counter for auto-shutdown
	float TailCounter;

	ReverbHQParamFaders m_paramFaders;
	ReverbHQPresetBank m_paramBank;
	vox::Mutex m_mutex;

	unsigned int CalcLengths(unsigned int length[13], float frequency);
	void CreateDelayLines(void);
	
	void _SetParameters(ReverbHQParameters *param);
	void UpdateParameters(float dt);
	float GetTailDecayTime();

	int FToNeon(float in);
	int F2ToNeon(float in, float in2);
	int Clamp16(float in);
	void CopyWriteWraparound();

public:
	ReverbHQNeon();
	virtual ~ReverbHQNeon(void);
	virtual bool ConnectToBus(float sampleRate, int channels, int flags);
	virtual void Update(const int *input, int *output, int nbSamples);
	virtual bool WillOutput(bool hasInput);

	void SetParameters(ReverbHQParameters *parameters, float fadeTime);
	
	bool LoadParameterBank(const char *filename);
	// bool SetBankPreset(int index, float fadeTime);     // Deprecated - please set presets by name
	bool SetBankPresetByName(const char *name, float fadeTime);
};


#else // VOX_NEON_HQREVERB

class ReverbHQNeon : public vox::CustomDSP
{
};

#endif // VOX_NEON_HQREVERB

} // namespace vox


#endif // _CUSTOM_DSP_INTERNAL_H_
