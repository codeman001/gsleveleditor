// #include "stdafx.h"


#include "hq_reverb_internal.h"
#include <string.h>
#include <math.h>

#if VOX_NEON_HQREVERB

#if defined(_WIN32)
	#define STRICMP _stricmp
#else
	#define STRICMP strcasecmp	
#endif


#ifndef VOX_HQREVERB_PI
	#define VOX_HQREVERB_PI 3.141592653589793f
#endif

#define VOX_HQREVERB_SPEEDOFSOUNDMETRESPERSEC	(343.3f)



#define PMAP_STORE_ALLPASS (0/4)
#define PMAP_STORE_LR (128/4)
#define PMAP_STORE_ER (192/4)

#define PMAP_PARAM_INFILTER (256/4)
#define PMAP_PARAM_ALLPASS (320/4)
#define PMAP_PARAM_MATRIX (384/4)
#define PMAP_PARAM_MIX (392/4)
#define PMAP_PARAM_EARLY (592/4)
#define PMAP_PARAM_FILTER (608/4)
#define PMAP_PARAM_BIAS (736/4)

#define PMAP_MEMORY_FILTER (400/4)
#define PMAP_MEMORY_INFILTER (432/4)

#define PMAP_HEAD_ERR (448/4)
#define PMAP_HEAD_ERW (464/4)
#define PMAP_HEAD_ARR (480/4)
#define PMAP_HEAD_ARW (496/4)
#define PMAP_HEAD_LRR (512/4)
#define PMAP_HEAD_LRW (528/4)
#define PMAP_HEAD_IRR (544/4)
#define PMAP_HEAD_IRR0 (560/4)
#define PMAP_HEAD_IRW (564/4)

#define PMAP_BUFFER_INPUT (568/4)
#define PMAP_BUFFER_OUTPUT (572/4)
#define PMAP_BUFFER_END (576/4)

#define PMAP_DELAY_END (580/4)
#define PMAP_DELAY_POINTER (584/4)
#define PMAP_DELAY_SIZE (588/4)



namespace vox
{
// **************************************************************************************** //
// *********************************** ReverbHQNeon class ********************************* //
// **************************************************************************************** //


ReverbHQNeon::ReverbHQNeon()
{
    unsigned int index;

	TotalLength = 0;
    SampleBufferMemory = 0;
	SampleBuffer = 0;
	SampleBufferPointer = 0;

	parameters = parametersMemory;
	while ((unsigned int)parameters & 0x1c) // While not aligned to a 32 byte boundary
		parameters++;         // Increment

	for(index = 0; index<184; index++)
		parameters[index] = 0;

	TailCounter = 0;

	ReverbHQParameters defaultParameters;
	SetParameters(&defaultParameters, 0.0f);

	
}

// Connect to bus can be run multiple times!
bool ReverbHQNeon::ConnectToBus(float sampleRate, int channels, int specialFlags)
{
	m_sampleRate = sampleRate;
	if(channels != 2)
		return false;
	if(specialFlags)
		return false;
	
	if(!SampleBuffer)
		CreateDelayLines();
	
	return true;
}


ReverbHQNeon::~ReverbHQNeon(void)
{	
	if(SampleBufferMemory)
	{
        delete [] SampleBufferMemory;
        SampleBufferMemory = 0;
		SampleBuffer = 0;
    }
}


unsigned int ReverbHQNeon::CalcLengths(unsigned int length[13], float frequency)
{
    unsigned int samples, totalLength, index;

    // This is very different from the non-Neon version!
	// 16 sample padding is added between lines
	// Does not have to be 2^n (not necessary and reduces cache aliasing)

    samples = (unsigned int)
              ((MASTER_LINE_LENGTH +
                (LATE_LINE_LENGTH[0] * (1.0f + LATE_LINE_MULTIPLIER) *
                 (DECO_FRACTION * DECO_MULTIPLIER_TOTAL))) *
               frequency) + 10; // Extra samples in case it rounds the wrong way!
    length[0] = ((samples - 1) & 0xfffffff0) + 16 + 32; // Aligned to 16 samples with +32 to prevent overlap
    totalLength = length[0];
    for(index = 0;index < 4;index++)
    {
        samples = (unsigned int)(EARLY_LINE_LENGTH[index] * frequency) + 1;
		length[1 + index] = ((samples - 1) & 0xfffffff0) + 16 + 16; // Aligned to 16 samples with +16 to prevent overlap
        totalLength += length[1 + index];
    }
    for(index = 0;index < 4;index++)
    {
        samples = (unsigned int)(ALLPASS_LINE_LENGTH[ALLPASS_REMAP[index]] * frequency) + 1;
        length[5 + index] = ((samples - 1) & 0xfffffff0) + 16 + 16; // Aligned to 16 samples with +16 to prevent overlap
        totalLength += length[5 + index];
    }
    for(index = 0;index < 4;index++)
    {
        samples = (unsigned int)(LATE_LINE_LENGTH[index] *
                           (1.0f + LATE_LINE_MULTIPLIER) * frequency) + 1;
        length[9 + index] = ((samples - 1) & 0xfffffff0) + 16 + 16; // Aligned to 16 samples with +16 to prevent overlap
        totalLength += length[9 + index];
    }

    return totalLength; 
}

// This updates the device-dependant reverb state.  This is called on initialization and any time
// the device parameters (eg. playback frequency, format) have been changed.

void ReverbHQNeon::CreateDelayLines(void)
{
    unsigned int length[13], totalLength;
    unsigned int index;
	
    totalLength = CalcLengths(length, m_sampleRate);
    if(totalLength != TotalLength)
	{
		// Extra 16 for alignment, extra 16 for read/write heads overlapping the block N-1 and N
        SampleBufferMemory = new signed short[totalLength + 16 + 16];
		SampleBuffer = SampleBufferMemory;
		if(SampleBufferMemory)
		{
			while((unsigned int)SampleBuffer & 0x1e) // While not aligned to a 16 byte boundary
				SampleBuffer++;        // Increment
			TotalLength = totalLength;

			// All lines share a single sample buffer
			// This setup is very different fron the non-Neon version
			// Instead of a bunch of contiguous buffers with 2^n sizes,
			// we use one large buffer with writing and reading heads,
			// and wrapping heads around when reaching the end.
			// Heads may partially ovelap blocks N-1 and N, so when
			// witing heads reach the end the data from the block N
			// must be replicated in block 0

			parameters[PMAP_DELAY_SIZE] = TotalLength * 2; // must translate samples to bytes
			parameters[PMAP_DELAY_END] = (unsigned int)(SampleBuffer + TotalLength);
			SampleBufferPointer = SampleBuffer;


			parameters[PMAP_HEAD_IRW] = 2*(length[0] - 16);
			totalLength = length[0];
			for(index = 0; index < 4; index++)
			{
				parameters[PMAP_HEAD_ERW + index] = 2*(totalLength + length[1 + index] - 16);
				parameters[PMAP_HEAD_ERR + index] = 2*(totalLength + length[1 + index] - 16 - (unsigned int)(EARLY_LINE_LENGTH[index] * m_sampleRate));
				totalLength += length[1 + index];
			}
			for(index = 0; index < 4; index++)
			{
				parameters[PMAP_HEAD_ARW + index] = 2*(totalLength + length[5 + index] - 16);
				parameters[PMAP_HEAD_ARR + index] = 2*(totalLength + length[5 + index] - 16 - (unsigned int)(ALLPASS_LINE_LENGTH[ALLPASS_REMAP[index]] * m_sampleRate));
				totalLength += length[5 + index];
			}
			for(index = 0; index < 4; index++)
			{
				parameters[PMAP_HEAD_LRW + index] = 2*(totalLength + length[9 + index] - 16);
				totalLength += length[9 + index];
			}

		    for(index = 0; index < TotalLength + 16; index++)
			{
				SampleBuffer[index] = 0;
			}

	    }

	}

}

int ReverbHQNeon::FToNeon(float in)
{
	in *= 32768;
	int res = in;
	if (res >  32767)
		res =  32767;
	if (res < -32768)
		res = -32768;
	return res;
}

int ReverbHQNeon::F2ToNeon(float in, float in2)
{
	return FToNeon(in) + FToNeon(in2)*65536;
}

void ReverbHQNeon::_SetParameters(ReverbHQParameters *param)
{    
    unsigned int index;
    float length, mixCoeff, cw, g, coeff;
	int lengthInt;
    float hfRatio = param->DecayHFRatio;
	float fc;
	float fpGainAdjust;

    // Calculate the master low-pass filter (from the master effect HF gain).
    cw = cos(2.0f * VOX_HQREVERB_PI * param->HFReference / m_sampleRate);
	g = param->GainHF;
	if(g < 0.0001f)
	{
		g = 0.0001f;
	}

    if(g > 0.9999f) // 1-epsilon
	{
		g = 0.9999f;
	}
		
	fc = (1 - g*cw - sqrtf(2*g*(1-cw) - g*g*(1 - cw*cw))) / (1 - g);

	// fc = 0.05f;

	fpGainAdjust = 1 - fc;
	fpGainAdjust *= fpGainAdjust; // Filter is applied twice so we must adjust twice

	float fc4 = fc*fc*fc*fc;

	float oldGainAdjust = 1 - (((signed short)parameters[PMAP_PARAM_INFILTER+8]) / 32768.f);

	parameters[PMAP_PARAM_INFILTER   ] = F2ToNeon(0, 0);
	parameters[PMAP_PARAM_INFILTER+1 ] = F2ToNeon(0, -fpGainAdjust);
	parameters[PMAP_PARAM_INFILTER+2 ] = F2ToNeon(-fc, -fc*fc);
	parameters[PMAP_PARAM_INFILTER+3 ] = F2ToNeon(-fc*fc*fc, -fc4);
	parameters[PMAP_PARAM_INFILTER+4 ] = F2ToNeon(-fc4*fc, -fc4*fc*fc);
	parameters[PMAP_PARAM_INFILTER+5 ] = F2ToNeon(-fc4*fc*fc*fc, -fc4*fc4);
	parameters[PMAP_PARAM_INFILTER+6 ] = F2ToNeon(-fc4*fc4*fc, -fc4*fc4*fc*fc);
	parameters[PMAP_PARAM_INFILTER+7 ] = F2ToNeon(-fc4*fc4*fc*fc*fc, -fc4*fc4*fc4);

	parameters[PMAP_PARAM_INFILTER+8 ] = F2ToNeon( 0, 0);
	parameters[PMAP_PARAM_INFILTER+9 ] = F2ToNeon( 0, 0);
	parameters[PMAP_PARAM_INFILTER+10] = F2ToNeon( fc,  fc*fc);
	parameters[PMAP_PARAM_INFILTER+11] = F2ToNeon( fc*fc*fc,  fc4);
	parameters[PMAP_PARAM_INFILTER+12] = F2ToNeon( fc4*fc,  fc4*fc*fc);
	parameters[PMAP_PARAM_INFILTER+13] = F2ToNeon( fc4*fc*fc*fc,  fc4*fc4);
	parameters[PMAP_PARAM_INFILTER+14] = F2ToNeon( fc4*fc4*fc,  fc4*fc4*fc*fc);
	parameters[PMAP_PARAM_INFILTER+15] = F2ToNeon( fc4*fc4*fc*fc*fc,  fc4*fc4*fc4);

	float newGainAdjust = 1 - (((signed short)parameters[PMAP_PARAM_INFILTER+8]) / 32768.f);

	if(newGainAdjust != oldGainAdjust)
	{
		int oldMemory = ((signed short)(parameters[PMAP_MEMORY_INFILTER+1] >> 16));
		int newMemory = Clamp16(oldMemory * newGainAdjust / oldGainAdjust * newGainAdjust / oldGainAdjust);
		parameters[PMAP_MEMORY_INFILTER+1] = (parameters[PMAP_MEMORY_INFILTER+1] & 0xffff) + newMemory*65536;

		oldMemory = ((signed short)(parameters[PMAP_MEMORY_INFILTER+3] >> 16));
		newMemory = Clamp16(oldMemory * newGainAdjust / oldGainAdjust);
		parameters[PMAP_MEMORY_INFILTER+3] = (parameters[PMAP_MEMORY_INFILTER+3] & 0xffff) + newMemory*65536;
	}

	parameters[PMAP_PARAM_BIAS  ] = 65537*2;
	parameters[PMAP_PARAM_BIAS+1] = 65537*2;
	parameters[PMAP_PARAM_BIAS+2] = 65537*2;
	parameters[PMAP_PARAM_BIAS+3] = 65537*2;

    // Calculate the initial delay taps.
    length = param->EarlyReflectionsDelay;
	lengthInt = (unsigned int)(length * m_sampleRate);
	if(lengthInt < 16)
		lengthInt = 16;
	parameters[PMAP_HEAD_IRR0] = parameters[PMAP_HEAD_IRW] - lengthInt * 2;
	if(SampleBufferPointer + (parameters[PMAP_HEAD_IRR0] >> 1) < SampleBuffer)
	{
		parameters[PMAP_HEAD_IRR0] += TotalLength*2;
	}

    length += param->LateReverbDelay;

    // * The four inputs to the late reverb are decorrelated to smooth the
    // * initial reverb and reduce harsh echos.  The timings are calculated as
    // * multiples of a fraction of the smallest cyclical delay time. This
    // * result is then adjusted so that the first tap occurs immediately (all
    // * taps are reduced by the shortest fraction).
    // *
    // * offset[index] = ((FRACTION MULTIPLIER^index) - 1) delay
    // *
    for(index=0; index<4; index++)
    {
        length += LATE_LINE_LENGTH[0] *
            (1.0f + (param->Density * LATE_LINE_MULTIPLIER)) *
            (DECO_FRACTION * (pow(DECO_MULTIPLIER, (float)index) - 1.0f));
		lengthInt = (unsigned int)(length * m_sampleRate);
		if(lengthInt < 16)
			lengthInt = 16;

        parameters[PMAP_HEAD_IRR + index] = parameters[PMAP_HEAD_IRW] - lengthInt * 2;
		if(SampleBufferPointer + (parameters[PMAP_HEAD_IRR + index] >> 1) < SampleBuffer)
		{
			parameters[PMAP_HEAD_IRR + index] += TotalLength*2;
		}

    }

    // Calculate the gain (coefficient) for each early delay line.
	
	parameters[PMAP_PARAM_EARLY  ] = F2ToNeon(pow(2.0f,  EARLY_LINE_LENGTH[0] / param->LateReverbDelay * (-9.9657f)),
	                                          pow(2.0f,  EARLY_LINE_LENGTH[1] / param->LateReverbDelay * (-9.9657f)));
	parameters[PMAP_PARAM_EARLY+1] = F2ToNeon(pow(2.0f,  EARLY_LINE_LENGTH[2] / param->LateReverbDelay * (-9.9657f)),
	                                          pow(2.0f,  EARLY_LINE_LENGTH[3] / param->LateReverbDelay * (-9.9657f)));

    // Calculate the first mixing matrix coefficient (x).
	mixCoeff = 1.0f - (0.5f * pow(param->Diffusion, 3.0f));

	parameters[PMAP_PARAM_MIX] = (int)(param->Dry * 4096);
    
	// Calculate the late reverb gain (from the master effect gain, and late
    // reverb gain parameters).  Since the output is tapped prior to the
    // application of the delay line coefficients, this gain needs to be
    // attenuated by the 'x' mix coefficient from above.
    // Also calculate the early reflections gain (from the master effect gain, and reflections gain parameters).
    parameters[PMAP_PARAM_MIX+1] = F2ToNeon(param->Gain * param->Wet * param->LateReverbGain * mixCoeff,
	                                        param->Gain * param->Wet * param->EarlyReflectionsGain);
	
    // * To compensate for changes in modal density and decay time of the late
    // * reverb signal, the input is attenuated based on the maximal energy of
    // * the outgoing signal.  This is calculated as the ratio between a
    // * reference value and the current approximation of energy for the output
    // * signal.
    // *
    // * Reverb output matches exponential decay of the form Sum(a^n), where a
    // * is the attenuation coefficient, and n is the sample ranging from 0 to
    // * infinity.  The signal energy can thus be approximated using the area
    // * under this curve, calculated as:  1 / (1 - a).
    // *
    // * The reference energy is calculated from a signal at the lowest (effect
    // * at 1.0) density with a decay time of one second.
    // *
    // * The coefficient is calculated as the average length of the cyclical
    // * delay lines.  This produces a better result than calculating the gain
    // * for each line individually (most likely a side effect of diffusion).
    // *
    // * The final result is the square root of the ratio bound to a maximum
    // * value of 1 (no amplification).
    // *
	float lateDensityGain;
	float lateApFeedCoeff;
	float lateMixCoeff;
	float lateApCoeff[4];
	float lateCoeff[4];

    length = (LATE_LINE_LENGTH[0] + LATE_LINE_LENGTH[1] +
              LATE_LINE_LENGTH[2] + LATE_LINE_LENGTH[3]);
    g = length * (1.0f + LATE_LINE_MULTIPLIER) * 0.25f;
    g = pow(10.0f, g * -60.0f / 20.0f);
    g = 1.0f / (1.0f - (g * g));
    length *= 1.0f + (param->Density * LATE_LINE_MULTIPLIER) * 0.25f;
    length = pow(10.0f, length / param->DecayTime * -60.0f / 20.0f);
    length = 1.0f / (1.0f - (length * length));
    lateDensityGain = sqrtf(g / length);
	if(lateDensityGain > 1)
	{
		lateDensityGain = 1;
	}

    // Calculate the all-pass feed-back and feed-forward coefficient.
    lateApFeedCoeff = 0.6f * pow(param->Diffusion, 3.0f);

    // Calculate the mixing matrix coefficient (y / x).
    g = sqrtf((1.0f - (mixCoeff * mixCoeff)) / 3.0f);
    lateMixCoeff = (g / mixCoeff);

	parameters[PMAP_PARAM_MATRIX] = F2ToNeon(-lateMixCoeff, 0); // Using negative range

	// Calculate the gain (coefficient) for each all-pass line.
	for(index=0; index<4; index++)
		lateApCoeff[index] = pow(10.0f, ALLPASS_LINE_LENGTH[ALLPASS_REMAP[index]] / param->DecayTime * -60.0f / 20.0f);

    // If the HF limit parameter is flagged, calculate an appropriate limit
    // based on the air absorption parameter.
    if(param->DecayHFLimit && param->AirAbsorptionGainHF < 1.0f)
    {
        float limitRatio;

        // For each of the cyclical delays, find the attenuation due to air
        // absorption in dB (converting delay time to meters using the speed
        // of sound).  Then reversing the decay equation, solve for HF ratio.
        // The delay length is cancelled out of the equation, so it can be
        // calculated once for all lines.
        limitRatio = 1.0f / (log10(param->AirAbsorptionGainHF) *
                             VOX_HQREVERB_SPEEDOFSOUNDMETRESPERSEC *
                             param->DecayTime / -60.0f * 20.0f);
        // Need to limit the result to a minimum of 0.1, just like the HF ratio parameter.
        if(limitRatio < 0.1f)
		{
			limitRatio = 0.1f;
		}

        // Using the limit calculated above, apply the upper bound to the HF ratio.
		if(hfRatio > limitRatio)
		{
			hfRatio = limitRatio;
		}
    }

    // Calculate the low-pass filter frequency.
    cw = cos(2.0f * VOX_HQREVERB_PI * param->HFReference / m_sampleRate);

    for(index = 0;index < 4;index++)
    {
        // Calculate the length (in seconds) of each cyclical delay line.
        length = LATE_LINE_LENGTH[index] * (1.0f + (param->Density * LATE_LINE_MULTIPLIER));

        // Calculate the delay offset for the cyclical delay lines.
		lengthInt = (unsigned int)(length * m_sampleRate);
		if(lengthInt < 16)
			lengthInt = 16;
		parameters[PMAP_HEAD_LRR+index] = parameters[PMAP_HEAD_LRW+index] - lengthInt * 2;
		if(SampleBufferPointer + (parameters[PMAP_HEAD_LRR + index] >> 1) < SampleBuffer)
		{
			parameters[PMAP_HEAD_LRR + index] += TotalLength*2;
		}

        // Calculate the gain (coefficient) for each cyclical line.
        lateCoeff[index] = pow(10.0f, length / param->DecayTime * -60.0f / 20.0f);
        // Attenuate the cyclical line coefficients by the mixing coefficient (x).


        // Eventually this should boost the high frequencies when the ratio exceeds 1.
        coeff = 0.0f;
        if (hfRatio < 1.0f)
        {
            // Calculate the decay equation for each low-pass filter.
            g = pow(10.0f, length / (param->DecayTime * hfRatio) * -60.0f / 20.0f);
			// Constant introduced by error due to fixed point manips. Will be kept because it puts the cutoff param in a saner range anyways.
			g /=  lateCoeff[index] / 4.0; 
			if(g < 0.1f)
			{
				g  = 0.1f;
			}
            g *= g;

            // Calculate the gain (coefficient) for each low-pass filter.
            if(g < 0.9999f) // 1-epsilon
			{
                coeff = (1 - g*cw - sqrtf(2*g*(1-cw) - g*g*(1 - cw*cw))) / (1 - g);
			}

            // Very low decay times will produce minimal output, so apply an
            // upper bound to the coefficient.
            if(coeff > 0.98f)
			{
				coeff = 0.98f;
			}

        }
		fc = coeff;
		fpGainAdjust = 1 - fc;
		fc4 = fc*fc*fc*fc;
		oldGainAdjust = 1 - (((signed short)parameters[PMAP_PARAM_FILTER+index*8 ]) / 32768.f);

		parameters[PMAP_PARAM_FILTER+index*8  ] = F2ToNeon(0, 0);
		parameters[PMAP_PARAM_FILTER+index*8+1] = F2ToNeon(0, 0);
		parameters[PMAP_PARAM_FILTER+index*8+2] = F2ToNeon(fc, fc*fc);
		parameters[PMAP_PARAM_FILTER+index*8+3] = F2ToNeon(fc*fc*fc, fc4);
		parameters[PMAP_PARAM_FILTER+index*8+4] = F2ToNeon(fc4*fc, fc4*fc*fc);
		parameters[PMAP_PARAM_FILTER+index*8+5] = F2ToNeon(fc4*fc*fc*fc, fc4*fc4);
		parameters[PMAP_PARAM_FILTER+index*8+6] = F2ToNeon(fc4*fc4*fc, fc4*fc4*fc*fc);
		parameters[PMAP_PARAM_FILTER+index*8+7] = F2ToNeon(fc4*fc4*fc*fc*fc, fc4*fc4*fc4);

		newGainAdjust = 1 - (((signed short)parameters[PMAP_PARAM_FILTER+index*8 ]) / 32768.f);

		if(newGainAdjust != oldGainAdjust)
		{
			int oldMemory = ((signed short)(parameters[PMAP_MEMORY_FILTER+index*2+1] >> 16));
			int newMemory = Clamp16(oldMemory * newGainAdjust / oldGainAdjust);
			parameters[PMAP_MEMORY_FILTER+index*2+1] = (parameters[PMAP_MEMORY_FILTER+index*2+1] & 0xffff) + newMemory*65536;
		}

        lateCoeff[index] *= mixCoeff;

		// out = (coef) * lineout - (feedcoef) * in
		// linein =  (feedcoef * coef) * lineout + (1 - feedcoef * feedcoef) * in
		
		// input gain:
		// gain for i-line = Density gain
		// gain for l-line = Late coeff
		// gain to compensate filter = fpGainAdjust

		// fi = (1 - feedcoef^2) * densitygain * fpGainAdjust
		// fl = (1 - feedcoef^2) * latecoeff * fpGainAdjust
		// fa = feedcoef*coef
		// oi = -feedcoef * densitygain * fpGainAdjust
		// ol = -feedcoef * latecoeff * fpGainAdjust
		// oa = coef		

		parameters[PMAP_PARAM_ALLPASS+index*4+0] = 
			F2ToNeon( (1 - lateApFeedCoeff*lateApFeedCoeff)*lateDensityGain *fpGainAdjust*0.5f,
			          (1 - lateApFeedCoeff*lateApFeedCoeff)*lateCoeff[index]*fpGainAdjust*0.5f);
		parameters[PMAP_PARAM_ALLPASS+index*4+1] = 
			F2ToNeon(lateApFeedCoeff*lateApCoeff[index]*0.5f, 0 );
		parameters[PMAP_PARAM_ALLPASS+index*4+2] = 
			F2ToNeon( -lateApFeedCoeff*lateDensityGain *fpGainAdjust*0.5f,
			          -lateApFeedCoeff*lateCoeff[index]*fpGainAdjust*0.5f);
		parameters[PMAP_PARAM_ALLPASS+index*4+3] = 
			F2ToNeon( lateApCoeff[index]*0.5f, 0 );
    }



}


void ReverbHQNeon::SetParameters(ReverbHQParameters *parameters, float fadeTime)
{
	vox::ScopeMutex sm(&m_mutex);
	if(fadeTime > 0.0f)
	{
		float minFadeTime;

		minFadeTime = fabs(m_paramFaders.Density.GetCurrentValue() - parameters->Density);
		minFadeTime *= 50;
		if(fadeTime > minFadeTime)
			minFadeTime = fadeTime;
		m_paramFaders.Density = vox::Fader(m_paramFaders.Density.GetCurrentValue(), parameters->Density, minFadeTime);
		m_paramFaders.Diffusion = vox::Fader(m_paramFaders.Diffusion.GetCurrentValue(), parameters->Diffusion, fadeTime);
		m_paramFaders.GainHF = vox::Fader(m_paramFaders.GainHF.GetCurrentValue(), parameters->GainHF, fadeTime);
		m_paramFaders.HFReference = vox::Fader(m_paramFaders.HFReference.GetCurrentValue(), parameters->HFReference, fadeTime);
		m_paramFaders.DecayTime = vox::Fader(m_paramFaders.DecayTime.GetCurrentValue(), parameters->DecayTime, fadeTime);
		m_paramFaders.DecayHFRatio = vox::Fader(m_paramFaders.DecayHFRatio.GetCurrentValue(), parameters->DecayHFRatio, fadeTime);
		m_paramFaders.AirAbsorptionGainHF = vox::Fader(m_paramFaders.AirAbsorptionGainHF.GetCurrentValue(), parameters->AirAbsorptionGainHF, fadeTime);

		m_paramFaders.Gain = vox::Fader(m_paramFaders.Gain.GetCurrentValue(), parameters->Gain, fadeTime);
		m_paramFaders.EarlyReflectionsGain = vox::Fader(m_paramFaders.EarlyReflectionsGain.GetCurrentValue(), parameters->EarlyReflectionsGain, fadeTime);
		minFadeTime = fabs(m_paramFaders.EarlyReflectionsDelay.GetCurrentValue() - parameters->EarlyReflectionsDelay);
		minFadeTime *= 200;
		if(fadeTime > minFadeTime)
			minFadeTime = fadeTime;
		m_paramFaders.EarlyReflectionsDelay = vox::Fader(m_paramFaders.EarlyReflectionsDelay.GetCurrentValue(), parameters->EarlyReflectionsDelay, minFadeTime);
		m_paramFaders.LateReverbGain = vox::Fader(m_paramFaders.LateReverbGain.GetCurrentValue(), parameters->LateReverbGain, fadeTime);
		minFadeTime = fabs(m_paramFaders.LateReverbDelay.GetCurrentValue() - parameters->LateReverbDelay);
		minFadeTime *= 200;
		if(fadeTime > minFadeTime)
			minFadeTime = fadeTime;
		m_paramFaders.LateReverbDelay = vox::Fader(m_paramFaders.LateReverbDelay.GetCurrentValue(), parameters->LateReverbDelay, minFadeTime);
	
		m_paramFaders.Dry = vox::Fader(m_paramFaders.Dry.GetCurrentValue(), parameters->Dry, fadeTime);
		m_paramFaders.Wet = vox::Fader(m_paramFaders.Wet.GetCurrentValue(), parameters->Wet, fadeTime);
	}
	else
	{
		m_paramFaders.Density = vox::Fader(parameters->Density, parameters->Density, 0.0f);
		m_paramFaders.Diffusion = vox::Fader(parameters->Diffusion, parameters->Diffusion, 0.0f);
		m_paramFaders.GainHF = vox::Fader(parameters->GainHF, parameters->GainHF, 0.0f);
		m_paramFaders.HFReference = vox::Fader(parameters->HFReference, parameters->HFReference, 0.0f);
		m_paramFaders.DecayTime = vox::Fader(parameters->DecayTime, parameters->DecayTime, 0.0f);
		m_paramFaders.DecayHFRatio = vox::Fader(parameters->DecayHFRatio, parameters->DecayHFRatio, 0.0f);
		m_paramFaders.AirAbsorptionGainHF = vox::Fader(parameters->AirAbsorptionGainHF, parameters->AirAbsorptionGainHF, 0.0f);
		m_paramFaders.Gain = vox::Fader(parameters->Gain, parameters->Gain, 0.0f);
		m_paramFaders.EarlyReflectionsGain = vox::Fader(parameters->EarlyReflectionsGain, parameters->EarlyReflectionsGain, 0.0f);
		m_paramFaders.EarlyReflectionsDelay = vox::Fader(parameters->EarlyReflectionsDelay, parameters->EarlyReflectionsDelay, 0.0f);
		m_paramFaders.LateReverbGain = vox::Fader(parameters->LateReverbGain, parameters->LateReverbGain, 0.0f);
		m_paramFaders.LateReverbDelay = vox::Fader(parameters->LateReverbDelay, parameters->LateReverbDelay, 0.0f);

		m_paramFaders.Dry = vox::Fader(parameters->Dry, parameters->Dry, 0.0f);
		m_paramFaders.Wet = vox::Fader(parameters->Wet, parameters->Wet, 0.0f);
	}
}

void ReverbHQNeon::UpdateParameters(float dt)
{
	ReverbHQParameters parameters;

	vox::ScopeMutex sm(&m_mutex);
	if( !m_paramFaders.Diffusion.IsFinished() ||
		!m_paramFaders.Density.IsFinished() ||
		!m_paramFaders.EarlyReflectionsDelay.IsFinished() ||
		!m_paramFaders.LateReverbDelay.IsFinished() )
	{
		m_paramFaders.Density.Update(dt);
		parameters.Density = m_paramFaders.Density.GetCurrentValue();
		
		m_paramFaders.Diffusion.Update(dt);
		parameters.Diffusion = m_paramFaders.Diffusion.GetCurrentValue();

		m_paramFaders.GainHF.Update(dt);
		parameters.GainHF = m_paramFaders.GainHF.GetCurrentValue();

		m_paramFaders.HFReference.Update(dt);
		parameters.HFReference = m_paramFaders.HFReference.GetCurrentValue();

		m_paramFaders.DecayTime.Update(dt);
		parameters.DecayTime = m_paramFaders.DecayTime.GetCurrentValue();

		m_paramFaders.DecayHFRatio.Update(dt);
		parameters.DecayHFRatio = m_paramFaders.DecayHFRatio.GetCurrentValue();

		m_paramFaders.AirAbsorptionGainHF.Update(dt);
		parameters.AirAbsorptionGainHF = m_paramFaders.AirAbsorptionGainHF.GetCurrentValue();

		m_paramFaders.Gain.Update(dt);
		parameters.Gain = m_paramFaders.Gain.GetCurrentValue();

		m_paramFaders.EarlyReflectionsGain.Update(dt);
		parameters.EarlyReflectionsGain = m_paramFaders.EarlyReflectionsGain.GetCurrentValue();

		m_paramFaders.EarlyReflectionsDelay.Update(dt);
		parameters.EarlyReflectionsDelay = m_paramFaders.EarlyReflectionsDelay.GetCurrentValue();

		m_paramFaders.LateReverbGain.Update(dt);
		parameters.LateReverbGain = m_paramFaders.LateReverbGain.GetCurrentValue();

		m_paramFaders.LateReverbDelay.Update(dt);
		parameters.LateReverbDelay = m_paramFaders.LateReverbDelay.GetCurrentValue();


		m_paramFaders.Dry.Update(dt);
		parameters.Dry = m_paramFaders.Dry.GetCurrentValue();

		m_paramFaders.Wet.Update(dt);
		parameters.Wet = m_paramFaders.Wet.GetCurrentValue();


		_SetParameters(&parameters);
	}
}


bool ReverbHQNeon::LoadParameterBank(const char *filename)
{
	return m_paramBank.loadBank(filename);
}

// Deprecated - please set presets by name
//
//bool ReverbHQNeon::SetBankPreset(int index, float fadeTime)
//{
//	bool value;
//	ReverbHQParameters param;
//	value = m_paramBank.getPreset(index, &param);
//	SetParameters(&param, fadeTime);
//	return value;
//}
//

bool ReverbHQNeon::SetBankPresetByName(const char *name, float fadeTime)
{
	bool value;
	ReverbHQParameters param;
	value = m_paramBank.getPresetByName(name, &param);
	SetParameters(&param, fadeTime);
	return value;
}





extern "C" int HQReverbUpdateNeonAsm(unsigned int *params);



int ReverbHQNeon::Clamp16(float in)
{
	if(in >  32767)
		return  32767;
	if(in < -32768)
		return -32768;
	return (int)in;
}

void ReverbHQNeon::CopyWriteWraparound()
{
	for(int i=0; i<16; i++)
		SampleBuffer[i] = SampleBuffer[i+TotalLength];
}


void ReverbHQNeon::Update(const int *input, int *output, int nbSamples)
{

	const int *inputBufferCursor = input;
	int *outputBufferCursor = output;

	// Update reverb parameters
	float dt = (float) nbSamples / m_sampleRate;
	UpdateParameters(dt);

	if(!SampleBuffer) // No delay buffers -> reverb effect impossible
	{
		memcpy(output, input, nbSamples * 2 * sizeof(int) );
		return;
	}

	if(TailCounter > 1) // Signal is coming in, set the counter at 1
		TailCounter = 1;
	else
	{
		TailCounter -= (nbSamples / m_sampleRate) / GetTailDecayTime();
		if(TailCounter < 0)
			TailCounter = 0;
	}

	while(nbSamples > 0)
	{
		if( ((unsigned int)SampleBufferPointer & 0x1f) == 0 && nbSamples >= 16)
		{
			int samplesToDo = nbSamples - (nbSamples & 0xf);

			parameters[PMAP_BUFFER_INPUT]  = (unsigned int)inputBufferCursor;
			parameters[PMAP_BUFFER_OUTPUT] = (unsigned int)outputBufferCursor;
			parameters[PMAP_BUFFER_END]    = (unsigned int)(outputBufferCursor + samplesToDo * 2);
			parameters[PMAP_DELAY_POINTER] = (unsigned int)SampleBufferPointer;

			HQReverbUpdateNeonAsm(parameters);

			inputBufferCursor   = (int *)parameters[PMAP_BUFFER_INPUT];
			outputBufferCursor  = (int *)parameters[PMAP_BUFFER_OUTPUT];
			SampleBufferPointer = (signed short *)parameters[PMAP_DELAY_POINTER];
			nbSamples -= samplesToDo;
		}
		else
		{
			while( ( ((unsigned int)SampleBufferPointer & 0x1f) != 0 || nbSamples < 16) && nbSamples > 0 )
			{
				signed short *parameters16 = (signed short *)parameters;
				float k[6];
				float v;
				float in;
				float er_out[2];
				float apf_out[4];
				float lr_out[2];
				int i;

				for(i=0; i<4; i++)
					if(SampleBufferPointer + (parameters[PMAP_HEAD_ERR+i]>>1) >= SampleBuffer + TotalLength)
						parameters[PMAP_HEAD_ERR+i] -= TotalLength*2;

				for(i=0; i<4; i++)
					k[i] = SampleBufferPointer[parameters[PMAP_HEAD_ERR+i]>>1] * parameters16[PMAP_PARAM_EARLY*2+i]  / 32768.0f;

				if(SampleBufferPointer + (parameters[PMAP_HEAD_IRR0]>>1) >= SampleBuffer + TotalLength)
					parameters[PMAP_HEAD_IRR0] -= TotalLength*2;				

				in = SampleBufferPointer[parameters[PMAP_HEAD_IRR0]>>1];

				v = in + (k[0] + k[1] + k[2] + k[3]) * 0.5f;
				k[0] = v - k[0];
				k[1] = v - k[1];
				k[2] = v - k[2];
				k[3] = v - k[3];

				for(i=0; i<4; i++)
				{
					SampleBufferPointer[parameters[PMAP_HEAD_ERW+i]>>1] = Clamp16(k[i]);
					if(SampleBufferPointer + (parameters[PMAP_HEAD_ERW+i]>>1) >= SampleBuffer + TotalLength + 15)
					{
						CopyWriteWraparound();
						parameters[PMAP_HEAD_ERW+i] -= TotalLength*2;
					}
				}
				
				er_out[0] = k[0];
				er_out[1] = k[1];

				for(i=0; i<4; i++)
				{
					if(SampleBufferPointer + (parameters[PMAP_HEAD_IRR+i]>>1) >= SampleBuffer + TotalLength)
						parameters[PMAP_HEAD_IRR+i] -= TotalLength*2;
					if(SampleBufferPointer + (parameters[PMAP_HEAD_LRR+i]>>1) >= SampleBuffer + TotalLength)
						parameters[PMAP_HEAD_LRR+i] -= TotalLength*2;
					if(SampleBufferPointer + (parameters[PMAP_HEAD_ARR+i]>>1) >= SampleBuffer + TotalLength)
						parameters[PMAP_HEAD_ARR+i] -= TotalLength*2;

					k[3] = SampleBufferPointer[parameters[PMAP_HEAD_IRR+i]>>1] / 16384.f;
					k[4] = SampleBufferPointer[parameters[PMAP_HEAD_LRR+i]>>1] / 16384.f;
					k[5] = SampleBufferPointer[parameters[PMAP_HEAD_ARR+i]>>1] / 16384.f;

					k[0] = k[3] * parameters16[PMAP_PARAM_ALLPASS*2+i*8  ];
					k[1] = k[4] * parameters16[PMAP_PARAM_ALLPASS*2+i*8+1];
					k[2] = k[5] * parameters16[PMAP_PARAM_ALLPASS*2+i*8+2];
					k[3] = k[3] * parameters16[PMAP_PARAM_ALLPASS*2+i*8+4];
					k[4] = k[4] * parameters16[PMAP_PARAM_ALLPASS*2+i*8+5];
					k[5] = k[5] * parameters16[PMAP_PARAM_ALLPASS*2+i*8+6];
					
					SampleBufferPointer[parameters[PMAP_HEAD_ARW+i]>>1] = Clamp16(k[0]+k[1]+k[2]);
					if(SampleBufferPointer + (parameters[PMAP_HEAD_ARW+i]>>1) >= SampleBuffer + TotalLength + 15)
					{
						CopyWriteWraparound();
						parameters[PMAP_HEAD_ARW+i] -= TotalLength*2;
					}

					apf_out[i] =   parameters16[PMAP_MEMORY_FILTER*2+i*4+3] = Clamp16(parameters16[PMAP_MEMORY_FILTER*2+i*4+3] * parameters16[PMAP_PARAM_FILTER*2+i*16] / 32768.0 + k[3] + k[4] + k[5]);
				}

				k[1] = apf_out[0] - ( apf_out[1] - apf_out[2] + apf_out[3]) * parameters16[PMAP_PARAM_MATRIX*2] / 32768.f;
				k[3] = apf_out[1] - (-apf_out[0] + apf_out[2] + apf_out[3]) * parameters16[PMAP_PARAM_MATRIX*2] / 32768.f;
				k[0] = apf_out[2] - ( apf_out[0] - apf_out[1] + apf_out[3]) * parameters16[PMAP_PARAM_MATRIX*2] / 32768.f;
				k[2] = apf_out[3] - (-apf_out[0] - apf_out[1] - apf_out[2]) * parameters16[PMAP_PARAM_MATRIX*2] / 32768.f;

				for(i=0; i<4; i++)
				{
					SampleBufferPointer[parameters[PMAP_HEAD_LRW+i]>>1] = Clamp16(k[i]);
					if(SampleBufferPointer + (parameters[PMAP_HEAD_LRW+i]>>1) >= SampleBuffer + TotalLength + 15)
					{
						CopyWriteWraparound();
						parameters[PMAP_HEAD_LRW+i] -= TotalLength*2;
					}
				}

				lr_out[0] = k[1];
				lr_out[1] = k[3];

				v = (inputBufferCursor[0] + inputBufferCursor[1]) * parameters16[PMAP_PARAM_INFILTER*2+3] / 8.0f / -32768.f;
				for(i=0; i<2; i++)
					v = parameters16[PMAP_MEMORY_INFILTER*2+i*4+3] = Clamp16(parameters16[PMAP_MEMORY_INFILTER*2+i*4+3] * parameters16[PMAP_PARAM_INFILTER*2+16] / 32768.0 - v);

				SampleBufferPointer[parameters[PMAP_HEAD_IRW]>>1] = (signed short)v;
				if(SampleBufferPointer + (parameters[PMAP_HEAD_IRW]>>1) >= SampleBuffer + TotalLength + 15)
				{
					CopyWriteWraparound();
					parameters[PMAP_HEAD_IRW] -= TotalLength*2;
				}

				outputBufferCursor[0]=(int)(((int)(parameters  [PMAP_PARAM_MIX]) * inputBufferCursor[0]
									       + parameters16[PMAP_PARAM_MIX*2+2] * lr_out[0]
									       + parameters16[PMAP_PARAM_MIX*2+3] * er_out[0]) / 4096.f);
				outputBufferCursor[1]=(int)(((int)(parameters  [PMAP_PARAM_MIX]) * inputBufferCursor[1]
									       + parameters16[PMAP_PARAM_MIX*2+2] * lr_out[1]
									       + parameters16[PMAP_PARAM_MIX*2+3] * er_out[1]) / 4096.f);

				outputBufferCursor+=2;	
				inputBufferCursor+=2;
				parameters  [PMAP_DELAY_POINTER] += 2;
				SampleBufferPointer++;
				nbSamples--;
			}
		}
	}
}



float ReverbHQNeon::GetTailDecayTime()
{
	float decayTime = m_paramFaders.DecayTime.GetCurrentValue();
	if(decayTime > 0)
		return 0.5f + decayTime * 1.6f;
	else
		return 0.5f;
}

bool ReverbHQNeon::WillOutput(bool hasInput)
{
	if(hasInput)
	{
		TailCounter = 2; // This signals that signal is coming in.
		return true;
	}
	else
	{
		if(TailCounter > 0) // Starts at 1 when input stops, goes down to 0
			return true;
		else
			return false;
	}
}


} // namespace vox

#endif // VOX_NEON_HQREVERB






