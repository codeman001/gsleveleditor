////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                             Vox Audio Engine                               //
//                                                                            //
//                        Minibus system & HQReverb                           //
//                                                                            //
//                               Robert Houde                                 //
//                             (c)2011 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

FIRST STEP TO MAKING THE HQ REVERB WORK:
run setup.bat (will create the vox_config/hq_reverb/hq_reverb_config.h file)
============================================================================

Vox minibus system comprises a master bus and two auxiliary buses (AUX1 and AUX2).
Each auxiliary bus comprises one slot for an 'application custom' DSP effect.
Emitters can be routed to any of the three buses.

Minibus system usage
====================

1) Setting the output volumes of an auxiliary bus
-------------------------------------------------

Auxiliary buses provide their data to the master bus via two paths, wet and dry.
Dry path contains the sum of all emitter data routed to the auxiliary bus while
the wet path is the result of the dry signal having passed into DSP processing.
The amount of dry and wet signals sent to the master bus can be controlled via
method VoxEngine::SetRoutingVolume() with parameters:

  a) c8* busFromName : Name of the auxiliary bus. Either "AUX1" or "AUX2".
  b) c8* busToName   : Implicitely "MASTER". This value is not used.
  c) VoxDSPGeneralParameter::BusRoutingType routingType : VoxDSPGeneralParameter::k_nWetAndDry,
     VoxDSPGeneralParameter::k_nWet or VoxDSPGeneralParameter::k_nDry.
  d) f32 dryVolume   : Value for dry volume.
  e) f32 wetVolume   : Value for wet volume.
  f) f32 fadeTime    : Volumes will be ramped up/down from current value to the
                       desired value during this fade time (in seconds).

2) Routing an emitter to a bus
------------------------------

An emitter can be routed to any bus (MASTER, AUX1 or AUX2) by calling method
VoxEngine::SetDSPEmitterParameter() with parameters:

  a) EmitterHandle &handle : The emitter handle
  b) s32 paramId           : Set to vox::VoxDSPEmitterParameter::k_nBusId
  c) const void* param     : A char pointer to the Name of the bus. Valid names
                             are "AUX1" and "AUX2". Any other name results in the
                             emitter being routed to the master bus.
               
NOTE : Emitters are routed to the master bus by default. Therefore, it is not
necessary to call SetDSPEmitterParameter() to route an emitter to the master
bus (this will only add unnecessary processing).

NOTE 2 : In Vox 1.1, bus routing is part of the Emitter::CreationSettings structure
so it should be automatically set depending on the contents of your SDD.

3) Creating a DSP for an auxiliary bus
--------------------------------------

All DSP classes must derive from abstract class CustomDSP and implement method
virtual void Update(const s32 *input, s32 *output, int nbSamples), which is
called by vox whenever the DSP is assigned to an auxiliary bus. Parameters are:

  a) const s32 *input: Input buffer containing the data sum from all emitters assigned
                       to the auxiliary bus. The data is stereo and interleaved
                       with left channel first. There are nbSamples left samples
                       and nbSamples right samples. Data is in (18.14) complement-2
                       fixed point format.
  b) s32 *output: Output buffer in which to put the result of the input buffer
                  being processed by the DSP effect. The output buffer is provided
                  by vox. Data must be outputted as interleaved stereo with
                  left channel first. There must be nbSamples left samples and
                  nbSamples right samples. Data must be provided in (18.14) complement-2
                  fixed point format.
  c) nbSamples : Number of samples in a single channel of input and output buffers.
                 This means that the input and output buffers have 2 * nbSamples
                 samples.

4) Assigning a DSP to an auxiliary bus
--------------------------------------

A DSP can be assigned to an auxiliary bus by calling VoxEngine::AttachDSP(). Parameters are:

  a) const char *busName: Name of bus to attach the dsp to. Can only be "AUX1" or "AUX2".
  b) CustomDSP *dsp: Pointer to dsp to attach.

HQ reverberation usage
======================

1) General usage
----------------

Vox provides an HQ reverberation module as a DSP plugin. This plugin is contained
in files hq_reverb.cpp, hq_reverb.h, hq_reverb_internal.h, hq_reverb_neon.h
and hq_reverb_neon.s on ARM platforms (found in folder <vox_root>/Plugins/hq_reverb).
In order to use the HQ reverb module, you have to:

  a) Add the HQ Reverb files to your project (they are not part of vox project).
     You might have to turn off precompiled headers for these files.
  b) Create a ReverbHQ object.
  c) Load a reverb parameter preset bank using the LoadParameterBank(const char *filename)
     function. Parameter preset banks can be exported from the VST version of the HQReverb
     in FXB format (see in the tools folders).
  d) Assign the ReverbHQ to an auxiliary bus (see item 4 of the 'Minibus system
     usage' section), with a dry mix setting of 0.0 and a wet mix setting of 1.0 (HQReverb
     does its own dry-wet mix so you shouldn't use the mixing bus settings for this).
     Use VoxEngine::SetRoutingVolume and VoxEngine::AttachDSP for this.
  e) Assign any emitter on which you would like to have reverb to the auxiliary
     bus to which you assign the HQ reverb (see item 2 of the 'Minibus system
     usage' section) using VoxEngine::SetDSPEmitterParameter. If you're using the XML
     Soundpack, effect bus should already be set in your CreationSettings.
  f) Load a reverb setting from the bank using SetBankPreset(int index, float fadeTime) or
     SetBankPresetByName(const char *name, float fadeTime). You should use a fadeTime of
     0 for the first preset you load, and then another larger value later on each time you
     need to change reverb parameters. The parameters will be changed in a gradual fashion
     during the time 'fadeTime' (in seconds). If you change the parameters with a value of
     0 while reverberated sound is already playing, you will get a click (due to the jump
     in the values). 

2) Usage example (using the preset bank)     
----------------------------------------

	vox::VoxEngine &vox = vox::VoxEngine::GetVoxEngine();
	vox::ReverbHQ reverbDSP;
	vox::EmitterHandle emitterHandle;


// Startup
	reverbDsp.LoadParameterBank("../common_data/mini_sound_manager.fxb");
	reverbDsp.SetBankPresetByName("initial preset", 0); // no fade on startup
	vox.AttachDSP("AUX1", &reverbDsp);
	vox.SetRoutingVolume("AUX1", "MASTER", vox::VoxDSPGeneralParameter::k_nWetAndDry, 0, 1);


// Changing reverb presets
	reverbDsp.SetBankPresetByName("cathedral", 2.0f);


// Activating the effect on an emitter
	vox.SetDSPEmitterParameter(emitterHandle, vox::VoxDSPEmitterParameter::k_nBusId, "AUX1");



3) Reverberation parameters
---------------------------

The way the reverberation sounds is dependent on a variety of parameters. You can
change the value of those parameters by calling method ReverbHQ::SetParameters()
and passing it a pointer to a ReverbHQParameters structure. Parameters in this 
structure are the following:

  a) Density: This parameter affects the density of the late reverb impulse response.
              A smaller value provides a greater density in the sense that more
              impulses are present in the impulse response.
	
  b) Diffusion: Affects the intensity of impulses in late reverb impulse response
                (but not their position). A small value attenuates most of the impulses
                while increasing a few (leading to an echo-like effect). Values greater
                than cubic root of 3 make no sense. Default value is 1.0.

	c) GainHF:		Gain of the master lowpass filter
	
	d) HFReference: Cutoff frequency of the master lowpass filter (in Hz).
	
	e) DecayTime:	Time interval (in seconds) at which late reverb drops at -60dB from
                input signal. 

	f) DecayHFRatio: Affects the response of the high frequency response of the late reverb.
                   A smaller value means less high frequency content.

	g) DecayHFLimit: When true, the HFRatio is limited to a value dependent upon AirAbsorptionGainHF.
                   In this case, the value provided by DecayHFRatio has no impact.
	

	h) AirAbsorptionGainHF: When DecayHFLimit is true, this parameter is used to set the value of
                          the HFRatio. A smaller value decreases the high frequency response of
                          the late reverb. Valid values are between 0.0 and 1.0.

	i) Gain: Gain common to early reflections and late reverb (applied on their respective gains).
	
	j) EarlyReflectionsGain: Early reflections gain factor (the effective gain also involves parameter Gain).
 
  k) EarlyReflectionsDelay;	Time between input signal and first reflection (in seconds).
	
  l) LateReverbGain: Late reverb gain factor (the effective gain also involves parameter Gain
                     and a mix coefficient factor).
	
  m) LateReverbDelay:	Time between first reflection and start of late reverb (in seconds).

  n) Dry: Amount of dry signal that goes through. (This is not the same parameter as the bus dry mix setting!)

  o) Wet: Amount of wet signal that goes through. (This is not the same parameter as the bus wet mix setting!)


4) Neon Optimized HQReverb
--------------------------

On ARM platforms (IOS 3gs and up, psp2, Android...), the optimized version of the reverb should be
used. This reduces the cpu usage quite substantially (5% to 1% on the 3gs at 32khz
for instance), except on Android phones using the Tegra2 (but those all have a beefy multicore CPU).

The NEON version defaults to ON on IOS (on armv7 builds). On Android, you must make sure you're building
for armv7. The lines that you add to android.mk should look something like this:
(remember to adjust the path to point to the location of the files):

ifeq ($(TARGET_ARCH_ABI),armeabi-v7a)
  LOCAL_SRC_FILES += ../../../../Plugins/hq_reverb/hq_reverb_neon.cpp
  LOCAL_SRC_FILES += ../../../../Plugins/hq_reverb/hq_reverb_neon.s.neon
  LOCAL_CFLAGS    := $(LOCAL_CFLAGS) -D__ARM_NEON__
endif

"HQReverbNeon.s.neon" is not a typo (".neon" must be added for NEON opcodes to be recognised)

If you're having bugs  or problems with the NEON optimization in the HQ reverb, you can to turn it off
by defining VOX_USE_NEON_HQREVERB to 0 in your vox_config/hq_reverb/hq_reverb_config.h.

(Note that you should also have other Neon optimisations activated. If no other Neon optimisations
are active, Neon HQReverb will be turned off at compile time too. In Vox1.1 neon is activated by default
in all armv7 builds.)


5) Block subdivision
--------------------

To make reverb preset transitions smoother, the sound processing blocks are now subdivided. This can
be changed with the VOX_HQREVERB_BLOCK_SUBDIVIDE option. Setting this to 0 turns off block subdivision.
Default value is now 128, which offers an ok compromise between speed and smoothness (total CPU time
goes from 0.9% to 1.0% on Iphone 4).

6) Warnings
-----------

To enable warnings, you must add #define HQREVERB_VOX_CONSOLE_ENABLE 1 to your reverb config file
(vox_config/hq_reverb/hq_reverb_config.h). This is recommended.
