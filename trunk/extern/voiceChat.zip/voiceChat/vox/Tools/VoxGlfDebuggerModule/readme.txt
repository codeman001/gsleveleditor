////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox 1.1 Audio Engine Tools                         //
//                                                                            //
//                           Vox glf debugger module                          //
//                                                                            //
//                               Robert Houde                                 //
//                             (c)2012 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

The glf debugger module provides the application with the ability to view vox
related information. Currently, only console messages are forwarded to the glf
debugger.

Usage
=====

1) Make sure your application is built with glf. If not on win32 debug, set
GLF_ENABLE_DEBUGGER to a non-null value in your glf_config.h (GLF_ENABLE_DEBUGGER
is already enabled on win32 debug). 
   
2) Set VOX_ENABLE_CONSOLE and VOX_USE_GLF_DEBUGGER_MODULE to non-null values
in your vox_config.h.

3) OPTIONAL: If you want to forward custom emitter user data to the glf debugger
module, set VOX_USE_CUSTOM_EMITTER_USER_DATA to a non-null value in your vox_config.h
and define class EmitterHandleUserData in a custom header file (either vox_config.h
or a file included from vox_config.h). The requirements and default implementation
for this class are found in vox/include/vox_custom_emitter_user_data.h.

4) OPTIONAL: If you want to forward custom data source user data to the glf debugger
module, set VOX_USE_CUSTOM_DATA_SOURCE_USER_DATA to a non-null value in your vox_config.h
and define class DataHandleUserData in a custom header file (either vox_config.h
or a file included from vox_config.h). The requirements and default implementation
for this class are found in vox/include/vox_custom_datasource_user_data.h.

5) Start your application. You should normally see a message like "debugger listening:..."
in the console. This informs you that the server part of the glf debugger has started.

6) Start the glf debugger (glf/tools/debugger/glfDebugger.exe, see NOTE 1). If your
application runs on Windows, this can be done simply by pressing F1 (which forwards
you directly into the glf debugger client).

7) If your application doesn't run on Windows (or if you haven't pressed F1 for 
a Windows application), you will be forwarded to the 'Device Finder' dialog. In
this dialog, set the "host" field to SDSGlitchProxy for non-Windows applications or
to the name of your workstation (SDSWKSxxxx) if on Windows. Click on the "RefreshNow"
button and select the device on which your application is running in the table at
the bottom of the dialog. This will open the glf debugger client.

8) Once in the glf debugger client application, select the "Vox" tab and then the
"Console" tab. The console messages (basically VOX_WARNINGS) are printed out in
the "Output console" text area at the bottom of the tab. The toolbars over the console
provides you with different controls/filters to control the view in the console.
Mouse hovering tool tips are provided for each tool bar component.
 
 
NOTE 1: Executing glfDebugger.exe directly doesn't work on all platforms. Please
refer to glf/tools/debugger/_readme.txt for more details about the glf debugger
startup procedure on specific platforms.

Revision History
================
1.0 May 4, 2012
by Robert Houde
- Initial Version
