////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                              Zip scrambler                                 //
//                                                                            //
//                               Robert Houde                                 //
//                             (c)2010 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This tool allows processing of uncompressed zip archives for the following:

1) ARCHIVE SCRAMBLING:
----------------------

This is done by overwriting the signatures of all headers in the following way:

1) Local file headers : Signature is replaced by magic number
2) Central directory file headers : The signature is XORed with the magic number.
3) End of central directory header : The signature is XORed with the magic number.

A custom magic number can be provided as argument. If not, constant VOX_ZIP_MAGIC_NUMBER
is taken as the magic number.

Note: Even though one can provide a custom magic number, the value of VOX_ZIP_MAGIC_NUMBER
      will have to be overriden to that value in vox_config.h before running a game. If not,
      the archive sound files will not be registered (at runtime) by vox ZipReader and won't
      get played.


2) APPENDING AN EXTENSION TABLE TO ARCHIVE:
-------------------------------------------

In order to increase runtime speed access of sound information needed by vox ZipReader,
it is possible to append a table at the end of the archive. This table contains the local
headers information that is relevant to the ZipReader.

Note that the local headers signatures are not included in the extension table.
When using a zip file with an extension table, vox doesn't verify signatures
and plays the archive sound files as if signatures were valid.

Note: It is possible to append the extension table without scrambling the file by
      adding the flag "-noscrambling" to the command.


USAGE :
=======
 
VoxZipScrambler [-m magicNumber] [-o outputFile] [-createextension] [-noscrambling] <inputFile>

where 

- 'magicNumber' is a custom magic number provided as a 32-bit hexadecimal number (either
  with or without the 0x prefix). For example, both 0x12345678 and 12345678 are accepted.
- 'inputFile' and 'outputFile' are respectively the names of the input and output files.
- '-createextension' is used to create the extension table.
- '-noscrambling' is used to avoid scrambling.

Note 1: Optional flags can be in any order but must precede the input file name.
    
Note 2: If only the input file is specified the scrambler will overwrite it with 
        the new data, without any warning.

Note 3: When drag-and-dropping a zip file over VoxZipScrambler.exe, only scrambling with
        VOX_ZIP_MAGIC_NUMBER is performed. The input file will be overridden with
        the scrambled file.


Revision History
================
1.0 October 25, 2010
by Robert Houde
- Initial Version (scrambler only)

1.1 September 1, 2011
by Robert Houde
- Added zip extension table