import os
import ctypes
from pyExcelerator import *

# version semantic should be major.minor.fix
# fix version should not change exporter compatibility
# minor version may or may not change compatibility
# major version should always require a new version of the exporter
# if sheet is newer than exporter, always fails
# if sheet is older, conversion may be implemented in exporter or as a side tool  
API_VERSION = [ "1" , "1" , "0" ]  

# When enable data filename are force to lowercase
g_forceFilenameLowerCase = 0
# When enable script will also export data according to sample rate and encoding define in sheets
g_exportData = 0
# When enable script will reexport all data, not just newer file
g_forceReexport = 0
# More output
g_extraVerbose = 0
# Print all item
g_printItems = 0
# No output other than warnings and error
g_quietMode = 0
# Offset for UID
g_offsetUID = 0
# Script exit on error, XML is not produced
g_stopOnError = 0
# Script process warning as if theu were error
g_treatWarningAsError = 0
# Script will export event even if some assets are missing
g_allowIncompleteEvent = 0

g_inputFile = ""
g_soundsRoot = ""

G_ERROR_MESSAGE_TYPES = {'duplicate': 0, 'sddUnmatched': 1, 'soundpackUnmatched': 2}

g_errorMessageIndex = -1
g_sddDuplicatedFileMessageList = []
g_sddUnmatchedFileMessageList = []
g_soundpackUnmatchedFileMessageList = []
  
#update this function according to which version of the sheet the exporter is compatible
def CheckVersion( sheetVersion ) :
  version = sheetVersion.split('.')
  if API_VERSION[0] == version[0] and API_VERSION[1] == version[1] :
    return 1
  
  return 0

### [END] ### : def CheckVersion( sheetVersion ) :  

def PrintUsage ():
  print "Usage :"
  print "\tpython soundpackValidator.py -i inputfile [-p soundsRoot] [> outputfile]"
  print ""
  print "Options :"
  print "\t-p soundsRoot         Specify the name of the root folder containing the sounds to validate"
  print ""

def ParseCommandLine( commandLine ) :
  count = len(commandLine)
  
  if count < 3:
    PrintUsage()
    exit(1)

  global g_forceFilenameLowerCase
  global g_exportData
  global g_forceReexport
  global g_extraVerbose
  global g_printItems
  global g_offsetUID
  global g_stopOnError
  global g_treatWarningAsError
  global g_allowIncompleteEvent
  global g_inputFile
  global g_soundsRoot
  
  index = 1
  while index < count :
    if commandLine[index] == "-i" :
      index = index + 1
      if index >= count :
        PrintUsage()
        PrintError("Error : missing argument for -i")        
        exit(1)      
      if commandLine[index][0] == '-' :
        PrintUsage()
        PrintError("Error : argument " + commandLine[index] + " is not valid for -i")        
        exit(1)      
      g_inputFile = commandLine[index]
      if not g_inputFile.endswith(".xls") :
        PrintError("Error : file " + g_inputFile + " is not compatible")
        exit(1)
    elif commandLine[index] == "-p" :
      index = index + 1
      g_soundsRoot = commandLine[index]
    elif commandLine[index] == "-printitem" :
      g_printItems = 1
    else :
      PrintError("Error : Option " + commandLine[index] + " is not recognized" )
      
    index = index + 1

  if g_inputFile == "" :
    PrintUsage()
    PrintError("Error : No input file specified")
    exit(1)

  # If soundpack root folder is not provided as argument, set it to current directory
  if g_soundsRoot == "" :
    g_soundsRoot = os.getcwd()
  
### [END] ### : def ParseCommandLine( commandLine ) :


def AppendErrorMessage(messageType, filename, fullFileName):
  message = ""
  if messageType == G_ERROR_MESSAGE_TYPES['duplicate']:
    message = "[ERROR 0] : Duplicated label in sdd : " + filename
    g_sddDuplicatedFileMessageList.append(message)
  elif messageType == G_ERROR_MESSAGE_TYPES['sddUnmatched']:
    message = "[ERROR 1] : File found in SDD but missing from sounds folder : " + filename
    g_sddUnmatchedFileMessageList.append(message)
  elif messageType == G_ERROR_MESSAGE_TYPES['soundpackUnmatched']:
    message = "[ERROR 2] : File found in sounds folder but missing from sdd : " + fullFileName
    g_soundpackUnmatchedFileMessageList.append(message)
### [END] ### : def AppendErrorMessage(messageType, filename, fullFileName):


def RetrieveXLSSheets( inputfile, outSheetDict) :  
# Parsing of xls file provides a list of pairs (worksheetName, worksheetData)
  sheets = parse_xls( inputfile)  
  
  for sheet in sheets :
    sectionName,vals = sheet
    sectionNameString = str.upper(str(sectionName))
    
    # Get sheets related to sound files
    if sectionNameString == 'SFX' or sectionNameString == 'VOICE_OVER' or sectionNameString == 'MUSIC' :
      outSheetDict[str.upper(str(sectionName))] = vals

### [END] ### : def RetrieveXLSSheets( inputfile, outSheetDict) :
 
# Dependencies :
#   global
#   group
#   bank
#   bus      
def ParseSoundSheet ( soundSheet, outSoundDict) :
  # entry xls header : ( xml property, to lowercase, mandatory)
  headerConversionDict = { 'LABEL' : ( 'label', 0, 0, 1), 'Filename (with Extension)' : ('filename', g_forceFilenameLowerCase, 0, 0), 'Filename (including Extension)' : ('filename', g_forceFilenameLowerCase, 0, 0), 'GROUP' : ('group', 0, 0, 1), 'BUS' : ('bus', 0, 0, 0), 'BANK' : ('bank', 0, 0, 1), 'PRIORITY' : ('priority', 0, 0, 1), 'Loop' : ('loop', 0, 0, 0), 'FORMAT' : ('format', 1, 0, 1), 'LOADING FLAGS' : ('loadingflags', 1, 0,1), '3D MODE' : ('mode3d', 1, 0, 0), 'Reference Distance' : ('refdistance', 0, 1, 0), 'Max Distance' : ('maxdistance', 0, 1, 0), 'Rolloff Factor' : ('rolloff', 0, 1, 0), 'Base gain (dB)' : ('basegain', 0, 1, 0), 'Min gain mod (dB)' : ('mingainmod', 0, 1, 0), 'Max gain mod (dB)' : ('maxgainmod', 0, 1, 0), 'Base pitch (ratio)' : ('basepitch', 0, 1, 0), 'Min pitch mod (cents)' : ('minpitchmod', 0, 0, 0), 'Max pitch mod (cents)' : ('maxpitchmod', 0, 0, 0), "Custom1" : ( 'customparam', 0, 0, 0)}
  # entry (xlm property, col index, mandatory) 
  headerList = []

  #Get Header List
  GetHeaderList(soundSheet, headerConversionDict, headerList)

  #Get sound sheet entries in a dictionary having labels as keys
  tempDict = {}
  GetEntryDict(soundSheet, headerList, tempDict)
   
  # Construct sound dictionary with filenames as keys from 'tempDict'
  for key, val in tempDict.items() :
    outSoundDict[val['filename']] = val

### [END] ### : def ParseSoundSheet ( soundSheet, outSoundDict) :  


def has_hidden_attribute(filepath):
  try:
    attrs = ctypes.windll.kernel32.GetFileAttributesW(unicode(filepath))
    assert attrs != -1 
    result = bool(attrs & 2)
  except (AttributeError, AssertionError):
    result = False
  return result
### [END] ### :  def has_hidden_attribute(filepath):  

def ListFiles(dir, soundpackDict):
    basedir = dir
    subdirlist = []
    for item in os.listdir(dir):
      # Ignore items beginning with '.'
      if item.find('.') != 0:
        fullPathName = os.path.join(basedir, item)
        if not has_hidden_attribute(fullPathName):
          # If item is a file, it to the soundpack dictionary
          if os.path.isfile(fullPathName):
            if not soundpackDict.has_key(item):
              soundpackDict[item] = os.path.join(basedir, item)
          # If item is a folder, add it to the subfolder list
          else:
            subdirlist.append(os.path.join(basedir, item))

    # Search recursively in all subfolders
    for subdir in subdirlist:
        ListFiles(subdir, soundpackDict)

### [END] ### :  def ListFiles(dir, soundpackDict) :  

def GetFileName(label, format) :
  filename = ""
  if format == "pcm" or format == "adpcm" :
    extension = ".wav"
  elif format == "mpc" or format == "mpc8" :
    extension = ".mpc"
  elif format == "ogg" :
    extension = ".ogg"
  elif format == "vxn" :
    extension = ".vxn"
  elif format == "bcwav" :
    extension = ".bcwav"
  else :
    extension = ""
    
  if extension != "" :
    filename = label + extension
  return filename

### [END] ### :  def GetFileName(label, format) :       

  
def GetEntryDict(sheet, headerList, outEntryDict) :
  # find table extents
  maxRow = 0
  maxCol = 0
  for val in sheet :
    if val[0] > maxRow : maxRow = val[0]
    if val[1] > maxCol : maxCol = val[1]  
  maxCol = maxCol + 1
  maxRow = maxRow + 1
  
  for line in range (2, maxRow) :
    filenameMissing = 0
    labelPos = (line, 0)
    if sheet.has_key(labelPos) : 
      localDict = {}
      export = 1
      for (property, col, tolower, isDecimal, mandatory) in headerList :
        pos = (line, col)
        if property == "customparam" :
          strCustom = ""
          if sheet.has_key(pos) :
            strCustom = str(sheet[pos])
            for colCustom in range(col+1, maxCol) :
              posCustom = (line, colCustom)
              if sheet.has_key(posCustom) :
                strCustom = strCustom + "," + str(sheet[posCustom])
              else :
                break
            localDict[property] =  strCustom
        else:
          if sheet.has_key(pos) :
            val = str(sheet[pos])
            if isDecimal == 1 :
              val = val.replace(",", ".")
              
            if tolower == 1 : 
              localDict[property] = val.lower()
              if property == 'filename':
                print "filename put to lower " + val
            else :
              localDict[property] = val   
          else :
            if property == "filename" :
              filenameMissing = 1
              
      if filenameMissing == 1 :
        localDict['filename'] = GetFileName(localDict['label'], localDict['format'])
        
      if export == 1 :
        if outEntryDict.has_key(localDict['label']) :
          AppendErrorMessage(G_ERROR_MESSAGE_TYPES['duplicate'], localDict['label'], "");
        else :
          #outEntryDict.append(localDict)
          if localDict.has_key('filename') :
            outEntryDict[localDict['label']] = localDict
 
### [END] ### :  def GetEntryDict( sheet, headerList, outEntryList) :

################################################################################
#
# GetHeaderList
# in :
#   sheet list containing an excel data
#   headerDist dictionnary containing the column header identifier and information to convert to XML property. Entry = xls header : ( xml property, to lowercase, mandatory)
# out :
#   outHeaderList List containing tuple for xml exporting.  Entry = (xlm property, col index, tolower, mandatory)
#
################################################################################
def GetHeaderList( sheet, headerDict, outHeaderList) :
  # find table extents
  maxRow = 0
  maxCol = 0
  for val in sheet :
    if val[0] > maxRow : maxRow = val[0]
    if val[1] > maxCol : maxCol = val[1]  
  maxCol = maxCol + 1
  maxRow = maxRow + 1
  
  if g_extraVerbose == 1:
    print "Fetching column from sheet"
    for key in headerDict.keys() :
      (label, tolower, isDecimal, mandatory) = headerDict[key]
      print "\t" + key
      print "\t\tLabel : " + label
      if tolower == 1 :
        print "\t\tTo lower : true"
      else :     
        print "\t\tTo lower : false" 
      if isDecimal == 1:
        print "\t\tIs decimal : true"
      else :     
        print "\t\tIs decimal : false" 
      
  for col in range (0, maxCol) :
    pos = (1, col)
    if sheet.has_key(pos):
      if headerDict.has_key(sheet[pos]) :
        property = headerDict[str(sheet[pos])][0]
        tolower = headerDict[str(sheet[pos])][1] 
        isDecimal = headerDict[str(sheet[pos])][2] 
        mandatory = headerDict[str(sheet[pos])][3]
        outHeaderList.append((property, col, tolower, isDecimal, mandatory))    

### [END] ### :  GetHeaderList( sheet, headerDict, outHeaderList) : 

def PrintItem( itemList ) :
  count = 0
  for item in itemList :
    keys = sorted(item)
    print "Item " + str(count) + " :"
    for key in keys :
      print "\t" + key + " : " + item[key]
    count = count + 1
    
### [END] ### :  def PrintItem( itemList ) :

def PrintErrorMessage( ) :
  print "\n"
  print "**************************** DUPLICATED LABELS ******************************"
  print "\n"
  g_sddDuplicatedFileMessageList.sort()
  for item in g_sddDuplicatedFileMessageList:
    print item
  print "\n\n" 
  print "**************************** SDD UNMATCHED FILES ****************************"
  print "\n"
  g_sddUnmatchedFileMessageList.sort()
  for item in g_sddUnmatchedFileMessageList:
    print item
  print "\n\n" 
  print "************************ SOUNDPACK UNMATCHED FILES **************************"
  print "\n"
  g_soundpackUnmatchedFileMessageList.sort()
  for item in g_soundpackUnmatchedFileMessageList:
    print item
    
### [END] ### :  def PrintErrorMessage( ) :

################################################################################

import ctypes

# Constants from the Windows API
STD_OUTPUT_HANDLE = -11
FOREGROUND_RED    = 0x0004 | 0x0008 # text color contains bright red.
FOREGROUND_YELLOW = 0x0006 | 0x0008 # text color contains bright yellow.
FOREGROUND_WHITE  = 0x0007 | 0x0008 # text color contains bright white.

def get_csbi_attributes(handle):
    # Based on IPython's winconsole.py, written by Alexander Belchenko
    import struct
    csbi = ctypes.create_string_buffer(22)
    res = ctypes.windll.kernel32.GetConsoleScreenBufferInfo(handle, csbi)
    assert res

    (bufx, bufy, curx, cury, wattr,
    left, top, right, bottom, maxx, maxy) = struct.unpack("hhhhHhhhhhh", csbi.raw)
    return wattr

def PrintError(msg) :
  handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
  reset = get_csbi_attributes(handle)
  ctypes.windll.kernel32.SetConsoleTextAttribute(handle, FOREGROUND_RED)
  print msg
  ctypes.windll.kernel32.SetConsoleTextAttribute(handle, reset)
  if g_stopOnError == 1 :
    print "Stop on error enabled, stopped exporting"
    exit(1)
  
def PrintWarning(msg) :
  if g_treatWarningAsError == 1:
    PrintError(msg)
  else :
    handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
    reset = get_csbi_attributes(handle)
    ctypes.windll.kernel32.SetConsoleTextAttribute(handle, FOREGROUND_YELLOW)
    print msg
    ctypes.windll.kernel32.SetConsoleTextAttribute(handle, reset)  
  
def PrintMessage(msg) :
  handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
  reset = get_csbi_attributes(handle)
  ctypes.windll.kernel32.SetConsoleTextAttribute(handle, FOREGROUND_WHITE)
  print msg
  ctypes.windll.kernel32.SetConsoleTextAttribute(handle, reset)  
    
if __name__ == '__main__':
    ParseCommandLine(sys.argv)

    sheetDict = {}    
    sfxDict = {}
    vfxDict = {}
    musicDict = {}
    # sddDict is a dictionary of sound files listed in the SDD (key = filename, value = dictionary representing an xls line)
    sddDict = {}
    # soundpackDict is a dictionary of files in soundpack folder with (key = filename, value = fullFileName)
    soundpackDict = {}
    soundpackUnmatchedFilesDict = {}
    sddUnmatchedFilesDict = {}
        
    RetrieveXLSSheets( g_inputFile, sheetDict)

    # Parse every sound sheet and get results in sfxDict, vfxDict or musicDict
    ParseSoundSheet(sheetDict['SFX'],sfxDict)
    ParseSoundSheet(sheetDict['VOICE_OVER'], vfxDict)
    ParseSoundSheet(sheetDict['MUSIC'], musicDict)      
    
    # Construct sound dictionary with entries from sfx, vfx and music dictionaries  
    for key, val in sfxDict.items() :
      sddDict[key] = val
      
    for key, val in vfxDict.items() :
      sddDict[key] = val
      
    for key, val in musicDict.items() :
      sddDict[key] = val
    
    # Construct dictionary (key = filename, value = fullFilename) from files in soundpack folder (and subfolders)
    ListFiles(g_soundsRoot, soundpackDict)
    
    # Get files that are in sdd but have not match in soundpack folder
    for key, value in sddDict.items():
      if not soundpackDict.has_key(key):
        AppendErrorMessage(G_ERROR_MESSAGE_TYPES['sddUnmatched'], key, "")
        soundpackUnmatchedFilesDict[key] = value
        
    # Get files that are in soundpack folder but have not match in sdd
    for key, value in soundpackDict.items():
      if not sddDict.has_key(key):
        AppendErrorMessage(G_ERROR_MESSAGE_TYPES['soundpackUnmatched'], key, value)
        sddUnmatchedFilesDict[key] = value
        
    # Construct and output error message
    PrintErrorMessage()
  
    
