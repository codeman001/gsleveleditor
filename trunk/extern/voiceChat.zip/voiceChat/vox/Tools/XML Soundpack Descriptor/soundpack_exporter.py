import xml.dom.minidom
from pyExcelerator import *

# version semantic should be major.minor.fix
# fix version should not change exporter compatibility
# minor version may or may not change compatibility
# major version should always require a new version of the exporter
# if sheet is newer than exporter, always fails
# if sheet is older, conversion may be implemented in exporter or as a side tool  
API_VERSION = [ "1" , "1" , "0" ]  

# When enable data filename are force to lowercase
g_forceFilenameLowerCase = 0
# When enable script will also export data according to sample rate and encoding define in sheets
g_exportData = 0
# When enable script will reexport all data, not just newer file
g_forceReexport = 0
# More output
g_extraVerbose = 0
# Print all item
g_printItems = 0
# No output other than warnings and error
g_quietMode = 0
# Generate UID
g_generateUID = 0
# Offset for UID
g_offsetUID = 0
# Script exit on error, XML is not produced
g_stopOnError = 0
# Script process warning as if theu were error
g_treatWarningAsError = 0
# Script will export event even if some assets are missing
g_allowIncompleteEvent = 0
# Script will generate integration log
g_generateLog = 0
# Script will use color for console
g_consoleUseColor = 0;

g_inputFile = ""
g_outputFile = ""
g_logFile = ""
  
#update this function according to which version of the sheet the exporter is compatible
def CheckVersion( sheetVersion ) :
  version = sheetVersion.split('.')
  if API_VERSION[0] == version[0] and API_VERSION[1] == version[1] :
    return 1
  
  return 0

### [END] ### : def CheckVersion( sheetVersion ) :  

def PrintUsage ():
  print "Usage :"
  print "\tpython soundpack_exporter.py -i inputfile [-o outputfile] [-l logfile] [option ...]"
  print ""
  print "Options :"
  print "\t-o outputfile            Specify name of the output XML file (default inputfile with .xls replaced with .xml)"
  print "\t-l logfile               Output integration log into specified file."
  print "\t-forcefilenamelowercase  Force to set filename in the sheets to be set to lower case (default false)"
  print "\t-quiet                   Reduce output to warnings and error only (default false)"
  print "\t-extraverbose            Generate more output (default false)"
  print "\t-printitem               Print all items information to be exported (default false)"
  print "\t-stoponerror             Stop export on any error (default false)"
  print "\t-treatwarningaserror     Process warnings as if they were errors (default false)"
  print "\t-allowincompleteevent    Export event even if an asset is missing (default false)"
  print "\t-generateuid             Generate uid at export (default false)"
  print "\t-uidoffset offset        Offset to start uid at (default 0)"
  print "\t-exportdata              Export data accordingly to sample rate and encoding defined in sdd (default false)"
  print "\t-forcereexport           Reexport all data, not just the new data (default false)"
  print "\t-consolecolor            Enable color for console output (windows only)"
  print "\t-help                    Print this help information"
  print ""

def ParseCommandLine( commandLine ) :
  count = len(commandLine)
  
  if count < 3:
    PrintUsage()
    exit(1)

  global g_forceFilenameLowerCase
  global g_exportData
  global g_forceReexport
  global g_extraVerbose
  global g_quietMode
  global g_printItems
  global g_generateUID
  global g_offsetUID
  global g_stopOnError
  global g_treatWarningAsError
  global g_allowIncompleteEvent
  global g_generateLog
  global g_inputFile
  global g_outputFile
  global g_logFile
  global g_consoleUseColor
  
  index = 1
  while index < count :
    if commandLine[index] == "-i" :
      index = index + 1
      if index >= count :
        PrintUsage()
        PrintError("Error : missing argument for -i")        
        exit(1)      
      if commandLine[index][0] == '-' :
        PrintUsage()
        PrintError("Error : argument " + commandLine[index] + " is not valid for -i")        
        exit(1)      
      g_inputFile = commandLine[index]
      if not g_inputFile.endswith(".xls") :
        PrintError("Error : file " + g_inputFile + " is not compatible")
        exit(1)
      if g_outputFile == "" :
        g_outputFile = g_inputFile.replace(".xls", ".xml")
    elif commandLine[index] == "-o" :
      index = index + 1
      if index >= count :
        PrintUsage()
        PrintError("Error : missing argument for -o")        
        exit(1)      
      if commandLine[index][0] == '-' :
        PrintUsage()
        PrintError("Error : argument " + commandLine[index] + " is not valid for -o")        
        exit(1)      
      g_outputFile = commandLine[index] 
    elif commandLine[index] == "-l" :
      index = index + 1
      if index >= count :
        PrintUsage()
        PrintError("Error : missing argument for -l")        
        exit(1)      
      if commandLine[index][0] == '-' :
        PrintUsage()
        PrintError("Error : argument " + commandLine[index] + " is not valid for -l")        
        exit(1)      
      g_logFile = commandLine[index]
      g_generateLog = 1
    elif commandLine[index] == "-forcefilenamelowercase" :
      g_forceFilenameLowerCase = 1
    elif commandLine[index] == "-quiet" :
      g_quietMode = 1
    elif commandLine[index] == "-extraverbose" :
      g_extraVerbose = 1
    elif commandLine[index] == "-printitem" :
      g_printItems = 1
    elif commandLine[index] == "-stoponerror" :
      g_stopOnError = 1
    elif commandLine[index] == "-treatwarningaserror" :
      g_treatWarningAsError = 1
    elif commandLine[index] == "-allowincompleteevent" :
      g_allowIncompleteEvent = 1
    elif commandLine[index] == "-generateuid" :
      g_generateUID = 1
    elif commandLine[index] == "-uidoffset" :
      index = index + 1
      if index >= count :
        PrintUsage()
        PrintError("Error : missing argument for -uidoffset")        
        exit(1)      
      if commandLine[index][0] == '-' :
        PrintUsage()
        PrintError("Error : argument " + commandLine[index] + " is not valid for -uidoffset")        
        exit(1)         
      g_offsetUID = int(commandLine[index])
    elif commandLine[index] == "-exportdata" :
      g_exportData = 1
      print "Option -exportdata is not supported yet, this option has no effect"
    elif commandLine[index] == "-forcereexport" :
      g_forceReexport = 1
      print "Option -forcereexport is not supported yet, this option has no effect"
    elif commandLine[index] == "-consolecolor" :
      if sys.platform.startswith('win32'):
        g_consoleUseColor = 1
      else :
        PrintMessage("Option -consolecolor not supported on this system")
    elif commandLine[index] == "-help" :
      PrintUsage()
      exit(0)  
    else :
      PrintError("Error : Option " + commandLine[index] + " is not recognized" )
      
    index = index + 1

  if g_inputFile == "" :
    PrintUsage()
    PrintError("Error : No input file specified")
    exit(1)

def RetrieveXLSSheets( inputfile, outSheetDict) :  
# Parsing of xls file provides a list of pairs (worksheetName, worksheetData)
  sheets = parse_xls( inputfile)  
  
  for sheet in sheets :
    sectionName,vals = sheet
    outSheetDict[str.upper(str(sectionName))] = vals    
    
def ParseConfigSheet( configSheet, outGlobalDict) :
  vals = configSheet
  localDict = {}
  for line in range(2 , 10) :
    pos = (line,0)          
    if vals.has_key(pos) :
      pos2 = (line, 1)
      localDict[str(vals[pos]).lower()] = str(vals[pos2])  
      if g_quietMode == 0:             
        print str(vals[pos]).lower() + " : " + str(vals[pos2]) 
  localDict['mixingrate'] = localDict['mixingrate'].split(' ')[0]
  del localDict['documentation']
  outGlobalDict['CONFIG'] = localDict    
  
  for col in range(3, 12) :
    pos = (2, col)
    if vals.has_key(pos) :
      localList = []
      if g_extraVerbose == 1: 
        print str(vals[pos])
      for line in range (3, 19) :
        pos2 = (line, col)
        if vals.has_key(pos2) :
          localList.append(str(vals[pos2]))
          if g_extraVerbose == 1: 
            print "    " + str.upper(str(vals[pos2]))
      outGlobalDict[str(vals[pos])] = localList
     
### [END] ### : def RetrieveXLSSheets( inputfile, outSheetDict) :  

      
# Dependencies :
#   global
#   group
#   bank
#   bus      
def ParseSoundSheet ( soundSheet, outSoundList, groupList, bankList, busList, globalDict) :  
  
  # entry xls header : ( xml property, to lowercase, convert decimal point, mandatory)
  headerConversionDict = { 'LABEL' : ( 'label', 0, 0, 1), 'DESCRIPTION' : ('description', 0, 0, 0), 'Filename (with Extension)' : ('filename', g_forceFilenameLowerCase, 0, 0), 'GENERATE EVENT' : ('generateevent', 1, 0, 0), 'GROUP' : ('group', 0, 0, 1), 'BUS' : ('bus', 0, 0, 0), 'BANK' : ('bank', 0, 0, 1), 'PRIORITY' : ('priority', 0, 0, 1), 'Loop' : ('loop', 1, 0, 0), 'FORMAT' : ('format', 1, 0, 1), 'LOADING FLAGS' : ('loadingflags', 1, 0,1), '3D MODE' : ('mode3d', 1, 0, 0), 'Reference Distance' : ('refdistance', 0, 1, 0), 'Max Distance' : ('maxdistance', 0, 1, 0), 'Rolloff Factor' : ('rolloff', 0, 1, 0), 'Base gain (dB)' : ('basegain', 0, 1, 0), 'Min gain mod (dB)' : ('mingainmod', 0, 1, 0), 'Max gain mod (dB)' : ('maxgainmod', 0, 1, 0), 'Base pitch (cents)' : ('basepitch', 0, 1, 0), 'Min pitch mod (cents)' : ('minpitchmod', 0, 1, 0), 'Max pitch mod (cents)' : ('maxpitchmod', 0, 1, 0), 'Kill on resume' : ('killonresume', 1, 0, 0), 'Fade on play' : ('fadeonplay', 0, 1, 0), 'Fade on stop' : ('fadeonstop', 0, 1, 0), "Custom1" : ( 'customparam', 0, 0, 0)}
  # entry (xlm property, col index, mandatory) 
  headerList = []

  #Get Header List
  GetHeaderList(soundSheet, headerConversionDict, headerList)
  
  #Get Entries  
  tempList = []
  GetEntryList(soundSheet, headerList, tempList)
  
  #check on bus, bank and group
  busLabelDict = {}
  for bus in busList :
    busLabelDict[bus['label']]  = bus['label']
  
  groupLabelDict = {}
  for group in groupList :
    groupLabelDict[group['name']]  = group['name']
    
  bankLabelDict = {}
  for bank in bankList :
    bankLabelDict[bank['label']]  = bank['label']
      
  for sound in tempList :
    export = 1
    if sound.has_key('bus') :
      if not busLabelDict.has_key(sound['bus']):
        PrintError( "[" + sound['label'] + "] Error bus '" + sound['bus'] + "' is not a valid bus")
        export = 0
    if sound.has_key('bank') :
      if not bankLabelDict.has_key(sound['bank']):
        PrintError( "[" + sound['label'] + "] Error bank '" + sound['bank'] + "' is not a valid bank")
        export = 0   
    if not groupLabelDict.has_key(sound['group']):
        PrintError( "[" + sound['label'] + "] Error group '" + sound['group'] + "' is not a valid group")
        export = 0    
              
    if export == 1 :
      outSoundList.append(sound)
      
  GenerateUID(outSoundList)

### [END] ### : def ParseSoundSheet ( soundSheet, outSoundList, groupList, bankList, busList, globalDict) :  


# Dependencies :
#   global
#   sound
def ParseEventSheet ( eventSheet, outEventList, soundList, globalDict):
  
  # entry xls header : ( xml property, to lowercase, convert decimal point, mandatory)
  headerConversionDict = { 'Label' : ( 'label', 0, 0, 1), 'Type' : ('type', 1, 0, 1), 'Variable Assets' : ('value', 0, 0, 0), 'Param' : ('params', 0, 0, 0), 'Description' : ('description', 0, 0, 0), 'Cooldown Value' : ('cooldownvalue', 1, 1, 0), 'Cooldown Type' : ('cooldowntype', 1, 0, 0), "Custom1" : ( 'customparam', 0, 0, 0)}
  # entry (xlm property, col index, mandatory) 
  headerList = []

  #Get Header List
  GetHeaderList(eventSheet, headerConversionDict, headerList)
  
  #Get Entries  
  tempList = []
  GetEntryList(eventSheet, headerList, tempList)
  
  #check on bus, bank and group
  soundLabelDict = {}
  for sound in soundList :
    soundLabelDict[sound['label']]  = sound['label']
     
  for event in tempList :
    export = 1
    if event.has_key('value') :
      event['value'] = event['value'].replace(" ", "")
      event['value'] = event['value'].replace("\n", "")
      sndList = event['value'].split(",")
      #print sndList
      for snd in sndList :
        if not soundLabelDict.has_key(snd):
          if g_allowIncompleteEvent == 0 :
            PrintError("[" + event['label'] + "] Could not find sound " + snd)
            export = 0
          else :
            PrintWarning("[" + event['label'] + "] Could not find sound " + snd)          
    else :
      if g_allowIncompleteEvent == 0 :
        PrintError( "[" + event['label'] + "] No asset assigned" )
        export = 0        
      else :
        PrintWarning( "[" + event['label'] + "] No asset assigned" )
              
    if export == 1 :
      outEventList.append(event)
      
  GenerateUID(outEventList)

### [END] ### : def ParseEventSheet ( eventSheet, outEventList, soundList, globalDict) :
  
  
# Dependencies :
#   global     
def ParseBusSheet ( busSheet, outBusList, globalDict) :

  # entry xls header : ( xml property, to lowercase, convert decimal point, mandatory)
  headerConversionDict = { 'Name' : ( 'label', 0, 0, 1), 'Channel' : ('channel', 1, 0, 1), 'Sampling Rate' : ('sample_rate', 1, 0, 1) }
  # entry (xlm property, col index, mandatory) 
  headerList = []

  #Get Header List
  GetHeaderList(busSheet, headerConversionDict, headerList)
  
  #Get Entries  
  GetEntryList(busSheet, headerList, outBusList)
  
  # Remove hz from sample rate
  for dict in outBusList :
    dict['sample_rate'] = dict['sample_rate'].split(' ')[0]
    
  #GenerateUID(outBusList)  
    
  
### [END] ### : def ParseBusSheet ( busSheet, outBusList, globalDict) :

# Dependencies :
#   global
#   bus
def ParseBusRoutingSheet ( busRoutingSheet, outBusConnectionList, busList, globalDict) :

  # entry xls header : ( xml property, to lowercase, convert decimal point, mandatory)
  headerConversionDict = { 'Origin Bus' : ( 'inbus', 0, 0, 1), 'Target Bus' : ('outbus', 0, 0, 1), 'Dry Gain (dB)' : ('dry_gain', 0, 1, 1), 'Wet Gain (dB)' : ('wet_gain', 0, 1, 1) }
  # entry (xlm property, col index, mandatory) 
  headerList = []

  #Get Header List
  GetHeaderList(busRoutingSheet, headerConversionDict, headerList)
  
  #Get Entries  
  tempList = []
  GetEntryList(busRoutingSheet, headerList, tempList)
  
  #check on bus
  busLabelDict = {}
  for bus in busList :
    busLabelDict[bus['label']]  = bus['label']
  
  for busConnection in tempList :
    if not busLabelDict.has_key(busConnection['inbus']):
      PrintError( "[" + busConnection['inbus'] + "] Error in bus '" + busConnection['inbus'] + "' is not a valid bus")
    elif not busLabelDict.has_key(busConnection['outbus']):
      PrintError( "[" + busConnection['inbus'] + "] Error out bus '" + busConnection['outbus'] + "' is not a valid bus" )
    else :
      outBusConnectionList.append(busConnection)
      
  #GenerateUID(outBusConnectionList) 

### [END] ### : ParseBusRoutingSheet ( busRoutingSheet, outBusConnectionList, busList, globalDict) :
  
# Dependencies :
#   global
#   bus
def ParseGroupSheet ( groupSheet, outGroupList, busList, globalDict ) :
  
  # entry xls header : ( xml property, to lowercase, convert decimal point, mandatory)
  headerConversionDict = { 'Name' : ( 'name', 0, 0, 1), 'Parent Group' : ('parent', 0, 0, 0), 'Entering Bus' : ('bus', 0, 0, 1),'Default Gain (dB)' : ('gain', 0, 1, 1), 'Default Enable' : ('enable', 1, 0, 1), '3D MODE' : ('mode3d', 1, 0, 0), 'Reference Distance' : ('refdistance', 0, 1, 0), 'Reference Distance' : ('refdistance', 0, 1, 0), 'Max Distance' : ('maxdistance', 0, 1, 0), 'Rolloff Factor' : ('rolloff', 0, 1, 0), 'Base gain (dB)' : ('basegain', 0, 1, 0), 'Min gain mod (dB)' : ('mingainmod', 0, 1, 0), 'Max gain mod (dB)' : ('maxgainmod', 0, 1, 0), 'Base pitch (cents)' : ('basepitch', 0, 1, 0), 'Min pitch mod (cents)' : ('minpitchmod', 0, 1, 0), 'Max pitch mod (cents)' : ('maxpitchmod', 0, 1, 0), 'Kill on resume' : ('killonresume', 1, 0, 0), 'Fade on play' : ('fadeonplay', 0, 1, 0), 'Fade on stop' : ('fadeonstop', 0, 1, 0)}
  # entry (xlm property, col index, mandatory) 
  headerList = []

  #Get Header List
  GetHeaderList(groupSheet, headerConversionDict, headerList)
  
  #Get Entries  
  tempList = []
  GetEntryList(groupSheet, headerList, tempList)
  
  #check parent
  groupLabelDict = {}
  for group in tempList :
    groupLabelDict[group['name']] = group['name']
  
  for group in tempList :
    if group['name'] == 'master' :
      outGroupList.append(group)
    else :
      if not groupLabelDict.has_key(group['parent']):
        PrintError( "[" + group['name'] + "] Error parent group '" + group['parent'] + "' is not a valid group")
      else :
        outGroupList.append(group)  
 
  tempList = outGroupList
  outGroupList = []
  
  #check on bus
  busLabelDict = {}
  for bus in busList :
    busLabelDict[bus['label']]  = bus['label']
  
  for group in tempList :
    if not busLabelDict.has_key(group['bus']):
      PrintError( "[" + group['name'] + "] Error parent bus '" + group['bus'] + "' is not a valid bus")
    else :
      outGroupList.append(group)
  
  #GenerateUID(outGroupList)    
      
### [END] ### : ParseBusRoutingSheet ( busRoutingSheet, outBusConnectionList, busList, globalDict) :
      
# Dependencies :
#   global
def ParsePriorityBankSheet ( priorityBankSheet, outBankList, globalDict ):

  # entry xls header : ( xml property, to lowercase, convert decimal point, mandatory)
  headerConversionDict = { 'Name' : ( 'label', 0, 0, 1), 'Max playbacks' : ('maxplaybacks', 1, 0, 0), 'Max playbacks Behaviour' : ('behaviour', 1, 0, 1), 'Threshold' : ('threshold', 1, 0, 0), 'Parent Bank' : ('parent', 0, 0, 0), 'Priority' : ('priority', 0,0,0) }
  # entry (xlm property, col index, mandatory) 
  headerList = []

  #Get Header List
  GetHeaderList(priorityBankSheet, headerConversionDict, headerList)
  
  #Get Entries  
  GetEntryList(priorityBankSheet, headerList, outBankList)
 
  #GenerateUID(outBankList)
  
### [END] ### : def ParsePriorityBankSheet ( priorityBankSheet, outBankList, globalDict ):  

def ParseGeneratedEvents ( outEventList, soundList) :  
  for sound in soundList :
    if sound.has_key('generateevent') :
      if len(sound['generateevent']) > 0 :
        if sound['generateevent'][0] == 'y' :
          event = {}
          event['label'] = 'ev_' + sound['label']
          event['type'] = 'playlist'
          event['value'] = sound['label']
          if sound.has_key('description') :
            event['description'] = sound['description']
          outEventList.append(event)
          
### [END] ### : def ParseGeneratedEvents ( outEventList, SoundList) :  

def GenerateIntegrationLog ( eventList, globalDict, filename) :
  configSheet = globalDict['CONFIG']
  
  textout = "<HTML><HEAD><title>" + configSheet['nameofgame'] + ' : Integration log' + '</title><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></HEAD><BODY>\n'
  textout = textout + '<p><table bgcolor="ff9988">\n'
  textout = textout + '<tr><td bgcolor="ffddcc"><strong>Name of game</strong></td><td bgcolor="ffeedd">' + configSheet['nameofgame'] + '</td></tr>\n'
  textout = textout + '<tr><td bgcolor="ffddcc"><strong>Console</strong></td><td bgcolor="fffcec">' + configSheet['console'] + '</td></tr>\n'
  textout = textout + '<tr><td bgcolor="ffddcc"><strong>Game version</strong></td><td bgcolor="ffeedd">' + configSheet['descriptorversion'] + '</td></tr>\n'
  textout = textout + '<tr><td bgcolor="ffddcc"><strong>Vox api version</strong></td><td bgcolor="fffcec">' + configSheet['apiversion'] + '</td></tr>\n'
  textout = textout + '</table></p>\n'
  
  textout = textout + '<p><table bgcolor="7799ff"><tr><td bgcolor="bbccff"><strong>Event label</strong></td><td bgcolor="bbccff"><strong>Description</strong></td></tr>\n'
  bgcolor = 'e4f4ff'
  for event in eventList :
    if event.has_key('description') :
      textout = textout + '<tr><td bgcolor="d8e8ff">' + event['label'] + '</td><td bgcolor="' + bgcolor + '">' + event['description'] + '</td></tr>\n'
    else :
      textout = textout + '<tr><td bgcolor="d8e8ff">' + event['label'] + '</td><td bgcolor="' + bgcolor + '">' + ' ' + '</td></tr>\n'
    if bgcolor == 'e4f4ff' :
      bgcolor = 'eefaff'
    else :
      bgcolor = 'e4f4ff'
  textout = textout + '</table></p>\n'  
  textout = textout + "</BODY></HTML>\n"
  
  reportfile = open(filename, "w")
  reportfile.write(textout)
  reportfile.close()

### [END] ### : def GenerateIntegrationLog ( eventList, filename) :

def StripUselessData ( soundList, eventList) :
  for sound in soundList : 
    if sound.has_key('generateevent') :
      del sound['generateevent']
    if sound.has_key('description') :
      del sound['description']

  for event in eventList :
    if event.has_key('description') :
      del event['description']

### [END] ### : def StripUselessData ( soundList, eventList) :

def GetEntryList( sheet, headerList, outEntryList) :
  # find table extents
  maxRow = 0
  maxCol = 0
  for val in sheet :
    if val[0] > maxRow : maxRow = val[0]
    if val[1] > maxCol : maxCol = val[1]  
  maxCol = maxCol + 1
  maxRow = maxRow + 1
  
  for line in range (2, maxRow) :
    labelPos = (line, 0)
    if sheet.has_key(labelPos) : 
      localDict = {}
      export = 1
      for (property, col, tolower, isDecimal, mandatory) in headerList :
        pos = (line, col)
        if property == "customparam" :
          strCustom = ""
          if sheet.has_key(pos) :
            strCustom = str(sheet[pos])
            for colCustom in range(col+1, maxCol) :
              posCustom = (line, colCustom)
              if sheet.has_key(posCustom) :
                strCustom = strCustom + "," + str(sheet[posCustom])
              else :
                break
            localDict[property] =  strCustom 
        else:
          if sheet.has_key(pos) :
            if property == "description" :
              val = sheet[pos].encode('utf-8')
            else :
              val = str(sheet[pos])
            if isDecimal == 1 :
              val = val.replace(",", ".")
              
            if tolower == 1 : 
              localDict[property] = val.lower()
            else :
              localDict[property] = val            
          else :
            if mandatory == 1 :
              export = 0
              PrintError("[" + str(sheet[labelPos]) + "] Missing mandatory property  " + property + " at line " + str(line))
        
      if export == 1 : 
        outEntryList.append(localDict)
 
### [END] ### :  def GetEntryList( sheet, headerList, outEntryList) :     
          
################################################################################
#
# GetHeaderList
# in :
#   sheet list containing an excel data
#   headerDist dictionnary containing the column header identifier and information to convert to XML property. Entry = xls header : ( xml property, to lowercase, mandatory)
# out :
#   outHeaderList List containing tuple for xml exporting.  Entry = (xlm property, col index, tolower, mandatory)
#
################################################################################
def GetHeaderList( sheet, headerDict, outHeaderList) :
  # find table extents
  maxRow = 0
  maxCol = 0
  for val in sheet :
    if val[0] > maxRow : maxRow = val[0]
    if val[1] > maxCol : maxCol = val[1]  
  maxCol = maxCol + 1
  maxRow = maxRow + 1
  
  if g_extraVerbose == 1:
    print "Fetching column from sheet"
    for key in headerDict.keys() :
      (label, tolower, isDecimal, mandatory) = headerDict[key]
      print "\t" + key
      print "\t\tLabel : " + label
      if tolower == 1 :
        print "\t\tTo lower : true"
      else :     
        print "\t\tTo lower : false" 
      if isDecimal == 1:
        print "\t\tIs decimal : true"
      else :     
        print "\t\tIs decimal : false" 
      if mandatory == 1 :
        print "\t\tMandatory : true"
      else :     
        print "\t\tMandatory : false"
      
  for col in range (0, maxCol) :
    pos = (1, col)
    if sheet.has_key(pos):
      if headerDict.has_key(sheet[pos]) :
        property = headerDict[str(sheet[pos])][0]
        tolower = headerDict[str(sheet[pos])][1] 
        isDecimal = headerDict[str(sheet[pos])][2] 
        mandatory = headerDict[str(sheet[pos])][3]
        outHeaderList.append((property, col, tolower, isDecimal, mandatory))    

### [END] ### :  GetHeaderList( sheet, headerDict, outHeaderList) : 

def GenerateUID( itemDictList ) :
  if g_generateUID == 1:
    index = g_offsetUID
    for item in itemDictList :
      item['uid'] = str(index)
      index = index + 1

def PrintItem( itemList ) :
  count = 0
  for item in itemList :
    keys = sorted(item)
    print "Item " + str(count) + " :"
    for key in keys :
      print "\t" + key + " : " + item[key]
    count = count + 1

################################################################################

import ctypes

# Constants from the Windows API
STD_OUTPUT_HANDLE = -11
FOREGROUND_RED    = 0x0004 | 0x0008 # text color contains bright red.
FOREGROUND_YELLOW = 0x0006 | 0x0008 # text color contains bright yellow.
FOREGROUND_WHITE  = 0x0007 | 0x0008 # text color contains bright white.

def get_csbi_attributes(handle):
    # Based on IPython's winconsole.py, written by Alexander Belchenko
    import struct
    csbi = ctypes.create_string_buffer(22)
    res = ctypes.windll.kernel32.GetConsoleScreenBufferInfo(handle, csbi)
    assert res

    (bufx, bufy, curx, cury, wattr,
    left, top, right, bottom, maxx, maxy) = struct.unpack("hhhhHhhhhhh", csbi.raw)
    return wattr

def PrintError(msg) :
  if g_consoleUseColor == 1:
    handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
    reset = get_csbi_attributes(handle)
    ctypes.windll.kernel32.SetConsoleTextAttribute(handle, FOREGROUND_RED)
    print msg
    ctypes.windll.kernel32.SetConsoleTextAttribute(handle, reset)
  else :
    print msg
    
  if g_stopOnError == 1 :
    print "Stop on error enabled, stopped exporting"
    exit(1)
  
def PrintWarning(msg) :
  if g_treatWarningAsError == 1:
    PrintError(msg)
  else :
    if g_consoleUseColor == 1:
      handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
      reset = get_csbi_attributes(handle)
      ctypes.windll.kernel32.SetConsoleTextAttribute(handle, FOREGROUND_YELLOW)
      print msg
      ctypes.windll.kernel32.SetConsoleTextAttribute(handle, reset)  
    else :
      print msg
  
def PrintMessage(msg) :
  if g_consoleUseColor == 1:
    handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
    reset = get_csbi_attributes(handle)
    ctypes.windll.kernel32.SetConsoleTextAttribute(handle, FOREGROUND_WHITE)
    print msg
    ctypes.windll.kernel32.SetConsoleTextAttribute(handle, reset)  
  else :
    print msg

#
# XML helper functions
#

def pynativeToDomElement( dom, data ):
    (elemName,attributes,children) = data
    elem = dom.createElement(elemName)
    for (attr,val) in attributes.items() :
        elem.setAttribute(attr,val)
    for child in children :
        elem.appendChild( pynativeToDomElement(dom,child) )
    return elem

#
#

def exportSoundPackXML( filename, soundData ) : 
    dom = xml.dom.minidom.parseString( "<soundpack/>" )
    doc = dom.documentElement
    for section in soundData :
        doc.appendChild(pynativeToDomElement(dom,section))  
    #print dom.toprettyxml()
    f = open(filename,'wb')
    f.write( dom.toprettyxml() )

def SoundpackExporter(commandline):
    ParseCommandLine(commandline)

    sheetDict = {}    
    globalDict = {}
    busList = []
    busConnectionList = []
    bankList = []
    groupList = []
    sfxList = []
    vfxList = []
    musicList = []
    soundList = []
    realEventList = []
    generatedEventList = []
    eventList = []
        
    RetrieveXLSSheets( g_inputFile, sheetDict)
    ParseConfigSheet( sheetDict['CONFIG'], globalDict)

    configSheet = globalDict['CONFIG']
    
    if CheckVersion(configSheet['apiversion']) == 0 :
      PrintError("Fatal error : Exporter verions " + str(API_VERSION) + " not compatible with xls file version " +  configSheet['API Version'] )
      exit(1)
      
    if g_quietMode == 0:
      PrintMessage("Exporting Priority banks")
    ParsePriorityBankSheet( sheetDict['BANK_PRIORITY'], bankList, globalDict)
    if g_printItems == 1 :
      PrintItem(bankList)
    
    if g_quietMode == 0:
      PrintMessage("Exporting Buses")
    ParseBusSheet( sheetDict['BUS'], busList, globalDict)
    if g_printItems == 1 :
      PrintItem(busList)
    
    #if g_quietMode == 0:
    #  PrintMessage("Exporting Bus Connections")
    #ParseBusRoutingSheet( sheetDict['BUS_ROUTING'], busConnectionList, busList, globalDict)
    #if g_printItems == 1 :
    #  PrintItem(busConnectionList)
    
    if g_quietMode == 0:
      PrintMessage("Exporting Groups")
    ParseGroupSheet( sheetDict['GROUP'], groupList, busList, globalDict)
    if g_printItems == 1 :
      PrintItem(groupList)
    
    if g_quietMode == 0:
      PrintMessage("Exporting SFX")
    ParseSoundSheet ( sheetDict['SFX'], sfxList, groupList, bankList, busList, globalDict)
    if g_printItems == 1 :
      PrintItem(sfxList)
     
    if g_quietMode == 0:
      PrintMessage("Exporting VOICE OVER")
    ParseSoundSheet ( sheetDict['VOICE_OVER'], vfxList, groupList, bankList, busList, globalDict)
    if g_printItems == 1 :
      PrintItem(vfxList)
    
    if g_quietMode == 0:
      PrintMessage("Exporting MUSIC")
    ParseSoundSheet ( sheetDict['MUSIC'], musicList, groupList, bankList, busList, globalDict)      
    if g_printItems == 1 :
      PrintItem(musicList)
    
    soundList.extend(sfxList)
    soundList.extend(vfxList)
    soundList.extend(musicList)
   
    if g_quietMode == 0:
      PrintMessage("Exporting EVENTS")
    ParseEventSheet ( sheetDict['EVENT'], realEventList, soundList, globalDict)
    if g_printItems == 1 :
      PrintItem(realEventList)

    # Add generated events
    if g_quietMode == 0:
      PrintMessage("Exporting GENERATED EVENTS")
    ParseGeneratedEvents ( generatedEventList, soundList)

    eventList.extend(realEventList)
    eventList.extend(generatedEventList)
    
    # Generate integration log
    if g_generateLog == 1:
      if g_quietMode == 0:
        PrintMessage("Writing integration log")
      GenerateIntegrationLog ( eventList, globalDict, g_logFile )   

    # Strip extra data
    StripUselessData ( soundList, eventList)
    
    # Convert to fit with data structure of XML writer          
    soundParam = {}
    soundParam['size'] = str(len(soundList))
    soundEntries = []
    for sound in soundList :
      soundEntries.append(('sound', sound, []))
    
    bankParam = {}
    bankParam['size'] = str(len(bankList))
    bankEntries = []
    for bank in bankList :
      bankEntries.append(('bank', bank, []))
      
    groupParam = {}
    groupParam['size'] = str(len(groupList))
    groupEntries = []
    for group in groupList :
      groupEntries.append(('group', group, []))
      
    eventParam = {}
    eventParam['size'] = str(len(eventList))  
    eventEntries = []
    for event in eventList :
      eventEntries.append(('event', event, []))
      
    #busParam = {}
    #busParam['size'] = str(len(busList)) 
    #busEntries = []
    #for bus in busList :
    #  busEntries.append(('bus', bus, []))
         
    #busConnectionParam = {}
    #busConnectionParam['size'] = str(len(busConnectionList))  
    #busConnectionEntries = []
    #for busConnection in busConnectionList :
    #  busConnectionEntries.append(('busconnection', busConnection, []))  
    
    #soundData = [('config', globalDict['CONFIG'], []), ('sounds', soundParam, soundEntries), ('groups', groupParam, groupEntries), ('banks', bankParam, bankEntries), ('events', eventParam, eventEntries), ('buses', busParam, busEntries), ('busconnections', busConnectionParam, busConnectionEntries) ] 
    soundData = [('config', globalDict['CONFIG'], []), ('sounds', soundParam, soundEntries), ('groups', groupParam, groupEntries), ('banks', bankParam, bankEntries), ('events', eventParam, eventEntries) ]
    
    exportSoundPackXML(g_outputFile,  soundData)
    #parseSoundPackXLS( infile, globalDict )
  
    
if __name__ == '__main__':
    SoundpackExporter(sys.argv)
    
