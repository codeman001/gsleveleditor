#pragma once

#ifndef _STDAFX_H_
#define _STDAFX_H_

// System Header File
#include <new>

#ifdef _WIN32
#if VOX_DEBUG_SERVER_ENABLE
#include <winsock2.h>
#endif
#define WIN32_LEAN_AND_MEAN
#define VC_EXTRALEAN
#include <windows.h>
#endif

#include <string.h>
#include <cstring>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cstdio>
#include <cstdarg>

// Vox interface definition
// External interface - must not change with vox_config.h
#include <vox.h>
#include <vox_types.h>
#include <vox_filesystem.h>
#include <vox_memory.h>
#include <vox_mutex.h>
#include <vox_thread.h>
#include <vox_decoder.h>
#include <vox_stream.h>
#include <vox_driver.h>


#endif
