#pragma once
#ifndef _VOX_H_
#define _VOX_H_

// #include "vox_default_config.h"
#include "vox_types.h"

//! Main namespace for Vox Audio Engine
namespace vox {

// #ifndef VOX_THREADING_MODE_NONE
class VoxThread;
// #endif
class Mutex;

class Handlable;

class Handle;
class EmitterHandle;

class VoxEngine;
class VoxEngineInternal;

class StreamInterface;
typedef StreamInterface* (*StreamTypeFactoryFnPtr)(void* params);

class DecoderInterface;
typedef DecoderInterface* (*DecoderTypeFactoryFnPtr)(void* params);

typedef s64 HandleId;

class DataHandleUserData;
class EmitterHandleUserData;


class CustomDSP;

//! Official Vox Audio Engine supported stream type
enum StreamTypes
{
	k_nStreamTypeInvalid = -1,  //!< Invalid/Unrecognized stream type
	k_nStreamTypeMemoryBuffer,  //!< Ram buffer
	k_nStreamTypeCFile,         //!< Internal file system file pointer (similar to C file pointer)
	
	// Add shared stream types here, then add dispatch code in Initialize().
	// Note: You can alternatively add new types through 'RegisterStreamType()', if you need game-specific stuff.

	k_nStreamTypeCount //!< Count of officially supported stream type
};

//! Official Vox Audio Engine supported encoding format type
enum FormatTypes
{
	k_nDecoderTypeInvalid = -1, //!< Invalid/Unrecognized encoding format
	k_nDecoderTypeRAW, //!< Raw PCM encoding
	k_nDecoderTypeMSWav, //!< Wave container encoding (sub decoder support PCM and IMA/DVI-ADPCM)
	k_nDecoderTypeStbVorbis, //!< Vorbis encoding 
	k_nDecoderTypeMPC8,	//!< Musepack version 8 encoding (legacy support of Musepack version 7)
	k_nDecoderTypeInteractiveMusic, //!< Vox Interactive Music format (VXN)
	k_nDecoderTypeBCWav, //!< CTR format compatible with hardware decoder
	
	// Add shared decoder types here, then add dispatch code in Initialize().
	// Note: You can alternatively add new types through 'RegisterDecoderType()', if you need game-specific stuff.

	k_nDecoderTypeCount	//!< Count of officially supported encoding format type
};

// Groups have been completely overhauled!
// Now the only preset group is named "master" and has id 0
// Other groups have to be defined by the user
// using the RegisterGroup function.
#define VOX_GROUP_MASTER_ID ((vox::u32)0)
#define VOX_GROUP_INVALID_ID 0xFFFFFFFF

/*!
	\brief Namespace for distance attenuation model
	\details See OpenAL specification 1.1 for more details on distance attenuation models
	<br>Distance is clamped to [ReferenceDistance, MaxDistance]
*/
namespace Vox3DDistanceModel
{
	enum
	{
		k_nNone=0, //!< All 3d is not computed (Not supported on OpenAL driver)
		k_nInverseDistanceClamped, //!< \f$ GainModifier = \frac{ReferenceDistance}{ReferenceDistance + RolloffFactor * (distance - ReferenceDistance)} \f$
		k_nLinearDistanceClamped, //!< \f$ GainModifier = 1 - \frac{RolloffFactor * (distance - ReferenceDistance)}{MaxDistance - ReferenceDistance} \f$
		k_nExponentDistanceClamped //!< \f$ GainModifier = (\frac{distance}{ReferenceDistance})^{-ReferenceDistance} \f$
	};
}

struct Vox3DEmitterParameters
{
    Vox3DEmitterParameters();

	s32		relativeToListener;   // default 0 (false). Other values: 1 (true), -1 (disable all 3d)
	f32		maxDistance;			// default MAX_FLOAT
	f32		referenceDistance;	// default 1.0f
	f32		rolloffFactor;		// default 1.0f
	f32		innerConeAngle;		// default 360.0f
	f32		outerConeAngle;		// default 360.0f
	f32		outerConeGain;		// default0.0f
};

//! Namespace for emitter 3D parameter ids
/*
	See OpenAL specification 1.1 for more detail on each parameter
*/
namespace Vox3DEmitterParameter
{
	enum
	{
		k_nRelativeToListener=0, //!< Emitter position is world coordinate (0) or listener coordinate (1) <b>Default : 0</b>
		k_nMaxDistance, //!< Emitter maximum distance <b>Default : MAX_FLOAT</b>
		k_nReferenceDistance, //!< Emitter reference distance <b>Default : 1</b>
		k_nRolloffFactor, //!< Emitter rolloff factor <b>Default : 1</b>
		k_nInnerConeAngle, //!< Emitter inner cone angle <b>Default : 360.0f</b>
		k_nOuterConeAngle, //!< Emitter outer cone angle <b>Default : 360.0f</b>
		k_nOuterConeGain, //!< Emitter outer cone gain <b>Default : 0.0f</b>
		k_nPosition, //!< Emitter position  <b>Default : {0.0f, 0.0f, 0.0f} </b>
		k_nVelocity, //!< Emitter velocity  <b>Default : {0.0f, 0.0f, 0.0f} </b>
		k_nDirection, //!< Emitter direction <b>Default : {0.0f, 0.0f, 0.0f} </b>
		k_nCount//param count
	};
}

struct Vox3DGeneralParameters
{
	Vox3DGeneralParameters();

	f32 dopplerFactor;    // Default 1.0f
	f32 speedOfSound;     // Default 343.3f
	u32 distanceModel;    // Default InverseDistanceClamped
	u32 enhanced3d; // Default 0

	// See vox_default_config.h for the defaults of the following
	f32 enhanced3dStereoPanningPower;
	f32 enhanced3dStereoMaxDelayFront;
	f32 enhanced3dStereoMaxDelayBack;
	
	f32 enhanced3dNotchDepth;
	f32 enhanced3dNotchDepthSide;
	f32 enhanced3dNotchDepthBack;
	f32 enhanced3dNotchDepthDistance;

	f32 enhanced3dNotchWidth;
	f32 enhanced3dNotchWidthSide;
	f32 enhanced3dNotchWidthBack;
	f32 enhanced3dNotchWidthDistance;

	f32 enhanced3dDistanceWidthMinimum;
	f32 enhanced3dDistanceWidthMaximum;
	f32 enhanced3dDistanceWidthCurve;
	f32 enhanced3dDistanceWidthSide;
	f32 enhanced3dDistanceWidthBack;
	f32 enhanced3dDistanceFrequency;

	f32 enhanced3dRolloffFactor;

};


//! Namespace for emitter DSP parameter ids
namespace VoxDSPEmitterParameter
{
	enum
	{
		k_nBusId //!< String id of bus to use for the emitter
	};


}

//! Namespace for general 3D parameter ids
/*
	See OpenAL specification 1.1 for more detail on each parameter
*/
namespace Vox3DGeneralParameter
{
	enum
	{
		k_nDopplerFactor=0, //!< Factor to apply to doppler shift. <b>Default 1.0f</b>
		k_nSpeedOfSound,	//!< Speed of sound in meter per second. <b>If the unit uses for listener and emitter velocity is different, this value must be changed accordingly.</b> <b>Default 343.3f</b>
		k_nDistanceModel,	//!< Model of distance attenuation <b>Default : Vox3DDistanceModel::k_nInverseDistanceClamped</b>
		k_nEnhanced3d,      //!< Runtime switch to front/back and up/down 3d enhancement filters on(1) or off(0). <b>Default : 0</b>
		k_nListenerPosition, //!< Listener position <b>Default { 0.0f, 0.0f, 0.0f }</b>
		k_nListenerVelocity, //!< Listener velocity <b>Default { 0.0f, 0.0f, 0.0f }</b>
		k_nListenerOrientation, //!< Listener orientation <b>Default {{ 0.0f, 1.0f, 0.0f }, { 0.0f, 0.0f, -1.0f }}</b>

		k_nEnhanced3dStereoPanningPower,
		k_nEnhanced3dStereoMaxDelayFront,
		k_nEnhanced3dStereoMaxDelayBack,
	
		k_nEnhanced3dNotchDepth,
		k_nEnhanced3dNotchDepthSide,
		k_nEnhanced3dNotchDepthBack,
		k_nEnhanced3dNotchDepthDistance,

		k_nEnhanced3dNotchWidth,
		k_nEnhanced3dNotchWidthSide,
		k_nEnhanced3dNotchWidthBack,
		k_nEnhanced3dNotchWidthDistance,

		k_nEnhanced3dDistanceWidthMinimum,
		k_nEnhanced3dDistanceWidthMaximum,
		k_nEnhanced3dDistanceWidthCurve,
		k_nEnhanced3dDistanceWidthSide,
		k_nEnhanced3dDistanceWidthBack,
		k_nEnhanced3dDistanceFrequency,

		k_nEnhanced3dRolloffFactor,

		k_nCount//param count
	};
}

//! Namespace for general DSP parameter ids
namespace VoxDSPGeneralParameter
{
	//! Routing path type
	enum BusRoutingType
	{
		k_nDry, //!< Dry path
		k_nWet, //!< Wet path
		k_nWetAndDry //!< Dry and Wet path
	};

	enum
	{
		k_nRoutingVolume, //!< Routing path volume
		k_nDSPModuleParameter
	};

	//! Minibus parameters
	enum Minibus
	{
		k_nDSPPresence //!< Order to remove DSP (when used in a Set..()). Is DSP removed (when used in a Get..()).
	};
}



enum VoxOutputMode
{
	k_nOutputModeUnknown = -1,
	k_nOutputModeMono,
	k_nOutputModeStereo,
	k_nOutputModeSurround
};

#define VOX_BANK_INVALID_ID 0xFFFFFFFF

namespace priority_bank
{
//! Behaviour of the priority bank is full
enum Behaviour
{
	B_STEAL_OLDEST, //!< New emitter will steal oldest emitter slot
	B_STEAL_LOWEST_PRIORITY, //!< New emitter will steal emitter slot with lowest priority, if lower than his
	B_STEAL_LOWEST_PRIORITY_OLDEST, //!< New emitter will steal emitter slot with lowest priority, if lower than his or the oldest slot with the same priority
	B_STEAL_QUIETEST, //!< New emitter will steal the quietest emitter, if more attenuated than itself
	B_DO_NOTHING //!< New emitter will not play
};//enum Behaviour
}//namespace priority_bank


//! Loading flags for data source of StreamType k_nStreamTypeCFile
enum VoxSourceLoadingFlags
{
	//Loading flags
	k_nNone = 0, //!< Normal streaming mode
	k_nLoadToRam = 0x0001, //!< Load the file to a buffer in ram (StreamType changed to k_nStreamTypeMemoryBuffer)
	k_nLoadToRamAndDecode = 0x0002, //!< Decode the file to a buffer in ram (StreamType changed to k_nStreamTypeMemoryBuffer, DecoderType changed to k_nDecoderTypeRAW)
	k_mLoadFlagMask = 0xFFFF, //!< Mask for basic loading flag

	//Other Flags
	k_nAsync = 0x00010000, //!< Optional flags to postpone data source loading to next UpdateSources call
	k_mOtherFlags = 0xFFFF0000, //!< Mask for optional loading flags

	//Mixed Flags
	k_nAsyncLoadToRam = k_nAsync | k_nLoadToRam, //!< k_nAsync + k_nLoadToRam
	k_nAsyncLoadToRamAndDecode = k_nAsync | k_nLoadToRamAndDecode //!< k_nAsync + k_nLoadToRamAndDecode
};

//! Observable emitter state flags
enum EmitterExternState
{
	//state
	k_nError	=   0x00, //!< Emitter is in error
	k_nPlaying	=	0x01, //!< Emitter is playing
	k_nPaused	=	0x02, //!< Emitter is paused
	k_nStopped	=	0x04, //!< Emitter is stopped

	//sub-state
	k_nFadingIn	=	0x10, //!< Emitter volume is fading in
	k_nFadingOut=	0x20 //!< Emitter volume is fading out
};

//! Callback definition for emitter state changed callback
/*!
	\param handle Handle of the emitter
	\param userData User data sent during callback
	\param state Current state of the emitter (main state only)
*/
typedef void (*VoxEmitterStateChangedCallbackFunc) (EmitterHandle &handle, void* userData, EmitterExternState state); 

struct VoxVector3f
{
	f32 x, y, z;
	VoxVector3f():x(0), y(0), z(0){}
	VoxVector3f(f32 _x, f32 _y, f32 _z):x(_x), y(_y), z(_z){}
	VoxVector3f(f32* fv):x(fv[0]), y(fv[1]), z(fv[2]){}
	void ToArray(f32* fv){fv[0]=x;fv[1]=y;fv[2]=z;}
};

//! Namespace for emitter CreationSettings
namespace emitter
{

struct CreationSettings
{
	CreationSettings();
	CreationSettings(f32 gain, f32 pitch, u32 groupId, s32 priority, u32 prorityBankId);

	void SetRandomGain(f32 minimumRandomGain, f32 maximumRandomGain, bool enable = true);
	void SetRandomPitch(f32 minimumRandomCents, f32 maximumRandomCents, bool enable = true);

	//gain
	f32 m_gain;
	f32 m_minimumRandomGainRatio;
	f32 m_maximumRandomGainRatio;
	bool m_enableRandomGain;

	//Pitch
	f32 m_pitch;
	f32 m_minimumRandomPitchCents;
	f32 m_maximumRandomPitchCents;
	bool m_enableRandomPitch;

	//Loop
	bool m_isLoop;

	//Group
	u32 m_groupId;

	//Bank
	u32 m_priorityBankId;
	s32 m_priority;

	//3d parameters
	bool m_is3d;
	Vox3DEmitterParameters m_pEmitter3DParameters;
	VoxVector3f m_pPosition;
	VoxVector3f m_pVelocity;
	VoxVector3f m_pDirection;

	// bus
	const char* m_busName;

	// misc
	bool m_killOnResume;
	float m_fadeOnPlay;
	float m_fadeOnStop;

	// uid (used by soundpackXML)
	s32 m_uid;

	vox::EmitterHandleUserData* m_pEmitterHandleUserData;
	VoxEmitterStateChangedCallbackFunc m_stateChangedCallback;
	void *m_pStateChangedCallbackUserData;

	s32 m_numCustomSound;//!< Custom parameter count
	c8 const * const * m_customSoundStr;//!< List of custom parameters
};

} // namespace emitter

//! Namespace for data source CreationSettings
namespace data_source
{
struct CreationSettings
{
	CreationSettings(s32 streamType, void* streamParams, s32 decoderType, void* decoderParams,  VoxSourceLoadingFlags loadingFlags);
	CreationSettings();

	s32 m_streamType;
	void* m_pStreamParams;
	s32 m_decoderType;
	void* m_pDecoderParams;
	VoxSourceLoadingFlags m_loadingFlags;

	s32 m_uid;
	u32 m_groupId;

	// GROUP???
	s32 m_numCustomSound;//!< Custom parameter count
	c8 const * const * m_customSoundStr;//!< List of custom parameters
};
} // namespace data_source


//! Namespace for group CreationSettings
namespace group
{
struct CreationSettings
{
	CreationSettings()
	{
		m_name = 0;
		m_parentId = 0;
		m_volume = 1;
		m_enable = true;
	}

	const c8* m_name;//!< Label of the group
	
	u32 m_parentId;
	f32 m_volume;
	bool m_enable;
};
} // namespace group

//! Namespace for priority bank CreationSettings and the behaviour enum
namespace priority_bank
{
struct CreationSettings
{
	CreationSettings()
	:m_name(0)
	,m_threshold(-(s32)2147483647) 
	,m_maxPlayback(0xFFFFFFFF) 
	,m_behaviour(priority_bank::B_DO_NOTHING)
	,m_parentBankId(0)
	,m_overrideChildPriority(false)
	,m_bankPriority(0)
	{}

	const c8* m_name;//!< Label of the bank

	s32 m_threshold;
	s32 m_maxPlayback;
	priority_bank::Behaviour m_behaviour;
	u32 m_parentBankId;
	bool m_overrideChildPriority;
	s32 m_bankPriority;
};
} // namespace priority_bank

///

class Handle
{
public:
	virtual ~Handle(){};
	Handle( const Handle &handle) : m_id(handle.m_id), m_timestamp(handle.m_timestamp), m_tsGroup(handle.m_tsGroup), m_pObject(handle.m_pObject), m_ppInternal(handle.m_ppInternal), m_debugPointerToObjectThatIsNotGaranteedToExistAnymore(handle.m_debugPointerToObjectThatIsNotGaranteedToExistAnymore){}

	bool operator==(const Handle &rhs) const;

protected:
	Handle(HandleId id, VoxEngineInternal** ppInternal = 0, Handlable* object = 0, u32 timestamp = 0, u32 tsGroup = 0) : m_id(id), m_timestamp(timestamp), m_tsGroup(tsGroup), m_pObject(object), m_ppInternal(ppInternal), m_debugPointerToObjectThatIsNotGaranteedToExistAnymore(object){}

protected:
	virtual HandleId GetId() const {return m_id;}
	virtual Handlable* GetObjectPointer() const {return m_pObject;};

	virtual void GetTimeStamp(u32 &timeStamp, u32 &tsGroup) const {timeStamp = m_timestamp;tsGroup = m_tsGroup;};
	virtual void SetTimeStamp(u32 timeStamp, u32 tsGroup){m_timestamp = timeStamp;m_tsGroup = tsGroup;};

protected:
	HandleId m_id;
	u32 m_timestamp;
	u32 m_tsGroup;
	Handlable* m_pObject;

	VoxEngineInternal** m_ppInternal;

	Handlable* m_debugPointerToObjectThatIsNotGaranteedToExistAnymore;
};

//! Opaque handle for data source object
class DataHandle : public Handle
{
public:
	virtual ~DataHandle();
	DataHandle( const DataHandle &handle);
	DataHandle(): Handle(-1){}
	DataHandle & operator=( const DataHandle &rhs);

protected:
	DataHandle(HandleId id, VoxEngineInternal** ppInternal = 0, Handlable* object = 0, u32 timestamp = 0, u32 tsGroup = 0);

	friend class Handlable;
	friend class HandlableContainer;
	friend class VoxEngineInternal;
	friend class VoxEngine;
};


//! Opaque handle for emitter object
class EmitterHandle : public Handle
{
public:
	virtual ~EmitterHandle();
	EmitterHandle( const EmitterHandle &handle);
	EmitterHandle(): Handle(-1){}
	EmitterHandle & operator=(const EmitterHandle &rhs);

protected:
	EmitterHandle(HandleId id, VoxEngineInternal** ppInternal = 0, Handlable* object = 0, u32 timestamp = 0, u32 tsGroup = 0);

	friend class Handlable;
	friend class HandlableContainer;
	friend class VoxEngineInternal;
	friend class VoxEngine;
};

// For VehicleSounds and other low latency sound generators
class MinibusDataGeneratorInterface
{
public:
	virtual ~MinibusDataGeneratorInterface()
	{
	}
	virtual void GetData(s32* buffer, s32 nbSample, s32 sampleRate)=0;
protected:
	 static fx1814	s_driverCallbackPeriod;
	 static s32		s_driverSampleRate;

	 friend class DriverCallbackSourceInterface;
};

// For microphone support
class RecordedAudioReceptor
{
public:
    virtual ~RecordedAudioReceptor(){}
    virtual void GetData(s16* buffer, s32 nbSample, s32 sampleRate, s32 numChannels)=0;
};

struct TrackParams
{
	s32 numChannels;
	s32 samplingRate;
	s32 bitsPerSample;
	u32 numSamples;

	TrackParams():numChannels(0), samplingRate(0), bitsPerSample(0), numSamples(0) {}

	void Reset(void)
	{
		numChannels = 0;
		samplingRate = 0;
		bitsPerSample = 0;
		numSamples = 0;
	}
};

//! Structure containing debug information
/*!
	\deprecated Application should now use debug server to get more accurate metrics
*/
struct DebugInfo
{
	s32 m_nDataSource; //!< Data source count
	s32 m_nEmitter; //!< Emitter count (all states)
	s32 m_nPlayingEmitter; //!< Emitter currently playing count
	s32 m_nApproxMem;
};

//
//
//


//! Vox Engine User Interface
/*!
	This class is the user interface to Vox Audio Engine.  The user first has to get a reference through
	the static method GetVoxEngine.  This class follow singleton design patern and can have up to one instance
	at the time.
*/
class VoxEngine
{
protected:
	VoxEngine();
	VoxEngine(void*):m_isInitialized(false){}//dummy ctor
public:
	~VoxEngine();

	//! Retrieve current VoxEngine singleton
	/*!
		If VoxEngine doesn't exist yet, it's created.
		\return Reference to current VoxEngine object.
	*/	
	static VoxEngine& GetVoxEngine();

	//! VoxEngine singleton destructor
	/*!
		If VoxEngine exist, it's destroyed.
	*/	
	static void DestroyVoxEngine();

public:

	//
	// Initialization methods
	//	

	//! Initialize Vox Engine
	/*!
		Initialize internal component of the Vox Engine
	*/	
	void Initialize();

	//! Shutdown Vox Engine
	/*!
		Internal shutdown of Vox Engine.  If thread are enabled, the threads are killed.
	*/	
	void Shutdown();

	//! Register a new stream type
	/*!
		This method allow to add game specific stream type, according they repect StreamInterface.
		\param fnPtr Pointer to the factory function to create Stream object of this type
		\return The stream id to use for loading data source with stream of this type.  If the maximum number of stream type is already reach or an error occur, -1 is returned.
	*/	
	s32  RegisterStreamType( StreamTypeFactoryFnPtr fnPtr);
	
	//! Register a new decoder type
	/*!
		This method allow to add game specific decoder type, according they repect DecoderInterface.
		\param fnPtr Pointer to the factory function to create Decoder object of this type
		\return The decoder id to use for loading data source with decoder of this type.  If the maximum number of decoder type is already reach or an error occur, -1 is returned.
	*/	
	s32  RegisterDecoderType( DecoderTypeFactoryFnPtr fnPtr);


	//! Add a priority bank
	/*!
		This method allows adding a priority bank.
		\param creationSettings Settings to which set the bank
		\return Id of the bank if allocated successfully, or VOX_BANK_INVALID_ID if not
	*/	
	u32 AddPriorityBank(priority_bank::CreationSettings &creationSettings);

	//! Configure an already existing priority bank
	/*!
		This method allows configuring a priority bank.
		\param id Id of bank to be reconfigured.
		\param creationSettings Settings to which set the bank. Note: the name and parentid settings cannot be reconfigured.
		\return True if the bank was configured successfully
	*/	
	bool ReconfigurePriorityBank(u32 id, priority_bank::CreationSettings &creationSettings);

	//! Find the id of a priority bank from name
	/*!
		\param name Name of bank to find the id of
		\return Id of bank if found, VOX_BANK_INVALID_ID if not
	*/	
	u32 GetPriorityBankIdFromName(const char *name);

	//
	// Microphone input methods
	//

	//! Set microphone callback and initialise microphone support
	/*!
		This method activates the microphone support and sets the
		RecordedAudioReceptor object used for receiving microphone data.
		Activating microphone input clicks on windows so you probably want
		to do it on startup. If the VOX_MICROPHONE_INPUT config option isn't set, this
		always returns false. Setting the VOX_MICROPHONE_INPUT on iphone
		will change your audio session type and the ringer/silence switch will not
		be able to mute the audio anymore!
		\param receptor Receptor object with the reception callback. If this is null, no callback is sent but the microphone support is still turned on.
		\return True if the sound input was configured successfully, false if there's no microphone input available or something failed.
	*/	
	bool SetMicrophoneCallback(RecordedAudioReceptor *receptor);

	//! Remove microphone callback and uninitialize microphone support
	/*!
		This method unactivates the microphone support (this causes half a second of silence
		on iPhone and the ringer/silent switch starts working again)
		and removes the microphone callback.
	*/	
	void RemoveMicrophoneCallback();

	//
	// Interruption methods
	//

	//! Suspend vox engine
	/*!
		This method suspends the vox engine. A counter is incremented each time the
		method is called and decremented each time ResumeEngine() is called. Actual
		resumption is effective when the counter gets to 0.
	*/	
	void SuspendEngine(void);

	//! Resume vox engine
	/*!
		This method resumes the vox engine. A counter is decremented each time the
		method is called and incremented each time SuspendEngine() is called. Actual
		resumption is effective when the counter gets to 0.
	*/	
	void ResumeEngine(void);

	//! Get engine suspension state
	/*!
		This method provides the suspension state resulting from SuspendEngine()
		and ResumeEngine() calls.
		\return True if the vox engine is suspended.
	*/	
	bool IsEngineSuspended(void);

public:

	//
	// Update methods
	//

	//! Update all data sources. Normally you will never need to call this, unless you set vox in non threaded mode.
	/*!
		This method update all data sources.  
		This is where data sources auto-release is done.  
		If VOX_THREAD_SAFETY_LEVEL is set to 1, this method can be used in an external thread.
	*/	
	void UpdateSources();

	//! Update all emitters. Normally you will never need to call this, unless you set vox in non threaded mode.
	/*!
		This method update all emitters.  This is the moment all command are actually sent to the hardware driver.  If the time interval between call is long, delay in commande execution is to be expected.  
		This is where emitter auto-release is done.  
		If VOX_THREAD_SAFETY_LEVEL is set to 1, this method can be used in an external thread.
		\param dt Time elapsed since last call (seconds)
	*/	
	void UpdateEmitters(f32 dt); // Playing ( can be on a separate thread )
	// Note: Both of these update methods can be placed in SEPARATE threads, so that loading can be done asynchronously.
	
	//! Update both data sources and emitters
	/*!
		This method first call UpdateSources, than UpdateEmitters.  In non-threaded implementation, calling this method should be enough.
		\param dt Time elapsed since last call (seconds)
	*/	

void Update(f32 dt);

private:
	//! Update method for single thread implementation loop
	/*!
		This method call UpdateThreaded then sleep for VOX_THREAD_UPDATE_DT ms, until thread is shutdown.
		\param caller Pointer to vox engine object
		\param param Parameter needed for VoxThread method signature <i>(unused)</i>
	*/	
	static void UpdateThreaded(void* caller, void* param);

	//! Data source update method for dual thread implementation loop
	/*!
		This method call UpdateSourcesThreaded then sleep for VOX_THREAD_UPDATE_DT ms, until thread is shutdown.
		\param caller Pointer to vox engine object
		\param param Parameter needed for VoxThread method signature <i>(unused)</i>
	*/	
	static void UpdateSourcesThreaded(void* caller, void* param);

	//! Emitter update method for dual thread implementation loop
	/*!
		This method call UpdateEmittersThreaded then sleep for VOX_THREAD_UPDATE_DT ms, until thread is shutdown.
		\param caller Pointer to vox engine object
		\param param Parameter needed for VoxThread method signature <i>(unused)</i>
	*/	
	static void UpdateEmittersThreaded(void* caller, void* param);


	//! Update data sources in dual thread implementation
	/*!
	*/
	void UpdateSourcesThreaded();

	//! Update emitters in dual thread implementation
	/*!
		This method keep track of update time and generate dt needed by UpdateEmitter
	*/
	void UpdateEmittersThreaded();

	//! Update both data sources and emitters in single thread implementation
	/*!
		This method first call UpdateSourcesThreaded, than UpdateEmittersThreaded.
	*/
	void UpdateThreaded();

	// No threading: the values are unused
	// Single threaded: only m_updateThread[0] is used
	// Double threaded: m_updateThread[0] and [1] are used
	VoxThread* m_updateThread[2];
	f64 m_lastUpdateTime;

public:
	//
	// Data methods
	//

	//! Create a data source
	/*!
		Create a data source according to the parameter received.  
		If there's an error during the data source creation, data source isn't created and an invalid handle is returned.
		\param creationSetting Data source creation settings to create the data source
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/
	DataHandle LoadDataSource( const data_source::CreationSettings& creationSettings);


	//! Create a data source
	/*!
		Create a data source according to the parameter received.  
		If there's an error during the data source creation, data source isn't created and an invalid handle is returned.
		\param streamType Id of the stream type for the data source
		\param streamParams Parameters to initialize the stream
		\param decoderType Id of the decoder type for the data source
		\param decoderParams Parameters to initialize the decoder
		\param groupId Default group for all emitter created with this data handle
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/
	DataHandle LoadDataSource( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, u32 groupId = VOX_GROUP_MASTER_ID );

	//! Create a data source
	/*!
		Create a data source according to the parameter received.  
		If there's an error during the data source creation, data source isn't created and an invalid handle is returned.
		\param streamType Id of the stream type for the data source
		\param streamParams Parameters to initialize the stream
		\param decoderType Id of the decoder type for the data source
		\param decoderParams Parameters to initialize the decoder
		\param groupName Default group for all emitter created with this data handle
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/
	DataHandle LoadDataSource( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, const char *groupName);

	//! Create a data source with asynchronous loading
	/*!
		Create a data source according to the parameter received.  
		If there's an error during the data source creation, data source isn't created and an invalid handle is returned.
		\param streamType Id of the stream type for the data source
		\param streamParams Parameters to initialize the stream
		\param decoderType Id of the decoder type for the data source
		\param decoderParams Parameters to initialize the decoder
		\param groupId Default group for all emitter created with this data handle
		\param loadingFlags Loading flags
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/
	DataHandle LoadDataSourceAsync( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, u32 groupId = VOX_GROUP_MASTER_ID, VoxSourceLoadingFlags loadingFlags = k_nAsync );

	//! Create a data source with asynchronous loading
	/*!
		Create a data source according to the parameter received.  
		If there's an error during the data source creation, data source isn't created and an invalid handle is returned.
		\param streamType Id of the stream type for the data source
		\param streamParams Parameters to initialize the stream
		\param decoderType Id of the decoder type for the data source
		\param decoderParams Parameters to initialize the decoder
		\param groupName Default group for all emitter created with this data handle
		\param loadingFlags Loading flags
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/
	DataHandle LoadDataSourceAsync( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, const char *groupName, VoxSourceLoadingFlags loadingFlags = k_nAsync );

	//! Create a new data source already decoded in a RAM buffer
	/*!
		Create a new data source with stream type k_nStreamTypeMemoryBuffer and decoder type k_nDecoderTypeRAW.  
		The data handle used for the conversion is not affected by this operation.
		\param handle Handle of the data source to convert
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/	
	DataHandle ConvertToRawSource(DataHandle &handle );

	//! Create a new data source in a RAM buffer
	/*!
		Create a new data source with stream type k_nStreamTypeMemoryBuffer without any decoding.  
		The data handle used for the conversion is not affected by this operation.
		\param handle Handle of the data source to convert
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/	
	DataHandle ConvertToRamBufferSource(DataHandle &handle );

	//! Set the user data linked to the data source
	/*!
		\param handle Handle of the data source to set the pointer to.
		\param data DataHandleUserData object containing user defined data.
	*/
	void SetUserData( DataHandle &handle, DataHandleUserData &data);
	
	//! Get the user data linked to the data source
	/*!
		\param handle Handle of the data source to get the user data from.
		\return DataHandleUserData as defined by user.  If no user data was defined or data source doesn't exist, defaut one is returned.
	*/	
	DataHandleUserData GetUserData( DataHandle &handle);

	//! Set the priority bank for the data source
	/*!
		\param handle Handle of the data source to set the priority bank.
		\param bankId Id of the bank to use.
	*/	
	void SetPriorityBankId( DataHandle &handle, u32 bankId);

	//! Set the priority bank for the emitter
	/*!
		\param handle Handle of the emitter to set the priority bank.
		\param bankId Id of the bank to use.
	*/	
	void SetPriorityBankId( EmitterHandle &handle, u32 bankId);

	//! Set unique numeric id for the sound entity
	/*!
		\param handle Handle of the data source to set the priority bank.
		\param Uid Id of the sound entity.
	*/
	void SetUid( DataHandle &handle, s32 Uid);

	//! Get unique numeric id for the sound entity
	/*!
		\param handle Handle of the data source to get the uid.
		\return Unique id of the sound entity.
	*/
	s32 GetUid( DataHandle &handle);

	//! Get unique numeric id for the emitter
	/*!
		\param handle Handle of the data source to get the uid.
		\return Unique id of the sound entity.
	*/
	s32 GetUid( EmitterHandle &handle);

	//! Release a data source
	/*!
		Release the data source associated with the data handle in real time.  This is a blocking method when thread are enabled.  
		All emitters associated with the data source are killed before the data source is released.
		\param handle Handle of the data source to release
	*/	
	void ReleaseDatasource( DataHandle &handle ); // Forced release, no matter what the ref count is. Emitters should die gracefully.

	//! Release all data source within a group and its childrens
	/*!
		Release all the data source within the group and its children in real time.  This is a blocking method when threads are enabled.  
		All emitters associated with a given data source are killed before the data source is released.
		\param groupId Group to apply the command to
	*/	
	void ReleaseDatasourceGroup(u32 groupId = VOX_GROUP_MASTER_ID); // Forced release, based on groups.

	//! Release all data source within a group and its childrens
	/*!
		Release all the data source within the group and its children in real time.  This is a blocking method when threads are enabled.  
		All emitters associated with a given data source are killed before the data source is released.
		\param groupName Group to apply the command to
	*/	
	void ReleaseDatasourceGroup(const char *groupName); // Forced release, based on groups.

	//! Test if a data source is valid and ready to receive command
	/*!
		\param handle Handle of the data source to test
		\return True if the data source is valid and ready to receive commands
	*/	
	bool IsReady( DataHandle &handle );

	//! Test if a data source is valid
	/*!
		\param handle Handle of the data source to test
		\return True if the data source is valid
	*/	
	bool IsValid( DataHandle &handle );

	//! Get the duration of the stream of the data source
	/*!
		\param handle Handle of the data source to get the duration
		\return Duration of the stream (seconds)
	*/	
	f32 GetDuration( DataHandle &handle );

	//! Get all current emitter for a data sources
	/*!
		Return up to bufferCount data source handles of current data sources.  These count as valid reference to data source. 
		\param handle Handle of the data source to get the emitters
		\param handlesBuffer Array to write emitter handles to 
		\param bufferCount Maximum emitter handles to write to array
		\return Actual number of emitter handles written to the array
	*/
	s32  GetEmitterHandles( DataHandle &handle, EmitterHandle* handlesBuffer, s32 bufferCount );

	//! Get all current data sources
	/*!
		Return up to bufferCount data source handles of current data sources.  These count as valid reference to data source. 
		\param handlesBuffer Array to write data source handles to 
		\param bufferCount Maximum data source handles to write to array
		\return Actual number of data source handles written to the array
	*/
	s32  GetAllDataSources( DataHandle* handlesBuffer, s32 bufferCount );

public:

	//
	// Emitter methods
	//

	//! Register a callback to notify of an emitter state changing
	/*!
		Register a state changed callback for an emitter with optional user
		data structure sent back when the callback occurs.  The state returned
		doesn't contain the substate, only the main state.  If emitter sending
		the callback has no reference, it might be already deleted when the 
		callback is sent.
		<br>
		<b>Note : The callback function should be thread-safe. It's best to keep 
		work light and avoid call to Vox Audio Engine methods during the 
		callback.</b>
		\param handle Handle of the emitter
		\param callback Function that will be called by when the state changes
		\param userData User data structure that will be available in callback
	*/
	void RegisterForEmitterStateChangeNotification( EmitterHandle &handle, VoxEmitterStateChangedCallbackFunc callback, void* userData = 0);

	//! Unregister a callback to notify of an emitter state changing
	/*!	
		Unregister a previously registered callback for an emitter state changed
		notification.
		<br>
		<b>Note : When Vox is in threaded mode, the callback may still be called
		one time after unregistering if the callback is currently in the 
		callback queue</b>
	*/
	void UnregisterForEmitterStateChangeNotification( EmitterHandle &handle);

	//! Create an active emitter from a data source 
	/*!
		Create an active emitter from the data source linked to the DataHandle. 
		If an error occurs during emitter creation, the emitter isn't created.
		\param handle DataHandle to the data source to use in the creation of the emitter
		\param creationSettings Structure containing all creation information
		\return Always return an EmitterHandle, but the handle return will not be link if the emitter wasn't created
	*/
	EmitterHandle CreateEmitter( DataHandle &handle, const emitter::CreationSettings &creationSettings);

	//! Create an active emitter from a data source 
	/*!
		Create an active emitter from the data source linked to the DataHandle. 
		If no more hardware source is available, will steal one from a lower priority emitter.
		If an error occurs during emitter creation, the emitter isn't created.
		\param handle DataHandle to the data source to use in the creation of the emitter
		\param priority Sound priority (natural number order). Only relevant if hardware source pooling is enabled.
		\param driverParam Parameter to overider the driver default parameter.  Must send the right type of parameter according to the active driver.
		\return Always return an EmitterHandle, but the handle return will not be link if the emitter wasn't created
	*/
	EmitterHandle CreateEmitter( DataHandle &handle, s32 priority = 0, void* driverParam = 0);

	//! Create an active emitter from a data source asynchronously
	/*!
		Create an active emitter from the data source linked to the DataHandle. 
		If no more hardware source is available, will steal one from a lower priority emitter.
		If an error occurs during emitter creation, the emitter isn't created.
		When using this method, some of the creation process is deferred to the first update, some commands on the emitter handle return might not work before the emitter is ready.
		\param handle DataHandle to the data source to use in the creation of the emitter
		\param creationSettings Structure containing all creation information
		\return Always return an EmitterHandle, but the handle return will not be link if the emitter wasn't created
	*/
	EmitterHandle CreateEmitterAsync( DataHandle &handle, const emitter::CreationSettings &creationSettings);

	//! Create an active emitter from a data source asynchronously
	/*!
		Create an active emitter from the data source linked to the DataHandle. 
		If no more hardware source is available, will steal one from a lower priority emitter.
		If an error occurs during emitter creation, the emitter isn't created.
		When using this method, some of the creation process is deferred to the first update, some commands on the emitter handle return might not work before the emitter is ready.
		\param handle DataHandle to the data source to use in the creation of the emitter
		\param priority Sound priority (natural number order). Only relevant if hardware source pooling is enabled.
		\param driverParam Parameter to overider the driver default parameter.  Must send the right type of parameter according to the active driver.
		\return Always return an EmitterHandle, but the handle return will not be link if the emitter wasn't created
	*/
	EmitterHandle CreateEmitterAsync( DataHandle &handle, s32 priority = 0, void* driverParam = 0);

	//! Set the user data linked to the emitter
	/*!
		\param handle Handle of the emitter to set the pointer to.
		\param data EmitterHandleUserData object containing user defined data.
	*/	
	void SetUserData( EmitterHandle &handle, EmitterHandleUserData &data);
	
	//! Get the user data linked to the emitter
	/*!
		\param handle Handle of the emitter to get the user data from.
		\return EmitterHandleUserData as defined by user.  If no user data was defined or emitter doesn't exist, defaut one is returned.
	*/	
	EmitterHandleUserData GetUserData( EmitterHandle &handle);

	//! Kill an active emitter 
	/*!
		Kill an active emitter in real time.  In threaded implementation, this method can block will waiting for 
		write access to the emitter list.  This method stop the playback of the emitter.
		\param handle EmitterHandle to the emitter to kill
	*/
	void KillEmitter( EmitterHandle &handle ); // Forced release, immediate stop.

	//! Get the data source used by the emitter
	/*!
		Get the data source used in the creation of the emitter.
		\param handle EmitterHandle to the emitter
		\return DataHandle to the the data source
	*/
	DataHandle GetData(EmitterHandle &handle);

	//! Play the emitter associated with the handle
	/*!
		The playback cursor is rewind to the start of the sound source.
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to play
		\param loop Initial looping state of the emitter
		\param fadeTime Duration of the fade in (seconds)
	*/
	void  Play( EmitterHandle &handle, bool loop, f32 fadeTime);

	//! Play the emitter associated with the handle
	/*!
		The playback cursor is rewind to the start of the sound source.
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to play
		\param loop Initial looping state of the emitter
	*/
	void  Play( EmitterHandle &handle, bool loop);

	//! Play the emitter associated with the handle
	/*!
		The playback cursor is rewind to the start of the sound source.
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to play
		\param fadeTime Duration of the fade in (seconds)
	*/
	void  Play( EmitterHandle &handle, f32 fadeTime);

	//! Play the emitter associated with the handle
	/*!
		The playback cursor is rewind to the start of the sound source.
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to play
	*/
	void  Play( EmitterHandle &handle );

	//! Stop the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to stop
		\param fadeTime Duration of the fade out (seconds)
	*/
	void  Stop( EmitterHandle &handle, f32 fadeTime);

	//! Stop the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to stop
	*/
	void  Stop( EmitterHandle &handle);

	//! Pause the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to pause
		\param fadeTime Duration of the fade out (seconds)
	*/
	void  Pause( EmitterHandle &handle, f32 fadeTime);

	//! Pause the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to pause
	*/
	void  Pause( EmitterHandle &handle);

	//! Resume the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.  
		Only a source in "paused" state can resume.
		\param handle Handle of the emitter to pause
		\param fadeTime Duration of the fade in (seconds)
	*/
	void  Resume( EmitterHandle &handle, f32 fadeTime);

	//! Resume the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.  
		Only a source in "paused" state can resume.
		\param handle Handle of the emitter to pause
	*/
	void  Resume( EmitterHandle &handle);

	//! Return the current playback position of a cursor
	/*!
		If the emitter is currently playing the precision of the value return is dependent of the hardware driver.
		\param handle Handle of the emitter to get position from
		\return Position of the playback (seconds)
	*/
	f32 GetPlayCursor( EmitterHandle &handle );

	//! Set the current playback position of a cursor
	/*!
		If the emitter is currently playing, the playback is first stopped, than the position is set and the emitter playback start again.  
		Setting play cursor on a playing source may result in clicking sound of short interruption in the sound playback.
		On a looping emitter, setting the cursor farther then the end of the stream will loop back and continue to advanced to the desired position.
		On non-looping emitter, the cursor will stop at the end.
		\param handle Handle of the emitter to set position to
		\param time Position, in seconds, to set the cursor to
	*/
	void  SetPlayCursor( EmitterHandle &handle, f32 time = 0.0f );
	
	//! Test if an emitter is valid and ready to accept a command
	/*!
		\param handle Handle of the emitter to test
		\return True if the handle is associated with a valid emitter ready to received a command.
	*/
	bool  IsReady( EmitterHandle &handle );

	//! Test if a emitter is valid
	/*!
		\param handle Handle of the emitter to test
		\return True if the emitter is valid
	*/	
	bool IsValid( EmitterHandle &handle );

	//! Test if an emitter is valid and not in the process of being deleted
	/*!
		\param handle Handle of the emitter to test
		\return True if the handle is associated with a valid emitter ready to received a command and not waiting to be deleted.
	*/
	bool  IsAlive( EmitterHandle &handle );

	//! Test if an emitter is currently playing
	/*!
		\param handle Handle of the emitter to test
		\return True if the handle is associated with a valid emitter currently playing.
	*/
	bool  IsPlaying( EmitterHandle &handle );

	//! Test if an emitter playback has ended
	/*!
		\param handle Handle of the emitter to test
		\return True if the handle is associated with a valid emitter currently in "stopped" state.
	*/
	bool  IsDone( EmitterHandle &handle );

	//! Return an extended state for the emitter
	/*!
		\param handle Handle of the emitter to test
		\return Extended state of the emitter
	*/
	u32 GetStatus( EmitterHandle &handle );

	//! Add a group
	/*!
		This adds a group for data sources and emitters
		\param creationSettings Structure containing info on how to setup the group.
		\return Id of new group. VOX_GROUP_INVALID_ID if the id is already taken or the parent group is invalid.
	*/
	u32 AddGroup(group::CreationSettings &creationSettings);

	//! Reconfigure a group
	/*!
		This reconfigures a group. Not all settings are reconfigured: name and parent group can't be changed.
		\param groupId Id of group that is to be reconfigured.
		\param creationSettings Structure containing info on how to setup the group.
		\return True if successful, false if fail.
	*/
	bool ReconfigureGroup(u32 groupId, group::CreationSettings &creationSettings);

	//! Reconfigure a group
	/*!
		This reconfigures a group. Not all settings are reconfigured: name and parent group can't be changed.
		\param groupName Name of group that is to be reconfigured.
		\param creationSettings Structure containing info on how to setup the group. The name and parentId fields are ignored.
		\return True if successful, false if fail.
	*/
	bool ReconfigureGroup(const char *groupName, group::CreationSettings &creationSettings);

	//! Find group id from the group's name
	/*!
		This scans the groups to find the group id of the group with a given name.
		\param name Name of group that is searched for.
		\return Id of the group with that name.
	*/
	u32 GetGroupId(const char *name);


	//! Find group name from the group's name
	/*!
		This scans the groups to find the group name of the group with a given id.
		\param id Id of group that is searched for.
		\param stringData Char array to write the string to.
		\param maxString Maximum size of returned string including null. By default, group names are limited to 32 bytes (31 characters).
		\return True if group was found and storage space was sufficient (and stringData has been written to), false otherwise.
	*/
	bool GetGroupName(u32 id, char *stringData, s32 maxString = 32);

	//! Find group name from the group's id
	/*!
		This returns the name of a group.
		\param id Id of group that is searched for.
		\param target Char array that is filled with the group's name
		\param maximum length of the group name
	*/
	// STRING_OF_SOME_KIND GetGroupName(u32 id, char *target, u32 maxChars);

	//! Set the group of an emitter
	/*!
		Use with no group parameter to reset group to default.  
		Upon creation, an emitter will receive its group from the data source.  
		This method allow to override default group assignation.
		\param handle Handle of the emitter to set group
		\param groupId Group id to set
	*/
	void  SetGroup( EmitterHandle &handle, u32 groupId = VOX_GROUP_MASTER_ID); // Note: Group flags are initialy inherited from the data source

	//! Set the group of an emitter
	/*!
		Use with no group parameter to reset group to default.  
		Upon creation, an emitter will receive its group from the data source.  
		This method allow to override default group assignation.
		\param handle Handle of the emitter to set group
		\param groupName Group name to set
	*/
	void  SetGroup( EmitterHandle &handle, const char *groupName); // Note: Group flags are initialy inherited from the data source

	//! Get the group of an emitter
	/*!
		\param handle Handle of the emitter to set group
		\return Id of the group
	*/
	u32 GetGroup( EmitterHandle &handle );


	//! Set looping state of an emitter
	/*!
		\param handle Handle of the emitter to set looping state
		\param loop Looping state to set
	*/
	void  SetLoop( EmitterHandle &handle, bool loop = false );

	//! Get looping state of an emitter
	/*!
		\param handle Handle of the emitter to set looping state
		\return Looping state to set
	*/
	bool  GetLoop( EmitterHandle &handle);

	//! Set the gain of an emitter
	/*!
		\param handle Handle of the emitter to set gain
		\param gain Gain to set [0.0~1.0]
		\param fadeTime Duration of the transition (seconds)
	*/
	void  SetGain( EmitterHandle &handle, f32 gain, f32 fadeTime);

	//! Set the gain of an emitter
	/*!
		\param handle Handle of the emitter to set gain
		\param gain Gain to set [0.0~1.0]
	*/
	void  SetGain( EmitterHandle &handle, f32 gain = 1.0f);

	//! Get the gain of an emitter
	/*!
		This method return the gain value for the emitter, it doesn't consider
		the value of the group gain or the master gain.  If the emitter is
		currently fading, this method will return the target gain, not the 
		current gain.<br>
		<b>Note : This value represent the value the user set, the driver might 
		clamp this value to match it's limitation.</b>
		\param handle Handle of the emitter to get gain
	*/
	f32  GetGain( EmitterHandle &handle );

	//! Set the pitch of an emitter
	/*!
		\param handle Handle of the emitter to set pitch
		\param pitch Pitch to set (0.0~2.0]
		\param fadeTime Duration of the transition (seconds)
	*/
	void  SetPitch( EmitterHandle &handle, f32 pitch, f32 fadeTime);

	//! Set the pitch of an emitter
	/*!
		\param handle Handle of the emitter to set pitch
		\param pitch Pitch to set (0.0~2.0]
	*/
	void  SetPitch( EmitterHandle &handle, f32 pitch = 1.0f);

	//! Get the pitch of an emitter
	/*!
		This method return the pitch value for the emitter.  If the emitter is
		currently fading, this method will return the target pitch, not the 
		current pitch.<br>
		<b>Note : This value represent the value the user set, the driver might 
		clamp this value to match it's limitation.</b>
		\param handle Handle of the emitter to get pitch
	*/
	f32  GetPitch( EmitterHandle &handle );

	//! Set the priority of an emitter
	/*!
		This method change the priority of an emitter. <b>If the priority is
		changed while the emitter is in a bank, the behaviour may be different
		from expected (Some check are only done when adding an emitter to a
		bank)</b>
		\param handle Handle of the emitter to set priority
		\param priority Priority to set
	*/
	void SetPriority( EmitterHandle &handle, s32 priority);

	//! Get the priority of an emitter
	/*!
		\param handle Handle of the emitter to set priority
		\return Priority of the emitter.  If the emitter is not valid, result undefined
	*/
	s32  GetPriority( EmitterHandle &handle);

	//3D

	//! Set an emitter position
	/*!
		\param handle Handle of the emitter to set position
		\param x x coordinate of the emitter
		\param y y coordinate of the emitter
		\param z z coordinate of the emitter
	*/
	void  Set3DEmitterPosition( EmitterHandle &handle, f32 x, f32 y, f32 z );

	//! Set an emitter velocity
	/*!
		\param handle Handle of the emitter to set velocity
		\param x Velocity x component of the emitter
		\param y Velocity y component of the emitter
		\param z Velocity z component of the emitter
	*/
	void  Set3DEmitterVelocity( EmitterHandle &handle, f32 x, f32 y, f32 z );

	//! Set an emitter direction
	/*!
		Doesn't affect emitter with 360 degree cone.
		\param handle Handle of the emitter to set velocity
		\param x Velocity x component of the emitter
		\param y Velocity y component of the emitter
		\param z Velocity z component of the emitter
	*/
	void  Set3DEmitterDirection( EmitterHandle &handle, f32 x, f32 y, f32 z );

	//! Set all emitter scalar 3D properties
	/*!
		Allow to set all scalar 3D properties at once.
		\param handle Handle of the emitter to set velocity
		\param param Structure containing all the 3D properties to set
	*/
	void  Set3DEmitterParameters( EmitterHandle &handle, const Vox3DEmitterParameters &param);

	//! Set a f32 3D property of an emitter
	/*!
		Non-float property will be ignored. The following properties can be used with this method:
		<ul>
		<li>k_nMaxDistance</li>
		<li>k_nReferenceDistance</li>
		<li>k_nRolloffFactor</li>
		<li>k_nInnerConeAngle</li>
		<li>k_nOuterConeAngle</li>
		<li>k_nOuterConeGain</li>
		<li>k_nCullingDistance</li>
		</ul>
		These properties are defined in Vox3DEmitterParameter namespace.
		\param handle Handle of the emitter to set velocity
		\param paramId Id of the property to set (see list above) 
		\param floatValue Value to set the property to
	*/
	void  Set3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 floatValue );

	//! Set an integer 3D property of an emitter
	/*!
		Non-integer property will be ignored. The following property can be used with this method:
		<ul>
		<li>k_nRelativeToListener</li>
		</ul>
		This property is defined in Vox3DEmitterParameter namespace.
		\param handle Handle of the emitter to set velocity
		\param paramId Id of the property to set (see list above) 
		\param intValue Value to set the property to
	*/
	void  Set3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 intValue );
	
	//! Get an emitter position
	/*!
		\param handle Handle of the emitter to get position
		\param x x coordinate of the emitter
		\param y y coordinate of the emitter
		\param z z coordinate of the emitter
	*/
	void  Get3DEmitterPosition( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );

	//! Get an emitter velocity
	/*!
		\param handle Handle of the emitter to get velocity
		\param x Velocity x component of the emitter
		\param y Velocity y component of the emitter
		\param z Velocity z component of the emitter
	*/
	void  Get3DEmitterVelocity( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );

	//! Set an emitter direction
	/*!
		Doesn't affect emitter with 360 degree cone.
		\param handle Handle of the emitter to get velocity
		\param x Velocity x component of the emitter
		\param y Velocity y component of the emitter
		\param z Velocity z component of the emitter
	*/
	void  Get3DEmitterDirection( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );

	//! Get all emitter scalar 3D properties
	/*!
		Allow to set all scalar 3D properties at once.
		\param handle Handle of the emitter to set velocity
		\param param Structure containing all the 3D properties to set
	*/
	void  Get3DEmitterParameters( EmitterHandle &handle, Vox3DEmitterParameters &param);

	//! Get a f32 3D property of an emitter
	/*!
		Non-float property will be ignored. The following properties can be used with this method:
		<ul>
		<li>k_nMaxDistance</li>
		<li>k_nReferenceDistance</li>
		<li>k_nRolloffFactor</li>
		<li>k_nInnerConeAngle</li>
		<li>k_nOuterConeAngle</li>
		<li>k_nOuterConeGain</li>
		<li>k_nCullingDistance</li>
		</ul>
		These properties are defined in Vox3DEmitterParameter namespace.
		\param handle Handle of the emitter to get velocity
		\param paramId Id of the property to get (see list above) 
		\param floatValue Value to set the property to
	*/
	void  Get3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 &floatValue );

	//! Get an integer 3D property of an emitter
	/*!
		Non-integer property will be ignored. The following property can be used with this method:
		<ul>
		<li>k_nRelativeToListener</li>
		</ul>
		This property is defined in Vox3DEmitterParameter namespace.
		\param handle Handle of the emitter to get velocity
		\param paramId Id of the property to get (see list above) 
		\param intValue Value to set the property to
	*/
	void  Get3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 &intValue );

	//! Set a DSP property of an emitter
	/*!
		The following property can be used with this method:
		<ul>
		<li>k_nBusId (c8*)</li>
		</ul>
		This property is defined in VoxDSPEmitterParameter namespace.
		\param handle Handle of the emitter to set velocity
		\param paramId Id of the property to set (see list above) 
		\param param Value to set the property to
	*/
	void  SetDSPEmitterParameter( EmitterHandle &handle, s32 paramId, const void* param );

	//! Set next state of an interactive music emitter
	/*!
		\param handle Emitter handle to set the state to
		\param stateLabel Label of the state to set
	*/
	void SetInteractiveMusicState(EmitterHandle &handle, const char *stateLabel);

	//! Set KillOnResume flag of an interactive music emitter. Any emitters with this flag will be killed if the engine is resumed.
	/*!
		\param handle Emitter handle to set the flag on
		\param value New value of the flag
	*/
	void SetKillOnResume(EmitterHandle &handle, bool value);

	//! Get KillOnResume flag of an interactive music emitter.
	/*!
		\param handle Emitter handle to get the flag from
		\return Current value of the flag
	*/
	bool GetKillOnResume(EmitterHandle &handle);

	//! Get all current emitters
	/*!
		Return up to bufferCount emitter handles of current emitter.  These count as valid reference to emitter. 
		\param handlesBuffer Array to write emitter handles to 
		\param bufferCount Maximum emitter handles to write to array
		\return Actual number of emitter handles written to the array
	*/
	s32   GetAllEmitters( EmitterHandle* handlesBuffer, s32 bufferCount );

	//
	// Group methods
	//

	//! Play all emitters with group matching the group or children of the group
	/*!
		\param groupId Group to apply the command to
		\param fadeTime Duration of the fade in (seconds)
	*/
	void PlayGroup(u32 groupId, f32 fadeTime);

	//! Play all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
		\param fadeTime Duration of the fade in (seconds)
	*/
	void PlayGroup(const char *groupName, f32 fadeTime);

	//! Stop all emitters with group matching the group or children of the group
	/*!
		\param groupId Group to apply the command to
		\param fadeTime Duration of the fade out (seconds)
	*/
	void StopGroup(u32 groupId, f32 fadeTime);

	//! Stop all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
		\param fadeTime Duration of the fade out (seconds)
	*/
	void StopGroup(const char *groupName, f32 fadeTime);

	//! Pause all emitters with group matching the group or children of the group
	/*!
		\param groupId Group to apply the command to
		\param fadeTime Duration of the fade out (seconds)
	*/
	void PauseGroup(u32 groupId, f32 fadeTime);

	//! Pause all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
		\param fadeTime Duration of the fade out (seconds)
	*/
	void PauseGroup(const char *groupName, f32 fadeTime);

	//! Resume all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
		\param fadeTime Duration of the fade in (seconds)
	*/
	void ResumeGroup(u32 groupId, f32 fadeTime);

	//! Resume all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
		\param fadeTime Duration of the fade in (seconds)
	*/
	void ResumeGroup(const char *groupName, f32 fadeTime);



	//! Play all emitters with group matching the group or children of the group
	/*!
		\param groupId Group to apply the command to
	*/
	void PlayGroup(u32 groupId = VOX_GROUP_MASTER_ID);

	//! Play all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
	*/
	void PlayGroup(const char *groupName);

	//! Stop all emitters with group matching the group or children of the group
	/*!
		\param groupId Group to apply the command to
	*/
	void StopGroup(u32 groupId = VOX_GROUP_MASTER_ID);

	//! Stop all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
	*/
	void StopGroup(const char *groupName);

	//! Pause all emitters with group matching the group or children of the group
	/*!
		\param groupId Group to apply the command to
	*/
	void PauseGroup(u32 groupId = VOX_GROUP_MASTER_ID);

	//! Pause all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
	*/
	void PauseGroup(const char *groupName);

	//! Resume all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
	*/
	void ResumeGroup(u32 groupId = VOX_GROUP_MASTER_ID);

	//! Resume all emitters with group matching the group or children of the group
	/*!
		\param groupName Group to apply the command to
	*/
	void ResumeGroup(const char *groupName);


public:

	//
	// Listener methods
	//

	//! Set the gain of the master group
	/*!
		This is an alias for SetGroupVolume(VOX_MASTER_GROUP_ID, gain, fadeTime);
		\param gain Gain to set the master group volume to
		\param fadeTime Duration of the volume transition (seconds)
	*/
	void  SetMasterGain( f32 gain, f32 fadeTime);

	//! Set the gain of the master group
	/*!
		This is an alias for SetGroupVolume(VOX_MASTER_GROUP_ID, gain);
		\param gain Gain to set the master group volume to
	*/
	void  SetMasterGain( f32 gain);

	//! Get the gain of the master group
	/*!
		This is an alias for GetGroupVolume(VOX_MASTER_GROUP_ID);
	*/
	f32 GetMasterGain();

	//! Set the gain for groups
	/*!
		\param groupId <b>Id</b> of the group to apply the command to
		\param volume Volume to set
		\param fadeTime Duration of the volume transition (seconds)
	*/
	void  SetGroupVolume(u32 groupId, f32 volume, f32 fadeTime);

	//! Set the gain for groups
	/*!
		\param groupName <b>Name</b> of the group to apply the command to
		\param volume Volume to set
		\param fadeTime Duration of the volume transition (seconds)
	*/
	void  SetGroupVolume(const char *groupName, f32 volume, f32 fadeTime);

	//! Set the gain for groups
	/*!
		\param groupId <b>Id</b> of the group to apply the command to
		\param volume Volume to set
	*/
	void  SetGroupVolume(u32 groupId, f32 volume);

	//! Set the gain for groups
	/*!
		\param groupName <b>Name</b> of the group to apply the command to
		\param volume Volume to set
	*/
	void  SetGroupVolume(const char *groupName, f32 volume);

	//! Get the volume of a group
	/*!
		\param groupId <b>Id</b> of the group to query
	*/
	f32 GetGroupVolume(u32 groupId );

	//! Get the volume of a group
	/*!
		\param groupName <b>Name</b> of the group to query
	*/
	f32 GetGroupVolume(const char *groupName);

	//! Set the enable status of a group
	/*!
		\param groupId <b>Id</b> of the group to apply the command to
		\param enable New enable status to set
		\param fadeTime Duration of the volume transition (seconds)
	*/
	void SetGroupEnable(u32 groupId, bool enable, f32 fadeTime);

	//! Set the enable status of a group
	/*!
		\param groupName <b>Name</b> of the group to apply the command to
		\param enable New enable status to set
		\param fadeTime Duration of the volume transition (seconds)
	*/
	void SetGroupEnable(const char *groupName, bool enable, f32 fadeTime);

	//! Set the enable status of a group
	/*!
		\param groupId <b>Id</b> of the group to apply the command to
		\param enable New enable status to set
	*/
	void SetGroupEnable(u32 groupId, bool enable);

	//! Set the enable status of a group
	/*!
		\param groupName <b>Name</b> of the group to apply the command to
		\param enable New enable status to set
	*/
	void SetGroupEnable(const char *groupName, bool enable);

	//! Get the enable status of a group
	/*!
		\param groupId <b>Id</b> of the group to query
	*/
	bool GetGroupEnable(u32 groupId );

	//! Get the enable status of a group
	/*!
		\param groupName <b>Name</b> of the group to query
	*/
	bool GetGroupEnable(const char *groupName);

	//! Set the listener position
	/*!
		\param x x coordinate of the listener
		\param y y coordinate of the listener
		\param z z coordinate of the listener
	*/
	void Set3DListenerPosition(f32 x, f32 y, f32 z);

	//! Set the listener position
	/*!
		\param x Velocity x component of the listener
		\param y Velocity y component of the listener
		\param z Velocity z component of the listener
	*/
	void Set3DListenerVelocity(f32 x, f32 y, f32 z);

	//! Set the listener position
	/*!
		<b>Note : Look at vector is the vector that goes from the listener to the point it look at.</b>
		\param x_at Look at vector x component of the listener
		\param y_at Look at vector y component of the listener
		\param z_at Look at vector z component of the listener
		\param x_up Up vector x component of the listener
		\param y_up Up vector y component of the listener
		\param z_up Up vector z component of the listener
	*/
	void Set3DListenerOrientation(f32 x_at, f32 y_at, f32 z_at, f32 x_up, f32 y_up, f32 z_up);

	//! Set all listener scalar 3D properties
	/*!
		Allow to set all scalar 3D properties at once.
		\param param Structure containing all the 3D properties to set
	*/
	void Set3DGeneralParameter(const Vox3DGeneralParameters &param);

	//! Set a f32 3D property of the listener
	/*!
		Non-f32 property will be ignored. The following properties can be used with this method:
		<ul>
		<li>k_nDopplerFactor</li>
		<li>k_nSpeedOfSound</li>
		<li>k_nEnhanced3dStereoPanningPower</li>
		<li>k_nEnhanced3dStereoMaxDelayFront</li>
		<li>k_nEnhanced3dStereoMaxDelayBack</li>
		<li>k_nEnhanced3dNotchDepth</li>
		<li>k_nEnhanced3dNotchDepthSide</li>
		<li>k_nEnhanced3dNotchDepthBack</li>
		<li>k_nEnhanced3dNotchDepthDistance</li>
		<li>k_nEnhanced3dNotchWidth</li>
		<li>k_nEnhanced3dNotchWidthSide</li>
		<li>k_nEnhanced3dNotchWidthBack</li>
		<li>k_nEnhanced3dNotchWidthDistance</li>
		<li>k_nEnhanced3dDistanceWidthMinimum</li>
		<li>k_nEnhanced3dDistanceWidthMaximum</li>
		<li>k_nEnhanced3dDistanceWidthCurve</li>
		<li>k_nEnhanced3dDistanceWidthSide</li>
		<li>k_nEnhanced3dDistanceWidthBack</li>
		<li>k_nEnhanced3dDistanceFrequency</li>
		<li>k_nEnhanced3dRolloffFactor</li>
		</ul>
		These properties are defined in Vox3DGeneralParameter namespace.
		\param paramId Id of the property to set (see list above) 
		\param floatValue Value to set the property to
	*/
	void Set3DGeneralParameterf( s32 paramId, f32 floatValue );

	//! Set an integer 3D property of an emitter
	/*!
		Non-integer property will be ignored. The following property can be used with this method:
		<ul>
		<li>k_nDistanceModel</li>
		<li>k_nEnhanced3d</li>
		</ul>
		This property is defined in Vox3DGeneralParameter namespace.
		\param paramId Id of the property to set (see list above) 
		\param intValue Value to set the property to
	*/
	void Set3DGeneralParameteri( s32 paramId, s32 intValue );

	//! Get the listener position
	/*!
		\param x x coordinate of the listener
		\param y y coordinate of the listener
		\param z z coordinate of the listener
	*/
	void Get3DListenerPosition(f32 &x, f32 &y, f32 &z);

	//! Get the listener position
	/*!
		\param x Velocity x component of the listener
		\param y Velocity y component of the listener
		\param z Velocity z component of the listener
	*/
	void Get3DListenerVelocity(f32 &x, f32 &y, f32 &z);

	//! Get the listener position
	/*!
		\param x_at Look at x component of the listener
		\param y_at Look at y component of the listener
		\param z_at Look at z component of the listener
		\param x_up Up vector x component of the listener
		\param y_up Up vector y component of the listener
		\param z_up Up vector z component of the listener
	*/
	void Get3DListenerOrientation(f32 &x_at, f32 &y_at, f32 &z_at, f32 &x_up, f32 &y_up, f32 &z_up);

	//! Get all listener scalar 3D properties
	/*!
		Allow to get all scalar 3D properties at once.
		\param param Structure containing all the 3D properties to set
	*/
	void Get3DGeneralParameter(Vox3DGeneralParameters &param);

	//! Get a f32 3D property of the listener
	/*!
		Non-f32 property will be ignored. The following properties can be used with this method:
		<ul>
		<li>k_nDopplerFactor</li>
		<li>k_nSpeedOfSound</li>
		<li>k_nEnhanced3dStereoPanningPower</li>
		<li>k_nEnhanced3dStereoMaxDelayFront</li>
		<li>k_nEnhanced3dStereoMaxDelayBack</li>
		<li>k_nEnhanced3dNotchDepth</li>
		<li>k_nEnhanced3dNotchDepthSide</li>
		<li>k_nEnhanced3dNotchDepthBack</li>
		<li>k_nEnhanced3dNotchDepthDistance</li>
		<li>k_nEnhanced3dNotchWidth</li>
		<li>k_nEnhanced3dNotchWidthSide</li>
		<li>k_nEnhanced3dNotchWidthBack</li>
		<li>k_nEnhanced3dNotchWidthDistance</li>
		<li>k_nEnhanced3dDistanceWidthMinimum</li>
		<li>k_nEnhanced3dDistanceWidthMaximum</li>
		<li>k_nEnhanced3dDistanceWidthCurve</li>
		<li>k_nEnhanced3dDistanceWidthSide</li>
		<li>k_nEnhanced3dDistanceWidthBack</li>
		<li>k_nEnhanced3dDistanceFrequency</li>
		<li>k_nEnhanced3dRolloffFactor</li>
		</ul>
		These properties are defined in Vox3DGeneralParameter namespace.
		\param paramId Id of the property to get (see list above) 
		\param floatValue Value to set the property to
	*/
	void Get3DGeneralParameterf( s32 paramId, f32 &floatValue );

	//! Get an integer 3D property of an emitter
	/*!
		Non-integer property will be ignored. The following property can be used with this method:
		<ul>
		<li>k_nDistanceModel</li>
		</ul>
		This property is defined in Vox3DGeneralParameter namespace.
		\param paramId Id of the property to get (see list above) 
		\param intValue Value to set the property to
	*/
	void Get3DGeneralParameteri( s32 paramId, s32 &intValue );

	//! Attaches a DSP to a given bus
	/*!
		\param busName Name of bus to attach DSP to.
		\param dsp Pointer to dsp.
		\return True if DSP successfully attached; false otherwise
	*/
	bool AttachDSP( const char *busName, CustomDSP *dsp );

	//! Detaches a DSP to a given bus
	/*!
		\param busName Name of bus to detach DSP from.
		\return True when DSP successfully detached
	*/
	bool DetachDSP( const char *busName );

    //! Set the bus routing volume
	/*!
		On driver supporting bus routing, this allows to set the volume of the bus
		routing. This method allow de modification of the volume on routing
		already set, this doesn't allow the creation of new routing path
		\param busFromName Bus identifier of the bus the routing is from
		\param busToName Bus identifier of the bus the routing is going into
		\param routingType Routing type to modify
		\param dryVolume Volume to set for dry path (ignore if routing type isn't dry)
		\param wetVolume Volume to set for wet path (ignore if routing type isn't wet)
		\param fadeTime Time to fade volume modification
	*/
	void  SetRoutingVolume(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume, f32 fadeTime);

    //! Set the bus routing volume
	/*!
		On driver supporting bus routing, this allows to set the volume of the bus
		routing. This method allow de modification of the volume on routing
		already set, this doesn't allow the creation of new routing path
		\param busFromName Bus identifier of the bus the routing is from
		\param busToName Bus identifier of the bus the routing is going into
		\param routingType Routing type to modify
		\param dryVolume Volume to set for dry path (ignore if routing type isn't dry)
		\param wetVolume Volume to set for wet path (ignore if routing type isn't wet)
	*/
	void  SetRoutingVolume(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume);

	//! Get current current output mode
	/*!
		Return the current mode of the driver.
		\return Current output mode of the driver
	*/
	VoxOutputMode GetOutputMode();

	//! Set current output mode
	/*!
		Set the current output mode, if the driver support dynamic output
		configuration changes (Only support in CTR HW driver at this moment).
		Even when method return true, output mode change may not occur immediatly.
		\param mode Output mode to set
		\return True is mode is supported and modification is allowed
	*/
	bool SetOutputMode(VoxOutputMode mode);

	//
	// Other
	//

	//! Print all debug info of current engine objects
	/*!
		This call recursively the debug output of all vox objects.  If console is enabled, the result may be incomplete if console entry limit is low or if a lot of objects are active.
	*/
	void PrintDebug();

	void GetDebugInfo(DebugInfo &info);

	//! Register a data generator plugin to one of the buses from the minibus system
	/*!
		Registers the data generator plugin to the bus labeled by parameter 'busLabel'.
		\param pPlugin A pointer to the plugin object to register
		\param busLabel One of minibus labels ("MASTER", "AUX1" or "AUX2)
		\return True if the plugin has been registered
	*/
	bool RegisterExternalDataGenerator(MinibusDataGeneratorInterface *pPlugin, const char* busLabel);

	//! Unregister a data generator plugin from the minibus system
	/*!
		Unregisters the data generator plugin provided as argument from the minibus system.
		\param pPlugin A pointer to the plugin object to unregister
	*/
	void UnregisterExternalDataGenerator(MinibusDataGeneratorInterface *pPlugin);

protected:
	Mutex* m_mutex;

protected:
	bool m_isInitialized;
	static VoxEngine* s_voxEngine;
	static VoxEngineInternal* m_internal;
	
};

//VoxEngine& GetVoxEngine();
//void       DestroyVoxEngine();


} //namespace vox

#endif //_VOX_H_
