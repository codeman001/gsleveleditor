#pragma once
#ifndef _VOX_CONSOLE_H_
#define _VOX_CONSOLE_H_

#include "vox_memory.h"
#include "vox_mutex.h"
#ifdef __QNXNTO__
#include <stdarg.h>
using std::va_list;
#endif

namespace vox
{

class Console;

//! Console Implementation Interface
/*!
	This class provides the interface for vox consoles. It is possible to create a custom console overriding 
	vox default console by calling Console::SetConsoleImpl(ConsoleImplInterface* pExternalConsole). The
	application is responsible for deleting its own ConsoleImplInterface implementation (if using one) and
	calling Console::SetConsoleImpl(0) after doing so.
*/

class ConsoleImplInterface
{
 public:
	virtual ~ConsoleImplInterface(){}

	//! Send a message to be printed to console.
	/*!
		This method allows sending a message to console. Messages can be forwarded to the 'Console'
		tab of the vox glf debugger module by setting VOX_USE_GLF_DEBUGGER_MODULE to a non-null value
		in your vox_config.h.
		\param level Level of message.
		\param str The string to print.
		\param arguments Extra arguments (e.g. may be values replacing the string format tags).
	*/
	virtual void Print(s32 level, const c8* str, va_list arguments)=0;

 protected:
	static s32 s_logLevel;
	
	friend class Console;
};

//! Console
/*!
	This class is a singleton used for console printout. You have to set VOX_ENABLE_CONSOLE to a
	non-null value in your vox_config.h in order to use the console. The console relies on an
	implementation of the	interface ConsoleImplInterface to perform its job. Vox provides a default
	implementation, however you can create a custom implementation and register it by calling
	SetConsoleImpl(). The application is responsible for deleting its own ConsoleImplInterface
	implementation (if using one) and calling Console::SetConsoleImpl(0) after doing so.
*/

class Console
{	
public:
	//! Set a user implementation of the Console
	/*!
		Set a user implementation of the Console.
		IMPORTANT : When user releases its console implementation, he must call this method and provide
		a null pointer to notify vox that the console is no longer to be used.
		\param pExternalConsole A pointer to a custom implementation of the ConsoleImplInterface interface.
	*/
	static void SetConsoleImpl(ConsoleImplInterface* pExternalConsole);

	//! Set the log level of the console
	/*!
		This method permits to dynamically set the level of the console
		\param level A value between 0 and 5 (both inclusive). Messages having a level smaller than (or equal to) this parameter are outputted.
	*/
	static void SetLogLevel(u32 level);

	//! Print a message to console.
	/*!
		This method prints a message to the console. The message is outputted to the console if the
		level parameter is smaller than (or equal to) the level set through method SetLogLevel().
		If the glf debugger module is used (VOX_USE_GLF_DEBUGGER_MODULE set to a non-null value in
		your vox_config.h),	the message is forwarded to a console in the Vox tab of the glf debugger
		(whatever the level	parameter value).
		\param level Level of message. No impact on whether or not the message is printed. 
		\param str The string to print.
		\param arguments Values replacing the string format tags (e.g. a %d or %x).
	*/
	static void Print(s32 level, const c8* str, ...);

private:
	Console();
	~Console();

	static void _Print(s32 level, const c8* str);

	static ConsoleImplInterface	*s_pConsoleImplementation;	// Pointer to actual console implementation.
};

}
#endif // _VOX_CONSOLE_H_
