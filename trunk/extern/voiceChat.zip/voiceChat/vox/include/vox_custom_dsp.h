#pragma once
#ifndef _VOX_CUSTOM_DSP_H_
#define _VOX_CUSTOM_DSP_H_

#include <vox_types.h>

namespace vox
{

class CustomDSP
{ 
 protected:
	float m_sampleRate; // Warning: sample rate is not valid during the constructor!

 public:
	CustomDSP();
	virtual ~CustomDSP(void) = 0;

	// Virtual methods;
	virtual void Update(const s32 *input, s32 *output, int nbSamples) = 0;
	
	// By default this sets up the sampling rate and fails if
	// the number of channels is wrong or unsupported special flags are specified
	virtual bool ConnectToBus(float sampleRate, int channels, int specialFlags)
	{
		m_sampleRate = sampleRate;
		if (channels != 2)
			return false;
		if (specialFlags) // Floating point, multibus, etc...
			return false;
		return true;
	}

	virtual void DisconnectFromBus() {} // Normally you don't need to implement this

	// By default, the plugin is always active
	// Only implement this if you want to support a CPU saving mode for processing
	virtual bool WillOutput(bool hasInput) { return true; } 
};

} // namespace vox

#endif // _VOX_CUSTOM_DSP_H_
