#pragma once
#ifndef _VOX_CUSTOM_EMITTER_USER_DATA_H_
#define _VOX_CUSTOM_EMITTER_USER_DATA_H_

namespace vox
{
//! User defined data for emitter object
/*!
	This class is meant to contain user defined data associated with an emitter object.  The default constructor
	should create a state that is easily identified with uninitialized object, since it will get returned on any
	failed getter call and for emitter object that no user data was set.  If threading is active, this class should
	be made be thread-safe. The user can redefine this class by first defining VOX_USE_CUSTOM_EMITTER_USER_DATA,
	then creating its own EmitterHandleUserData class in a custom define header (either your vox_config.h or
	a header included in your vox_config.h).
*/
class EmitterHandleUserData
{
public:
	EmitterHandleUserData():m_userId(-1), m_emptyString(0){}
	EmitterHandleUserData(s32 userId):m_userId(userId), m_emptyString(0){}

	s32 GetUserId() const {return m_userId;}
	void SetUserId(s32 userId){m_userId = userId;}
	const c8 *ToString(){return &m_emptyString;}
private:
	s32 m_userId;
	c8 m_emptyString;
};
}

#endif // _VOX_CUSTOM_EMITTER_USER_DATA_H_