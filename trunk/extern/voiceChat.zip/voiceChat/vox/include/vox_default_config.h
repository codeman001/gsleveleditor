#pragma once
#ifndef _VOX_DEFAULT_CONFIG_H_
#define _VOX_DEFAULT_CONFIG_H_

//
// Do not mofify this file in any way.
//

// Make sure this file isn't included in user code
#ifndef VOX_INTERNAL_CODE
#error "This file must not be included by host application"
#endif

#ifndef GAME_VOX_CONFIG_ALT_FILE
// Default game-specific configuration file.
#include "../../vox_config/vox_config.h"
#else
// The GAME_VOX_CONFIG_ALT_FILE macro can be used to point to an alternate.
// For example, the following preprocessor definition can be added to the project settings:
// GAME_VOX_CONFIG_ALT_FILE=\"my_vox_config.h\"
#include GAME_VOX_CONFIG_ALT_FILE
#endif

#if defined(__APPLE__)
#include "TargetConditionals.h"
#endif 

#include "vox_types.h"

//*  BOOKMARKS *//
//
//  You can find setting related to a spefic part of vox by searching a bookmark
//
//   1. GENERAL               [GENERAL]
//   2. MEMORY                [MEMORY]
//   3. DEBUG                 [DEBUG]
//   4. VOX INTERNAL THREAD   [THREAD]
//   5. DATA SOURCES          [DATASOURCE]
//   6. EMITTERS              [EMITTER]
//   7. 3D SOUND              [3DSOUND]
//   8. STB VORBIS            [STBVORBIS]
//  10. IOS / REMOTEIO DRIVER [REMOTEIO]
//  15. DATA DRIVER           [DATA]
//  18. NO CATEGORY           [MISC]
//	20.	ZIP                   [ZIP]
//  24. PROFILER              [PROFILER]
//	25. VXN DECODER			  [VXN DECODER]
//  26. ANDROID				  [ANDROID]
//  29. NULL DRIVER (LINUX)   [NULL]
//  30. MMSYSTEM DRIVER		  [MMSYSTEM]
//  31. ENHANCED 3D           [ENHANCED3D]
//  32. NEON                  [NEON]
//
//******************************************************************************
//   1. GENERAL               [GENERAL]
//******************************************************************************

// This define will compile Vox to use glf classes within the generic layer.
#ifndef VOX_USE_GLF
#define VOX_USE_GLF 0
#endif

#ifndef VOX_MAX_STREAM_TYPES
#define VOX_MAX_STREAM_TYPES 32
#endif

#ifndef VOX_MAX_DECODER_TYPES
#define VOX_MAX_DECODER_TYPES 32
#endif

#ifndef VOX_USE_SOUNDPACK_XML
#define VOX_USE_SOUNDPACK_XML 0
#endif

#ifndef VOX_NB_TIMESTAMP_GROUP
#define VOX_NB_TIMESTAMP_GROUP 16
#endif

// Setting the VOX_MICROPHONE_INPUT option on iphone will change
// your audio session type and the ringer/silence switch will not
// be able to mute the audio anymore!

// Microphone support still beta
// #undef VOX_MICROPHONE_INPUT

#ifndef VOX_MICROPHONE_INPUT
#define VOX_MICROPHONE_INPUT 0
#endif

//******************************************************************************
//   2. MEMORY                [MEMORY]
//******************************************************************************

// Applications MUST now use custom allocator (mandatory).
// You must define the 4 VoxAlloc functions, and VoxFree. Example:
// 
// #include "vox_memory.h" // for vox::VoxMemHint type
// void* VoxAlloc(size_t size, const char* filename, const char* function, int line) {return malloc(size);}
// void* VoxAlloc(size_t size) {return malloc(size);}
// void* VoxAlloc(size_t size, vox::VoxMemHint memhint, const char* filename, const char* function, int line) {return VoxAlloc(size, filename, function, line);}
// void* VoxAlloc(size_t size, vox::VoxMemHint memhint) {return VoxAlloc(size);}
// void  VoxFree(void* ptr) {return free(ptr);}


//******************************************************************************
//   3. DEBUG                 [DEBUG]
//******************************************************************************

#ifndef VOX_ASSERT
#define VOX_ASSERT(X) // none
#endif

// VOX_WARNING_LEVEL defines the default level of the vox console. The console level is configurable
// at runtime by calling method Console::SetLogLevel(u32 level). A level of N means that all warnings
// with level smaller than (or equal to) N will be outputted.
//
// VOX_WARNING_LEVEL_1 Major error, will most likely be related to an error that make VoxEngine unusable.  Failed assert message also use this level.
// VOX_WARNING_LEVEL_2 Major error that has a major impact on the playback, as an error in a data source
// VOX_WARNING_LEVEL_3 Minor error that should only impact 1 sound playback, as an error in an emmiter
// VOX_WARNING_LEVEL_4 Minor error that should not have any impact, as setting volume higher than maximum value
// VOX_WARNING_LEVEL_5 Mainly information about what happening in Vox
//
#ifndef VOX_WARNING_LEVEL
#define VOX_WARNING_LEVEL 0
#endif

// Vox console is disabled by default. Set VOX_ENABLE_CONSOLE to a non-null value in your vox_config.h
// to enable the console.
#ifndef VOX_ENABLE_CONSOLE
#define VOX_ENABLE_CONSOLE 0
#endif

#ifndef VOX_MAX_CONSOLE_ENTRY
#define VOX_MAX_CONSOLE_ENTRY 1024
#endif

// Vox information can be forwarded to the glf debugger. Set VOX_USE_GLF_DEBUGGER_MODULE to a non-null
// value in your vox_config.h to enable this functionality. As for now, only vox console messages are
// forwarded to the glf debugger (if VOX_ENABLE_CONSOLE is set).
#ifndef VOX_USE_GLF_DEBUGGER_MODULE
#define VOX_USE_GLF_DEBUGGER_MODULE 0
#endif

#ifndef VOX_DEBUG_SERVER_ENABLE
#define VOX_DEBUG_SERVER_ENABLE 0
#else 
#ifndef _WIN32 //Only support on win32 atm
#undef VOX_DEBUG_SERVER_ENABLE
#define VOX_DEBUG_SERVER_ENABLE 0
#endif
#endif

#ifndef VOX_DEBUG_SERVER_REMOTE_ADDRESS
#define VOX_DEBUG_SERVER_REMOTE_ADDRESS {(char)127,(char)0,(char)0,(char)1}
#endif

#ifndef VOX_DEBUG_SERVER_REMOTE_PORT
#define VOX_DEBUG_SERVER_REMOTE_PORT 11000
#endif

#ifndef VOX_DEBUG_SERVER_LISTEN_PORT
#define VOX_DEBUG_SERVER_LISTEN_PORT 11001
#endif

#ifndef VOX_DEBUG_SERVER_UPDATE_RATE
#define VOX_DEBUG_SERVER_UPDATE_RATE 1
#endif

//******************************************************************************
//   4. VOX INTERNAL THREAD   [THREAD]
//******************************************************************************

// VOX_THREAD_SAFETY_LEVEL 0 => No thread safety enabled
// VOX_THREAD_SAFETY_LEVEL 1 => Both UpdateEmitter and UpdateSource are safe to run in their own thread

#ifndef VOX_THREAD_SAFETY_LEVEL
#define VOX_THREAD_SAFETY_LEVEL 0
#endif

// Minimal time between voxthread update loop
#ifndef VOX_THREAD_UPDATE_DT
#define VOX_THREAD_UPDATE_DT 33 //ms
#endif

// This defined the platform offcially supported by Vox Audio Engine that use
// Posix thread.  This define can be enable to activate Posix thread for platform
// that are not officially supported by Vox Audio Engine.  This define is 
// overiden when GLF is used or a platform spefic threading API is available.
#ifndef VOX_USE_PTHREAD
#if defined(__linux__) || defined(__APPLE__) || defined(ANDROID)
#define VOX_USE_PTHREAD 1
#else
#define VOX_USE_PTHREAD 0
#endif
#endif

// VOX_THREADING_MODE_NONE          => No intern thread
// VOX_THREADING_MODE_SINGLE_THREAD => 1 thread that do both updates
// VOX_THREADING_MODE_DUAL_THREAD   => Each update has it's own thread
// If multi-threading is enabled, thread safety is forced to 1
#ifdef VOX_THREADING_MODE_NONE
#undef VOX_THREADING_MODE_SINGLE_THREAD
#undef VOX_THREADING_MODE_DUAL_THREAD
#elif defined(VOX_THREADING_MODE_SINGLE_THREAD)
#undef VOX_THREADING_MODE_DUAL_THREAD
#undef VOX_THREAD_SAFETY_LEVEL
#define VOX_THREAD_SAFETY_LEVEL 1
#elif defined(VOX_THREADING_MODE_DUAL_THREAD)
#undef VOX_THREAD_SAFETY_LEVEL
#define VOX_THREAD_SAFETY_LEVEL 1
#else
#define VOX_THREADING_MODE_DUAL_THREAD
#undef VOX_THREAD_SAFETY_LEVEL
#define VOX_THREAD_SAFETY_LEVEL 1
#endif


// This define allow to use user-defined priority for pthread instead of using
// default value.  This will not change the scheduling policy
#ifndef VOX_OVERRIDE_PTHREAD_DEFAULT_PRIORITY
#define VOX_OVERRIDE_PTHREAD_DEFAULT_PRIORITY 0
#endif

// When VOX_OVERRIDE_PTHREAD_DEFAULT_PRIORITY is enabled, this define set the 
// value of the priority to use
#ifndef VOX_PTHREAD_PRIORITY
#define VOX_PTHREAD_PRIORITY 31
#endif

//******************************************************************************
//   5. DATA SOURCES          [DATASOURCE]
//******************************************************************************


//
// To define your own data source user data, first define VOX_USE_CUSTOM_DATA_SOURCE_USER_DATA
// then define the class DataSourceUserData as you want it.  The class is responsible of its own data.
// The only guarantee is that the constructor is called at the construction of a data source and the
// destructor will be call at the destruction of the data source.  The class should handle properly
// copy and assignation. If thread are active, at least copy and assignation should be thread-safe.
//
#ifndef VOX_USE_CUSTOM_DATA_SOURCE_USER_DATA
#include <vox_custom_datasource_user_data.h>
#endif

//******************************************************************************
//   6. EMITTERS              [EMITTER]
//******************************************************************************

//
//  Default fade time for all methods that support fading in seconds
//
#ifndef VOX_DEFAULT_FADE_TIME_PLAY
#define VOX_DEFAULT_FADE_TIME_PLAY 0.0f // Fade time on play has to be very fast
#endif

#ifndef VOX_DEFAULT_FADE_TIME_STOP
#define VOX_DEFAULT_FADE_TIME_STOP 0.05f // 50ms on stop, pause, resume,
#endif

#ifndef VOX_DEFAULT_FADE_TIME_VOLUME
#define VOX_DEFAULT_FADE_TIME_VOLUME 0.05f // 50ms on volume and enable flag change
#endif

#ifndef VOX_DEFAULT_FADE_TIME_PITCH
#define VOX_DEFAULT_FADE_TIME_PITCH 0.05f // 50ms on pitch change
#endif

#ifndef VOX_DEFAULT_FADE_TIME_VOICE_STEAL
#define VOX_DEFAULT_FADE_TIME_VOICE_STEAL 0.05f // 50ms on voice stealing
#endif

#ifndef VOX_DRIVER_SOURCE_NUM_BUFFER
#define VOX_DRIVER_SOURCE_NUM_BUFFER 3
#endif

#ifndef VOX_EMITTER_BUFFER_DURATION_MS
#define VOX_EMITTER_BUFFER_DURATION_MS 250 //ms
#endif

#ifndef VOX_BUFFERED_FILE_STREAM
#define VOX_BUFFERED_FILE_STREAM 0
#endif

#ifndef VOX_FILE_STREAM_BUFFER_SIZE
#define VOX_FILE_STREAM_BUFFER_SIZE 32 * 1024
#endif

//
//	If VOX_USE_EMITTER_PREFETCH is enable, the emitter will prefecth data at
//	every update according to update dt.  When disable, the emitter only fetch
//	the data to fill the whole buffer when the driver needs data.  Enabling it
//	may slightly reduce performance, but will allow more consistent update
//	duration.
//
#ifndef VOX_USE_EMITTER_PREFETCH
#define VOX_USE_EMITTER_PREFETCH 0
#endif

#ifndef VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
#define VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK 0
#endif

//
//	Vox default sound parameters
//

//
//	Default value for the master gain parameter.  This will be the master gain
//	until set by the application
//
#ifndef VOX_DEFAULT_MASTER_GAIN
#define VOX_DEFAULT_MASTER_GAIN 1.0f
#endif

//
//	Default gain value for all group.  Each group will use this value, unless 
//	set by the application
//
#ifndef VOX_DEFAULT_GROUP_GAIN
#define VOX_DEFAULT_GROUP_GAIN 1.0f
#endif

//
//	Default gain value for all newly created emitter.  There's not fade on the 
//	initial gain value.
//
#ifndef VOX_DEFAULT_EMITTER_GAIN
#define VOX_DEFAULT_EMITTER_GAIN 1.0f
#endif

//
//	Initial pitch value for all newly created emitter.  Unless set by the 
//	application for each emitter, this is the value used.
//
#ifndef VOX_DEFAULT_EMITTER_PITCH
#define VOX_DEFAULT_EMITTER_PITCH 1.0f
#endif

//
// To define your own emitter user data, first define VOX_USE_CUSTOM_EMITTER_USER_DATA
// then define the class EmitterHandleUserData as you want it.  The class is responsible of its own data.
// The only garantee is that the constructor is called at the construction of an emitter and the
// destructor will be call at the destruction of the emitter.  The class should handle properly
// copy and assignation. If thread are active, at least copy and assignation should be thread-safe.
//
#ifndef VOX_USE_CUSTOM_EMITTER_USER_DATA
#include <vox_custom_emitter_user_data.h>
#endif

//******************************************************************************
//   7. 3D SOUND              [3DSOUND]
//******************************************************************************

//
//	Vox default 3d sound parameters
//	Since Vox first hardware driver was OpenAL, most of the 3D sound parameter
//	are based on OpenAL 1.1 specifications.  For more information on a
//	parameter, the specification should be in the OpenAL folder of the library 
//	folder. The specification should also be available from creative labs
//	website.	
//
//	There is not set unit system in Vox.  You are free to use any unit
//	system, as long it's the same for all emitters and listener.  The only
//	exception to this is the constant for the speed of sound that uses meter
//	per second as a unit.  This constant is only used in doppler effect 
//	calculation.
//

//
//	Default Vox 3D model. The model k_nNone implitly disables any 3D sound
//	processing. The model currently avaibable are listed in Vox3DDistanceModel
//	namespace in vox.h.  For more detailed information on each model, you can 
//	refer to either OpenAL 1.1 specification or Vox user documentation.  As of
//	iPhone OS 3.1.2 OpenAL implementation, disabling distance attenuation is 
//	bugged and should be used.
//
#ifndef VOX_DEFAULT_3D_MODEL
#define VOX_DEFAULT_3D_MODEL Vox3DDistanceModel::k_nInverseDistanceClamped
#endif

//
//	Factor to apply to doppler effect calculation.  A value higher than 1.0
//	will exagerate the doppler effect, while a value lower than 1.0 will reduce
//	it.
//
#ifndef VOX_DEFAULT_3D_DOPPLER_FACTOR
#define VOX_DEFAULT_3D_DOPPLER_FACTOR 1.0f
#endif

//
//	This is the default speed of sound to use in doppler effect calculation.
//	This value is in meter per second.  IMPORTANT : If the velocity vector of 
//	emitters and listener do not use this unit, this value need to be set to 
//	the same unit system.  This constant represent the speed of sound in air at
//	sea level.
//
#ifndef VOX_DEFAULT_3D_SPEED_OF_SOUND
#define VOX_DEFAULT_3D_SPEED_OF_SOUND 343.3f
#endif

//
//	This parameter controls the front/back and up/down sound position
//  simulation at run time. Enabling this increases CPU usage for positioned sources.
//
#ifndef VOX_DEFAULT_3D_ENHANCED_3D
#define VOX_DEFAULT_3D_ENHANCED_3D 0
#endif

//
//	Default listener position in the 3D world.
//
#ifndef VOX_DEFAULT_3D_LISTENER_POSITION
#define VOX_DEFAULT_3D_LISTENER_POSITION { 0.0f, 0.0f, 0.0f }
#endif

//
//	Default listener velocity in the 3D world.
//
#ifndef VOX_DEFAULT_3D_LISTENER_VELOCITY
#define VOX_DEFAULT_3D_LISTENER_VELOCITY { 0.0f, 0.0f, 0.0f }
#endif

//
//	Default up vector for the listener.
//
#ifndef VOX_DEFAULT_3D_LISTENER_UP 
#define VOX_DEFAULT_3D_LISTENER_UP { 0.0f, 1.0f, 0.0f }
#endif

//
//	Default "look at" vector for the listener.  The combination of this value
//	and "up" value create the orientation parameter.
//
#ifndef VOX_DEFAULT_3D_LISTENER_LOOKAT
#define VOX_DEFAULT_3D_LISTENER_LOOKAT { 0.0f, 0.0f, -1.0f }
#endif

//
//	This value determine if all vector value of the emitter have their origin
//	at the world origin or at the listener position.  This is the default value
//	for all newly creted emitter.
//
#ifndef VOX_DEFAULT_3D_EMITTER_RELATIVE_TO_LISTENER
#define VOX_DEFAULT_3D_EMITTER_RELATIVE_TO_LISTENER 0
#endif

//
//	Default value for max distance in attenuation calculation.
//  Clamps distance in the inverse and exponential models.
//  Is the distance at which volume reaches 0 in the linear model (with rolloff = 1).
//	For more information on attenuation model, you can look at OpenAL
//	specification or Vox user documention. The default value is the maximum
//  32bit float value.
//
#ifndef VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE
#define VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE 3.40282346638528860e+38
#endif 

//
//	Default initial distance for attenuation calculation for clamped model. In
//	clamped model, this is the absolute minimum distance needed before any
//	attenuation is applied to the emitter. This value needs to be equal or 
//	higher than zero.
//
#ifndef VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE
#define VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE 1.0f
#endif

//
//	Default rolloff factor for attenuation calculation.  This value has a
//	effect on the amplitude of the attenuation.  The higher the value, the
//	stronger will be the attenuation. This value needs to equal or higher than
//	zero.
//
#ifndef VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR
#define VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR 1.0f
#endif

//
//	Default angle for the inner cone for directional sound.  The cone is
//	positioned according to the emitter position and direction.  The inner cone
//	is the region where no radial attenuation is applied.  This is the radial
//	equivalent of the reference distance.
//
#ifndef VOX_DEFAULT_3D_EMITTER_INNER_CONE_ANGLE
#define VOX_DEFAULT_3D_EMITTER_INNER_CONE_ANGLE 360.0f
#endif

//
//	Default angle for the outer cone for directionnal sound.  This cone is 
//	positioned according to the emitter position and direction.  The outer cone
//	is the outer limit for attenuation calculation.  For the region between the
//	inner cone and the outer cone, a linear attenuation, based on the angle is 
//	applied. For the region outside the outer cone, a constant value is used.
//	For directionnal sound, this attenuation is multiplied with the distance
//	attenuation facor.
//
#ifndef VOX_DEFAULT_3D_EMITTER_OUTER_CONE_ANGLE
#define VOX_DEFAULT_3D_EMITTER_OUTER_CONE_ANGLE 360.0f
#endif

//
//	Default gain value for the zone outside the outer cone of a directionnal
//	sound.  The distance attenuation is applied to that value.
//
#ifndef VOX_DEFAULT_3D_EMITTER_OUTER_CONE_GAIN
#define VOX_DEFAULT_3D_EMITTER_OUTER_CONE_GAIN 0.0f
#endif

//
//	Default ditance value to exclude an emitter for the 3D sound redering. At
//	the moment no driver support this parameter.
//
#ifndef VOX_DEFAULT_3D_EMITTER_CULLING_DISTANCE
#define VOX_DEFAULT_3D_EMITTER_CULLING_DISTANCE 3.40282346638528860e+38
#endif

//
//	Default position for all newly created emitter. The effect of this value
//	will varie depending if the emitter vector are relative to the origin of
//	the world or the to the position of the emitter.The default value is the 
//	maximum value for a single precision floating point variable according to 
//	IEEE standard 754.  If you system uses another standard, this value might 
//	not be adequate.
//
#ifndef VOX_DEFAULT_3D_EMITTER_POSITION
#define VOX_DEFAULT_3D_EMITTER_POSITION { 0.0f, 0.0f, 0.0f }
#endif

//
//	Default velocity for all newly created emitter. The effect of this value
//	will varie depending if the emitter vector are relative to the origin of
//	the world or the to the position of the emitter.
//
#ifndef VOX_DEFAULT_3D_EMITTER_VELOCITY
#define VOX_DEFAULT_3D_EMITTER_VELOCITY { 0.0f, 0.0f, 0.0f }
#endif

//
//	Default direction for all newly created emitter. The effect of this value
//	will varie depending if the emitter vector are relative to the origin of
//	the world or the to the position of the emitter.  This vector is only used
//	for directionnal emitter (inner cone < 360 degree).
//
#ifndef VOX_DEFAULT_3D_EMITTER_DIRECTION
#define VOX_DEFAULT_3D_EMITTER_DIRECTION { 0.0f, 0.0f, 0.0f }
#endif

//
// Power value in channel located on the same side as source, when source is totally on one side of listener.
// For default value of 1.0, no sound will be heard in left (right) channel if source is totally to the right
// (left). For values smaller than 1.0f, VOX_MAX_STEREO_PANNING_POWER of the power will be in the channel that
// is on the same side as source and 1 - VOX_MAX_STEREO_PANNING_POWER of the power will in the channel opposite
// from source. One must have 0.5 <= VOX_MAX_STEREO_PANNING_POWER <= 1.0f, where 0.5 corresponds to both channels
// having the same power. Realistic values would rather be larger than 0.8f.
//
#ifndef VOX_MAX_STEREO_PANNING_POWER
#define VOX_MAX_STEREO_PANNING_POWER 1.0f
#endif




//******************************************************************************
//   8. STB VORBIS            [STBVORBIS]
//******************************************************************************

//
//	STBVORBIS decoder can use a buffer for all its allocations.  If enabled, one buffer
//	will be allocated per decoder.  If disabled, the decoder will use vox standard 
//	allocator (around 350 allocations per decoder).
//
#ifndef VOX_USE_STBVORBIS_INTERNAL_BUFFER
#define VOX_USE_STBVORBIS_INTERNAL_BUFFER 0
#endif

//
//	If STBVORBIS internal buffer are enabled, the size of the buffer can be change.  According to
//	STBVORBIS documentation, 150k bytes are needed for each decoder instance.  Each emitter using
//	STBVORBIS decoder will have its own decoder instance.  If the buffer size is too small, the intern
//	allocator will override the setting and use Vox allocator to allocate remaining memory needed.
//
#ifndef VOX_STBVORBIS_INTERNAL_BUFFER_SIZE
#define VOX_STBVORBIS_INTERNAL_BUFFER_SIZE (150 << 10) // 150 kbytes
#endif

//
//	Since most of STBVORBIS data is the same for every decoder using the same file and is read-only,
//	some of it can be share by all theses decoders.  When this setting is active, the main
//	decoder data will be store inside the data source, then sent to every new emitter.  This bring
//	the cost in memory to around 150k for the main decoder data and 6k x numChannel per emitter.
//	Enabling shared data also prevent to recreate the codebook for each emitter. This setting 
//	is experimental at the moment and should be tested with the application data.
//
#ifndef VOX_ALLOW_STBVORBIS_SHARE_COMMON_DATA
#define VOX_ALLOW_STBVORBIS_SHARE_COMMON_DATA 0
#endif

//
//	If data sharing is enabled, STBVORBIS internal buffer cannot be used since the shared and 
//	private data share the same allocator.
//
#if VOX_ALLOW_STBVORBIS_SHARE_COMMON_DATA && VOX_USE_STBVORBIS_INTERNAL_BUFFER
#undef VOX_USE_STBVORBIS_INTERNAL_BUFFER
#define VOX_USE_STBVORBIS_INTERNAL_BUFFER 0
#endif

//******************************************************************************
//  10. IPHONE / REMOTEIO DRIVER       [REMOTEIO]
//******************************************************************************

#ifndef VOX_USE_POSIX_FILESYSTEM
#define VOX_USE_POSIX_FILESYSTEM 0
#endif

#if (defined(TARGET_OS_IPHONE)) // defined if IOS or MacOS, else undefined
#if (TARGET_OS_IPHONE) // If 1, IOS, if 0, MacOS
// defining our own version of the TARGET_OS_IPHONE switch because the normal one doesn't behave as we'd expect
#define VOX_TARGET_OS_IPHONE 
#endif
#endif

#ifndef VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM
#if (defined(VOX_TARGET_OS_IPHONE))
#define VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM 1
#else
#define VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_IPHONE_REMOTEIO
#define VOX_DRIVER_USE_IPHONE_REMOTEIO 1
#endif

#ifndef VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE
#define VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE 44100.0 // Hz.
#endif

#ifndef VOX_IPHONE_REMOTEIO_DRIVER_BUFFER_LENGTH
#define VOX_IPHONE_REMOTEIO_DRIVER_BUFFER_LENGTH	0.023f //seconds
#endif

#ifndef VOX_IPHONE_REMOTEIO_OVERRIDE_HW_IO_BUFFER_LENGTH
#define VOX_IPHONE_REMOTEIO_OVERRIDE_HW_IO_BUFFER_LENGTH 0
#endif

// VOX_REMOTEIO_FORCE_SW_RESAMPLER now always on 

#ifndef VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS
#define VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS	1
#endif

// Only use this if you need a specific sampling rate at input!
// Microphone input always uses the hardware rate at driver level (normally 44.1khz)
// Using this option will cause the number of samples per block to vary
// (between 371 and 372 samples for instance)
#ifndef VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_INPUT
#define VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_INPUT 0
#endif

// Rate to resample to if using resampling
#ifndef VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_RATE
#define VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_RATE 44100
#endif


//******************************************************************************
//  30. MMSYSTEM DRIVER            [MMSYSTEM]
//******************************************************************************

#ifndef VOX_MMSYSTEM_DRIVER_PLATFORM
#if defined(_WIN32)
#define VOX_MMSYSTEM_DRIVER_PLATFORM 1
#else
#define VOX_MMSYSTEM_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_MMSYSTEM
#define VOX_DRIVER_USE_MMSYSTEM 1 // always use MMSYSTEM on win32.
#endif

#ifndef VOX_MMSYSTEM_DRIVER_PREFERRED_RATE
#define VOX_MMSYSTEM_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_MMSYSTEM_DRIVER_BUFFER_LENGTH
#define VOX_MMSYSTEM_DRIVER_BUFFER_LENGTH  0.023f //seconds
#endif


#ifndef VOX_MMSYSTEM_DRIVER_RECORDING_PREFERRED_RATE
#define VOX_MMSYSTEM_DRIVER_RECORDING_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_MMSYSTEM_DRIVER_RECORDING_BUFFER_LENGTH
#define VOX_MMSYSTEM_DRIVER_RECORDING_BUFFER_LENGTH  0.023f //seconds
#endif

#ifndef VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS
#define VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS	1
#endif


//******************************************************************************
//  18. NO CATEGORY           [MISC]
//******************************************************************************

#ifndef VOX_BIG_ENDIAN
#	define VOX_BIG_ENDIAN 0       // No big endian platforms supported ATM
#endif

#ifndef VOX_USE_HANDLABLE_MAP
#define VOX_USE_HANDLABLE_MAP 1
#endif

#define VOX_LIST_INCLUDE <list>
#define VOX_LIST std::list
#define VOX_VECTOR_INCLUDE <vector>
#define VOX_VECTOR std::vector
#define VOX_MAP_INCLUDE <map>
#define VOX_MAP std::map
#define VOX_STRING_INCLUDE <string>
#define VOX_STRING std::basic_string< char, std::char_traits<char>, SAllocator<char> > 


//******************************************************************************
//  20. ZIP           [ZIP]
//******************************************************************************

#ifndef VOX_ZIP_MAGIC_NUMBER
#define VOX_ZIP_MAGIC_NUMBER 0x05044c51 //'PK' 03 04 +1 //Glitch obfuscating
#endif

#ifndef VOX_ZIP_TABLE_CACHE
#define VOX_ZIP_TABLE_CACHE 0
#endif



//******************************************************************************
//  24. PROFILER              [PROFILER]
//******************************************************************************

// Enable Vox call to external profiler.  Vox doesn't have a profiler, but
// expose function to allow an application to pipe Vox profiling information
// to the profiler of their choice
// Note: Some profiling scope are fast and their scoped time may be of the same 
// order than the profiler added cost. You have to consider a "correction" for
// scoped with time near the average added cost of the profiler.
#ifndef VOX_ENABLE_CPU_PROFILING
#define VOX_ENABLE_CPU_PROFILING 0
#endif

// Bit mask of all Vox profiling event scopes
#define VOX_PROFILER_EVENT_TYPE_GENERAL		0x00000001
#define VOX_PROFILER_EVENT_TYPE_EMITTER		0x00000002
#define VOX_PROFILER_EVENT_TYPE_SOURCE		0x00000004
#define VOX_PROFILER_EVENT_TYPE_DRIVER		0x00000008
#define VOX_PROFILER_EVENT_TYPE_DECODER		0x00000010
#define VOX_PROFILER_EVENT_TYPE_STREAM		0x00000020
#define VOX_PROFILER_EVENT_TYPE_CALLBACK	0x00000040
#define VOX_PROFILER_EVENT_TYPE_IO			0x00000080
#define VOX_PROFILER_EVENT_TYPE_ALL			0xFFFFFFFF

// Bit mask to activate profiler scopes.  More than one scope can be active.
// If Vox is running in threaded mode, application profiler must be thread safe
// for any of the event scope.
// !!! IMPORTANT !!!
// VOX_PROFILER_EVENT_TYPE_CALLBACK require a thread safe application profiler,
// even when Vox is running in non-threaded mode.
#ifndef VOX_PROFILER_EVENT_ENABLED
#define VOX_PROFILER_EVENT_ENABLED 0
#endif

//******************************************************************************
//  25. VXN DECODER		[VXN DECODER]
//******************************************************************************

#ifndef VOX_NATIVE_REDUCE_LATENCY
	#define VOX_NATIVE_REDUCE_LATENCY 1
#endif

// Maximum time (in miliseconds) by which data overwrite can be performed in order to reduce latency.
#ifdef VOX_NATIVE_MAX_DATA_OVERWRITE_TIME
	#if VOX_NATIVE_MAX_DATA_OVERWRITE_TIME > ((VOX_DRIVER_SOURCE_NUM_BUFFER + 1) * VOX_EMITTER_BUFFER_DURATION_MS)
		#undef VOX_NATIVE_MAX_DATA_OVERWRITE_TIME
		#define VOX_NATIVE_MAX_DATA_OVERWRITE_TIME ((VOX_DRIVER_SOURCE_NUM_BUFFER + 1) * VOX_EMITTER_BUFFER_DURATION_MS)
	#endif
#else
	#define VOX_NATIVE_MAX_DATA_OVERWRITE_TIME ((VOX_DRIVER_SOURCE_NUM_BUFFER + 1) * VOX_EMITTER_BUFFER_DURATION_MS)
#endif

#ifndef VOX_NATIVE_LATENCY_SAFETY_MARGIN
		#define VOX_NATIVE_LATENCY_SAFETY_MARGIN 2 // In number of driver callbacks
#endif

//******************************************************************************
//  26. ANDROID				  [ANDROID]
//******************************************************************************

#ifndef VOX_DRIVER_USE_ANDROID
#define  VOX_DRIVER_USE_ANDROID 1
#endif

#ifndef VOX_ANDROID_DRIVER_PLATFORM
#ifdef _ANDROID
#define VOX_ANDROID_DRIVER_PLATFORM 1
#else
#define VOX_ANDROID_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_ANDROID_AUDIOTRACK_DRIVER_PREFERRED_RATE
#define VOX_ANDROID_AUDIOTRACK_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_ANDROID_AUDIOTRACK_DRIVER_BUFFER_LENGTH
#define VOX_ANDROID_AUDIOTRACK_DRIVER_BUFFER_LENGTH	0.02322f // In seconds. //1024 samples @ 44100
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_PREFERRED_RATE
#define VOX_ANDROID_OPENSLES_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_BUFFER_LENGTH
#define VOX_ANDROID_OPENSLES_DRIVER_BUFFER_LENGTH 0.02322f // In seconds.
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_BUFFER_NUM
#define VOX_ANDROID_OPENSLES_DRIVER_BUFFER_NUM 2 // size of buffer queue
#endif

// WARNING : Recording rate must be supported in HW! (and my vary from phone to phone)
// Non standard rates will not work!
// Rates that might work: 8, 11.025, 12, 16, 22.05, 24, 32, 44.1 and 48khz
// 96khz crashes the OS on some models
#ifndef VOX_ANDROID_OPENSLES_DRIVER_RECORDING_PREFERRED_RATE
#define VOX_ANDROID_OPENSLES_DRIVER_RECORDING_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_LENGTH
#define VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_LENGTH 0.02322f // In seconds.
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_NUM
#define VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_NUM 2 // size of buffer queue
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS
#define VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS 1 // number of interleaved sound channels
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNEL_MASK
	// mono: use center channel
	#if (VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS == 1)
		#define VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNEL_MASK 4
	#endif
	// stereo: left and right channels (usually have the same data anyways)
	#if (VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS == 2)
		#define VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNEL_MASK 3
	#endif
	// more channels: you must define your own channel mask!
	#if ((VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS != 1) && (VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS != 2))
		#error When using more than recording 2 channels on Android, you must define your own channel mask!
	#endif
#endif

//******************************************************************************
//  29. NULL DRIVER (LINUX)	  [NULL]
//******************************************************************************

#ifndef VOX_DRIVER_USE_NULL
#define  VOX_DRIVER_USE_NULL 0
#endif

#ifndef VOX_NULL_DRIVER_PLATFORM
#define VOX_NULL_DRIVER_PLATFORM 1
#endif




//******************************************************************************
//  31. ENHANCED 3D		  [ENHANCED3D]
//******************************************************************************

// Enable processing of sounds to give a front/back and up/down effect
// using filters derived from HRTFs. You will want to disable this on
// armv6 platforms, as cpu usage for mixing mono sounds gets
// multiplied by 8 unless the Neon mixer is turned on (see below).
// Even on platforms that support Neon, you might want to turn this
// off to improve performance.
// See documentations/vox_enhanced_3d.txt for more info.
#ifndef VOX_ENHANCED_3D
#define VOX_ENHANCED_3D 1
#endif

// Processes the enhanced 3d filters using floating point. No effect
// if the Neon mixer is used. Slightly slower than integer filters.
#ifndef VOX_ENHANCED_3D_FLOAT
#define VOX_ENHANCED_3D_FLOAT 0
#endif

// 1.0f = Maximum panning amount
// 0.5f = Minimum panning amount (no panning)
// 
#ifndef VOX_DEFAULT_ENHANCED_3D_STEREO_PANNING_POWER
#define VOX_DEFAULT_ENHANCED_3D_STEREO_PANNING_POWER (VOX_MAX_STEREO_PANNING_POWER * 0.96f)
#endif

// In miliseconds. Use .455 for a 30cm head.
#ifndef VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_FRONT
#define VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_FRONT 0.355f 
#endif

// In miliseconds. Use .455 for a 30cm head.
#ifndef VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_BACK
#define VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_BACK 0.555f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH
#define VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH 40.0f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_SIDE
#define VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_SIDE -0.5f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_BACK
#define VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_BACK -0.1f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_DISTANCE
#define VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_DISTANCE 0.0f
#endif



#ifndef VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH
#define VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH 0.025f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_SIDE
#define VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_SIDE 5.0f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_BACK
#define VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_BACK 1.0f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_DISTANCE
#define VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_DISTANCE 0.0f
#endif



#ifndef VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MINIMUM
#define VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MINIMUM 3.0f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MAXIMUM
#define VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MAXIMUM 12.0f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_CURVE
#define VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_CURVE 6.0f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_SIDE
#define VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_SIDE 0.0f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_BACK
#define VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_BACK 0.2f
#endif

#ifndef VOX_DEFAULT_ENHANCED_3D_DISTANCE_FREQUENCY
#define VOX_DEFAULT_ENHANCED_3D_DISTANCE_FREQUENCY 1500.0f
#endif


// This factor multiplies all the rolloffs when in enhanced3d mode.
// Use this to compensate volume loss from the filters.
// Values lower than 1 = more rolloff = less effect from distance.
// Suggested range: 0.5f to 1.0f
#ifndef VOX_DEFAULT_ENHANCED_3D_ROLLOFF_FACTOR
#define VOX_DEFAULT_ENHANCED_3D_ROLLOFF_FACTOR 1.0f
#endif




//******************************************************************************
//  32. NEON		  [NEON]
//******************************************************************************

// Speeds up mixing
#ifndef VOX_USE_NEON_MIXER
#define VOX_USE_NEON_MIXER 1
#endif

// Speeds up decoding of IMA adpcm wav files (VXN support will be added later)
#ifndef VOX_USE_NEON_DECODER_IMA
#define VOX_USE_NEON_DECODER_IMA 1
#endif

// Speeds up decoding of MS adpcm wav files (VXN support will be added later)
#ifndef VOX_USE_NEON_DECODER_MS
#define VOX_USE_NEON_DECODER_MS 1
#endif



#if defined(__ARM_NEON__)
	#if VOX_USE_NEON_MIXER
	#define VOX_NEON_MIXER 1
	#else
	#define VOX_NEON_MIXER 0
	#endif

	#if VOX_USE_NEON_DECODER_IMA
	#define VOX_NEON_DECODER_IMA 1
	#else
	#define VOX_NEON_DECODER_IMA 0
	#endif

	#if VOX_USE_NEON_DECODER_MS
	#define VOX_NEON_DECODER_MS 1
	#else
	#define VOX_NEON_DECODER_MS 0
	#endif

#else // IPhone & Android armv6..
	#define VOX_NEON_MIXER 0
	#define VOX_NEON_DECODER_IMA 0
	#define VOX_NEON_DECODER_MS 0
#endif





#endif //_VOX_DEFAULT_CONFIG_H_
