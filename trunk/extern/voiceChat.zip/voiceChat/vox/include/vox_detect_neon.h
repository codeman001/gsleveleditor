#pragma once
#ifndef _VOX_DETECT_NEON_H_
#define _VOX_DETECT_NEON_H_

namespace vox
{
// This flag is set in DriverCallbackInterface::Init(void* param)
bool neonInstructionsPresent();

bool DetectNeonInstructionsPresent();
}

#endif // _VOX_DETECT_NEON_H_

