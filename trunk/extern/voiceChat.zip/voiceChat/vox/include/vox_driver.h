#pragma once
#ifndef _VOX_DRIVER_H_
#define _VOX_DRIVER_H_

#include "vox_types.h"
#include "vox.h"

namespace vox {



namespace DriverSource
{
	enum
	{
		STATE_ERROR = -1,
		STATE_INITIAL,
		STATE_PLAYING,
		STATE_PAUSED,
		STATE_STOPPED
	};
};

struct DriverSourceParam
{
public:
	DriverSourceParam();
	virtual ~DriverSourceParam() {}

public:
	s32 numBuffer;
};

class DriverSourceInterface
{
public:
	virtual ~DriverSourceInterface(){}

	virtual void Play()=0;
	virtual void Stop()=0;
	virtual void Pause()=0;
	virtual void Reset()=0;

	virtual s32 GetState()=0;

	virtual long GetByteOffset()=0;
	virtual void SetByteOffset(s32 offset)=0;

	virtual bool NeedData()=0;
	virtual void UploadData(void* soundData, s32 bufferSize)=0;

	virtual void SetGain(f32 gain)=0;
	virtual void SetPitch(f32 pitch)=0;
	
	virtual f32 GetGain()=0;
	virtual f32 GetPitch()=0;

	virtual void Set3DParameter(s32 paramId, void* param)=0;
	virtual void SetDSPParameter(s32 paramId, void* param){};

	virtual void Update(f32 dt){}

	virtual bool AllowBufferReference(){return false;}
	virtual void FreeDisposableData(s32 maxSamplesToFree, s32 &nbBuffersFreed, s32 &nbBytesFreed){};

	virtual void PrintDebug()=0;

	virtual s32 GetBufferCount()=0;
protected:

	virtual void Init()=0;
	virtual void Cleanup()=0;
};

class DriverInterface
{
public:
	virtual ~DriverInterface(){};

	virtual void Init(void* param)=0;
	virtual void Shutdown()=0;
	
	virtual void Suspend()=0;
	virtual void Resume()=0;
	
	virtual void RampOut(){}
	virtual void RampIn(){}
	
	virtual void Update(f32 dt){}

	virtual void Set3DParameter(s32 paramId, void* param)=0;
	virtual void SetDSPParameter(s32 paramId, void* param){};

	virtual bool SetOutputMode(VoxOutputMode mode){return false;}
	virtual VoxOutputMode GetOutputMode(){return k_nOutputModeStereo;}

	virtual void PrintDebug()=0;

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0)=0;
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource)=0;

	virtual bool SetMicrophoneCallback(RecordedAudioReceptor *generator){return false;}
	virtual void RemoveMicrophoneCallback(){}
//protected:

};

extern "C++" DriverInterface* CreateDriver();

};//namespace vox

#endif //_VOX_DRIVER_H_
