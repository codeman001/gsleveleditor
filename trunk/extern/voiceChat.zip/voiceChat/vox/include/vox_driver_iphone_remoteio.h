#pragma once
#ifndef _VOX_DRIVER_IPHONE_REMOTEIO_H_
#define _VOX_DRIVER_IPHONE_REMOTEIO_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM
#include "vox_driver_callback_template.h"
#include "vox_internal.h"
#include <AudioUnit/AudioUnit.h>

namespace vox {



class DriverIPhoneRemoteIO : public DriverCallbackInterface
{
public:
	DriverIPhoneRemoteIO();
	virtual ~DriverIPhoneRemoteIO();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	
	
	virtual void RampOut(){m_needRampOut = true;}
	virtual void RampIn(){m_needRampIn = true;}

	virtual void PrintDebug();

	virtual void Update(f32 dt);
	
private:

	virtual void FillBuffer(s16* outBuffer, s32 nbSample);	
	
	void _InitializeAudioUnit();
	void _Suspend();
	void _Resume();	


	static OSStatus playbackCallback(void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags, const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber, UInt32 inNumberFrames, AudioBufferList *ioData);
	static OSStatus recordingCallback(void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags, const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber, UInt32 inNumberFrames, AudioBufferList *ioData);
	
	f64  m_hwSampleRate;
	bool m_needResampling;
	s16* m_resampleBuffer;
	s32	 m_resampleBufferSize;
	fx1814 m_resamplePos;
	s16  m_prevLeft, m_prevRight;

	AudioComponentInstance m_audioUnit;	
	bool m_audioCallbackActive;
	bool m_audioUnitInitialized;
	bool m_driverSuspended;
	int  m_nbAudioUnitReactivationTrials;
	f32  m_reactivationTrialInterval;
	bool m_needRampOut;
	bool m_needRampIn;
	bool m_isMuted;

	volatile s32 m_interruptionLevel; // 0 = running. >=1 driver is interrupted. -1 = driver is interrupted, try to autoresume if non suspended.
	UInt32 m_defaultAudioSessionCategory;
	f32 m_timeSinceOtherAudioCheck; // incremented up to 500ms when autoresuming.
	s32 m_checkThreshold; // this counts the number of times we wait 500ms when autoresuming. After 3 times, try to resume driver.

	RecordedAudioReceptor *m_microphoneReceptor;
    Mutex m_recordingMutex;
	AudioBufferList *m_recordingBuffer;
	
	s16 *m_inResamplingBuffer;
	s32  m_inResamplingBufferSize; // must have extra samples for overflow and size variation
	u32  m_inResamplingPointer; // must be unsigned!!
	s32  m_inResamplingMemory[VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS];
	s32  m_inResamplingAccum [VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS];

	static void interruptionListenerCallback(void *inUserData,UInt32 interruptionState);
	void beginInterruption();
	void endInterruption();
	void ForceEndAudioInterruption();

	virtual bool SetMicrophoneCallback(RecordedAudioReceptor *receptor);
	virtual void RemoveMicrophoneCallback();

};

};//namespace vox

#endif //VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM

#endif //_VOX_DRIVER_IPHONE_REMOTEIO_H_
