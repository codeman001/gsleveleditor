#pragma once
#ifndef _VOX_DRIVER_IPHONE_REMOTEIO_HELPER_H_
#define _VOX_DRIVER_IPHONE_REMOTEIO_HELPER_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM

namespace vox
{
	int GetMajorOSVersion();
	bool Is1stGenDevice();
}

#endif //VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM

#endif //_VOX_DRIVER_IPHONE_REMOTEIO_H_
