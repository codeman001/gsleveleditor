#pragma once
#ifndef _VOX_DRIVER_MMSYSTEM_H_
#define _VOX_DRIVER_MMSYSTEM_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM

#include <mmsystem.h>
#include "vox_driver_callback_template.h"

#define VOX_DRIVER_MMSYSTEM_DEFAULT_NB_BUFFERS	5
#define VOX_DRIVER_MMSYSTEM_DEFAULT_NB_SAMPLES	512

namespace vox 
{

class DriverMMSystem : public DriverCallbackInterface
{
public:
	DriverMMSystem();
	virtual ~DriverMMSystem();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug(){}

	virtual bool SetMicrophoneCallback(RecordedAudioReceptor *receptor);
	virtual void RemoveMicrophoneCallback();

private:
	static void UpdateThreaded(void* caller, void* param);
	void UpdateData(void);

	static void UpdateInputThreaded(void* caller, void* param);
	void UpdateInputData(void);

	void InitInput();
	void ShutdownInput();

	// Buffer parameters
	u32		m_nbBuffers;
	s32		m_bufferSize;
	s32		m_currentBuffer;
	u8**	m_pOutBuffers;

	// MMSytem parameters
	WAVEFORMATEX	m_waveformat;
	HWAVEOUT		m_waveOut;			// Wave out object.
	WAVEHDR			*m_pWaveBlocks;		// Objects containing buffer address provided (by reference) to mmsystem.

	VoxThread*	m_updateThread;
	bool		m_isThreadRunning;

	struct
	{
		// Buffer parameters
		u32		m_nbBuffers;
		s32		m_bufferSize;
		s32		m_currentBuffer;
		u8**	m_pOutBuffers;

		// MMSytem parameters
		WAVEFORMATEX	m_waveformat;
		HWAVEIN		m_waveOut;			// Wave out object.
		WAVEHDR			*m_pWaveBlocks;		// Objects containing buffer address provided (by reference) to mmsystem.

		VoxThread*	m_updateThread;
		bool		m_isThreadRunning;
		bool        m_audioUnitActive;

		RecordedAudioReceptor *m_microphoneReceptor;
		Mutex m_mutex;
	} input;

};

}//namespace vox

#endif // VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM
#endif //_VOX_DRIVER_MMSYSTEM_H_
