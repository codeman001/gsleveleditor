#pragma once
#ifndef _VOX_DRIVER_NULL_H_
#define _VOX_DRIVER_NULL_H_

#include "vox_driver.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_NULL && VOX_NULL_DRIVER_PLATFORM

namespace vox {

class DriverNull : public DriverInterface
{
public:
	DriverNull(){}
	virtual ~DriverNull(){}

	virtual void Init(void* param){}
	virtual void Shutdown(){}
	
	virtual void Suspend(){}
	virtual void Resume(){}
	
	virtual void RampOut(){}
	virtual void RampIn(){}
	
	virtual void Update(f32 dt){}

	virtual void Set3DParameter(s32 paramId, void* param){}
	virtual void SetDSPParameter(s32 paramId, void* param){}

	virtual bool SetOutputMode(VoxOutputMode mode){return false;}
	virtual VoxOutputMode GetOutputMode(){return k_nOutputModeStereo;}

	virtual void PrintDebug(){}

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0){ return 0; }
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource){}

//protected:

};

};//namespace vox

#endif // VOX_DRIVER_USE_NULL && VOX_NULL_DRIVER_PLATFORM

#endif //_VOX_DRIVER_H_
