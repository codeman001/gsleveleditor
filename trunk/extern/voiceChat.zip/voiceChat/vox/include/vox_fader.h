#ifndef _VOX_FADER_H_
#define _VOX_FADER_H_

#include "vox_types.h"

namespace vox
{

class Fader
{
public:
	Fader():m_startValue(0.0f), m_endValue(1.0f), m_time(0.0f), m_totalTime(0.0f), m_done(true){}
	~Fader(){}
	Fader(f32 startValue, f32 endValue, f32 time):m_startValue(startValue), m_endValue(endValue), m_time(0.0f), m_totalTime(time), m_done(false){}

	void  Update(f32 dt){m_time < m_totalTime ? m_time += dt : m_done = true;}
	f32 GetStartValue(){return m_startValue;}
	f32 GetEndValue(){return m_endValue;}
	f32 GetCurrentValue() const {return (m_time < m_totalTime ? (m_totalTime > 0.0f ? (m_startValue + (m_endValue - m_startValue) * m_time / m_totalTime) : m_startValue) : m_endValue);}
	//bool  IsFinished(){return (m_totalTime <= 0.0f) || (m_time >= m_totalTime);}
	bool  IsFinished(){return m_done;}
	float GetRemainingTime(){return m_totalTime - m_time;}
private:
	f32 m_startValue;
	f32 m_endValue;
	f32 m_time;
	f32 m_totalTime;
	bool m_done;
};

} // namespace vox

#endif // _VOX_FADER_H_

