#pragma once
#ifndef _VOX_FILE_SYSTEM_H_
#define _VOX_FILE_SYSTEM_H_

#include "vox_types.h"
#include "vox_memory.h"
#include "vox_mutex.h"

namespace vox
{
class FileSystemInterface;
class CZipReader;
extern FileSystemInterface* VoxNewFileSystem();

enum VoxFileType
{
	k_nNormalFile,
	k_nLimitedFile
};

enum VoxFileSeekOrigin
{
	k_nSeekSet,
	k_nSeekCur,
	k_nSeekEnd
};

enum VoxFileAccessMode
{
	k_nRead,
	k_nCreateWrite,
	k_nAppend,
	k_nReadWrite,
	k_nCreateReadWrite,
	k_nReadAndAppend,
	k_nReadBinary,
	k_nCreateWriteBinary,
	k_nAppendBinary,
	k_nReadWriteBinary,
	k_nCreateReadWriteBinary,
	k_nReadAndAppendBinary
};

enum VoxZipStreamMode
{
	k_nZipExtensionRead,
	k_nZipExtensionWrite,
	k_nZipExtensionCreateWrite
};

enum VoxZipStreamStatus
{
	k_nZipInvalid = -1,
	k_nZipWithExtension,
	k_nZipWithoutExtension,
};

struct IOFunc {

	IOFunc():read(0), write(0), seek(0), tell(0), open(0), close(0){}

    /// Reads size bytes of data into buffer at ptr.
	s32 (*read) ( void * ptr, s32 size, s32 count, void * stream );

	s32 (*write) ( const void * ptr, s32 size, s32 count, void * stream );

    /// Seeks to byte position offset.
	s32 (*seek) ( void * stream, s32 offset, VoxFileSeekOrigin origin );

    /// Returns the current byte offset in the stream.
	s32 (*tell) ( void * stream );

	void* (*open) ( const c8 * filename, VoxFileAccessMode mode );

	s32 (*close) ( void * stream );
};

struct FileInterfaceInternalData;
struct FileSystemInterfaceInternalData;

class FileInterface
{
public:
	FileInterface();
	FileInterface(void* filePtr, const char* fullpath);
	virtual ~FileInterface();

	virtual s32 Read(void* dest, s32 size, s32 count);
	virtual s32 Seek(s32 offset, VoxFileSeekOrigin origin);
	virtual s32 Tell();
	virtual s32 Write(const void * dest, s32 size, s32 count);

	virtual const char* GetFilePath();
	virtual void* GetFilePtr();

protected:
	FileInterfaceInternalData *dat;
};

// read-only scoped file
class FileLimited : public FileInterface
{
public:
	FileLimited();
	FileLimited(void* filePtr, const char* fullpath, s32 baseOffset, s32 fileSize);
	virtual ~FileLimited(){}

	virtual s32 Read(void* dest, s32 size, s32 count);
	virtual s32 Seek(s32 offset, VoxFileSeekOrigin origin);
	virtual s32 Tell();
	virtual s32 Write(const void * dest, s32 size, s32 count){return 0;}

protected:
	s32 m_baseOffset;
	s32 m_fileSize;
	s32 m_filePosition;
};

class FileSystemInterface
{
public:
	static FileSystemInterface* GetInstance();
	static void DestroyInstance();
	virtual ~FileSystemInterface();

	virtual FileInterface* OpenFile(c8* filename, VoxFileAccessMode mode = k_nReadBinary);
	virtual s32 CloseFile(FileInterface* fileInterface);

	// Sets current .zip archive. Any previously active archives are closed.
	virtual s32 SetArchive(const c8* zipfilename, bool ignoreCase, bool ignorePath, bool tryArchiveFirst);
	// Adds a new archive to the set of currently open archives.
	// The "tryArchiveFirst" flag is global to all archives and gets overwritten.
	virtual s32 AddArchive(const c8* zipfilename, bool ignoreCase, bool ignorePath, bool tryArchiveFirst);
	
	virtual s32 PushDirectory(c8* directory);
	virtual s32 PopDirectory();

	static s32 GetDirectory(c8* dest, s32 size, c8* fullPath);

	static IOFunc m_IOFunc;

protected:
	FileSystemInterface();

	static FileSystemInterface* m_instance;

protected:
	bool m_archiveFirst;

	FileSystemInterfaceInternalData *m_internalData;
	Mutex		m_mutex;

private:
	virtual FileInterface* _OpenFile(c8* filename, VoxFileAccessMode mode = k_nReadBinary);
	virtual s32 _CloseFile(FileInterface* fileInterface);

	friend class ZipTableSerializer;
	friend class CZipReader;
};

// Class ZipTableSerializer provides a read or write stream into the extension table
// appended at the end of a zip file. The extension consists a serie of informations
// about the zip internal files (mainly the local headers) and a 8-bytes post-header
// containing the keyword "ZET_" (for Zip Extension Table) and the size of the extension
// (including the post-header) as a little-endian 4-bytes word.

class ZipTableSerializer
{
public:
	ZipTableSerializer(const c8* filename, VoxZipStreamMode mode);
	~ZipTableSerializer();

	void Close();							// Used to close file without writing extension.

	// Read methods
	size_t Read(void* buffer, size_t size);
	size_t ReadByte(u8 &byteValue);
	size_t ReadInt(s32 &intValue);
	size_t ReadShort(s16 &shortValue);

	// Write methods
	size_t Write(const void* buffer, size_t size);
	size_t WriteByte(u8 byteValue);
	size_t WriteInt(s32 intValue);
	size_t WriteShort(s16 shortValue);

	VoxZipStreamStatus GetStatus(void);
	const char* GetFilePath();				// Returns full path name of file received in constructor.
private:
	static const s32 k_extensionHeaderSize;	// Size of zip extension header (in bytes).

	FileInterface* m_fp;
	VoxZipStreamMode m_streamMode;			// Reading or writing (in new or existing file)
	s32 m_streamSize;						// Size of stream, excluding signature (in bytes)
	s32 m_cursorPosition;					// Cursor position into stream
	VoxZipStreamStatus m_status;

	u8 *m_cacheData;						// Pointer to cache data

	bool ParseExtensionHeader(void);

	inline void ConvertUnsignedShortToBE(u16 &value)
	{
		value = (value >> 8) | (value << 8);
	}

	inline void ConvertUnsignedIntToBE(u32 &value)
	{
		value = (value >> 24) | ((value >> 8) & 0x0000FF00) | ((value << 8) & 0x00FF0000) | (value << 24);
	}

	inline void ChangeIntEndianness(s32 &value)
	{
		u32 unsignedValue = static_cast<u32> (value);
		ConvertUnsignedIntToBE(unsignedValue);
		value = static_cast<s32> (unsignedValue);
	}

	inline void ChangeShortEndianness(s16 &value)
	{
		u16 unsignedValue = static_cast<u16> (value);
		ConvertUnsignedShortToBE(unsignedValue);
		value = static_cast<s16> (unsignedValue);
	}
};

} // namespace vox

#endif // _VOX_FILE_SYSTEM_H_
