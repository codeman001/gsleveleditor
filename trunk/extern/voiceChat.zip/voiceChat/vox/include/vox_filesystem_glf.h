#pragma once
#ifndef _VOX_FILE_SYSTEM_GLF_H_
#define _VOX_FILE_SYSTEM_GLF_H_

#include "vox_default_config.h"

#if VOX_USE_GLF

#include "vox_filesystem.h"

namespace vox
{
class FileSystemGLF : public FileSystemInterface
{
public:
	FileSystemGLF();
	virtual ~FileSystemGLF();
};
}

#endif //VOX_USE_GLF
#endif //_VOX_FILE_SYSTEM_GLF_H_
