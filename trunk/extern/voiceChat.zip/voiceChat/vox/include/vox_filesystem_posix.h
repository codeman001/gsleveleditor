#pragma once
#ifndef _VOX_FILE_SYSTEM_POSIX_H_
#define _VOX_FILE_SYSTEM_POSIX_H_

#include "vox_default_config.h"

#if ((defined(VOX_TARGET_OS_IPHONE)) && VOX_USE_POSIX_FILESYSTEM) && !VOX_USE_GLF

#include "vox_filesystem.h"

namespace vox
{

struct FilePosixInfo
{
	s32 m_fildes;
	s32 m_position;
	s32 m_size;
	void* m_mmapptr;
};

class FileSystemPosix : public FileSystemInterface
{
public:
	FileSystemPosix();
	virtual ~FileSystemPosix();
};

}

#endif
#endif //_VOX_FILE_SYSTEM_POSIX_H_
