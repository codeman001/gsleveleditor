#pragma once
#ifndef _VOX_FILTER_H_
#define _VOX_FILTER_H_

namespace vox
{

struct VoxFilter
{
public:
	VoxFilter();
	void setDistanceShelf(f32 attenuation, f32 sampleRate);
	void setDistanceBandpass(f32 bandwidth, f32 cutoff, f32 sampleRate);
	void setNotch(f32 cutoff, f32 gain, f32 bandwidth, f32 sampleRate);
public:
	f32 a0,a1,a2;
	f32 b1,b2;
	f32 x1,x2;
	f32 y1,y2;
	s32 err; // For error diffusion in s32 version

	static inline int clip_s16(float value)
	{
		if(value>32767.f)
			return 32767;
		if(value<-32768.f)
			return -32768;
		return (int)(value+0.5);
	}

	static inline int clip_s32(float value)
	{
		if(value >=  2147483647.f)
		{
			return 0x7fffffff;
		}
		if(value <= -2147483648.f)
		{
			return -0x8000000;
		}

		return (int)(value+0.5);
	}

};

struct VoxFilterInteger
{
	s32 a0,a1,a2;
	s32 b1,b2;
	s32 x1,x2;
	s32 y1,y2;
	s32 err; // For error diffusion in s32 version
};

} // namespace vox

#endif // _VOX_FILTER_H_
