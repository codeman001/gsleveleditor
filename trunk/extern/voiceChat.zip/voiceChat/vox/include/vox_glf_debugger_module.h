#pragma once
#ifndef _VOX_GLF_DEBUGGER_MODULE_H_
#define _VOX_GLF_DEBUGGER_MODULE_H_

#if VOX_USE_GLF_DEBUGGER_MODULE

#include <glf/debugger/debugger.h>
#include <vox_thread.h>

namespace vox
{

struct MessagesBuffer
{
	c8* m_data;
	s32 m_size;				// Size of buffer in bytes.
	s32 m_startPosition;	// In bytes.
	s32 m_nbValidBytes;		// Nb of valid bytes from start to end position (both included)

	MessagesBuffer():m_data(0), m_size(0), m_startPosition(0), m_nbValidBytes(0) {}

	void Clear()
	{
		m_startPosition = 0;
		m_nbValidBytes = 0;
	}
};

class VoxGlfDebuggerModule : public glf::debugger::Module
{
 private:
	enum State
	{
		S_WAITING_FOR_CLIENT,
		S_CONFIRM_COMMAND,
		S_DATA_TRANSFER
	};

	// Client to server message type
	enum CSMessageType
	{
		// Client asks server to start sending data
		// MT_CS_START_DATA_TRANSFER format:
		// No data with this message
		CS_START_DATA_TRANSFER,
		//
		// Client asks server to stop sending data
		// CS_STOP_DATA_TRANSFER format:
		// No data with this message
		CS_STOP_DATA_TRANSFER,
	};

	// Server to client message type
	enum SCMessageType
	{
		// Server sends data to client
		// SC_DATA_TRANSFER format:
		// char : Character representing the messages separator
		// dataSize * Byte : Block of data terminated with a null character
		SC_DATA_TRANSFER,
		//
		// Server sends client a confirmation that it has correctly received its command.
		// MT_SC_COMMAND_CONFIRMATION format:
		// IntLE : Value of the command received (e.g. CS_START_DATA_TRANSFER)
		SC_COMMAND_CONFIRMATION
	};

 public:
	virtual ~VoxGlfDebuggerModule();

	static VoxGlfDebuggerModule* GetInstance();
	static void ReleaseInstance();

	virtual void ConnectionClosed();
	virtual void DebuggerDestroyed();
	virtual void Parse(int type, glf::debugger::PacketReader& in);

	void AddConsoleMessage(const c8 *message);
	bool IsActive();
 private:
	static VoxGlfDebuggerModule* s_pInstance;	// Instance of singleton
	static Mutex s_instanceMutex;				// Mutex to protect singleton instance
	static const c8 k_messageSeparator;

	bool m_isFunctional;	// True if glf debugger module is functional

	State m_state;

	// Buffer containing vox console messages 
	MessagesBuffer m_messagesBuffer;

	// Thread parameters
	VoxThread* m_updateThread;
	bool m_isActive;

	CSMessageType m_clientCommand;

	Mutex m_mutex;

	static void UpdateThreaded(void* caller, void* param);

	VoxGlfDebuggerModule();
	void SendData();
	bool Start();							// Returns true if console exporter has started correctly
	void Stop();
	void Update();
};

} // namespace vox

#endif // VOX_USE_GLF_DEBUGGER_MODULE
#endif // _VOX_GLF_DEBUGGER_MODULE_H_

