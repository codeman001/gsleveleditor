#pragma once
#ifndef _VOX_GROUP_H_
#define _VOX_GROUP_H_

#include "vox_default_config.h"
#include <string.h>
#include VOX_VECTOR_INCLUDE

#include "vox_fader.h"

#define VOX_GROUP_NAME_SIZE 32

namespace vox
{

class Group
{
public:
	Group();
	Group(u32 id, const char *name, u32 parent);
	virtual ~Group();

	void Update(f32 dt);

	u32 GetId(void) const;
	const char *GetName(void) const;
	u32 GetParent(void) const;

	bool GetEnable(void) const;
	void SetEnable(bool enable, f32 fadeTime);
	f32 GetVolume(void) const;			// Get group volume (without ancestors volumes or faders).
	void SetVolume(f32 volume, f32 fadeTime);

	f32 GetFaderVolume(void) const;

private:	
	u32 m_id;							// Same as group index in GroupManager vector.
	float m_volume;						// Group volume (without including ancestors).
	u32 m_parent;						// Must use parentId instead of pointer - pointer becomes invalid on reallocation
	char m_name[VOX_GROUP_NAME_SIZE];
	bool m_enable;						// If false, GetEffectiveVolume() returns 0.

	Fader m_fader;

public:
	f32 m_effectiveVolume;
};


class GroupManager
{
public:
	GroupManager();
	~GroupManager();

	u32 AddGroup(group::CreationSettings &cs);
	bool ReconfigureGroup(u32 id, group::CreationSettings &cs);

	u32 GetGroupId(const char *name) const;
	bool GetGroupName(u32 id, char *stringData, s32 maxString) const;
	bool IsChild(u32 candidateId, u32 matchId) const;
	bool IsGroupValid(u32 id) const;

	bool GetEnable(u32 id) const;	
	bool SetEnable(u32 id, bool enable, f32 fadeTime);
	f32 GetVolume(u32 id) const;
	bool SetVolume(u32 id, f32 volume, f32 fadeTime);
	
	void Update(f32 dt);
	f32 GetEffectiveVolume(u32 id) const;

private:
	VOX_VECTOR<Group, SAllocator<Group> > m_groups;
};

} // namespace vox

#endif //_VOX_GROUP_H_

