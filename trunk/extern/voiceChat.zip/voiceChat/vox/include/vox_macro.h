#pragma once
#ifndef _VOX_MACRO_H
#define _VOX_MACRO_H

#include "vox_memory.h"
#include "vox_console.h"
#include "vox_default_config.h"

#if VOX_ENABLE_CONSOLE
#define VOX_CONSOLE_OUT(level, msg, ...) vox::Console::Print(level, msg, __VA_ARGS__)
#else
#define VOX_CONSOLE_OUT(...)
#endif

#define VOX_WARNING_LEVEL_1(msg, ...) VOX_CONSOLE_OUT(1, msg "\n", __VA_ARGS__)
#define VOX_WARNING_LEVEL_2(msg, ...) VOX_CONSOLE_OUT(2, msg "\n", __VA_ARGS__)
#define VOX_WARNING_LEVEL_3(msg, ...) VOX_CONSOLE_OUT(3, msg "\n", __VA_ARGS__)
#define VOX_WARNING_LEVEL_4(msg, ...) VOX_CONSOLE_OUT(4, msg "\n", __VA_ARGS__)
#define VOX_WARNING_LEVEL_5(msg, ...) VOX_CONSOLE_OUT(5, msg "\n", __VA_ARGS__)

#if VOX_ENABLE_CONSOLE
#define VOX_ASSERT_MSG(X, msg) if(!(X)) { VOX_WARNING_LEVEL_1("Assertion failed (%s:%d): " msg, __FUNCTION__, __LINE__); VOX_ASSERT(X); }
#else
#define VOX_ASSERT_MSG(X, msg) VOX_ASSERT(X)
#endif

#if (VOX_THREAD_SAFETY_LEVEL >= 2)
#define VOX_MUTEX_LEVEL_1(X) X
#define VOX_MUTEX_LEVEL_2(X) X
#elif (VOX_THREAD_SAFETY_LEVEL == 1)
#define VOX_MUTEX_LEVEL_1(X) X
#define VOX_MUTEX_LEVEL_2(X)
#else
#define VOX_MUTEX_LEVEL_1(X)
#define VOX_MUTEX_LEVEL_2(X)
#endif

#endif
