#pragma once
#ifndef _MEMORY_H_
#define _MEMORY_H_

#ifdef VOX_NEW
#undef VOX_NEW
#endif

#ifdef VOX_DELETE
#undef VOX_DELETE
#endif

// New in Vox 1.1:

// Applications MUST now use custom allocator (mandatory).
// You must define the 4 VoxAlloc functions, and VoxFree. Example:
// 
// #include "vox_memory.h" // for vox::VoxMemHint type
// void* VoxAlloc(size_t size, const char* filename, const char* function, int line) {return malloc(size);}
// void* VoxAlloc(size_t size) {return malloc(size);}
// void* VoxAlloc(size_t size, vox::VoxMemHint memhint, const char* filename, const char* function, int line) {return VoxAlloc(size, filename, function, line);}
// void* VoxAlloc(size_t size, vox::VoxMemHint memhint) {return VoxAlloc(size);}
// void  VoxFree(void* ptr) {return free(ptr);}

namespace vox
{
	enum VoxMemHint
	{
		k_nVoxMemHint_AlignAny = 0,
		k_nVoxMemHint_Align4 = 4,
		k_nVoxMemHint_Align8 = 8,
		k_nVoxMemHint_Align16 = 16,
		k_nVoxMemHint_Align32 = 32,
		k_nVoxMemHint_Align64 = 64,
		k_nVoxMemHint_Align128 = 128,
		k_nVoxMemHint_Align256 = 256,
		k_nVoxMemHint_Align512 = 512,
		k_nVoxMemHint_Align1024 = 1024,
		k_nVoxMemHint_Align2048 = 2048,

		k_nVoxMemHint_AlignMask = 0x00000FFF,
	};
}

#define VOX_ALLOC(X) VoxAlloc(X, vox::k_nVoxMemHint_AlignAny, __FILE__, __FUNCTION__, __LINE__)
#define VOX_ALLOC_ALIGN(X,A) VoxAlloc(X, A, __FILE__, __FUNCTION__, __LINE__)

#define VOX_FREE(X) VoxFree(X)
#define VOX_NEW new(vox::k_nVoxMemHint_AlignAny, __FILE__, __FUNCTION__, __LINE__)


template <class T> void Destruct(T* x) 
{
	x->~T();
}
#define VOX_DELETE(X) if(X != 0){Destruct(X); VOX_FREE(X);}

#include <new>

#if defined(_WIN32)
#pragma warning( disable : 4290 )
#pragma warning( disable : 4291 )
#endif

void* VoxAlloc(size_t size, const char* filename, const char* function, int line);
void* VoxAlloc(size_t size);
void* VoxAlloc(size_t size, vox::VoxMemHint memhint);
void* VoxAlloc(size_t size, vox::VoxMemHint memhint, const char* filename, const char* function, int line);
void VoxFree(void* ptr);

inline
void* operator new(std::size_t blocksize, vox::VoxMemHint hint)
{
	return VoxAlloc(blocksize, hint);
}

inline 
void* operator new(std::size_t blocksize, vox::VoxMemHint hint, const char* in_pszFileName, const char* in_pszFuncName, const int in_nLineNumber)
{
	return VoxAlloc(blocksize, hint, in_pszFileName, in_pszFuncName, in_nLineNumber);
}

namespace vox
{
	//! Very simple allocator implementation, containers using it can be used across dll boundaries
template<typename T, vox::VoxMemHint Hint = vox::k_nVoxMemHint_AlignAny>
class SAllocator
{
public:

	// STL allocator compliance defs

	typedef size_t size_type;
	typedef std::ptrdiff_t difference_type;
	typedef T* pointer;
	typedef const T* const_pointer;
	typedef T& reference;
	typedef const T& const_reference;
	typedef T value_type;

	template <typename T1>
	struct rebind
	{
		typedef SAllocator<T1> other;
	};

	SAllocator()
	{
	}

	template <typename T2>
	SAllocator(const SAllocator<T2>& /*other*/)
	{
	}

	pointer address(reference r) const
	{
		return &r;
	}

	const_pointer address(const_reference r) const
	{
		return &r;
	}

	//! Allocate memory for an array of objects
	T* allocate(size_t cnt, const void* hint = 0)
	{
		return (T*)internal_new(cnt* sizeof(T));
	}

	size_type max_size() const
	{
		return size_type(-1) / sizeof(T);
	}

	//! Deallocate memory for an array of objects
	void deallocate(T* ptr, size_type n = 0)
	{
		internal_delete(ptr);
	}

	//! Construct an element
	void construct(T* ptr, const T& e)
	{
		new ((void*)ptr) T(e);
	}

	//! Synonym for destruct (for STL compliance).
	void destroy(T* ptr)
	{
		ptr->~T();
	}

	// Below operators are required by some STL implementations

	bool operator == (const SAllocator& /*rhs*/) const
	{
		return true;
	}

	bool operator != (const SAllocator& /*rhs*/) const
	{
		return false;
	}

protected:

	void* internal_new(size_t cnt)
	{
		return VOX_ALLOC_ALIGN(cnt, Hint);
	}

	void internal_delete(void* ptr)
	{
		VOX_FREE(ptr);//delete(ptr);
	}

}; // end class SAllocator<T>
}


#endif
