#pragma once
#ifndef _VOX_MINIBUS_SYSTEM_H_
#define _VOX_MINIBUS_SYSTEM_H_

#include "vox_driver.h"
#include "vox_internal.h"		// To access Fader class
#include "vox_custom_dsp.h"
#include "vox_default_config.h"
#include "vox_types.h"

#include VOX_LIST_INCLUDE

#if defined(_WIN32)
	#define STRICMP _stricmp
#else
	#define STRICMP strcasecmp	
#endif

namespace vox
{

//Defines
#define VOX_MINIBUS_UNKNOWN -1
#define VOX_MINIBUS_MASTER	0
#define VOX_MINIBUS_AUX1	1
#define VOX_MINIBUS_AUX2	2

namespace minibus
{
enum GeneratorType
{
	GT_DRIVER_SOURCE,   // Internal vox sources
	GT_DATA_GENERATOR   // Data generator plugin
};
}

struct MiniBusGeneratorElement
{
	minibus::GeneratorType generatorType;
	void *generator;
};

class MiniBus
{
 public:
	MiniBus();
	virtual ~MiniBus();

	static void SetDriverSampleRate(s32 sampleRate){s_driverSampleRate = sampleRate;};

	s32 GetId(){return m_id;}
	f32 GetVolume(VoxDSPGeneralParameter::BusRoutingType path);

	void SetId(s32 id);
	void SetVolume(VoxDSPGeneralParameter::BusRoutingType path, f32 volume, f32 fadeTime);
	void RegisterDataGenerator(MinibusDataGeneratorInterface *pDataGenerator);
	bool UnregisterDataGenerator(MinibusDataGeneratorInterface *pDataGenerator);

	virtual void Update(f32 dt)=0;
 protected:
	static s32 s_driverSampleRate;

	s32  m_nbSamples;	// Nb of samples in wet and dry buffers
	s32* m_pWetBuffer;
	s32* m_pDryBuffer;

	fx1814 m_volumeDry;
	fx1814 m_volumeWet;

	Fader m_dryVolumeFader;
	Fader m_wetVolumeFader;

	s32 m_id;

	VOX_LIST<MinibusDataGeneratorInterface *, SAllocator<MinibusDataGeneratorInterface *> > m_dataGenerators;
	Mutex m_mutex;
};


class MiniAuxBus : public MiniBus
{
 public:
	MiniAuxBus();
	virtual ~MiniAuxBus();

	virtual void Update(f32 dt);

	s32 GetDSPPresence(void);
	void FillBuffer(s32* dryBuffer, s32* wetBuffer, s32 nbSamples);
	CustomDSP* GetDSP(void);
	void SetDSP(CustomDSP *pDsp);
	void RemoveDSP(void);
	
 protected:
	CustomDSP* m_pDsp; // Interleaved left-right fx1814 data as input and output
 private:
	bool m_isDspActive;
	bool m_needRemoveDsp;
};


class MiniMasterBus : public MiniBus
{
 public:
	MiniMasterBus();
	virtual ~MiniMasterBus();

	virtual void Update(f32 dt){};

	void FillBuffer(s32* outBuffer, s32 nbSamples);

	void RegisterInputBus(MiniAuxBus *pAuxiliaryBus);
	void UnregisterInputBus(MiniAuxBus *pAuxiliaryBus);
 protected:
	VOX_LIST<MiniAuxBus*, SAllocator<MiniAuxBus*> > m_inputBuses;
};


class MiniBusManager
{
 public:
	virtual ~MiniBusManager();

	static MiniBusManager* GetInstance();
	static void ReleaseInstance();

	MiniMasterBus *GetMasterBus(void);
	void AttachDataGeneratorToBus(s32 busId, MinibusDataGeneratorInterface *pDataGenerator);
	void DetachDataGeneratorFromBus(MinibusDataGeneratorInterface *pDataGenerator);
	bool AttachDSP(const char *busName, CustomDSP *dsp);

	void SetBusRoutingVolumeChange(BusRoutingChange* parameters);
	void SetDriverSampleRate(s32 sampleRate);
	void Update(f32 dt);
private:
	void _DetachDataGeneratorFromBus(MinibusDataGeneratorInterface *pDataGenerator);

	MiniBusManager();
	static MiniBusManager* s_pInstance;
	static Mutex s_busManagerMutex;
	static bool s_isActive;					// True if bus manager has been created successfully

	MiniMasterBus *m_pMasterBus;
	VOX_VECTOR<MiniAuxBus*, SAllocator<MiniAuxBus*> > m_auxBuses;
};


struct BusRoutingChange
{
	c8* BusFrom;
	c8* BusTo;
	VoxDSPGeneralParameter::BusRoutingType RoutingType;
	f32 DryVolume;
	f32 WetVolume;
	f32 FadeTime;

	BusRoutingChange(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume, f32 fadeTime)
	:BusFrom(0)
	,BusTo(0)
	,RoutingType(routingType)
	,DryVolume(dryVolume)
	,WetVolume(wetVolume)
	,FadeTime(fadeTime)
	{
		s32 size;
		if(busFromName && busToName)
		{
			size = strlen(busFromName);
			if(size >0)
			{
				BusFrom = (c8*)VOX_ALLOC(size+1);
				if(BusFrom)
					strcpy(BusFrom, busFromName);
			}

			size = strlen(busToName);
			if(size >0)
			{
				BusTo = (c8*)VOX_ALLOC(size+1);
				if(BusTo)
					strcpy(BusTo, busToName);
			}
		}
	}

	~BusRoutingChange()
	{
		if(BusFrom)
		{
			VOX_FREE(BusFrom);
		}

		if(BusTo)
		{
			VOX_FREE(BusTo);
		}
	}
};


}

#endif // _VOX_MINIBUS_SYSTEM_H_
