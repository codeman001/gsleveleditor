#pragma once
#ifndef _VOX_MSWAV_SUBDECODER_IMAADPCM_H
#define _VOX_MSWAV_SUBDECODER_IMAADPCM_H

#include "vox_mswav_subdecoder.h"
#include "AdpcmState.h"

namespace vox
{
#define SAMPLES_PER_CHUNK 8

class VoxMSWavSubDecoderIMAADPCM : public VoxMSWavSubDecoder
{
private:
	enum
	{
		k_needToProcessPreamble = 0x00000001
	};

public:
	VoxMSWavSubDecoderIMAADPCM(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks);
	virtual ~VoxMSWavSubDecoderIMAADPCM();

	virtual s32 Decode(void* outbuf, s32 nbBytes);
	virtual s32 Seek(u32 sample);
	virtual bool HasData();
private:	
	s32 DecodeBlock(void* outbuf);
#if VOX_NEON_DECODER_IMA
	s32 DecodeBlockNeonStereo(void* outbuf); // WARNING: output buffer must have special alignment
	void DecodeBlockNeonMono(void* outbuf1, void* outbuf2, s32 *samplesOut1, s32 *samplesOut2); 
	s32 DecodeNeon(void* outbuf, s32 nbBytes);
#endif

protected:
	AdpcmState		m_states[8]; //Up to eight channel
	u8*				m_readBuffer;
	bool			m_usingNeonDecoder;

	u32				m_samplesPerBlock;
	u32				m_totalDataBytesRead;
	s32				m_dataStartPosition;

	s32 m_samplesInBuffer;
	s32 m_samplesInBufferConsumed;
	u32 m_totalSampleDecoded;

	u8* m_blockReadBuffer;

	u8*	m_extraReadBuffer;
	u8*	m_readBufferSpecialAlignment;
	u8*	m_extraReadBufferSpecialAlignment;
	u8* m_extraBlockReadBuffer;
	s32 m_samplesInExtraBuffer;
	s32 m_samplesInExtraBufferConsumed;

};

}

#endif
