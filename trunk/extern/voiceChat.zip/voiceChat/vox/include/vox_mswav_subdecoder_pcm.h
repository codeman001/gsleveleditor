#pragma once
#ifndef _VOX_MSWAV_SUBDECODER_PCM_H
#define _VOX_MSWAV_SUBDECODER_PCM_H

#include "vox_mswav_subdecoder.h"

namespace vox
{
class StreamCursorInterface;

class VoxMSWavSubDecoderPCM : public VoxMSWavSubDecoder
{
public:
	VoxMSWavSubDecoderPCM(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks);
	virtual ~VoxMSWavSubDecoderPCM(){}
	virtual s32 Decode(void* buf, s32 nbSample);
	virtual s32 Seek(u32 nbBytes );
	virtual bool HasData();

private:
	s32 GetNbSamples();
	s32 GetDataSize();
};
}

#endif
