#pragma once
#ifndef _VOX_MUTEX_H_
#define _VOX_MUTEX_H_

#include "vox_types.h"

namespace vox {

struct VoxMutexData;

class Mutex
{
public:
	Mutex();
	Mutex(const Mutex &mutex);
	~Mutex();

public:
	void Lock();
	void Unlock();
	bool TryLock();

private:
	VoxMutexData* m_data;
};

struct ScopeMutex
{
	ScopeMutex(vox::Mutex* mutex):m(mutex){m->Lock();}
	~ScopeMutex()
	{
		m->Unlock();
	}
	
	Mutex* m;
};

}

namespace vox
{

class AccessController
{
public:
	AccessController():m_readers(0), m_writers(0){}
	~AccessController(){m_mutex.Unlock();}
	
	void GetReadAccess();
	void ReleaseReadAccess();
	void GetWriteAccess();
	void ReleaseWriteAccess();

private:
	s32 m_readers;
	s32 m_writers;
	Mutex m_mutex;
};

}

#endif //_VOX_MUTEX_H_
