#pragma once
#ifndef _VOX_NATIVE_PLAYLISTS_H
#define _VOX_NATIVE_PLAYLISTS_H

#include "NativeHeaders.h"
#include "vox_memory.h"
#include VOX_VECTOR_INCLUDE
#include VOX_LIST_INCLUDE

namespace vox
{


enum GroupPeekMode
{
	k_nGroupPeekUnforced,
	k_nGroupPeekForced
};


struct RandomGroupElement
{
	s32	m_elementPosition;	// Element position in the playlist it belongs to.
	s32 m_weight;			// Weight determining probability that element is picked up in random draw.

	~RandomGroupElement(){}
};


struct PlaylistElement
{
	s32	m_segmentIndex;		// Index of segment representing the group element.
	s32	m_entryPointType;	// Type of entry point into segment.
	s32	m_playPreEntry;
	s32	m_playPostExit;
	s32	m_nbLoops;

	PlaylistElement(void);
	PlaylistElement(PlaylistElement &playlistElement);
	void Reset(void);
};


struct RandomGroupState
{
	s32	m_nbLoopsRemaining;
	s32	m_nbPlaybacksRemaining;
	s32	m_nextRandomIndex;
	s32	m_activeWeightsSum;
	s32	m_loopPlaybackCount;
	s32	m_previousNbLoopsRemaining;
	s32	m_previousNbPlaybacksRemaining;
	s32	m_previousRandomIndex;
	s32	m_previousLoopPlaybackCount;

	SIMPLE_VECTOR(RandomGroupElement*)	*m_pActiveElements;
	SIMPLE_LIST(RandomGroupElement*)	*m_pUsedElements;
};


struct SequentialGroupState
{
	s32	m_nbLoopsRemaining;
	s32	m_nbPlaybacksRemaining;
	s32	m_currentPosition;
	s32	m_previousNbLoopsRemaining;
	s32	m_previousNbPlaybacksRemaining;
	s32 m_previousPosition;
};


class SegmentGroup
{
 protected:
	bool	m_isValid;				// True unless some allocation went wrong.
	s32		m_selectMode;			// Sequential or random
	s32		m_nbLoops;
	s32		m_playcount;

	// Parameters associated with current state
	s32		m_nbLoopsRemaining;
	s32		m_nbPlaybacksRemaining; // in the current playlist 

	// Parameters associated with previous state
	s32		m_previousNbLoopsRemaining;
	s32		m_previousNbPlaybacksRemaining;

	SegmentGroup(SegmentGroup &group);
	SegmentGroup(GroupInfos *pInfos, s32 switchMode);
 public:
	virtual ~SegmentGroup();

	virtual s32 GetGroupElementPosition(void)=0;
	virtual s32 PeekAtNextGroupElement(GroupPeekMode mode)=0;
	virtual void Reset(s32 resetType)=0;
	virtual void SetState(SegmentGroup &group);
	virtual void SetToPreviousState(void)=0;

	s32 GetSelectMode(void);
	bool IsValid(void);
};



class RandomGroup : public SegmentGroup
{
 private:
	SIMPLE_VECTOR(RandomGroupElement*)	m_activeElements;	// Elements that can be chosen by random operation.
	SIMPLE_LIST(RandomGroupElement*)	m_usedElements;		// Elements that cannot currently be chosen by random operation.

	s32 m_nbElements;				// Total nb of elements in group (active + used elements).
	s32	m_noRepeatLength;			// n -> n elements must be played before current can play again (0 = random)
	s32	m_desiredNoRepeatLength;	// Can be set to -1 to get 'play all elements before repetition'.
	s32	m_nextRandomIndex;			// Random index in m_activeElements used to trigger next element.
	s32 m_activeWeightsSum;			// Weight sum from active elements.
	s32 m_loopPlaybackCount;		// Nb of elements remaining to play during current loop.

	s32	m_previousRandomIndex;
	s32 m_previousLoopPlaybackCount;

	s32 m_hasElementBeenReactivated; // True if a used element had become active during last draw.

	s32 GetActiveElementIndex(void);
 public:
	RandomGroup(GroupInfos *pInfos, s32 switchMode);
	RandomGroup(RandomGroup &group);
	virtual ~RandomGroup();

	virtual s32 GetGroupElementPosition(void);
	virtual void GetState(RandomGroupState *pState);
	virtual s32 PeekAtNextGroupElement(GroupPeekMode mode);
	virtual void Reset(s32 resetType);
	virtual void SetState(RandomGroup &group);
	virtual void SetState(RandomGroupState *pState);
	virtual void SetToPreviousState(void);

	void AddElement(RandomGroupElement *pElement);
};


class SequentialGroup : public SegmentGroup
{
 private:
	SIMPLE_VECTOR(s32)	m_elements;
	s32					m_currentPosition;	// Current position in group (as an index into vector m_elements).
	s32					m_previousPosition;
 public:
	SequentialGroup(GroupInfos *pInfos, s32 switchMode);
	SequentialGroup(SequentialGroup &group);
	virtual ~SequentialGroup();

	virtual s32 GetGroupElementPosition(void);
	virtual void GetState(SequentialGroupState *pState);
	virtual s32 PeekAtNextGroupElement(GroupPeekMode mode);
	virtual void Reset(s32 resetType);
	virtual void SetState(SequentialGroup &group);
	virtual void SetState(SequentialGroupState *pState);
	virtual void SetToPreviousState(void);

	void AddElement(s32 elementIndex);
};


struct PlaylistState
{
	s32	m_currentGroup;			// Group into which a selection must be done
	s32	m_currentPosition;		// Current position in playlist.
	s32	m_nbLoopsRemaining;
	s32	m_previousGroup;
	s32	m_previousPosition;
	s32	m_previousNbLoopsRemaining;

	SIMPLE_VECTOR(SegmentGroup*)	*m_pGroups;
};


class NativePlaylist
{
 private:
	bool	m_isValid;			// True unless some allocation went wrong.
	s32		m_groupSwitchMode;
	s32		m_nbLoops;
	
	// Parameters associated with playlist's current state
	s32		m_currentGroup;			// Group into which a selection must be done
	s32		m_currentPosition;		// Current position in playlist.
	s32		m_nbLoopsRemaining;

	// Parameters associated with playlist's previous state
	s32		m_previousGroup;
	s32		m_previousPosition;
	s32		m_previousNbLoopsRemaining;

	SIMPLE_VECTOR(SegmentGroup*)			m_groups;
	SIMPLE_VECTOR(PlaylistElement*)			m_playlistElements;
 public:
	NativePlaylist(PlaylistInfos *pInfos);
	NativePlaylist(NativePlaylist &playlist);
	~NativePlaylist();

	void AddGroup(GroupInfos *pGroupInfos);
	void AddPlaylistElement(PlaylistElementInfos *pInfos);
	PlaylistElement *GetCurrentElement(void);
	s32 GetCurrentPosition(void);
	void GetState(PlaylistState *pState);
	bool IsValid(void);
	PlaylistElement *GetPlaylistElement(s32 position);
	PlaylistElement *GetPlaylistElement(void);
	PlaylistElement *PeekAtNextElement(void);
	void Reset(void);
	void SetState(NativePlaylist &playlist);
	void SetState(PlaylistState *pState);
	void SetToPreviousState(void);
};


class NativePlaylistsManager
{
 private:
	bool			m_isValid;			// True unless some allocation went wrong.
	s32				m_currentPlaylist;
	s32				m_nbPlaylists;
	NativePlaylist	**m_pPlaylists;

 public:
	NativePlaylistsManager();
	NativePlaylistsManager(NativePlaylistsManager &playlistManager);
	~NativePlaylistsManager();

	void AddPlaylist(s32 index, PlaylistInfos *pInfos);
	void AddPlaylistElement(PlaylistElementInfos *pInfos);
	void AddGroup(GroupInfos *groupInfos);
	s32 GetNbPlaylists(void);
	PlaylistElement *GetPlaylistElement(s32 playlistIndex, s32 playlistSelectMode, s32 position=-1);
	void Init(s32 nbPlaylists);
	bool IsValid(void);
	PlaylistElement *PeekAtNextPlaylistElement(s32 playlistIndex);
	void ResetPlaylist(s32 playlistIndex);
	void SetPlaylistToPreviousState(s32 playlistIndex);
	void SetState(NativePlaylistsManager &playlistManager);
	void TransposePlaylistParameters(s32 currentPlaylist, s32 newPlaylist);
};


} // End namespace vox

#endif // _VOX_NATIVE_PLAYLISTS_H
