#pragma once
#ifndef _VOX_NATIVE_SUBDECODER_H
#define _VOX_NATIVE_SUBDECODER_H

#include "vox_decoder.h"
#include "NativeHeaders.h"
#include "vox_native_playlists.h"
#include VOX_MAP_INCLUDE

namespace vox
{

#if VOX_NATIVE_REDUCE_LATENCY
class NativeSubDecoderState
{
 public:
	NativeSubDecoderState(NativePlaylistsManager *pPlaylists);
	virtual ~NativeSubDecoderState();

	NativePlaylistsManager	*m_pPlaylists;

	// State parameters
	s32				m_oldState;
	s32				m_currentState;
	s32				m_newState;

	// Playlist parameters
	s32				m_oldPlaylist;
	s32				m_currentPlaylist;
	s32				m_newPlaylist;
	bool			m_resetPlaylist;
	PlaylistElement m_oldPlaylistElement;
	PlaylistElement m_currentPlaylistElement;
	PlaylistElement m_newPlaylistElement;

	// Transition rules
	s32				m_currentRule;
	s32				m_newRule;
	
	// Segment parameters
	s32				m_nbSegmentsPlaying;
	SegmentState	m_dyingSegmentState;
	SegmentState	m_oldSegmentState;
	SegmentState	m_currentSegmentState;
	s32				m_mixingStartPosition;
	s32				m_currentSegmentOffset;

	bool			m_hasData;

};
#endif // VOX_NATIVE_REDUCE_LATENCY

class VoxNativeSubDecoder
{
 public:
	VoxNativeSubDecoder(StreamCursorInterface* pStreamCursor, NativeChunks* pNativeChunks, States *pStates,
						AudioSegments *pAudioSegments, DOUBLE_VECTOR(s32) *pSegmentsCues,
						TransitionRules *pTransitionRules, DOUBLE_VECTOR(TransitionParams) *pTransitions,
						STRING_MAP(s32,StringCompare) *pStateLabels, NativePlaylistsManager *pPlaylists);

	virtual ~VoxNativeSubDecoder(){}
	
	static void Clean(void);
	virtual bool HasData();
	virtual s32 Seek(u32 sampleNum )=0;

	s32 Decode(void* buf, s32 nbBytes);
	TrackParams GetTrackParams();
	bool HasStateChanged();
	virtual void Reset(void);

#if VOX_NATIVE_REDUCE_LATENCY
	s32 EmulateDecode(s32 nbBytes);
	void GetState(NativeSubDecoderState *pState);
	void SetState(NativeSubDecoderState *pState); // See if really need be virtual (children methods have children parameters)
#endif

	void SetLoop(bool loop){}				// Cannot set loop to a native file.
	void SetState(s32 stateIndex);

 protected:
	static s32*	s_pMixingBuffer;			// Buffer used to mix current and old segments.
	static s32	s_nbMixingBufferBytes;

	StreamCursorInterface	*m_pStreamCursor;

	AudioFormat				m_audioFormat;
	s32						m_dataStart;		// Position of first data byte from start of file (in bytes).

	AudioSegments								*m_pAudioSegments;
	TransitionRules								*m_pTransitionRules;
	States										*m_pStates;
	DOUBLE_VECTOR(TransitionParams)				*m_pTransitions;
	STRING_MAP(s32, StringCompare)				*m_pStateLabels;
	DOUBLE_VECTOR(s32)							*m_pSegmentsCues;
	NativePlaylistsManager						*m_pPlaylists;

	// State parameters
	s32				m_oldState;				// State associated with old playlist.
	s32				m_currentState;			// State associated with current playlist.
	s32				m_newState;				// Next state requested by game.
	bool			m_hasStateChanged;		// True if state has changed in current decode

	// Playlist parameters
	s32				m_oldPlaylist;				// Index of playlist that generated old segment.
	s32				m_currentPlaylist;			// Index of current playlist.
	s32				m_newPlaylist;				// Index of playlist generating next segment.
	bool			m_resetPlaylist;			// True means reset new playlist.
	PlaylistElement m_oldPlaylistElement;
	PlaylistElement m_currentPlaylistElement;
	PlaylistElement m_newPlaylistElement;

	// Transition rules parameters
	s32				m_currentRule;
	s32				m_newRule;
	
	// Segments parameters
	s32				m_nbSegmentsPlaying;
	SegmentState	m_dyingSegmentState;	// Segment that must die within one decode pass.
	SegmentState	m_oldSegmentState;		// Current gets old when a new segment enters into play.
	SegmentState	m_currentSegmentState;
	s32				m_mixingStartPosition;	// Current segment position where mixing with new segment should start (in samples).
	s32				m_currentSegmentOffset;	// Nb of samples from current segment to set to zero before starting decoding.

	bool			m_hasData;				// True if subdecoder has data to decode (from any segment).

	virtual s32 DecodeCurrentSegmentWithOffset(void* outputBuffer, s32 nbBytes)=0;
	virtual s32 DecodeSegment(void* outputBuffer, s32 nbBytes, SegmentState *pSegmentState)=0;
	virtual u32 GetBytePositionFromSampleOffset(u32 sampleOffset)=0;
	virtual s32 GetDecodingBuffer(void)=0;
	virtual void ReleaseDecodingBuffer(s32 bufferIndex)=0;
	virtual s32 Seek(s32 samplePosition, SegmentState *pSegmentState)=0;
	virtual void SetDecodingBufferToSegmentPosition(SegmentState *pSegmentState)=0;

#if VOX_NATIVE_REDUCE_LATENCY
	virtual s32 EmulateDecodeCurrentSegmentWithOffset(s32 nbBytes)=0;
	virtual s32 EmulateDecodeSegment(s32 nbBytes, SegmentState *pSegmentState)=0;
	s32 EmulateMixMultipleSegments(s32 nbBytes);
	void EmulateMixSegmentInBuffer(s32 nbBytesDecoded, SegmentState *pSegmentState);
#endif

	void ApplyTransitionRule(TransitionRule *pRule);
	s32 GetNextDyingSegmentLifeState(void);
	void InterpretTransitionRule(s32 ruleIndex);
	bool IsExtraSegmentNeeded(TransitionRule *pRule);
	s32 MixMultipleSegments(s16* outputBuffer, s32 nbBytes);
	void MixSegmentInBuffer(s16* outputBuffer, s32 nbBytesDecoded, SegmentState *pSegmentState);
	void StopSegment(SegmentState *pSegmentState);
	void SwapOldAndCurrentSegments(void);
	void UpdateCurrentSegmentState(TransitionRule *pRule, bool isExtraSegmentNeeded);
	void UpdateDyingSegmentState(TransitionRule *pRule);
	void UpdateOldSegmentState(TransitionRule *pRule);
	void UpdateSegmentsStates(void);
};

}

#endif // _VOX_NATIVE_SUBDECODER_H
