#pragma once
#ifndef _VOX_NATIVE_SUBDECODER_PCM_H
#define _VOX_NATIVE_SUBDECODER_PCM_H

#include "vox_native_subdecoder.h"


namespace vox
{

class StreamCursorInterface;

#if VOX_NATIVE_REDUCE_LATENCY

class NativeSubDecoderPCMState : public NativeSubDecoderState
{
 public:
	NativeSubDecoderPCMState(NativePlaylistsManager *pPlaylists);
	virtual ~NativeSubDecoderPCMState();
};

#endif // VOX_NATIVE_REDUCE_LATENCY

class VoxNativeSubDecoderPCM : public VoxNativeSubDecoder
{
 public:
	VoxNativeSubDecoderPCM(StreamCursorInterface* pStreamCursor, NativeChunks* pNativeChunks, States *pStates,
						   AudioSegments *pAudioSegments, DOUBLE_VECTOR(s32) *pSegmentsCues,
						   TransitionRules *pTransitionRules, DOUBLE_VECTOR(TransitionParams) *pTransitions,
						   STRING_MAP(s32, StringCompare) *pStateLabels,
						   NativePlaylistsManager *pPlaylists);
	virtual ~VoxNativeSubDecoderPCM();
	virtual s32 Seek(u32 nbBytes){return 0;};

#if VOX_NATIVE_REDUCE_LATENCY
	void GetState(NativeSubDecoderPCMState *pState);
	void SetState(NativeSubDecoderPCMState *pState);
#endif
 protected:
	virtual s32 DecodeCurrentSegmentWithOffset(void* outputBuffer, s32 nbBytes);
	virtual s32 DecodeSegment(void* outputBuffer, s32 nbBytes, SegmentState *pSegmentState);
	virtual u32 GetBytePositionFromSampleOffset(u32 sampleOffset);
	virtual s32 GetDecodingBuffer(void){return -1;};
	virtual void ReleaseDecodingBuffer(s32 bufferIndex){};
	virtual void Reset(void);
	virtual s32 Seek(s32 samplePosition, SegmentState *pSegmentState);
	virtual void SetDecodingBufferToSegmentPosition(SegmentState *pSegmentState){};

#if VOX_NATIVE_REDUCE_LATENCY
	virtual s32 EmulateDecodeCurrentSegmentWithOffset(s32 nbBytes);
	virtual s32 EmulateDecodeSegment(s32 nbBytes, SegmentState *pSegmentState);
#endif
};

}


#endif // _VOX_NATIVE_SUBDECODER_PCM_H
