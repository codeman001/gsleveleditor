#pragma once
#ifndef _VOX_PRIORITY_BANK_H_
#define _VOX_PRIORITY_BANK_H_

#include "vox_default_config.h"
#include <string.h>
#include VOX_VECTOR_INCLUDE
#include "vox_internal.h"

namespace vox
{
class PriorityBank;

struct PriorityBankElement
{
	PriorityBankElement():m_pEmitter(0),m_childBank(0){}
	PriorityBankElement(EmitterObj* pEmitter, PriorityBank* childBank, s32 priority)
		:m_pEmitter(pEmitter)
		,m_childBank(childBank)
		,m_priority(priority)
	{}

	EmitterObj* m_pEmitter;
	PriorityBank* m_childBank;
	s32 m_priority;
};

class PriorityBank
{
public:
	PriorityBank();
	PriorityBank(priority_bank::CreationSettings &cs, PriorityBank* parent);

	~PriorityBank()
	{
		if(m_name)
		{
			VOX_FREE(m_name);
		}

		m_bankElements.clear();
	}

public:
	const char* GetName() const {return m_name;}

	bool AddEmitter(EmitterObj* pEmitter, PriorityBank* childBank, s32 priority);
	bool RemoveEmitter(EmitterObj* pEmitter, bool stopEmitter = true, bool recursionUp = true, bool recursionDown = true);

	void Update();

	char* m_name;
	s32 m_threshold;
	u32 m_maxPlayback;
	priority_bank::Behaviour m_behaviour;

	PriorityBank* m_parent;
	bool m_overrideChildPriority;
	s32 m_bankPriority;

	VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> > m_bankElements;
};

class PriorityBankManager
{
public:
	PriorityBankManager();
	PriorityBankManager(u32 size);
	~PriorityBankManager();

	u32  AddPriorityBank(priority_bank::CreationSettings &cs);

	bool SetPriorityBank(u32 bankId, priority_bank::CreationSettings &cs);
	u32  GetPriorityBankId(const char* name);

	bool AddEmitter(u32 bankId, EmitterObj* pEmitter); 
	bool RemoveEmitter(u32 bankId, EmitterObj* pEmitter);
	//bool CanAddEmitter(u32 bankId, s32 priority)  const;

	void Update();

	//void GetDebugInfo(DebugChunk_bank* info);

private:
	//bool _CanAddEmitter(u32 bankId, s32 priority)  const;

	u32 m_bankQty;
	VOX_VECTOR<PriorityBank*, SAllocator<PriorityBank*> > m_banks;
	VOX_MUTEX_LEVEL_1(Mutex m_mutex;)
};
}//namespace vox

#endif
