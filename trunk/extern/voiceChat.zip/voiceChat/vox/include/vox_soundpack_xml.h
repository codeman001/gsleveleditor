#pragma once
#ifndef _VOX_SOUNDPACK_XML_H_
#define _VOX_SOUNDPACK_XML_H_

#include "vox.h"
#include "vox_memory.h"



namespace vox
{

enum VoxSoundPackEventType
{
	k_nEventTypeInvalid = -1,
	k_nEventTypeRandom  =  0,
	k_nEventTypePlaylist=  1,
	k_nEventTypePlRandom=  2
};

enum VoxSoundPackCooldownType
{
	k_nCooldownTypeInvalid = -1,
	k_nCooldownTypeTime = 0,
	k_nCooldownTypePlays = 1
};

//! 3D positioning type
enum Vox3DSoundType
{
	k_n3DSoundTypeNone,		/*!< Emitter relative to listener, position is set to  {0.0.0} */
	k_n3DSoundTypeAbsolute, /*!< Emitter not relative to listener, position is set to its world position */
	k_n3DSoundTypeRelative /*!< Emitter relative to listener, position is set to its position in the listener world */
};




//! Structure to retrieve information about an event from an XMLSoundpack object
struct EventInfoXML
{
	EventInfoXML():m_id(0), m_label(0), m_pSoundIds(0), m_numSounds(0), m_eventType(k_nEventTypeInvalid), m_eventParam(0), m_playbackProbability(0), m_cooldownValue(0), m_cooldownType(k_nCooldownTypeTime), m_numCustomEvent(0), m_customEventStr(0){}

	s32 m_id;//!< Unique id of the event
	const c8* m_label;//!< Label of the event

	const s32* m_pSoundIds;//!< Reference to the list of sound ids member of the event
	s32 m_numSounds;

	VoxSoundPackEventType m_eventType;//!< Event type
	s16 m_eventParam;//!< Parameter of the event
	s16 m_playbackProbability;	//!< Playback probability of the event

	f32 m_cooldownValue;
	s32 m_cooldownType;

	s32 m_numCustomEvent;//!< Custom parameter count
	c8 const * const * m_customEventStr;//!< List of custom parameter
};







struct ConfigInfoXML
{
	ConfigInfoXML()
		:m_majorVersion(0),
		m_minorVersion(0),
		m_fixVersion(0),
		m_gameName(0),
		m_console(0),
		m_packVersion(0)
	{}
	~ConfigInfoXML(){}

	u32 m_majorVersion;
	u32 m_minorVersion;
	u32 m_fixVersion;
	const char* m_gameName;
	const char* m_console;
	const char* m_packVersion;
};

//! XML sound pack descriptor class
/*!
	This class contain all the informations from the sound design document relevant at run-time
*/
class VoxSoundPackXMLInternalData;

class VoxSoundPackXML
{
public:
	//! Default constructor
	/*!
		Create an empty XML sound pack descriptor
	*/
	VoxSoundPackXML();

	//! Optional constructor
	/*!
		Create an XML sound pack descriptor based on the file passed as argument
		\param xmlFileName	Absolute path to the xml file containing sound pack information
	*/
	VoxSoundPackXML(const c8* xmlFileName);
	//! Destructor
	~VoxSoundPackXML();

	//! Get sound element count
	/*!
		\return How many sound element are present in descriptor
	*/
	s32 GetSoundCount() const;

	//! Get priority bank element count
	/*!
		\return How many priority bank element are present in descriptor
	*/
	s32 GetBankCount() const;

	//! Get group element count
	/*!
		\return How many group element are present in descriptor
	*/
	s32 GetGroupCount() const;

	//! Get event element count
	/*!
		\return How many event element are present in descriptor
	*/
	s32 GetEventCount() const;

	//! Get soundpack config info
	/*!
		\param configInfo ConfigInfo structure to write data to
		\return true if configuration info was properly copied
	*/
	bool GetConfigInfo(ConfigInfoXML &configInfo) const ;

	//! Get the numeric unique id of a priority bank
	/*!
		\param	name Name of the priority bank in the sound design document
		\return Unique id of the priority bank
	*/
	u32 GetBankUid(const c8* name) const ;

	//! Get priority bank information
	/*!	
		Get information needed to the configuration of the bank
		\param name Name of the priority bank to get information for
		\param bankInfo <b>[out]</b>Bank info struct to fill with the information
		\return True if the bank was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetBankInfo(const c8* name, priority_bank::CreationSettings &bankInfo) const ;

	//! Get priority bank information
	/*!	
		Get information needed to the configuration of the bank
		\param bankId Unique id of the priority bank to get information for
		\param bankInfo <b>[out]</b>Bank info struct to fill with the information
		\return True if the bank was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetBankInfo(u32 bankId, priority_bank::CreationSettings &bankInfo) const ;


	//! Get the numeric unique id of a group
	/*!
		\param	name Name of the group in the sound design document
		\return Unique id of the group
	*/
	u32 GetGroupUid(const c8* name) const ;
	
	//! Get group information
	/*!	
		Get information related to the group
		\param name Name of the group to get information for
		\param groupInfo <b>[out]</b>Group info struct to fill with the information
		\return True if the group was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetGroupInfo(const c8* name, group::CreationSettings &groupInfo) const ;

	//! Get group information
	/*!	
		Get information related to the group
		\param groupId Unique id of the group
		\param groupInfo <b>[out]</b>Group info struct to fill with the information
		\return True if the group was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetGroupInfo(u32 groupId, group::CreationSettings &groupInfo) const ;

	//! Get the numeric unique id of a sound
	/*!
		\param	label Label of the sound in the sound design document
		\return Unique id of the sound
	*/
	s32 GetSoundUid(const c8* label) const ;

	//! Get the label of a sound
	/*!
		\param	uid Uid of the sound
		\param	result Changed for the label of the sound if found
		\return true if the sound with given id is found
	*/
	bool GetSoundLabel(s32 uid, const char *&result) const ;

	//! Get data source information
	/*!	
		Get information needed to create a data source of the sound
		\param label Label of the sound to get information for
		\param dataSourceSettings <b>[out]</b>Creation Settings to fill with the information
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetDataSourceInfo(const c8* label, data_source::CreationSettings &dataSourceSettings) const ;

	//! Get data source information
	/*!	
		Get information needed to create a data source of the sound
		\param soundUid Unique id of the sound
		\param dataSourceSettings <b>[out]</b>Creation Settings to fill with the information
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetDataSourceInfo(s32 soundUid, data_source::CreationSettings &dataSourceSettings) const ;
	
	//! Get emitter information
	/*!
		Get information needed to create an emitter of the sound
		\param label Label of the sound to get information for
		\param emitterSettings <b>[out]</b>Creation settings struct to fill the with the information
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/

	bool GetEmitterInfo(const c8* label, emitter::CreationSettings &emitterSettings) const ;

	//! Get emitter information
	/*!	
		Get information needed to create an emitter of the sound
		\param soundUid Unique id of the sound
		\param emitterSettings <b>[out]</b>Creation settings struct to fill the with the information
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEmitterInfo(s32 soundUid, emitter::CreationSettings &emitterSettings) const ;

	//! Get emitter information from sound or event label
	/*!
		Get information needed to create an emitter of the sound
		\param label Label of the sound (or event) to get information for
		\param emitterInfo <b>[out]</b>Emitter info struct to fill the with the information
		\return True if the sound (or event) was found, if false, value of <b>[out]</b> parameters should not be used
	*/

	bool GetEmitterInfoFromSoundOrEvent(const c8* label, emitter::CreationSettings &emitterInfo);

	//! Get the value of a sound custom parameter
	/*!
		\param soundLabel Label of the sound
		\param index Index of the custom parameter
		\param param String that will contain the parameter
		\return True if the parameter returned is valid
	*/
	bool GetSoundCustomParam(const c8* soundLabel, s32 index, const c8* &param);

	//! Get the value of a sound custom parameter
	/*!
		\param soundUid Unique id of the sound
		\param index Index of the custom parameter
		\param param String that will contain the parameter
		\return True if the parameter returned is valid
	*/
	bool GetSoundCustomParam(s32 soundUid, s32 index, const c8* &param);

	//! Get the numeric unique id of an event
	/*!
		\param	eventLabel Label of the event in the sound design document
		\return Unique id of the event
	*/
	s32 GetEventUid(const c8* eventLabel) const;

	//! Get event information
	/*!	
		Get information about an event
		\param label Label of the event in the sound design document
		\param eventInfo <b>[out]</b>Envent info struct to fill the with the information
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventInfo(const c8* label, EventInfoXML &eventInfo) const ;

	//! Get event information
	/*!	
		Get information about an event
		\param eventUid Unique id of the event
		\param eventInfo <b>[out]</b>Envent info struct to fill the with the information
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventInfo(s32 eventUid, EventInfoXML &eventInfo) const ;

	//! Get sound id of the event
	/*!	
		Get the id of the sound that should be used according to the rule of the event
		\param eventLabel Label of the event in the sound design document
		\param soundUid <b>[out]</b>Unique id of the sound to use
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventSoundUid(const c8* eventLabel, s32 &soundUid);

	//! Get sound id of the event
	/*!	
		Get the id of the sound that should be used according to the rule of the event
		\param eventUid Unique id of the event
		\param soundUid <b>[out]</b>Unique id of the sound to use
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventSoundUid(s32 eventUid, s32 &soundUid);

	//! Reset event parameter to initial value
	/*!
		\param eventLabel Label of the event to reset
		\return True if the event was found
	*/
	bool ResetEvent(const c8* eventLabel);

	//! Reset event parameter to initial value
	/*!
		\param eventUid Unique id of the event to reset
		\return True if the event was found
	*/
	bool ResetEvent(s32 eventUid);

	//! Get count of the sound associated to the event
	/*!
		\param eventLabel Label of the event
		\return Count of the sound associated to the event
	*/
	s32 GetEventSize(const c8* eventLabel);

	//! Get count of the sound associated to the event
	/*!
		\param eventUid Unique id of the event
		\return Count of the sound associated to the event
	*/
	s32 GetEventSize(s32 eventUid);

	//! Get the value of an event custom parameter
	/*!
		\param eventLabel Label of the event
		\param index Index of the custom parameter
		\param param String that will contain the parameter
		\return True if the parameter returned is valid
	*/
	bool GetEventCustomParam(const c8* eventLabel, s32 index, const c8* &param);

	//! Get the value of an event custom parameter
	/*!
		\param eventUid Unique id of the event
		\param index Index of the custom parameter
		\param param String that will contain the parameter
		\return True if the parameter returned is valid
	*/
	bool GetEventCustomParam(s32 eventUid, s32 index, const c8* &param);

	//! Load a sound pack descriptor from a XML file
	/*!
		Load a sound pack descriptor from a XML file.
		<br>Note : This method first reset old descriptor.  If loading failed,
		previous information is not accessible.
		\param xmlFileName File to load information from
		\return True if the load was completed with success
	*/
	bool LoadXML(const c8* xmlFileName);

	//! Automatically setup all groups with settings from the SDD
	/*!	
		Gets information related to all the groups, setups the master group, registers all other groups
		\return True if successful, false if not (normally due to having way too many groups)
	*/
	bool AutoSetupGroups();

	//! Automatically setup all banks with settings from the SDD
	/*!	
		Gets information related to all the banks, setups the master bank, registers all other banks
		\return True if successful, false if not (normally due to having way too many banks)
	*/
	bool AutoSetupBanks();


private:
	VoxSoundPackXMLInternalData *data;

};


} //namespace vox

#endif //_VOX_SOUNDPACK_XML_H_
