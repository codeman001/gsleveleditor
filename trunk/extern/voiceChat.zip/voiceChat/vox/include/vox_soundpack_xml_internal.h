#pragma once
#ifndef _VOX_SOUNDPACK_XML_INTERNAL_H_
#define _VOX_SOUNDPACK_XML_INTERNAL_H_

#include "vox_soundpack_xml.h"

#include <vector>
#include <map>
#include <string>
#include <list>

namespace vox
{

struct stringcomp {
	bool operator() (const std::string& lhs, const std::string& rhs) const;
};

struct c8stringcomp {
  bool operator() (const c8* lhs, const c8* rhs) const;
};

struct BankXMLDef
{
	BankXMLDef()
		:m_name(""),
		m_behaviour(priority_bank::B_DO_NOTHING),
		m_maxPlayback(2147483647),
		m_threshold(-(s32)2147483647),
		m_parentId(0),
		m_overrideChildPriority(false),
		m_priority(0)
	{}

	std::string m_name;

	priority_bank::Behaviour m_behaviour;
	s32 m_maxPlayback;
	s32 m_threshold;

	u32 m_parentId;
	bool m_overrideChildPriority;
	s32 m_priority;

};

struct GroupXMLDef
{
	GroupXMLDef();

	std::string m_busName;
	std::string m_name;
	Vox3DSoundType m_is3D;

	u32 m_parentId;
	f32 m_volume;
	bool m_enable;
	
	f32 m_refdistance;
	f32 m_maxdistance;
	f32 m_rolloff;

	f32 m_baseGain;
	f32 m_basePitch;
	f32 m_maxGainMod;
	f32 m_maxPitchMod;
	f32 m_minGainMod;
	f32 m_minPitchMod;

	bool m_killOnResume;
	float m_fadeOnPlay;
	float m_fadeOnStop;

};




struct SoundXMLDef
{
	SoundXMLDef();

	~SoundXMLDef()
	{
		if(m_label)
			VOX_FREE(m_label);
		if(m_filename)
			VOX_FREE(m_filename);
		if(m_bus)
			VOX_FREE(m_bus);

		if(m_customSoundStr)
		{
			if(m_customSoundStr[0])
				VOX_FREE(m_customSoundStr[0]);
			VOX_FREE(m_customSoundStr);
		}
	}
	s32 m_priority;
	c8* m_label;
	c8* m_filename;
	VoxSourceLoadingFlags m_loadingFlags;
	/*FormatTypes*/ s8 m_format;
	s8 m_bankId;
	s8 m_groupId;
	bool m_isLoop;

	c8* m_bus;

	// 3D parameters
	Vox3DSoundType m_is3D;
	f32 m_referenceDistance;
	f32 m_maxDistance;
	f32	m_rolloffFactor;

	// Gain parameters
	f32 m_baseGain;
	f32 m_minGainMod;		// Minimum gain multiplier applied on base gain when using random gain modifications.
	f32 m_maxGainMod;		// Maximum gain multiplier applied on base gain when using random gain modifications.
	bool m_isGainRandom;	// True if gain can experience random modifications.

	// Pitch parameters
	f32 m_basePitch;
	f32 m_minPitchMod;		// Minimum pitch multiplier applied on base pitch when using random pitch modifications.
	f32 m_maxPitchMod;		// Maximum pitch multiplier applied on base pitch when using random pitch modifications.
	bool m_isPitchRandom;	// True if pitch can experience random modifications.

	bool m_killOnResume;
	float m_fadeOnPlay;
	float m_fadeOnStop;

	// User custom parameters
	s32		m_numCustomSound;
	c8**	m_customSoundStr;
};


struct EventXMLDef
{
	EventXMLDef(): m_label(0), m_eventType((s16)k_nEventTypeInvalid), m_eventParam(0), m_playbackProbability(100), m_currentEvent(-1), m_cooldownValue(0), m_cooldownType(k_nCooldownTypeTime), m_cooldownCounter(-999999), m_numCustomEvent(0), m_customEventStr(0){}
	~EventXMLDef()
	{
		if(m_label)
			VOX_FREE(m_label);

		if(m_customEventStr)
		{
			if(m_customEventStr[0])
				VOX_FREE(m_customEventStr[0]);
			VOX_FREE(m_customEventStr);
		}
	}
	
	c8* m_label;	

	std::list<s32, SAllocator<s32> > m_usedSoundIds;
	std::vector<s32, SAllocator<s32> > m_soundIds;

	/*VoxSoundPackEventType*/
	s16 m_eventType;
	s16 m_eventParam;
	s16 m_playbackProbability;		
	s16 m_currentEvent;

	f32 m_cooldownValue;
	s32 m_cooldownType;
	f64 m_cooldownCounter;

	s32 m_numCustomEvent;
	c8** m_customEventStr;
};

// From Vox2
namespace driver
{
enum OutputMode
{
	OM_UNKNOWN = -1,
	OM_MONO,
	OM_STEREO,
	OM_SURROUND
};
}

struct ConfigXMLDef
{
	ConfigXMLDef()
		:m_majorVersion(0),
		m_minorVersion(0),
		m_fixVersion(0),
		m_gameName(0),
		m_console(0),
		m_packVersion(0)
	{}
	~ConfigXMLDef()
	{
		VOX_FREE(m_gameName);
		m_gameName = 0;
		VOX_FREE(m_console);
		m_console = 0;
		VOX_FREE(m_packVersion);
		m_packVersion = 0;
	}

	u32 m_majorVersion;
	u32 m_minorVersion;
	u32 m_fixVersion;
	char* m_gameName;
	char* m_console;
	char* m_packVersion;
};

class VoxSoundPackXMLInternalData
{
public:
	ConfigXMLDef m_config;
	std::vector<SoundXMLDef, SAllocator<SoundXMLDef> >  m_soundVector;
	std::vector<GroupXMLDef, SAllocator<GroupXMLDef> >  m_groupVector;
	std::vector<BankXMLDef, SAllocator<BankXMLDef> >   m_bankVector;
	std::vector<EventXMLDef, SAllocator<EventXMLDef> >  m_eventVector;

#if defined(_NN_CTR)
	std::map<c8*, s32, c8stringcomp/*, SAllocator<std::pair<const c8*,s32> >*/ > m_soundLabel; //for fast uid search 
#else
	//std::map<std::string, s32, stringcomp, SAllocator<std::pair<const std::string,s32> > > m_soundLabel; //for fast uid search 
	std::map<c8*, s32, c8stringcomp, SAllocator<std::pair<const c8*,s32> > > m_soundLabel; //for fast uid search 
#endif
};

} // namespace vox

#endif //_VOX_SOUNDPACK_XML_INTERNAL_H_
