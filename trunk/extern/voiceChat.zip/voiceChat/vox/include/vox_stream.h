#pragma once
#ifndef _VOX_STREAM_H_
#define _VOX_STREAM_H_

#include "vox.h"

namespace vox {

class StreamCursorInterface;
class EmitterObj;

///

enum
{
	ORIGIN_START,
	ORIGIN_CURRENT,
	ORIGIN_END
};

class StreamInterface
{
public:
	StreamInterface() : m_streamSize(0) {}
	virtual ~StreamInterface(){}

public:
	virtual void Init() {}
	virtual void Shutdown() {}
	virtual s32  Size() { return m_streamSize; }
	virtual StreamCursorInterface* CreateNewCursor() = 0;
	virtual void DestroyCursor(StreamCursorInterface* pStreamCursor)=0;
	virtual s32 GetType()=0;

protected:
	s32  m_streamSize;
};

class StreamCursorInterface
{
protected:
	StreamCursorInterface(StreamInterface* pStream) : m_pStream(pStream) {}
public:
	virtual ~StreamCursorInterface(){}

	virtual void Init() {}
	virtual void Shutdown() {}
	virtual s32 Seek( s32 pos, s32 origin = ORIGIN_START ) = 0;
	virtual bool IsSeekable() = 0;
	virtual s32 Tell() = 0;
	virtual s32  Read( u8* buff, s32 len ) = 0;
	virtual s32  ReadRef( u8* &buff, s32 len ){ return Read(buff, len);}

	virtual bool EndOfStream()=0;

	virtual bool AllowBufferReference(){return false;}

	s32 Size() { return m_pStream ? m_pStream->Size() : 0 ; }

protected:
	StreamInterface* m_pStream; // TODO: make sure this pointer gets set to 0 if the stream is deleted.
	//EmitterObj* m_pEmitter;

	friend class StreamInterface;
};

}

#endif //_VOX_STREAM_H_
