#pragma once
#ifndef _VOX_THREAD_H_
#define _VOX_THREAD_H_

#include "vox_mutex.h"

namespace vox
{

class VoxRunnable;

typedef void (*ThreadUpdateCallback) (void* caller, void* param);

class VoxThread
{
public:
	VoxThread(ThreadUpdateCallback callbackMethod, void* caller, void* param, const c8* name=0);
	~VoxThread();

	static void Sleep(u32 sleepTimeMs);

	static u32 GetCurThreadId();

private:

	friend class VoxRunnable;

	void Stop();

	void _Update();

	ThreadUpdateCallback m_updateCallback;
	void* m_caller;
	void* m_param;
	Mutex m_mutex;
	bool m_update;
	bool m_alive;
	f64 m_lastUpdate;
	c8 m_name[64];
	VoxRunnable* m_voxRunnable;
};

}

#endif
