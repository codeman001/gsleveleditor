#pragma once
#ifndef _VOX_TYPES_H_
#define _VOX_TYPES_H_

#ifdef __cplusplus
#include <cstddef>
#else
#include <stddef.h>
#endif

namespace vox
{
//Define plateform independent variable type

//Unsigned integer
//! Unsigned 8 bit integer
typedef unsigned char	u8;
//! Unsigned 16 bit integer
typedef unsigned short	u16;
//! Unsigned 32 bit integer
typedef unsigned int	u32;

#if defined(_WIN32) ||  defined(__GNUC__) || defined(_PS3)
//! Unsigned 64 bit integer
typedef unsigned long long u64;
#endif //add other platform that support long long is needed

//Signed integer
//! Signed 8 bit integer
typedef signed char		s8;
//! Signed 16 bit integer
typedef signed short	s16;
//! Signed 32 bit integer
typedef signed int		s32;

//! 8 bit character
typedef char	c8;

#if defined(_WIN32) ||  defined(__GNUC__) || defined(_PS3) || defined(_NN_CTR) || defined(SN_TARGET_PSP2)
//! Signed 64 bit integer
typedef signed long long s64;
#endif //add other platform that support long long is needed

//Floating point
//! 32 bit IEEE754 floating point
typedef float	f32;
//! 64 bit IEEE754 floating point
typedef double	f64;

//Fixed Point
//! 1.17.14 signed fixed point format
typedef int fx1814;
//! fx1814 fraction shift
#define VOX_FX1814_FRACT_SHIFT 14
//! fx1814 one
#define VOX_FX1814_ONE (1 << 14)
//! fx1814 fraction mask
#define VOX_FX1814_FRACT_MASK 0x3FFF

typedef int fx1715; //1.16.15 signed fixed point format
#define VOX_FX1715_FRACT_SHIFT 15
#define VOX_FX1715_ONE (1 << 15)
#define VOX_FX1715_FRACT_MASK 0x7FFF

//Special type
#ifdef __cplusplus
typedef std::size_t size_t;
#endif

}
#endif //_VOX_TYPES_H_
