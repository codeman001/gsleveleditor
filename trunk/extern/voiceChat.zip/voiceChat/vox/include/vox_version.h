#ifndef _VOX_VERSION_H_
#define _VOX_VERSION_H_
#define VOX_VERSION "1.1.1767"
#endif // _VOX_VERSION_H_
