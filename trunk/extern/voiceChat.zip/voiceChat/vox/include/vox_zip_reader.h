#pragma once
#ifndef _VOX_ZIP_READER_H_
#define _VOX_ZIP_READER_H_

#include "vox_default_config.h"
#include "vox_memory.h"
#include "vox_filesystem.h"

#include VOX_STRING_INCLUDE
#include VOX_MAP_INCLUDE

namespace vox
{

class FileInterface;
const s16 ZIP_INFO_IN_DATA_DESCRITOR =	0x0008;

struct StringComp {
  bool operator() (const VOX_STRING& lhs, const VOX_STRING& rhs) const
  {return lhs<rhs;}
};

namespace os
{

template<typename T, u32 SIZE>
struct SSwap
{
	static T swap(const T& val)
	{
		T tmp;
		u8* dest = (u8*)&tmp;
		u8* src = (u8*)&val;
		for(u32 i = 0; i < SIZE; ++i){
			dest[i] = src[(SIZE - 1) - i];
		}
		return tmp;
	}
};

template<typename T>
T byteswap(const T& v)
{
	return SSwap<T, sizeof(T)>::swap(v);
}

}

struct SZIPFileDataDescriptor
{
	s32 CRC32;
	s32 CompressedSize;
	s32 UncompressedSize;
};

struct SZIPFileHeader
{
	s32 Sig;
	s16 VersionToExtract;
	s16 GeneralBitFlag;
	s16 CompressionMethod;
	s16 LastModFileTime;
	s16 LastModFileDate;
	SZIPFileDataDescriptor DataDescriptor;
	s16 FilenameLength;
	s16 ExtraFieldLength;

	s32 read32(unsigned char *p)
	{
		return p[0] + (p[1]<<8) + (p[2]<<16) + (p[3]<<24);
	}
	s16 read16(unsigned char *p)
	{
		return p[0] + (p[1]<<8);
	}
	void parseDataDescriptor(unsigned char *p)
	{
		DataDescriptor.CRC32            = read32(p + 0);
		DataDescriptor.CompressedSize   = read32(p + 4);
		DataDescriptor.UncompressedSize = read32(p + 8);		
	}
	void parseData(unsigned char *p)
	{
		Sig                  = read32(p + 0);
		VersionToExtract     = read16(p + 4);
		GeneralBitFlag       = read16(p + 6);
		CompressionMethod    = read16(p + 8);
		LastModFileTime      = read16(p + 10);
		LastModFileDate      = read16(p + 12);
		parseDataDescriptor(p + 14);
		FilenameLength   = read16(p + 26);
		ExtraFieldLength = read16(p + 28);
	}

};

struct SZipFileEntry
{
	VOX_STRING zipFileName;
	VOX_STRING simpleFileName;
	VOX_STRING path;
	s32 fileDataPosition; // position of compressed data in file
	SZIPFileHeader header;

	bool operator < (const SZipFileEntry& other) const
	{
		for(u32 i=0; i<simpleFileName.length() && i < other.simpleFileName.length(); ++i)
		{
			s32 diff = simpleFileName[i] - other.simpleFileName[i];
			if ( diff )
				return diff < 0;
		}
		return simpleFileName.length() < other.simpleFileName.length();
	}

	bool operator == (const SZipFileEntry& other) const
	{
		return simpleFileName.compare(other.simpleFileName) == 0;
	}
};

/*
	Zip file Reader written April 2002 by N.Gebhardt.
	Doesn't decompress data, only reads the file and is able to
	open uncompressed entries.
	Modified by A. Belanger June 2010
*/
class CZipReader
{
public:

	CZipReader(const c8* filename, bool ignoreCase, bool ignorePaths);

	virtual ~CZipReader();

	// opens a file by file name
	virtual bool getFileInfo(const c8* filename, s32 &baseOffset, s32 &fileSize);

	// returns the name of the zip file archive
	const c8* getZipFileName() const
	{
		return m_archiveName.c_str();
	}

	s32 getFileCount();

	bool isValid(){return m_isValid;};
	bool hasExtensionTable(){return m_hasExtensionTable;};

	enum { MAX_ZIP_FILENAME = 1024 };

	//! Export the zip's local headers to an output stream.
	bool ExportHeader(ZipTableSerializer& outStream);
private:
		
	//! scans for a local header, returns false if there is no more local file header.
	//! Used only if zip file doesn't contain an extension table with files headers content.
	bool scanLocalHeader();

	//! Gets local headers from (custom) file extension table
	bool ImportHeader(ZipTableSerializer& inStream);

	FileInterface* File;
	VOX_STRING m_archiveName;

protected:

	//! splits filename from zip file into useful filenames and paths
	void extractFilename(SZipFileEntry* entry);

	//! deletes the path from a filename
	void deletePathFromFilename(VOX_STRING& filename);

	bool IgnoreCase;
	bool IgnorePaths;
	typedef VOX_MAP<VOX_STRING, SZipFileEntry, StringComp, SAllocator<std::pair<const VOX_STRING,SZipFileEntry> > > FileListMap;
	FileListMap FileList;
	bool m_isValid;
	bool m_hasExtensionTable;
};

}

#endif //_VOX_ZIP_READER_H_
