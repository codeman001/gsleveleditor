//  ===================================================================================================================
//
//      COMMON (internal, libvox) - xcode config
//
//  * See the common global xcode config file (in Internal) for a detailled explanation about this system.
//  * See the user debug project xcode config file (in ../vox_config/xcode/ios) for a detailed explanation
//    about user customisable configuration.
//
//  ===================================================================================================================

// Target name
PRODUCT_NAME = vox
