import shutil 
import os
import sys
import xml.dom.minidom

def strip_x64_target(inproj, outproj):
  # load the config xml file
  projIn = xml.dom.minidom.parse(inproj)
  
  platforms = projIn.getElementsByTagName("Platforms")[0]
  elements = projIn.getElementsByTagName("Platform")
  
  for element in elements :
    print element.getAttribute("Name")
    platform = element.getAttribute("Name")
    if platform == "x64" :
      print "removing x64"         
      platforms.removeChild(element)
  
  configuration = projIn.getElementsByTagName("Configurations")[0]
  elements = projIn.getElementsByTagName("Configuration")
  
  for element in elements :
    print element.getAttribute("Name")
    platform = element.getAttribute("Name")
    if platform == "Debug|x64" or platform == "Release|x64" or platform == "Debug_CU|x64" or platform == "Release_CU|x64":
      print platform         
      configuration.removeChild(element)
    
  f = open(outproj,'w')
  f.write( projIn.toprettyxml() )  
  f.close()

if __name__ == '__main__':
  projbasename = sys.argv[1]
  print "Project : " + projbasename
  
  #
  # Convert the unnamed vox (2008) project to named 2008 project.
  # 2005 no longer supported.
  #
  
  vcprojNames 	= ['2008']
  vcprojVersions	= ['9.00']
  
  for name,version in zip(vcprojNames, vcprojVersions):
  	originVcproj=open(projbasename+'.vcproj', 'r')
  	newVcproj=open(projbasename+'.%s.vcproj' %(name), 'w')
  	tempVcproj = originVcproj.read().replace(r'Version="9.00"', r'Version="%s"' %(version))
  	newVcproj.write(tempVcproj.replace(r'Version="9,00"', r'Version="%s"' %(version)))
  	originVcproj.close()
  	newVcproj.close()
        
  #
  # Create the 2010 project from the 2008 project.
  #
  
  if os.path.exists(projbasename+'.2010.vcproj'):
  	os.remove(projbasename+'.2010.vcproj')
  
  if os.path.exists(projbasename+'.2010.vcxproj'):
  	os.remove(projbasename+'.2010.vcxproj')
  	
  if os.path.exists(projbasename+'.2010.vcxproj.filters'):
  	os.remove(projbasename+'.2010.vcxproj.filters')

  strip_x64_target(projbasename+'.2008.vcproj', projbasename+'.2010.vcproj')
  os.system('config_visual_studio_2010_express & vcupgrade ' + projbasename+'.2010.vcproj')
  
  props = open('vsprops_local\common.props', 'r')
  data = props.read().replace(r'ConfigurationName', r'Configuration')
  props.close()
  
  props = open('vsprops_local\common.props', 'w')
  props.write(data)
  props.close()
  
  if os.path.exists('pantheon.2010.vcproj'):
  	os.remove('pantheon.2010.vcproj')


