 __________________________________
[                                  ]
[             VOX 1.1              ]
[__________________________________]

Official Release: April 3rd 2012

Where to get documentation:
- Samples have been moved down 1 level. They're in /samples instead of /vox/samples.
  You might have to do a SVN checkout if you only have /vox.
- See the /vox/documentations folder.
- See the Vox 1.1 wiki page at https://wiki.gameloft.org/twiki/bin/view/Main/Vox_11
- The SDD manual has been updated. See /vox/Tools/XML Soundpack Descriptor folder.

Some catches on porting from 1.0:
- Custom allocator is mandatory. See /vox/include/vox_memory.h.
- Some header files are now "internal" to vox and including them will cause errors.
- No more VoxIphone, use VoxEngine. Ipod stuff is now in the external_player plugin.
- Groups and banks are now hierarchical. No more masks.
- The XML Soundpack has been updated. You must start from the new template.
- You should play all XML Soundpack sounds from events using creationSettings.



This document was updated by
Hubert Lamontagne on April 3rd 2012