
#include "StdAfx.h"

// MPC - C++/Vox interface part. C part is in vox_decoder_mpc8_cu.c
#include "../vox_decoder_mpc8.cpp"

// WAV
#include "../AdpcmDecoder.cpp"
#include "../AdpcmState.cpp"
#include "../vox_decoder_mswav.cpp"
#include "../vox_mswav_subdecoder.cpp"
#include "../vox_mswav_subdecoder_imaadpcm.cpp"
#include "../vox_mswav_subdecoder_msadpcm.cpp"
#include "../vox_mswav_subdecoder_pcm.cpp"

// VXN
#include "../vox_native_playlists.cpp"
#include "../vox_native_subdecoder.cpp"
#include "../vox_native_subdecoder_imaadpcm.cpp"
#include "../vox_native_subdecoder_msadpcm.cpp"
#include "../vox_native_subdecoder_pcm.cpp"
#include "../vox_decoder_native.cpp"

// Decode from raw data in memory
#include "../vox_decoder_raw.cpp"

