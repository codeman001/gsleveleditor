
#include "StdAfx.h"

// SW driver template
#include "../vox_driver_callback_template.cpp"
#include "../vox_driver_callback_template_neon.cpp"

// SW drivers
#include "../vox_driver_android.cpp"
#include "../vox_driver_iphone_remoteio.cpp"
#include "../vox_driver_mmsystem.cpp"

// SW DSP - minibus
#include "../vox_custom_dsp.cpp"
#include "../vox_minibus_system.cpp"

// Non SW drivers
#include "../vox_driver_null.cpp"


