
#include "StdAfx.h"

// File system template
#include "../vox_filesystem.cpp"

// Platform specific file systems
#include "../vox_filesystem_stdio.cpp"
#include "../vox_filesystem_glf.cpp"
#include "../vox_filesystem_posix.cpp"

// Zip reader
#include "../vox_zip_reader.cpp"

// Data streams
#include "../vox_stream_cfile.cpp"
#include "../vox_stream_memorybuffer.cpp"

