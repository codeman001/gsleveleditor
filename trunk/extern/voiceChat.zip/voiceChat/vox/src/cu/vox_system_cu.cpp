
#include "StdAfx.h"

// Access controller
#include "../vox_access_controller.cpp"

// Mutexes
#include "../vox_mutex_glf.cpp"
#include "../vox_mutex_pthread.cpp"
#include "../vox_mutex_win32.cpp"

// Threads
#include "../vox_thread_glf.cpp"
#include "../vox_thread_pthread.cpp"
#include "../vox_thread_win32.cpp"

// Neon detection
#include "../vox_detect_neon.cpp"

