
#include "StdAfx.h"
#include "vox_mutex.h"
#include "vox_macro.h"
#include <cstring>

namespace vox {

//! Get a read token from the access controller
/*!
	Will try to acquire a read token from the access controller, will block until token is acquired. 
	Multiple read token are available, but they cannot coexist with write token.
*/
void AccessController::GetReadAccess()
{
	bool done = false;
	do
	{
		m_mutex.Lock();
		if(m_writers == 0)
		{
			++m_readers;
			done = true;
			m_mutex.Unlock();
		}
		else
		{
			m_mutex.Unlock();
			VoxThread::Sleep(1);
		}		
	}
	while(!done);

	//VOX_WARNING_LEVEL_5("%s :  %d\n", __FUNCTION__, m_mutex);
}

//! Release a read token from the access controller
void AccessController::ReleaseReadAccess()
{
	m_mutex.Lock();
	--m_readers;
	m_mutex.Unlock();
	//VOX_WARNING_LEVEL_5("%s :  %d\n", __FUNCTION__, m_mutex);
}

//! Get a write token from the access controller
/*!
	Will try to acquire a write token from the access controller, will block until token is acquired. 
	Only one write token are available and cannot coexist with read token.
*/
void AccessController::GetWriteAccess()
{	
	bool done = false;
	do
	{
		m_mutex.Lock();
		if(m_writers == 0 && m_readers == 0)
		{
			++m_writers;
			done = true;
			m_mutex.Unlock();
		}
		else
		{
			m_mutex.Unlock();
			VoxThread::Sleep(1);
		}
	}
	while(!done);

	//VOX_WARNING_LEVEL_5("%s :  %d\n", __FUNCTION__, m_mutex);
}

//! Release a write token from the access controller
void AccessController::ReleaseWriteAccess()
{
	m_mutex.Lock();
	--m_writers;
	m_mutex.Unlock();
	//VOX_WARNING_LEVEL_5("%s :  %d\n", __FUNCTION__, m_mutex);
}

} //namespace vox


