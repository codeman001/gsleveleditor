#include "StdAfx.h"
#include "vox_console.h"
#include "vox_macro.h"
#include "vox_default_config.h"
#include "vox_glf_debugger_module.h"
#include <cstdio>
#include <cstdarg>

#ifdef ANDROID
#include <android/log.h>
#define VOX_CONSOLE_PRINT(level, msg, ...) __android_log_print(ANDROID_LOG_FATAL-level, "VOX", msg, __VA_ARGS__)
#else
#include <stdio.h>
#define VOX_CONSOLE_PRINT(level, msg, ...) std::printf(msg, __VA_ARGS__) 
#endif

namespace vox
{

//*** ConsoleImplInterface ***//

s32 ConsoleImplInterface::s_logLevel = VOX_WARNING_LEVEL;


//*** Console ***//

ConsoleImplInterface *Console::s_pConsoleImplementation = 0;

Console::Console()
{
}

Console::~Console()
{
}

void Console::SetConsoleImpl(ConsoleImplInterface* pExternalConsole)
{
	s_pConsoleImplementation = pExternalConsole;
}

void Console::Print(s32 level, const c8* str, ...)
{
#if VOX_ENABLE_CONSOLE
	va_list	argptr;
	va_start (argptr,str);
	
#if VOX_USE_GLF_DEBUGGER_MODULE
	char strBuf[1024], strBuf2[1024];

	// Resolve string
	vsprintf(strBuf, str, argptr);
	sprintf(strBuf2, "[VOX W%d] %s", level ,strBuf);

	if(s_pConsoleImplementation)
	{
		// Forward unresolved string to user console
		s_pConsoleImplementation->Print(level, str, argptr);
	}
	else
	{
		// Print resolved string using vox console
		_Print(level, strBuf2);
	}

	VoxGlfDebuggerModule *glfDebuggerModule = VoxGlfDebuggerModule::GetInstance();
	if(glfDebuggerModule)
	{
		// Forward string to glf debugger module
		if(glfDebuggerModule->IsActive())
		{
			glfDebuggerModule->AddConsoleMessage(strBuf2);
		}
	}
#else
	if(s_pConsoleImplementation)
	{
		// Forward unresolved string to user console
		s_pConsoleImplementation->Print(level, str, argptr);
	}
	else
	{
		char strBuf[1024], strBuf2[1024];

		// Resolve string
		vsprintf(strBuf, str, argptr);
		sprintf(strBuf2, "[VOX W%d] %s", level ,strBuf);

		// Print resolved string using vox console
		_Print(level, strBuf2);
	}
#endif
	va_end(argptr);
#endif
}

void Console::_Print(s32 level, const c8* str)
{
	if(level > 0 && level <= ConsoleImplInterface::s_logLevel)
	{
	VOX_CONSOLE_PRINT(level, "%s", str);
#ifdef WIN32
	OutputDebugString(str);
#endif
	}
}

void Console::SetLogLevel(unsigned int level)
{
	if(level < 0)
	{
		ConsoleImplInterface::s_logLevel = 0;
	}
	else if(level > 5)
	{
		ConsoleImplInterface::s_logLevel = 5;
	}
	else
	{
		ConsoleImplInterface::s_logLevel = level;
	}
}

} // namespace vox


