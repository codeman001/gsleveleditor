
#include "StdAfx.h"
#include "vox_custom_dsp.h"


namespace vox
{

CustomDSP::CustomDSP()
{	
	m_sampleRate = -1;
}


CustomDSP::~CustomDSP(void)
{
}



} // namespace vox


