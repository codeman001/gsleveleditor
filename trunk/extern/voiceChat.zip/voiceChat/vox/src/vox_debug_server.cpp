
#include "StdAfx.h"
#include "vox_debug_server.h"

#if VOX_DEBUG_SERVER_ENABLE
#include <fcntl.h>

namespace vox
{

DebugServer::DebugServer()
:m_state(DebugServerState::k_nInitial)
,m_updateToAnnouce(0)
{
#ifdef _WIN32
	WSADATA info;
    if (WSAStartup(MAKEWORD(2,0), &info)) {
		printf("error on init wsa\n/");
		return;
	}
#endif

	// UDP: use SOCK_DGRAM instead of SOCK_STREAM
	m_socketOut = socket(AF_INET,SOCK_DGRAM,0);

#if defined(_WIN32)
	u_long arg = 1;
    ioctlsocket(m_socketOut, FIONBIO, &arg);
#else //to check **-**
	fcntl(m_socketOut, F_SETFL, O_NONBLOCK);
#endif

	if (m_socketOut == INVALID_SOCKET) {
		VOX_WARNING_LEVEL_2("INVALID_SOCKET", 0);
		m_state = DebugServerState::k_nError;
	}
	else
	{
		char addrip[] = VOX_DEBUG_SERVER_REMOTE_ADDRESS;
		m_skAddrOut.sin_family = AF_INET;
		m_skAddrOut.sin_port = htons(VOX_DEBUG_SERVER_REMOTE_PORT);
		m_skAddrOut.sin_addr = *((in_addr *)addrip);//*((in_addr *)he->h_addr);
		memset(&(m_skAddrOut.sin_zero), 0, 8); 

		m_skAddrIn.sin_family = AF_INET;
		m_skAddrIn.sin_port = htons(VOX_DEBUG_SERVER_LISTEN_PORT);
		m_skAddrIn.sin_addr = *((in_addr *)addrip);//*((in_addr *)he->h_addr);
		memset(&(m_skAddrIn.sin_zero), 0, 8); 
		if (bind(m_socketOut,(struct sockaddr *)&m_skAddrIn,sizeof(sockaddr_in))<0) 
		{
			   m_state = DebugServerState::k_nError;
		}
		else
		{
			m_state = DebugServerState::k_nIdle;
		}
	}
}

DebugServer::~DebugServer()
{
#ifdef _WIN32
	WSACleanup();
#endif
}

void DebugServer::Send(void* data, s32 size)
{
	if(m_state == DebugServerState::k_nSendingData)
		sendto(m_socketOut, (const c8*)data, size, 0, (struct sockaddr *)&m_skAddrOut, sizeof(sockaddr_in));
}

s32 DebugServer::Receive()
{
	s32 addrlen = sizeof(sockaddr_in);
	s32 msgLen = recvfrom(m_socketOut, (c8*)m_data, 60*1024,0, (struct sockaddr *)&m_skAddrIn, &addrlen);
	if(msgLen > 0 && m_state != DebugServerState::k_nError)
	{ //temp until proper msg handling
		if(m_data[0] == 0)
			m_state = DebugServerState::k_nIdle;
		else if(m_data[0] == 1)
			m_state = DebugServerState::k_nSendingData;
	}

	return 0;
}

}

#endif //#if VOX_DEBUG_SERVER_ENABLE


