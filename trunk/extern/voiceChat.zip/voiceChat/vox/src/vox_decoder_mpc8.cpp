
#include "StdAfx.h"
#include "vox_decoder_mpc8.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "mpc/mpc_types.h"
#include "mpc/reader.h"
#include "mpc/internal.h"
#include <cstring>
#include "vox_profiler.h"

/// Reads size bytes of data into buffer at ptr.
mpc_int32_t mpc_read(mpc_reader *p_reader, void *ptr, mpc_int32_t size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "mpc_read", vox::VoxThread::GetCurThreadId());
	vox::StreamCursorInterface* streamCursor = (vox::StreamCursorInterface*)p_reader->data;
	if(streamCursor)
		return streamCursor->Read((vox::u8*)ptr, size);
	return 0;
}

/// Seeks to byte position offset.
mpc_bool_t mpc_seek(mpc_reader *p_reader, mpc_int32_t offset)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "mpc_seek", vox::VoxThread::GetCurThreadId());
	vox::StreamCursorInterface* streamCursor = (vox::StreamCursorInterface*)p_reader->data;
	if(streamCursor)
		return streamCursor->Seek(offset) == 0;
	return false;
}

/// Returns the current byte offset in the stream.
mpc_int32_t mpc_tell(mpc_reader *p_reader)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "mpc_tell", vox::VoxThread::GetCurThreadId());
	vox::StreamCursorInterface* streamCursor = (vox::StreamCursorInterface*)p_reader->data;
	if(streamCursor)
		return streamCursor->Tell();
	return 0;
}

/// Returns the total length of the source stream, in bytes.
mpc_int32_t mpc_getsize(mpc_reader *p_reader)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "mpc_getsize", vox::VoxThread::GetCurThreadId());
	vox::StreamCursorInterface* streamCursor = (vox::StreamCursorInterface*)p_reader->data;
	if(streamCursor)
		return streamCursor->Size();
	return 0;
}

/// True if the stream is a seekable stream.
mpc_bool_t mpc_canseek(mpc_reader *p_reader)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "mpc_canseek", vox::VoxThread::GetCurThreadId());
	return true;
}


namespace vox
{

DecoderInterface* DecoderMPC8Factory(void* params)
{
	return VOX_NEW DecoderMPC8((DecoderMPC8Params*)params); 
}

///

DecoderMPC8::DecoderMPC8(DecoderMPC8Params* param)
{
	if(param)
		m_forceSampleRate = param->m_forceSampleRate;
	else
		m_forceSampleRate = -1;
}

DecoderCursorInterface* DecoderMPC8::CreateNewCursor( StreamCursorInterface* pStreamCursor )
{
	return VOX_NEW DecoderMPC8Cursor(this,pStreamCursor);
}

void DecoderMPC8::DestroyCursor(DecoderCursorInterface* pDecoderCursor)
{
	VOX_DELETE( (DecoderMPC8Cursor*)pDecoderCursor);
}

///

DecoderMPC8Cursor::DecoderMPC8Cursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor)
: DecoderCursorInterface( pDecoder, pStreamCursor )
,m_totalSampleDecoded(0)
,m_samplesInBuffer(0)
,m_samplesInBufferConsumed(0)
,m_pDemux(0)
,m_sampleBuffer(0)
,m_error(MPC_STATUS_OK)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMPC8Cursor::DecoderMPC8Cursor", vox::VoxThread::GetCurThreadId());
	m_trackParams.numSamples = 0;

	//set reader functions

	m_reader.read = mpc_read;
	m_reader.seek = mpc_seek;
	m_reader.tell = mpc_tell;
	m_reader.canseek = mpc_canseek;
	m_reader.get_size = mpc_getsize;
	m_reader.data = (void*) pStreamCursor;

	m_sampleBuffer = (MPC_SAMPLE_FORMAT*)VOX_ALLOC(MPC_DECODER_BUFFER_LENGTH * sizeof(MPC_SAMPLE_FORMAT));

	if(m_sampleBuffer)
		m_pDemux = mpc_demux_init(&m_reader);

    if(m_pDemux)
	{
		if(m_pDemux->d && m_pDemux->r)
		{
			mpc_streaminfo si;
			mpc_demux_get_info(m_pDemux,  &si);
#ifdef _PS3
			m_trackParams.bitsPerSample = 32;
#else
			m_trackParams.bitsPerSample = 16;
#endif
			m_trackParams.numChannels = si.channels;
			s32 forceSampleRate = ((DecoderMPC8*)pDecoder)->GetForceSampleRate();
			if(forceSampleRate > 0)
				m_trackParams.samplingRate = forceSampleRate;
			else
				m_trackParams.samplingRate = si.sample_freq;
			m_trackParams.numSamples = (u32)si.samples;
		}
		else
		{
			m_trackParams.Reset();
		}
	}
	else
	{
		m_trackParams.Reset();
	}
}

DecoderMPC8Cursor::~DecoderMPC8Cursor()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMPC8Cursor::~DecoderMPC8Cursor", vox::VoxThread::GetCurThreadId());
	if(m_pDemux)
		mpc_demux_exit(m_pDemux);
	if(m_sampleBuffer)
	{
		VOX_FREE(m_sampleBuffer);
	}
}

bool DecoderMPC8Cursor::CheckForEndOfSample()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMPC8Cursor::HandleEndOfSample", vox::VoxThread::GetCurThreadId());
	
	// handle end of sample
	if(/*(frame.bits == -1) ||*/ (m_totalSampleDecoded == m_trackParams.numSamples)) 
	{
		if(!m_loop)
		{
			return true;
		}
		else
		{
			m_error = mpc_demux_seek_sample(m_pDemux, 0);
			if(m_error != MPC_STATUS_OK)
				return true;
			m_totalSampleDecoded = 0;
		}
	}	

	return false;
}

s32 DecoderMPC8Cursor::Decode( void* outputBuffer, s32 nbBytes )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMPC8Cursor::Decode", vox::VoxThread::GetCurThreadId());

	s32 nbSamplesDesired = nbBytes / (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;

	// First empty unused buffer data
	if(m_samplesInBufferConsumed < m_samplesInBuffer)
	{
		s32 sampleAvailable = m_samplesInBuffer - m_samplesInBufferConsumed;
		if(sampleAvailable > nbSamples)
		{
			if(m_trackParams.bitsPerSample == 32)
				memcpy(outputBuffer, &(m_sampleBuffer[m_samplesInBufferConsumed * m_trackParams.numChannels]), nbSamples * m_trackParams.numChannels * sizeof(f32));
			else
#ifdef MPC_FIXED_POINT
				ConvertFixedToShort((s16*) outputBuffer, &(m_sampleBuffer[m_samplesInBufferConsumed * m_trackParams.numChannels]), nbSamples * m_trackParams.numChannels);
#else
				ConvertFloatToShort((s16*) outputBuffer, &(m_sampleBuffer[m_samplesInBufferConsumed * m_trackParams.numChannels]), nbSamples * m_trackParams.numChannels);
#endif

			m_samplesInBufferConsumed += nbSamples;
			m_totalSampleDecoded += nbSamples;
			nbSamples = 0;
		}
		else
		{
			if(m_trackParams.bitsPerSample == 32)
				memcpy(outputBuffer, &(m_sampleBuffer[m_samplesInBufferConsumed * m_trackParams.numChannels]), sampleAvailable * m_trackParams.numChannels * sizeof(f32));
			else
#ifdef MPC_FIXED_POINT
				ConvertFixedToShort((s16*) outputBuffer, &(m_sampleBuffer[m_samplesInBufferConsumed * m_trackParams.numChannels]), sampleAvailable * m_trackParams.numChannels);
#else
				ConvertFloatToShort((s16*) outputBuffer, &(m_sampleBuffer[m_samplesInBufferConsumed * m_trackParams.numChannels]), sampleAvailable * m_trackParams.numChannels);
#endif

			nbSamples -= sampleAvailable;
			m_samplesInBufferConsumed += sampleAvailable;
			m_totalSampleDecoded += sampleAvailable;
		}
	}

	if(CheckForEndOfSample())
		return (nbSamplesDesired - nbSamples)*( m_trackParams.numChannels * (m_trackParams.bitsPerSample>>3));

	mpc_frame_info frame;
	memset(&frame, 0, sizeof(frame));
	frame.buffer = m_sampleBuffer;

	s32 bufferoffset;
	while(nbSamples > 0)
	{
		m_error = mpc_demux_decode(m_pDemux, &frame);
		m_samplesInBufferConsumed = 0;
		m_samplesInBuffer = frame.samples;

		bufferoffset = (nbSamplesDesired - nbSamples) * m_trackParams.numChannels;
		if(m_samplesInBuffer > nbSamples)
		{
			if(m_trackParams.bitsPerSample == 32)
				memcpy(&((f32*) outputBuffer)[bufferoffset], frame.buffer, nbSamples * m_trackParams.numChannels * sizeof(f32));
			else
#ifdef MPC_FIXED_POINT
				ConvertFixedToShort(&((s16*) outputBuffer)[bufferoffset], frame.buffer, nbSamples * m_trackParams.numChannels);
#else
				ConvertFloatToShort(&((s16*) outputBuffer)[bufferoffset], frame.buffer, nbSamples * m_trackParams.numChannels);
#endif

			m_samplesInBufferConsumed += nbSamples;
			m_totalSampleDecoded += nbSamples;
			nbSamples = 0;
		}
		else
		{
			if(m_trackParams.bitsPerSample == 32)
				memcpy(&((f32*) outputBuffer)[bufferoffset], frame.buffer, m_samplesInBuffer * m_trackParams.numChannels * sizeof(f32));
			else
#ifdef MPC_FIXED_POINT
				ConvertFixedToShort(&((s16*) outputBuffer)[bufferoffset], frame.buffer, m_samplesInBuffer * m_trackParams.numChannels);
#else
				ConvertFloatToShort(&((s16*) outputBuffer)[bufferoffset], frame.buffer, m_samplesInBuffer * m_trackParams.numChannels);
#endif

			nbSamples -= m_samplesInBuffer;
			m_samplesInBufferConsumed += m_samplesInBuffer;
			m_totalSampleDecoded += m_samplesInBuffer;
		}

		if(CheckForEndOfSample())
			break;
	}
	
	return (nbSamplesDesired - nbSamples)*( m_trackParams.numChannels * (m_trackParams.bitsPerSample>>3));
}

s32 DecoderMPC8Cursor::Seek( u32 sampleNum )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMPC8Cursor::Seek", vox::VoxThread::GetCurThreadId());
	if(sampleNum)
	{
		m_error = mpc_demux_seek_sample(m_pDemux, 0);
		if(m_error != MPC_STATUS_OK)
			return -1; //could not go back to beginning
		m_totalSampleDecoded = 0;
		m_samplesInBufferConsumed = 0;
		m_samplesInBuffer = 0;
		return 0;
	}

	return -1;
}

bool DecoderMPC8Cursor::HasData()
{
	if(m_pStreamCursor && m_error == MPC_STATUS_OK)
	{
		if(!(m_totalSampleDecoded < m_trackParams.numSamples) && m_loop)
			Seek(0);

		return m_totalSampleDecoded < m_trackParams.numSamples;
	}
	return false;
}

void DecoderMPC8Cursor::ConvertFloatToShort(s16* dest, f32* src, s32 size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMPC8Cursor::ConvertFloatToShort", vox::VoxThread::GetCurThreadId());
	s32 tempvalue;
	for(s32 i = 0; i < size; i++)
	{
		tempvalue = (s32)(src[i] * 32768);
        if ((u32) (tempvalue + 32768) > 65535)
			dest[i] = (s16)(tempvalue < 0 ? -32768 : 32767);
		else
			dest[i] = (s16)tempvalue;
	}
}

void DecoderMPC8Cursor::ConvertFixedToShort(s16* dest, vox::s32* src, s32 size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMPC8Cursor::ConvertFixedToShort", vox::VoxThread::GetCurThreadId());
#ifdef MPC_FIXED_POINT
	for(s32 i = 0; i < size; i++)
	{
		dest[i] = (s16)(src[i] >> (MPC_FIXED_POINT_FRACTPART));
	}
#endif
}
}


