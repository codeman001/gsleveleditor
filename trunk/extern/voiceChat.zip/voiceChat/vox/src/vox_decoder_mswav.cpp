
#include "StdAfx.h"
#include "vox_decoder_mswav.h"
#include "vox_mswav_subdecoder_pcm.h"
#include "vox_mswav_subdecoder_imaadpcm.h"
#if !defined(_NN_CTR) && !defined(_PS3)
#include "vox_mswav_subdecoder_msadpcm.h"
#endif
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox_profiler.h"

namespace vox {

DecoderInterface* DecoderMSWavFactory(void* params)
{
	return VOX_NEW DecoderMSWav(); 
}

///

DecoderMSWav::DecoderMSWav()
:m_needParsing(true)
{

}

DecoderMSWav::~DecoderMSWav()
{
	m_needParsing = true;
	if(m_waveChunks.m_dataNodes)
	{
		m_waveChunks.m_dataNodes->DropNodes();
		VOX_DELETE(m_waveChunks.m_dataNodes);
		m_waveChunks.m_dataNodes = 0;
	}
}

DecoderCursorInterface* DecoderMSWav::CreateNewCursor( StreamCursorInterface* pStreamCursor )
{
	return VOX_NEW DecoderMSWavCursor(this,pStreamCursor);
}

void DecoderMSWav::DestroyCursor(DecoderCursorInterface* pDecoderCursor)
{
	VOX_DELETE( (DecoderMSWavCursor*)pDecoderCursor);
}
///

DecoderMSWavCursor::DecoderMSWavCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor)
: DecoderCursorInterface( pDecoder, pStreamCursor ), m_pSubDecoder(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMSWavCursor::DecoderMSWavCursor", vox::VoxThread::GetCurThreadId());
	m_pWaveChunks = ((DecoderMSWav*)m_pDecoder)->GetWaveChunks();
	if(((DecoderMSWav*)m_pDecoder)->NeedParsing())
	{
		if(ParseFile())
		{
			((DecoderMSWav*)m_pDecoder)->SetParsed();
		}
		else
		{
			m_trackParams.Reset();
			return;
		}
	}

	bool result = (strncmp(m_pWaveChunks->m_riffHeader.chunkId, "RIFF", 4) == 0) && (strncmp(m_pWaveChunks->m_riffHeader.riffType, "WAVE", 4) == 0);

	if(m_pWaveChunks->m_formatHeader.compressionCode == k_ccPCM && result)
		m_pSubDecoder = VOX_NEW VoxMSWavSubDecoderPCM(pStreamCursor, m_pWaveChunks);
	else if(m_pWaveChunks->m_formatHeader.compressionCode == k_ccIMAADPCM && result)
		m_pSubDecoder = VOX_NEW VoxMSWavSubDecoderIMAADPCM(pStreamCursor, m_pWaveChunks);
#if !defined(_NN_CTR) && !defined(_PS3)
	else if(m_pWaveChunks->m_formatHeader.compressionCode == k_ccMSADPCM && result)
		m_pSubDecoder = VOX_NEW VoxMSWavSubDecoderMSADPCM(pStreamCursor, m_pWaveChunks);
#endif

	VOX_ASSERT_MSG(m_pSubDecoder, "Could not initialize MSWav subdecoder");
	if(m_pSubDecoder)
	{
		m_trackParams = m_pSubDecoder->GetTrackParams();
	}
	else
	{
		m_trackParams.Reset();
	}
}

DecoderMSWavCursor::~DecoderMSWavCursor()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMSWavCursor::~DecoderMSWavCursor", vox::VoxThread::GetCurThreadId());
	if(m_pSubDecoder)
		VOX_DELETE( m_pSubDecoder);
}

s32 DecoderMSWavCursor::Decode( void* outputBuffer, s32 nbBytes )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMSWavCursor::Decode", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_pSubDecoder, "Not MSWav subdecoder, cannot decode\n");

	if(m_pSubDecoder)
		return m_pSubDecoder->Decode(outputBuffer, nbBytes);

	return 0;
}

s32 DecoderMSWavCursor::Seek( u32 sampleNum )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMSWavCursor::Seek", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_pSubDecoder, "Not MSWav subdecoder, cannot Seek\n");

	if(m_pSubDecoder)
		return m_pSubDecoder->Seek(sampleNum);

	return -1;
}

void DecoderMSWavCursor::SetLoop( bool loop )
{
	VOX_ASSERT_MSG(m_pSubDecoder, "Not MSWav subdecoder, cannot SetLoop\n");

	if(m_pSubDecoder)
		m_pSubDecoder->SetLoop(loop);
}

bool DecoderMSWavCursor::HasData()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMSWavCursor::HasData", vox::VoxThread::GetCurThreadId());
	if(m_pSubDecoder)
		return m_pSubDecoder->HasData();
	return false;
}

bool DecoderMSWavCursor::ParseFile()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderMSWavCursor::ParseFile", vox::VoxThread::GetCurThreadId());;
	if(!m_pStreamCursor)
		return false;

	ChunkHeader chunkHeader;

	s32 initialPos = m_pStreamCursor->Tell();
	m_pStreamCursor->Seek(0, ORIGIN_START);

	bool validFile = false;
	while(!m_pStreamCursor->EndOfStream())
	{
		if(m_pStreamCursor->Tell() & 0x01) //all chunk are aligned on 16 bits
			m_pStreamCursor->Seek(1, ORIGIN_CURRENT);

		s32 readsize = m_pStreamCursor->Read((u8*)&chunkHeader, k_nChunkHeaderSize);
		if(readsize == k_nChunkHeaderSize)
		{
			if(strncmp(chunkHeader.chunkId, "RIFF", 4) == 0)
			{
				validFile = true;
				strncpy(m_pWaveChunks->m_riffHeader.chunkId, chunkHeader.chunkId, 4);
				m_pWaveChunks->m_riffHeader.filesize = chunkHeader.chunkSize;
				m_pStreamCursor->Read((u8*)&m_pWaveChunks->m_riffHeader + k_nChunkHeaderSize, k_nRiffChunkSize - k_nChunkHeaderSize);
#if VOX_BIG_ENDIAN
				ConvertRiffHeaderToBE(m_pWaveChunks->m_riffHeader);
#endif
			}
			else if(strncmp(chunkHeader.chunkId, "fmt ", 4) == 0)
			{
				strncpy(m_pWaveChunks->m_formatHeader.chunkId, chunkHeader.chunkId, 4);
				m_pWaveChunks->m_formatHeader.chunkDataSize = chunkHeader.chunkSize;
				m_pStreamCursor->Read((u8*)&m_pWaveChunks->m_formatHeader + k_nChunkHeaderSize, k_nFmtChunkSize - k_nChunkHeaderSize);
#if VOX_BIG_ENDIAN
				ConvertFormatHeaderToBE(m_pWaveChunks->m_formatHeader);
#endif
				if(m_pWaveChunks->m_formatHeader.chunkDataSize + k_nChunkHeaderSize > k_nFmtChunkSize) //extended - skip
				{
					m_pStreamCursor->Seek(m_pWaveChunks->m_formatHeader.chunkDataSize + k_nChunkHeaderSize - k_nFmtChunkSize, ORIGIN_CURRENT);
				}
			}
			else if(strncmp(chunkHeader.chunkId, "fact", 4) == 0)
			{
				strncpy(m_pWaveChunks->m_factHeader.chunkId, chunkHeader.chunkId, 4);
				m_pWaveChunks->m_factHeader.chunkDataSize = chunkHeader.chunkSize;
				m_pStreamCursor->Read((u8*)&m_pWaveChunks->m_factHeader + k_nChunkHeaderSize, k_nFactChunkSize - k_nChunkHeaderSize);
#if VOX_BIG_ENDIAN
				ConvertFactHeaderToBE(m_pWaveChunks->m_factHeader);
#endif
			}
			else if(strncmp(chunkHeader.chunkId, "data", 4) == 0)
			{
				strncpy(m_pWaveChunks->m_dataHeader.chunkId, chunkHeader.chunkId, 4);
				m_pWaveChunks->m_dataHeader.chunkSize = chunkHeader.chunkSize;
#if VOX_BIG_ENDIAN
				ConvertDataHeaderToBE(m_pWaveChunks->m_dataHeader);
#endif
				if(m_pWaveChunks->m_dataNodes)
				{
					m_pWaveChunks->m_dataNodes->AddNode(m_pStreamCursor->Tell() - k_nChunkHeaderSize, m_pWaveChunks->m_dataHeader.chunkSize);
				}
				else
				{
					m_pWaveChunks->m_dataNodes = VOX_NEW DataNode(m_pStreamCursor->Tell() - k_nChunkHeaderSize, m_pWaveChunks->m_dataHeader.chunkSize);
					if(!m_pWaveChunks->m_dataNodes)
						return false;
				}
				m_pStreamCursor->Seek(m_pWaveChunks->m_dataHeader.chunkSize, ORIGIN_CURRENT);
			}
			else // skip other chunk
			{
#if VOX_BIG_ENDIAN
				ConvertChunkHeaderToBE(chunkHeader);
#endif
				m_pStreamCursor->Seek(chunkHeader.chunkSize, ORIGIN_CURRENT);
			}
		}
		else
		{
			break;
		}

		if(!validFile) //didn't start with RIFF
		{
			break;
		}
	}

	m_pStreamCursor->Seek(initialPos, ORIGIN_START);
	return true;
}

} //namespace vox


