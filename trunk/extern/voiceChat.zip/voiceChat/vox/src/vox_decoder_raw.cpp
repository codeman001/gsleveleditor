
#include "StdAfx.h"
#include "vox_decoder_raw.h"
#include "vox_macro.h"
#include "vox_profiler.h"

namespace vox {

DecoderInterface* DecoderRawFactory(void* params)
{
	return VOX_NEW DecoderRaw( (TrackParams*)params ); 
}

///

DecoderRaw::DecoderRaw( TrackParams* params )
{
	//VOX_ASSERT(params);
	if ( params )
	{
		m_trackParams = *( (TrackParams*)params ) ;
	}
}

DecoderCursorInterface* DecoderRaw::CreateNewCursor( StreamCursorInterface* pStreamCursor )
{
	return VOX_NEW DecoderRawCursor(this,pStreamCursor);
}

void DecoderRaw::DestroyCursor(DecoderCursorInterface* pDecoderCursor)
{
	VOX_DELETE( (DecoderRawCursor*)pDecoderCursor);
}
///

DecoderRawCursor::DecoderRawCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor)
: DecoderCursorInterface( pDecoder, pStreamCursor )
,m_isDecoderInError(false)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderRawCursor::DecoderRawCursor", vox::VoxThread::GetCurThreadId());
	m_trackParams = ((DecoderRaw*)pDecoder)->GetTrackParams();
}

s32 DecoderRawCursor::DecodeRef( void* &outputBuffer, s32 nbBytes )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderRawCursor::DecodeRef", vox::VoxThread::GetCurThreadId());

	s32 size;
	if(m_pStreamCursor->AllowBufferReference())
	{
		size = m_pStreamCursor->ReadRef( (u8*&)outputBuffer, nbBytes);

		if(m_loop && m_pStreamCursor->EndOfStream())
		{
			m_pStreamCursor->Seek(0);
		}
	}
	else
	{
		size = Decode(outputBuffer, nbBytes);
	}

	// If no data is gotten, put decoder in error
	if(size == 0)
		m_isDecoderInError = true;

	return size;
}

s32 DecoderRawCursor::Decode( void* outputBuffer, s32 nbBytes )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderRawCursor::Decode", vox::VoxThread::GetCurThreadId());
	s32 nbBytesRemaining = nbBytes;	// Nb of bytes that still need to be read to fullfill the 'nbBytes' asked.
	s32 nbBytesRead;				// Nb of bytes read in the current loop pass.
	s32 totalBytesRead = 0;			// Total nb of bytes read since function call.
		
	while(totalBytesRead < nbBytes)
	{
		nbBytesRead = m_pStreamCursor->Read(((u8*) outputBuffer) + totalBytesRead, nbBytesRemaining);
		
		if(nbBytesRead > 0)
		{
			nbBytesRemaining -= nbBytesRead;
			totalBytesRead += nbBytesRead;
			if(m_loop)
			{
				// If end of stream is encountered, rewind streamCursor
				if(m_pStreamCursor->EndOfStream())
				{
					if(m_pStreamCursor->Seek(0)) 
					{
						break;	// Seek has failed if return is non-zero.
					}	
				}
			}
		}
		else // Could not read bytes.
		{
			break;
		}
	}

	return totalBytesRead;
}

s32 DecoderRawCursor::Seek(u32 sampleNum )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderRawCursor::Seek", vox::VoxThread::GetCurThreadId());
	if(sampleNum > m_trackParams.numSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}

	m_pStreamCursor->Seek(sampleNum * (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3)));
	return 0;
}

bool DecoderRawCursor::HasData()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderRawCursor::HasData", vox::VoxThread::GetCurThreadId());
	if(m_isDecoderInError)
		return false;

	if(m_loop && m_pStreamCursor->EndOfStream())
	{
		Seek(0);
	}

	return !m_pStreamCursor->EndOfStream();
}

} //namespace vox


