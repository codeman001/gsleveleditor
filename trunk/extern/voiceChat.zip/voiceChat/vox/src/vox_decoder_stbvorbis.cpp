
#include "StdAfx.h"
#include "vox_decoder_stbvorbis.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox_profiler.h"

vox::s32 fgetc(vox::StreamCursorInterface* pStream)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "fgetc", vox::VoxThread::GetCurThreadId());
	if(pStream)
	{
		vox::u8 c;
		pStream->Read(&c, 1);
		return c;
	}
	return -1;
}

size_t fread(void* buf, size_t element_size, size_t count, vox::StreamCursorInterface* pStream)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "fread", vox::VoxThread::GetCurThreadId());
	if(pStream)
	{
		return pStream->Read((vox::u8*)buf, element_size*count) / element_size;
	}
	return 0;
}

long ftell(vox::StreamCursorInterface* pStream)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "ftell", vox::VoxThread::GetCurThreadId());
	if(pStream)
	{
		return (vox::s32)pStream->Tell();
	}
	return -1;
}

vox::s32 fseek(vox::StreamCursorInterface*pStream, vox::s32 pos, vox::s32 origin = vox::ORIGIN_START)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "fseek", vox::VoxThread::GetCurThreadId());
	if(pStream)
	{
		pStream->Seek(pos,origin);
		return 0;
	}
	return -1;
}

vox::s32 fclose(vox::StreamCursorInterface*)
{
	VOX_ASSERT_MSG(0, "Must not use this method");
	return 0;
}

//vox::StreamCursorInterface* fopen(const c8*, const c8*)
//{
//	VOX_ASSERT_MSG(0, "Must not use this method");
//	return 0;
//}

namespace vox
{

DecoderInterface* DecoderStbVorbisFactory(void* params)
{
	return VOX_NEW DecoderStbVorbis(); 
}

DecoderStbVorbis::~DecoderStbVorbis()
{
	if(m_pVorbisFile)
	{
		stb_vorbis_close(m_pVorbisFile);
	}
}
///

DecoderCursorInterface* DecoderStbVorbis::CreateNewCursor( StreamCursorInterface* pStreamCursor )
{
	return VOX_NEW DecoderStbVorbisCursor(this,pStreamCursor);
}

void DecoderStbVorbis::DestroyCursor(DecoderCursorInterface* pDecoderCursor)
{
	VOX_DELETE ((DecoderStbVorbisCursor*)pDecoderCursor);
}

///

DecoderStbVorbisCursor::DecoderStbVorbisCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor)
: DecoderCursorInterface( pDecoder, pStreamCursor )
,m_pVorbisFile(0)
,m_totalSampleDecoded(0)
,m_isDecoderInError(false)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderStbVorbisCursor::DecoderStbVorbisCursor", vox::VoxThread::GetCurThreadId());
	m_trackParams.numSamples = 0;

#if VOX_USE_STBVORBIS_INTERNAL_BUFFER
	m_internalBuffer.alloc_buffer = (c8*)VOX_ALLOC(sizeof(c8) * (VOX_STBVORBIS_INTERNAL_BUFFER_SIZE));
	m_internalBuffer.alloc_buffer_length_in_bytes = VOX_STBVORBIS_INTERNAL_BUFFER_SIZE;
#endif

	s32 error;
#if VOX_ALLOW_STBVORBIS_SHARE_COMMON_DATA
	m_pVorbisFile = (stb_vorbis*)VOX_ALLOC(get_stb_vorbis_struct_size());
	stb_vorbis* f = ((DecoderStbVorbis*)pDecoder)->GetVorbisFile();
	if(!f)
	{
		f = stb_vorbis_open_file(pStreamCursor, 0, &error, 0);
		if(f)
		{
			((DecoderStbVorbis*)pDecoder)->SetVorbisFile(f);
			((DecoderStbVorbis*)pDecoder)->SetStreamOffset(stb_vorbis_get_stream_offset(f));
		}
	}

	if(f && m_pVorbisFile)
	{
		stb_vorbis_copy(m_pVorbisFile, f);
		pStreamCursor->Seek(((DecoderStbVorbis*)pDecoder)->GetStreamOffset());
		stb_vorbis_set_stream(m_pVorbisFile, pStreamCursor);
		f32 **pFloat, **pFloat2;
		for (s32 i=0; i < stb_vorbis_get_channel(m_pVorbisFile); ++i)
		{
			pFloat = stb_vorbis_get_previous_window(m_pVorbisFile, i);
			pFloat2 = stb_vorbis_get_previous_window(f, i);
			if(pFloat && pFloat2)
			{
				*pFloat = (f32 *) VoxAlloc(sizeof(f32) * stb_vorbis_get_blocksize_1(m_pVorbisFile)/2, __FILE__, __FUNCTION__, __LINE__);
				memcpy(*pFloat, *pFloat2, sizeof(f32) * stb_vorbis_get_blocksize_1(m_pVorbisFile)/2);
			}
			pFloat = stb_vorbis_get_buffer(m_pVorbisFile, i);
			pFloat2 = stb_vorbis_get_buffer(f, i);
			if(pFloat && pFloat2)
			{
				*pFloat = (f32 *) VoxAlloc(sizeof(f32) * stb_vorbis_get_blocksize_1(m_pVorbisFile), __FILE__, __FUNCTION__, __LINE__);
				memcpy(*pFloat, *pFloat2, sizeof(f32) * stb_vorbis_get_blocksize_1(m_pVorbisFile));
			}
		}
		stb_vorbis_info oggInfo = stb_vorbis_get_info(m_pVorbisFile);
		m_trackParams.bitsPerSample = 16;
		m_trackParams.numChannels = oggInfo.channels;
		m_trackParams.samplingRate = oggInfo.sample_rate;
		m_trackParams.numSamples = stb_vorbis_stream_length_in_samples(m_pVorbisFile);
	}
	else
	{
		VOX_WARNING_LEVEL_3("Could not open vorbis stream, error %d", error);
		m_trackParams.Reset();
	}
#else
#if VOX_USE_STBVORBIS_INTERNAL_BUFFER
	if(m_internalBuffer.alloc_buffer)
		m_pVorbisFile = stb_vorbis_open_file(pStreamCursor, 0, &error, m_internalBuffer.alloc_buffer ? &m_internalBuffer : 0);
#else
	m_pVorbisFile = stb_vorbis_open_file(pStreamCursor, 0, &error, 0);
#endif

	if(m_pVorbisFile)
	{
		stb_vorbis_info oggInfo = stb_vorbis_get_info(m_pVorbisFile);
#ifdef _PS3
		m_trackParams.bitsPerSample = 32;
#else
		m_trackParams.bitsPerSample = 16;
#endif
		m_trackParams.numChannels = oggInfo.channels;
		m_trackParams.samplingRate = oggInfo.sample_rate;
		m_trackParams.numSamples = stb_vorbis_stream_length_in_samples(m_pVorbisFile);
	}
	else
	{
		VOX_WARNING_LEVEL_3("Could not open vorbis stream, error %d", error);
		m_trackParams.Reset();
	}
#endif
}

DecoderStbVorbisCursor::~DecoderStbVorbisCursor()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderStbVorbisCursor::DecoderStbVorbisCursor", vox::VoxThread::GetCurThreadId());
	if(m_pVorbisFile)
	{
#if VOX_ALLOW_STBVORBIS_SHARE_COMMON_DATA
		f32** pFloat;
		for (s32 i=0; i < stb_vorbis_get_channel(m_pVorbisFile); ++i)
		{
			pFloat = stb_vorbis_get_previous_window(m_pVorbisFile, i);
			VoxFree((void*)*pFloat);
			pFloat = stb_vorbis_get_buffer(m_pVorbisFile, i);
			VoxFree((void*)*pFloat);
		}
		VoxFree(m_pVorbisFile);
#else
		stb_vorbis_close(m_pVorbisFile);
#endif
	}
#if VOX_USE_STBVORBIS_INTERNAL_BUFFER
	if(m_internalBuffer.alloc_buffer)
	{
		VOX_FREE(m_internalBuffer.alloc_buffer);
	}
#endif
}

s32 DecoderStbVorbisCursor::Decode( void* outputBuffer, s32 nbBytes )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderStbVorbisCursor::DecoderStbVorbisCursor", vox::VoxThread::GetCurThreadId());
	s32 nbSamples = 0;
	if(m_pVorbisFile)
	{
		if(m_trackParams.bitsPerSample == 32)
			nbSamples = stb_vorbis_get_samples_float_interleaved(m_pVorbisFile, m_trackParams.numChannels, (f32*) outputBuffer, nbBytes / sizeof(f32));
		else
			nbSamples = stb_vorbis_get_samples_short_interleaved(m_pVorbisFile, m_trackParams.numChannels, (s16*) outputBuffer, nbBytes / sizeof(s16));

		m_totalSampleDecoded += nbSamples;
		if((nbSamples == 0 || (m_totalSampleDecoded == m_trackParams.numSamples))&& m_loop)//EOF
		{
			Seek(0);	
		}
		else if(nbSamples == 0)
		{
			m_isDecoderInError = true;
		}
	}
	return nbSamples*( m_trackParams.numChannels * (m_trackParams.bitsPerSample>>3));
}

s32 DecoderStbVorbisCursor::Seek( u32 sampleNum )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderStbVorbisCursor::DecoderStbVorbisCursor", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(sampleNum == 0, "Vorbis decoder can only seek to 0");
	if(sampleNum > m_trackParams.numSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}

	if(sampleNum == 0 && m_pVorbisFile)
	{
		stb_vorbis_seek_start(m_pVorbisFile);
		m_totalSampleDecoded = 0;
		return 0;
	}
	return -1;
}

bool DecoderStbVorbisCursor::HasData()
{
	if(m_pStreamCursor && !m_isDecoderInError)
	{
		if(!(m_totalSampleDecoded < m_trackParams.numSamples) && m_loop)
			Seek(0);
		return m_totalSampleDecoded < m_trackParams.numSamples;
	}
	return false;
}

}


