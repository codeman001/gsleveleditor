
#include "StdAfx.h"
#include "vox_detect_neon.h"

#if ((VOX_NEON_MIXER)||(VOX_NEON_DECODER_MS)||(VOX_NEON_DECODER_IMA))
#ifdef ANDROID
#include <cpu-features.h>
#endif
#endif

namespace vox {

#if ((VOX_NEON_MIXER)||(VOX_NEON_DECODER_MS)||(VOX_NEON_DECODER_IMA))

bool DetectNeonInstructionsPresent()
{
#ifdef ANDROID
    if (android_getCpuFamily() != ANDROID_CPU_FAMILY_ARM)
		return false;

    uint64_t features = android_getCpuFeatures();
    if ((features & ANDROID_CPU_ARM_FEATURE_NEON) == 0)
		return false;
    
	return true;
	
#endif // ANDROID


// other platforms are PSP2 and 3DS which support neon in armv7
// Iphone is done by disabling VOX_NEON_MIXER on armv6
	return true;

}
#else // ((VOX_NEON_MIXER)||(VOX_NEON_DECODER_MS)||(VOX_NEON_DECODER_IMA))
bool DetectNeonInstructionsPresent()
{
	return false;
}

#endif // ((VOX_NEON_MIXER)||(VOX_NEON_DECODER_MS)||(VOX_NEON_DECODER_IMA))

bool neonInstructionsPresent()
{
	static bool detectionDone = false;
	static bool neonOk = false;

	if(detectionDone)
	{
		return neonOk;
	}
	else
	{
		neonOk = DetectNeonInstructionsPresent();
		detectionDone = true;
		return neonOk;
	}
}

} // Namespace vox


