
#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_ANDROID && VOX_ANDROID_DRIVER_PLATFORM

#include "vox_driver_android.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox.h"
#include "vox_profiler.h"

#include <unistd.h>

#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
JavaVM* vox::DriverAndroid::s_javaVM = NULL;
#endif

vox::s32 vox::DriverAndroid::s_androidAPILevel = 3;

extern "C" void VoxSetJavaVM(JavaVM* javaVM)
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	VOX_WARNING_LEVEL_2("Got javaVM : %x", javaVM);
	vox::DriverAndroid::s_javaVM = javaVM;
#endif
}

// Extern function to setup the threshold ratio
// threshold needs to be from [0.0 .. 1.0]
// 0.0 => no latency reduction
// 1.0 => full latency reduction
// Using full latency reduction may cause audio artifact
extern "C" void VoxSetDataThreshold(vox::f64 threshold)
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	VOX_WARNING_LEVEL_2("Got threshold : %llf", threshold);
	if(threshold < 0.0)
		threshold = 0.0;
	else if(threshold > 1.0)
		threshold = 1.0;
	vox::DriverAndroid::m_dataThresholdRatio = threshold;
#endif
}

extern "C" void VoxSetAndroidAPILevel(vox::s32 level)
{
	vox::DriverAndroid::s_androidAPILevel = level;
}

extern vox::f64 _GetTime();

namespace vox 
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	//AudioTrack
	#define STREAM_MUSIC 3
	#define CHANNEL_CONFIGURATION_STEREO 12
	#define ENCODING_PCM_16BIT 2
	#define MODE_STREAM 1

	#define AT_PLAYSTATE_STOPPED 1
	#define AT_PLAYSTATE_PLAYING 3
	#define AT_PLAYSTATE_PAUSED  2

	jclass DriverAndroid::cAudioTrack = NULL;
	jmethodID DriverAndroid::mAudioTrack = NULL;
	jmethodID DriverAndroid::mGetMinBufferSize = NULL;
	jmethodID DriverAndroid::mPlay = NULL;
	jmethodID DriverAndroid::mPause = NULL;
	jmethodID DriverAndroid::mStop = NULL;
	jmethodID DriverAndroid::mRelease = NULL;
	jmethodID DriverAndroid::mWrite = NULL;
	jmethodID DriverAndroid::mGetPlayState = NULL;
	jmethodID DriverAndroid::mGetNativeOutputSampleRate = NULL;

	int DriverAndroid::m_externalSampleRate = 44100;
	f64 DriverAndroid::m_updateTime = 0.0;
	f64 DriverAndroid::m_dataDuration = 0.0;	
	f64 DriverAndroid::m_dataThreshold = 0.0;
	f64 DriverAndroid::m_updateStartTime = 0.0;
	f64 DriverAndroid::m_dataThresholdRatio = 1.0;
#endif//#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)

#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
//OpenSL ES
 #define SLES_CHECKRESULT(X) if(X != SL_RESULT_SUCCESS){VOX_WARNING_LEVEL_1("%s:%s:%d : Error in driver : %d", __FILE__, __FUNCTION__, __LINE__, (u32)X);}
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)

bool DriverAndroid::m_running = false;


DriverInterface* CreateDriver()
{
	return VOX_NEW DriverAndroid();
}



	
//*** DriverAndroid ***//
	
DriverAndroid::DriverAndroid()
{
	//m_outBuffer = 0;
	m_audioAPI = AA_Invalid;
	Init(0);
}

DriverAndroid::~DriverAndroid()
{
	Shutdown();
}

void DriverAndroid::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverAndroid::Init", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);

	DriverCallbackInterface::Init(param);
		
	// Do the actual initialization of the sound API and allocate work buffer (m_outBuffer)

	SetDefaultParameter();

#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	if(s_androidAPILevel < 9)
	{
		_InitAT(param);
	}
	else
	{
		_InitOSL(param);
	}
#else
	_InitAT(param);
#endif

	SetDefaultParameter();

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


void DriverAndroid::_InitAT(void* param)
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	//If using a thread for update set it up here
	// Start thread or register callback
	f32 internalSampleRate = VOX_ANDROID_AUDIOTRACK_DRIVER_PREFERRED_RATE;
	DriverCallbackSourceInterface::SetDriverSampleRate(internalSampleRate);
	m_resamplingBuffer = 0;

	if(s_javaVM == NULL)
	{
		VOX_WARNING_LEVEL_1("%s", "Cannot initialize AutioTrack Driver without JavaVM");
		return;
	}

	JNIEnv* env = NULL;
	(s_javaVM)->GetEnv((void**)&env, JNI_VERSION_1_2);//GetEnv();

    if (!cAudioTrack)
    {
        /* Cache AudioTrack class and it's method id's
         * And do this only once!
         */

        cAudioTrack = (env)->FindClass("android/media/AudioTrack");
        if (!cAudioTrack)
        {
			VOX_WARNING_LEVEL_1("%s:%d : Could not get class reference", __FUNCTION__, __LINE__);
            return;
        }

        cAudioTrack = (jclass)(env)->NewGlobalRef(cAudioTrack);

        mAudioTrack = (env)->GetMethodID(cAudioTrack, "<init>", "(IIIIII)V");
        mGetMinBufferSize = (env)->GetStaticMethodID(cAudioTrack, "getMinBufferSize", "(III)I");
        mPlay = (env)->GetMethodID(cAudioTrack, "play", "()V");
		mPause = (env)->GetMethodID(cAudioTrack, "pause", "()V");
        mStop = (env)->GetMethodID(cAudioTrack, "stop", "()V");
        mRelease = (env)->GetMethodID(cAudioTrack, "release", "()V");
        mWrite = (env)->GetMethodID(cAudioTrack, "write", "([BII)I");
		mGetPlayState = (env)->GetMethodID(cAudioTrack, "getPlayState", "()I");
		mGetNativeOutputSampleRate = (env)->GetStaticMethodID(cAudioTrack, "getNativeOutputSampleRate", "(I)I");
    }
	m_externalSampleRate = (env)->CallStaticIntMethod(cAudioTrack, mGetNativeOutputSampleRate, STREAM_MUSIC);

	s32 bufferSizeInBytes = (env)->CallStaticIntMethod(cAudioTrack, 
    mGetMinBufferSize, m_externalSampleRate, CHANNEL_CONFIGURATION_STEREO, ENCODING_PCM_16BIT);

    m_samplePerBufferAT = bufferSizeInBytes / 4;//aluFrameSizeFromFormat(device->Format);


	m_samplePerUpdateAT = VOX_ANDROID_AUDIOTRACK_DRIVER_BUFFER_LENGTH * m_externalSampleRate;
	if(m_samplePerUpdateAT > m_samplePerBufferAT)
		m_samplePerUpdateAT = m_samplePerBufferAT; //cannot update more sample than buffer contains

	m_updateTime = (f64)((f64)m_samplePerUpdateAT / (f64)m_externalSampleRate);
	DriverCallbackSourceInterface::SetDriverCallbackPeriod(m_updateTime);

	f64 mnBufLen = (f64)((f64)m_samplePerBufferAT / (f64)m_externalSampleRate);
	m_dataThreshold = -(m_dataThresholdRatio * mnBufLen);

	m_dataDuration = 0.0;//-(f64)((f64)m_samplePerBufferAT / (f64)VOX_ANDROID_AUDIOTRACK_DRIVER_PREFERRED_RATE);

	m_resamplingFactor = (int) (16384.0 * internalSampleRate / ((double)m_externalSampleRate) + 0.5);
	s32 maxBufferSizeResampled = ((-1 + m_samplePerBufferAT * m_resamplingFactor) >> 14) + 2;
	maxBufferSizeResampled += 8;
	m_resamplingBuffer = (short *)malloc(maxBufferSizeResampled * 4);
	memset(m_resamplingBuffer, 0, maxBufferSizeResampled * 4);
	m_resamplingOffset = (8+1) * 16384;

	VOX_WARNING_LEVEL_2("Min buffer size for AudioTrack : %d samples", m_samplePerBufferAT);
	VOX_WARNING_LEVEL_2("Min buffer length for AudioTrack : %llf seconds", mnBufLen);
	VOX_WARNING_LEVEL_2("Update buffer size for AudioTrack : %d samples", m_samplePerUpdateAT);
	VOX_WARNING_LEVEL_2("Update buffer length for AudioTrack : %llf seconds", m_updateTime);
	VOX_WARNING_LEVEL_2("Update threshold for AudioTrack : %llf seconds", m_dataThreshold);

	m_audioAPI = AA_AudioTrack;
	m_running = true;
	m_suspendedAT = false;
	s32 result = pthread_create(&m_internThread, 0, UpdateThreadedAT, this);
	result = pthread_mutex_init(&m_suspendLock, 0);
	result = pthread_cond_init(&m_suspendCondition, 0);

#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
}

void DriverAndroid::_InitOSL(void* param)
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_ANDROID_OPENSLES_DRIVER_PREFERRED_RATE);
	DriverCallbackSourceInterface::SetDriverCallbackPeriod(VOX_ANDROID_OPENSLES_DRIVER_BUFFER_LENGTH);

	m_outputBufferOSL = 0;
	m_bufferSizeOSL = (float)VOX_ANDROID_OPENSLES_DRIVER_PREFERRED_RATE * 4.0f * VOX_ANDROID_OPENSLES_DRIVER_BUFFER_LENGTH;
	m_bufferSizeOSL &= ~0x3; //must be a multiple of 4 bytes

#if VOX_MICROPHONE_INPUT
	m_recorder.m_microphoneReceptor = 0;
	m_recorder.m_outputBufferOSL = 0;
	m_recorder.m_bufferSizeOSL =
		(int)(VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_LENGTH
		* VOX_ANDROID_OPENSLES_DRIVER_RECORDING_PREFERRED_RATE)
		* VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS * 2;

	m_recorder.m_nextBuffer = -1;
	m_recorder.m_active = false;
#endif

    // create engine
    SLresult result = slCreateEngine(&m_engineObject, 0, NULL, 0, NULL, NULL);
    SLuint32 state;
    SLES_CHECKRESULT(result);

    if(m_engineObject != NULL)
    {
        // realize the engine
        result = (*m_engineObject)->Realize(m_engineObject, SL_BOOLEAN_FALSE);
        SLES_CHECKRESULT(result);

        // get the engine interface, which is needed in order to create other objects
        result = (*m_engineObject)->GetInterface(m_engineObject, SL_IID_ENGINE, &m_engine);
        SLES_CHECKRESULT(result);

        result = (*m_engineObject)->GetState(m_engineObject, &state);
        SLES_CHECKRESULT(result);
        VOX_WARNING_LEVEL_5("Engine object state: %d", state);

        if (m_engine != NULL)
        {
            // create output mix, with environmental reverb specified as a non-required interface
            //const SLInterfaceID ids[1] = {SL_IID_ENVIRONMENTALREVERB};
            //const SLboolean req[1] = {SL_BOOLEAN_FALSE};
            //result = (*m_engine)->CreateOutputMix(m_engine, &m_output, 1, ids, req);
			result = (*m_engine)->CreateOutputMix(m_engine, &m_output, 0, 0, 0);
            SLES_CHECKRESULT(result);

            if (m_output != NULL)
            {
                // realize the output mix
                result = (*m_output)->Realize(m_output, SL_BOOLEAN_FALSE);
                SLES_CHECKRESULT(result);

                result = (*m_output)->GetState(m_output, &state);
                SLES_CHECKRESULT(result);
                VOX_WARNING_LEVEL_5("Engine output state: %d", state);
            }
            else
			{
                VOX_WARNING_LEVEL_1("Failed to create output mix",0);
				return;
			}
        }
        else
		{
            VOX_WARNING_LEVEL_1("Failed to get engine interface",0);
			return;
		}
    }
    else
	{
        VOX_WARNING_LEVEL_1("Failed to create object engine",0);
		return;
	}

	//Create audio player
    // configure audio source
    SLDataLocator_BufferQueue loc_bufq = {SL_DATALOCATOR_BUFFERQUEUE, VOX_ANDROID_OPENSLES_DRIVER_BUFFER_NUM};
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 2, VOX_ANDROID_OPENSLES_DRIVER_PREFERRED_RATE * 1000, SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT, SL_BYTEORDER_LITTLEENDIAN};
    //memcpy(&format_pcm + 1, tp, sizeof(TrackParams));
    SLDataSource audioSrc = {&loc_bufq, &format_pcm};
    VOX_WARNING_LEVEL_2("%s: SLDataFormat_PCM: %d %d %d %d", __FUNCTION__, format_pcm.numChannels, format_pcm.samplesPerSec, format_pcm.bitsPerSample, format_pcm.containerSize);

    // configure audio sink
    SLDataLocator_OutputMix loc_outmix = {SL_DATALOCATOR_OUTPUTMIX, m_output};
    SLDataSink audioSnk = {&loc_outmix, NULL};

    // create audio player
    const SLInterfaceID ids[3] = {SL_IID_BUFFERQUEUE};
    const SLboolean req[3] = {SL_BOOLEAN_TRUE};
    result = (*m_engine)->CreateAudioPlayer(m_engine, &m_playerObject, &audioSrc, &audioSnk, 1, ids, req);
    SLES_CHECKRESULT(result);

    result = (*m_playerObject)->Realize(m_playerObject, SL_BOOLEAN_FALSE);
    SLES_CHECKRESULT(result);

    result = (*m_playerObject)->GetInterface(m_playerObject, SL_IID_PLAY, &m_play);
    SLES_CHECKRESULT(result);

    result = (*m_playerObject)->GetInterface(m_playerObject, SL_IID_BUFFERQUEUE, &m_bufferQueue);
    SLES_CHECKRESULT(result);

	//register callback
	result = (*m_bufferQueue)->RegisterCallback(m_bufferQueue, CallbackOSL, this);
	SLES_CHECKRESULT(result);

	DoCallbackOSL();//Fill buffer queue;

	//Start player
	result = (*m_play)->SetPlayState(m_play, SL_PLAYSTATE_PLAYING);
    SLES_CHECKRESULT(result);

    //result = (*m_playerObject)->GetInterface(m_object, SL_IID_VOLUME, &m_volume);
    //SLES_CHECKRESULT(result);

	m_audioAPI = AA_OpenSLES;
	m_audioUnitActive = true;

#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
}

#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
#if VOX_MICROPHONE_INPUT
void DriverAndroid::_InitRecordOSL()
{
	SLresult result;

	/* Setup the data source structure */
	SLDataSource micSource;
	SLDataLocator_IODevice micLocator;
	micLocator.locatorType = SL_DATALOCATOR_IODEVICE;
	micLocator.deviceType = SL_IODEVICE_AUDIOINPUT;
	micLocator.deviceID = SL_DEFAULTDEVICEID_AUDIOINPUT;
	micLocator.device = NULL;
	micSource.pLocator = (void *)&micLocator;
	micSource.pFormat = NULL;

	/* Setup the data sink structure */
	SLDataSink micSink;
	SLDataLocator_BufferQueue micQueue;
    SLDataFormat_PCM format_pcm = {
		SL_DATAFORMAT_PCM,
		VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS,
		VOX_ANDROID_OPENSLES_DRIVER_RECORDING_PREFERRED_RATE * 1000,
		SL_PCMSAMPLEFORMAT_FIXED_16,
		SL_PCMSAMPLEFORMAT_FIXED_16,
        VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNEL_MASK,
		SL_BYTEORDER_LITTLEENDIAN };
	micQueue.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
	micQueue.numBuffers = VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_NUM;
	micSink.pLocator = (void *)&micQueue;
	micSink.pFormat = (void *)&format_pcm;

	const SLInterfaceID ids[3] = {SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
	const SLboolean req[3] = {SL_BOOLEAN_TRUE};
	result = (*m_engine)->CreateAudioRecorder(m_engine, &m_recorder.m_object, &micSource, &micSink, 1, ids, req); 
	SLES_CHECKRESULT(result);
	if(!m_recorder.m_object)
		return;

	result = (*m_recorder.m_object)->Realize(m_recorder.m_object, SL_BOOLEAN_FALSE); 
	SLES_CHECKRESULT(result);

	SLRecordItf recordItf;
	result = (*m_recorder.m_object)->GetInterface(m_recorder.m_object, SL_IID_RECORD, (void*)&m_recorder.m_record); 
	SLES_CHECKRESULT(result);
	if(!m_recorder.m_record)
		return;

	result = (*m_recorder.m_object)->GetInterface(m_recorder.m_object, SL_IID_ANDROIDSIMPLEBUFFERQUEUE, &m_recorder.m_bufferQueue);
	SLES_CHECKRESULT(result);
	if(!m_recorder.m_bufferQueue)
		return;

	//register callback
	result = (*m_recorder.m_bufferQueue)->RegisterCallback(m_recorder.m_bufferQueue, RecordCallbackOSL, this);
	SLES_CHECKRESULT(result);

	DoRecordCallbackOSL();//Enqueue buffers

	result = (*m_recorder.m_record)->SetRecordState(m_recorder.m_record,SL_RECORDSTATE_RECORDING);
	SLES_CHECKRESULT(result);

	m_recorder.m_active = true;

}
#endif // VOX_MICROPHONE_INPUT
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)

void DriverAndroid::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverAndroid::Shutdown", vox::VoxThread::GetCurThreadId());
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	if(m_audioAPI == AA_AudioTrack)
	{
		_ShutdownAT();
	}
	else if(m_audioAPI == AA_OpenSLES)
	{
		_ShutdownOSL();
	}
}

void DriverAndroid::_ShutdownAT()
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	m_running = false;
	pthread_join(m_internThread, 0);
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
}

void DriverAndroid::_ShutdownOSL()
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	ScopeMutex _sm(&m_mutex);
	m_audioUnitActive = false;

	//Stop player
	SLresult result = (*m_play)->SetPlayState(m_play, SL_PLAYSTATE_STOPPED);
    SLES_CHECKRESULT(result);

#if VOX_MICROPHONE_INPUT
	if(m_recorder.m_active)
		_ShutdownRecordOSL();
#endif

	//Destroy player
	if (m_playerObject != NULL)
	{
		(*m_playerObject)->Destroy(m_playerObject);
		m_playerObject = NULL;
		m_play = NULL;
		m_bufferQueue = NULL;
	}

    // destroy output mix object, and invalidate all associated interfaces
    if (m_output != NULL) {
        (*m_output)->Destroy(m_output);
        m_output = NULL;
        m_output = NULL;
    }

    // destroy engine object, and invalidate all associated interfaces
    if (m_engineObject != NULL) {
        (*m_engineObject)->Destroy(m_engineObject);
        m_engineObject = NULL;
        m_engine = NULL;
    }
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
}

#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
#if VOX_MICROPHONE_INPUT
void DriverAndroid::_ShutdownRecordOSL()
{
	if (m_recorder.m_object != NULL)
	{
		(*m_recorder.m_object)->Destroy(m_recorder.m_object);
		m_recorder.m_object = NULL;
		m_recorder.m_record = NULL;
		m_recorder.m_bufferQueue = NULL;
	}
	m_recorder.m_active = false;

}
#endif // VOX_MICROPHONE_INPUT
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)

void DriverAndroid::Suspend()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverAndroid::Suspend", vox::VoxThread::GetCurThreadId());
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	if(m_audioAPI == AA_AudioTrack)
	{
		_SuspendAT();
	}
	else if(m_audioAPI == AA_OpenSLES)
	{
		_SuspendOSL();
	}	
}

void DriverAndroid::_SuspendAT()
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	ScopeMutex _sm(&m_mutex);
	if(m_audioUnitActive)
	{
		JNIEnv* env = NULL;
		(s_javaVM)->GetEnv((void**)&env, JNI_VERSION_1_2);//GetEnv();
		(env)->CallNonvirtualVoidMethod(m_audioTrack, cAudioTrack, mPause);
		//(env)->CallNonvirtualVoidMethod(m_audioTrack, cAudioTrack, mStop);
		m_suspendedAT = true;
		m_dataDuration = m_dataDuration - (_GetTime() - m_updateStartTime);
	}
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
}

void DriverAndroid::_SuspendOSL()
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	ScopeMutex _sm(&m_mutex);
	if(m_audioUnitActive)
	{
		SLresult result = (*m_play)->SetPlayState(m_play, SL_PLAYSTATE_PAUSED);
		SLES_CHECKRESULT(result);
	}
#endif
}

void DriverAndroid::Resume()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverAndroid::Resume", vox::VoxThread::GetCurThreadId());
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	if(m_audioAPI == AA_AudioTrack)
	{
		_ResumeAT();
	}
	else if(m_audioAPI == AA_OpenSLES)
	{
		_ResumeOSL();
	}	
}

void DriverAndroid::_ResumeAT()
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	ScopeMutex _sm(&m_mutex);
	if(m_audioUnitActive)
	{
		JNIEnv* env = NULL;
		(s_javaVM)->GetEnv((void**)&env, JNI_VERSION_1_2);//GetEnv();
		(env)->CallNonvirtualVoidMethod(m_audioTrack, cAudioTrack, mPlay);
		
		pthread_mutex_lock(&m_suspendLock);
		m_suspendedAT = false;
		pthread_cond_signal(&m_suspendCondition);
		pthread_mutex_unlock(&m_suspendLock);

		m_updateStartTime = _GetTime();
		int atState = (env)->CallNonvirtualIntMethod(m_audioTrack, cAudioTrack, mGetPlayState);		
		VOX_WARNING_LEVEL_4("AudioTrack state after resume : %d", atState);
		if(atState != AT_PLAYSTATE_PLAYING)
		{
			VOX_WARNING_LEVEL_1("%s", "Audio Track failed to resume");
	}
	}
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
}

void DriverAndroid::_ResumeOSL()
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	ScopeMutex _sm(&m_mutex);
	if(m_audioUnitActive)
	{
		SLresult result = (*m_play)->SetPlayState(m_play, SL_PLAYSTATE_PLAYING);
		SLES_CHECKRESULT(result);
	}
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
}


void DriverAndroid::PrintDebug()
{
}

#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
void DriverAndroid::DoCallbackAT(jarray &buffer)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverAndroid::DoCallbackAT", vox::VoxThread::GetCurThreadId());
	// Send data to API

	static bool isFirst = true;

	JNIEnv* env = NULL;
	(s_javaVM)->GetEnv((void**)&env, JNI_VERSION_1_2);//GetEnv();

    void* pBuffer = (env)->GetPrimitiveArrayCritical(buffer, NULL);

    if (pBuffer)
    {
		s32 sampleToGet = m_samplePerUpdateAT;
		m_mutex.Lock();
		if (m_resamplingFactor != 16384)
		{
			int samplesToGenerate = ((m_resamplingOffset + (sampleToGet)*m_resamplingFactor)>>14) - 8 + 1;
			if(samplesToGenerate > 0)
				_FillBuffer(m_resamplingBuffer+8*2, samplesToGenerate);

			// for(int z=0; z < (samplesToGenerate*2); z++)
			//	m_resamplingBuffer[z] = 0;

			// m_resamplingBuffer[17] = 12000;
			// m_resamplingBuffer[19] = 24000;

			short *dest=static_cast<vox::s16*>(pBuffer);
			short *stop=dest + sampleToGet*2;
			for(int ind = 0; dest < stop; ind++)
			{
				int ip1, ip2, ip3, ip4;
				int sum;
				int sampleFrom = (m_resamplingOffset>>14)<<1;

				// Catmull-rom spline interpolation
				int interp  = m_resamplingOffset & 0x3fff;
				int interp2 = (interp  * interp) >> 14;
				int interp3 = (interp2 * interp) >> 14;
				int interpTan = interp2 - interp3;
				int interpRTan = interp - interp2 - interpTan;
				int interpBase = interpTan + interpTan + interp2;

				ip4 = m_resamplingBuffer[sampleFrom-8];
				ip3 = m_resamplingBuffer[sampleFrom-6];
				ip2 = m_resamplingBuffer[sampleFrom-4];
				ip1 = m_resamplingBuffer[sampleFrom-2];
				
				sum  = interpTan *(ip3 - ip1);
				sum += interpRTan*(ip2 - ip4);
				sum = sum>>1;
				sum += (ip3<<14) + ((ip2-ip3)*(interpBase));
				sum = sum >> 14;
				if ((u32) (sum + 32768) > 65535)
					*dest++ = (s16)(sum < 0 ? -32768 : 32767);
				else
					*dest++ = (s16)(sum);			

				ip4 = m_resamplingBuffer[sampleFrom-7];
				ip3 = m_resamplingBuffer[sampleFrom-5];
				ip2 = m_resamplingBuffer[sampleFrom-3];
				ip1 = m_resamplingBuffer[sampleFrom-1];
				
				sum  = interpTan *(ip3 - ip1);
				sum += interpRTan*(ip2 - ip4);
				sum = sum>>1;
				sum += (ip3<<14) + ((ip2-ip3)*(interpBase));
				sum = sum >> 14;
				if ((u32) (sum + 32768) > 65535)
					*dest++ = (s16)(sum < 0 ? -32768 : 32767);
				else
					*dest++ = (s16)(sum);

				m_resamplingOffset += m_resamplingFactor;
			}
			for(int i=0; i<16; i++)
				m_resamplingBuffer[i] = m_resamplingBuffer[i+samplesToGenerate*2];
			m_resamplingOffset -= samplesToGenerate<<14;
			
		}
		else
		{
			_FillBuffer(static_cast<vox::s16*>(pBuffer), sampleToGet);
		}
		m_mutex.Unlock();
        (env)->ReleasePrimitiveArrayCritical(buffer, pBuffer, 0);

        (env)->CallNonvirtualIntMethod(m_audioTrack, cAudioTrack, mWrite, buffer, 0, sampleToGet*4);
		m_dataDuration += m_updateTime;
    }
    else
    {
        VOX_WARNING_LEVEL_2("%s", "Failed to get pointer to array bytes");
    }

	if(isFirst)
	{
		m_updateStartTime = _GetTime();
		isFirst = false;
	}

	f64 dataDiff = m_dataDuration - (_GetTime() - m_updateStartTime);
	if(dataDiff > m_dataThreshold) //enough data for 2 update duration
	{
		usleep((u32)(m_updateTime * 1000000.0));
	}
}
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)

#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
void DriverAndroid::DoCallbackOSL()
{
	if(m_outputBufferOSL == 0)
	{
		if(m_bufferSizeOSL > 0)
			m_outputBufferOSL = (s16*)VOX_ALLOC(m_bufferSizeOSL);
	}

	if(m_outputBufferOSL == 0)
		return;

	SLBufferQueueState state;
    SLresult result = (*m_bufferQueue)->GetState(m_bufferQueue, &state);
    SLES_CHECKRESULT(result);

	for(int i = state.count; i < VOX_ANDROID_OPENSLES_DRIVER_BUFFER_NUM; i++)
	{
		_FillBuffer(m_outputBufferOSL, m_bufferSizeOSL/4);
		SLresult result = (*m_bufferQueue)->Enqueue(m_bufferQueue, m_outputBufferOSL, m_bufferSizeOSL);
		SLES_CHECKRESULT(result);
	}
}

void DriverAndroid::DoRecordCallbackOSL()
{
#if VOX_MICROPHONE_INPUT

	if(m_recorder.m_outputBufferOSL == 0)
	{
		if(m_recorder.m_bufferSizeOSL > 0)
			m_recorder.m_outputBufferOSL = (s16*)VOX_ALLOC(m_recorder.m_bufferSizeOSL * VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_NUM);
	}

	if(m_recorder.m_outputBufferOSL == 0)
		return;

	SLAndroidSimpleBufferQueueState state;
    SLresult result = (*m_recorder.m_bufferQueue)->GetState(m_recorder.m_bufferQueue, &state);
    SLES_CHECKRESULT(result);

	if(m_recorder.m_nextBuffer < 0)
	{
		m_recorder.m_nextBuffer = 0;
		for(int i = 0; i < VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_NUM; i++)
		{
			s16 *buffer = m_recorder.m_outputBufferOSL + m_recorder.m_bufferSizeOSL/2 * i;
			SLresult result = (*m_recorder.m_bufferQueue)->Enqueue(m_recorder.m_bufferQueue, buffer, m_recorder.m_bufferSizeOSL);
			SLES_CHECKRESULT(result);
		}
		return;
	}

	for(int i = state.count; i < VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_NUM; i++)
	{
		s16 *buffer = m_recorder.m_outputBufferOSL + m_recorder.m_bufferSizeOSL/2 * m_recorder.m_nextBuffer;

		m_recorder.m_mutex.Lock();
		if(m_recorder.m_microphoneReceptor)
			m_recorder.m_microphoneReceptor->GetData(buffer, m_recorder.m_bufferSizeOSL/2/VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS, VOX_ANDROID_OPENSLES_DRIVER_RECORDING_PREFERRED_RATE, VOX_ANDROID_OPENSLES_DRIVER_RECORDING_CHANNELS);
		m_recorder.m_mutex.Unlock();

		SLresult result = (*m_recorder.m_bufferQueue)->Enqueue(m_recorder.m_bufferQueue, buffer, m_recorder.m_bufferSizeOSL);
		SLES_CHECKRESULT(result);

		m_recorder.m_nextBuffer++;
		if(m_recorder.m_nextBuffer >= VOX_ANDROID_OPENSLES_DRIVER_RECORDING_BUFFER_NUM)
			m_recorder.m_nextBuffer = 0;
	}

#endif
}
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)

#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
void* DriverAndroid::UpdateThreadedAT(void* caller)
{
	//VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverAndroid::UpdateThreadedAT", vox::VoxThread::GetCurThreadId());
	if(!caller)
	{
		VOX_WARNING_LEVEL_1("%s", "AudioTrack driver could not initialize : No caller reference");
		return 0;
	}

	jarray buffer = NULL;
	JNIEnv* env = NULL;

	//mutex scope
	{
		ScopeMutex _sm(&(((DriverAndroid*)caller)->m_mutex));
		VOX_WARNING_LEVEL_5("%s : Init", __FUNCTION__);
		
		(s_javaVM)->AttachCurrentThread(&env, NULL);
		if(env == NULL)
		{
			VOX_WARNING_LEVEL_1("%s", "AudioTrack driver could not initialize : Could not attach thread to VM");
			return 0;
		}

		(env)->PushLocalFrame(2);

		((DriverAndroid*)caller)->m_audioTrack = (env)->NewObject(cAudioTrack, mAudioTrack,
			STREAM_MUSIC, m_externalSampleRate, CHANNEL_CONFIGURATION_STEREO, ENCODING_PCM_16BIT, /*2* */((DriverAndroid*)caller)->m_samplePerBufferAT*4, MODE_STREAM);

		if(((DriverAndroid*)caller)->m_audioTrack == NULL)
		{
			//error
			VOX_WARNING_LEVEL_1("%s", "AudioTrack driver could not initialize");
			(s_javaVM)->DetachCurrentThread();
			return 0;
		}

		((DriverAndroid*)caller)->m_audioTrack = (env)->NewGlobalRef(((DriverAndroid*)caller)->m_audioTrack);

		(env)->CallNonvirtualVoidMethod(((DriverAndroid*)caller)->m_audioTrack, cAudioTrack, mPlay);

		buffer = (env)->NewByteArray(((DriverAndroid*)caller)->m_samplePerBufferAT*4);

		if(buffer == NULL)
		{
			//ERROR
			VOX_WARNING_LEVEL_1("%s", "AudioTrack driver could not initialize");
			(s_javaVM)->DetachCurrentThread();
			return 0;
		}
		
		((DriverAndroid*)caller)->m_audioUnitActive = true;
	}

	VOX_WARNING_LEVEL_5("Audio track update duration : %f s", m_updateTime);

	m_updateStartTime = _GetTime();

	
    while (m_running)
    {
		if(((DriverAndroid*)caller)->m_suspendedAT)
		{
			pthread_mutex_lock(&(((DriverAndroid*)caller)->m_suspendLock));
			while(((DriverAndroid*)caller)->m_suspendedAT)
			{
				pthread_cond_wait(&(((DriverAndroid*)caller)->m_suspendCondition), &(((DriverAndroid*)caller)->m_suspendLock));
			}
			pthread_mutex_unlock(&(((DriverAndroid*)caller)->m_suspendLock));
			usleep(1); //should force a yield
		}
		/*if(((DriverAndroid*)caller)->m_suspendedAT)
		{
			
			usleep((s32)(m_updateTime * 1000000.0));
		}
		else*/
			((DriverAndroid*)caller)->DoCallbackAT(buffer);
    }
    
    
	//mutex scope
	{
		VOX_WARNING_LEVEL_5("%s : Shutdown", __FUNCTION__);
		((DriverAndroid*)caller)->m_audioUnitActive = false;
		ScopeMutex _sm(&(((DriverAndroid*)caller)->m_mutex));
		(env)->CallNonvirtualVoidMethod(((DriverAndroid*)caller)->m_audioTrack, cAudioTrack, mStop);
		(env)->CallNonvirtualVoidMethod(((DriverAndroid*)caller)->m_audioTrack, cAudioTrack, mRelease);
		
		(env)->DeleteGlobalRef(((DriverAndroid*)caller)->m_audioTrack);
		((DriverAndroid*)caller)->m_audioTrack = 0;
		(env)->PopLocalFrame(NULL);

		(s_javaVM)->DetachCurrentThread();	
	}

	return 0;
}
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)

#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
void DriverAndroid::CallbackOSL(SLBufferQueueItf bufferQueue, void *caller)
{
	if(caller)
	{
		ScopeMutex _sm(&(((DriverAndroid*)caller)->m_mutex));
		((DriverAndroid*)caller)->DoCallbackOSL();
	}
}

void DriverAndroid::RecordCallbackOSL(SLAndroidSimpleBufferQueueItf bufferQueue, void *caller)
{
#if VOX_MICROPHONE_INPUT
	if(caller)
	{
		ScopeMutex _sm(&(((DriverAndroid*)caller)->m_mutex));
		((DriverAndroid*)caller)->DoRecordCallbackOSL();
	}
#endif // VOX_MICROPHONE_INPUT
}

#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)

void DriverAndroid::Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverAndroid::Update", vox::VoxThread::GetCurThreadId());

	if(m_audioAPI == AA_AudioTrack)
	{
		_UpdateAT(dt);
		DriverCallbackInterface::_Update(dt);
	}
	else if(m_audioAPI == AA_OpenSLES)
	{
		_UpdateOSL(dt);
		DriverCallbackInterface::_Update(dt);
	}	
}

void DriverAndroid::_UpdateAT(f32 dt)
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	//If not using threaded update
	/*
	DoCallback();
	*/
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
}

void DriverAndroid::_UpdateOSL(f32 dt)
{
#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	//If not using threaded update
	/*
	DoCallback();
	*/
#endif //#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
}

bool DriverAndroid::SetMicrophoneCallback(RecordedAudioReceptor *receptor)
{
#if VOX_MICROPHONE_INPUT
#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	if(!m_recorder.m_active)
		_InitRecordOSL();

	m_recorder.m_mutex.Lock();
	m_recorder.m_microphoneReceptor = receptor;
	m_recorder.m_mutex.Unlock();
	
	return true;
#else // defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	return false;
#endif // defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
#else // VOX_MICROPHONE_INPUT
	return false;
#endif // VOX_MICROPHONE_INPUT
}

void DriverAndroid::RemoveMicrophoneCallback()
{
#if VOX_MICROPHONE_INPUT
#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	m_recorder.m_mutex.Lock();
	m_recorder.m_microphoneReceptor = 0;
	m_recorder.m_mutex.Unlock();

	if(m_recorder.m_active)
		_ShutdownRecordOSL();

#endif // defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
#endif // VOX_MICROPHONE_INPUT
}

}//namespace vox

#endif //VOX_DRIVER_USE_ANDROID && VOX_ANDROID_DRIVER_PLATFORM


