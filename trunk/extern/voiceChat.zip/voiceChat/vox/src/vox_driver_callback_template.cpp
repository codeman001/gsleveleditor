
#include "StdAfx.h"
#include "vox_default_config.h"

#include "vox_driver_callback_template.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox_profiler.h"
#include "vox.h"
#include <math.h> // Used for acos(), sqrt(), pow(), etc.
#include <cstring>

#include "vox_detect_neon.h"

namespace vox {

#define MAX_DOPPLER_PITCH		2.9f	// Limit so user*data*doppler max pitch = (2 * (44100 / 32000) * 2.9) * 2^28 doesn't overflow s32.
#define MIN_DOPPLER_PITCH		0.001f
#define ANGLE_180_DEGREES		180
#define NOMINAL_RAMP_INTERVAL	0.003f	// Volume ramping time span when volume changes or starving

#ifndef M_PI
	#define M_PI	3.14159265358979323846264f
#endif


void SourceDataGenerator::GetData(s32* buffer, s32 nbSample, s32 sampleRate)
{
	if(!m_parent)
		return;
	m_parent->FillBuffer(buffer, nbSample);
}

void SourceDataGenerator::setParent(DriverCallbackSourceInterface *parent)
{
	m_parent = parent;
}

//*** DriverCallbackSourceInterface ***//
s32    DriverCallbackSourceInterface::s_driverSampleRate = 44100;
fx1814 DriverCallbackSourceInterface::s_driverCallbackPeriod = 0x7FFFFFFF;

// Listener, general 3D and doppler static parameters
ListenerParameters DriverCallbackSourceInterface::s_listenerParameters;
u32 DriverCallbackSourceInterface::s_distanceModel = VOX_DEFAULT_3D_MODEL;
f32 DriverCallbackSourceInterface::s_dopplerFactor = VOX_DEFAULT_3D_DOPPLER_FACTOR;			
f32 DriverCallbackSourceInterface::s_alteredSpeedOfSound = VOX_DEFAULT_3D_SPEED_OF_SOUND;
u32 DriverCallbackSourceInterface::s_enable3dSimulation = VOX_DEFAULT_3D_ENHANCED_3D;

Enhanced3dTweakParameters DriverCallbackSourceInterface::s_tweakParameters =
{
	VOX_DEFAULT_ENHANCED_3D_STEREO_PANNING_POWER,
	VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_FRONT,
	VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_BACK,
	
	VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_SIDE,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_BACK,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_DISTANCE,

	VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_SIDE,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_BACK,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_DISTANCE,

	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MINIMUM,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MAXIMUM,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_CURVE,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_SIDE,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_BACK,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_FREQUENCY,

	VOX_DEFAULT_ENHANCED_3D_ROLLOFF_FACTOR

};


DriverCallbackSourceInterface::DriverCallbackSourceInterface(void * trackParam, void* driverParam, u32 sourceId):
m_isFirstBufferFilled(false)
,m_previousLeftGain(0)
,m_previousRightGain(0)
,m_userPitch(VOX_FX1814_ONE)
,m_effectiveUserPitch(VOX_FX1814_ONE)
,m_deltaPitch(0)
,m_effectivePitch(VOX_FX1814_ONE)
,m_state(DriverSource::STATE_INITIAL)
,m_sourceId(sourceId)
//,m_filter(0.4395f, -0.1394f, -0.0863f, 0.0856f, -0.1069f, 0.0212f)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::DriverCallbackSourceInterface", vox::VoxThread::GetCurThreadId());

	m_dataGenerator.setParent(this);

	m_trackParams = *((TrackParams*)trackParam);
	m_nominalRampLength = (s32) (NOMINAL_RAMP_INTERVAL * m_trackParams.samplingRate);
	if(driverParam != 0)
	{
		m_numBuffer = ((DriverSourceParam*)driverParam)->numBuffer;
	}
	else
	{
		m_numBuffer = VOX_DRIVER_SOURCE_NUM_BUFFER;
	}

	m_averageDt = VOX_THREAD_UPDATE_DT * VOX_FX1814_ONE / 1000;
	m_bytesPerSample = (m_trackParams.bitsPerSample >> 3) * m_trackParams.numChannels;

	Init();
}

DriverCallbackSourceInterface::~DriverCallbackSourceInterface()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::~DriverCallbackSourceInterface", vox::VoxThread::GetCurThreadId());
	Cleanup();
}

void DriverCallbackSourceInterface::Play() //**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Play", vox::VoxThread::GetCurThreadId());

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_state != DriverSource::STATE_ERROR)
	{
		m_state = DriverSource::STATE_PLAYING;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverCallbackSourceInterface::Stop()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Stop", vox::VoxThread::GetCurThreadId());

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_state != DriverSource::STATE_ERROR)
	{
		m_state = DriverSource::STATE_STOPPED;
		FreeAllBuffer();
		m_processedBytes = 0;
		m_previousRightGain = 0;
		m_previousLeftGain = 0;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverCallbackSourceInterface::Pause()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Pause", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_state == DriverSource::STATE_PLAYING)
	{
		m_state = DriverSource::STATE_PAUSED;
		m_previousRightGain = 0;
		m_previousLeftGain = 0;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverCallbackSourceInterface::Reset()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Reset", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_bufferList.size() > 0)
	{
		m_state = DriverSource::STATE_INITIAL;
		FreeAllBuffer();
		m_processedBytes = 0;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

s32 DriverCallbackSourceInterface::GetState()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::GetState", vox::VoxThread::GetCurThreadId());
	s32 result = DriverSource::STATE_ERROR;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_state == DriverSource::STATE_PLAYING && m_bufferList[m_currentReadBuffer].free)
	{
		result = DriverSource::STATE_STOPPED;
	}
	else
	{
		result = m_state;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}


void DriverCallbackSourceInterface::FreeDisposableData(s32 maxNbBytes, s32 &nbBuffersFreed, s32 &nbBytesFreed)
{
	ScopeMutex sm(&m_mutex);

	nbBuffersFreed = 0;
	nbBytesFreed = 0;

	if(maxNbBytes <= 0)
		return;

	s32 bufferIndex;
	s32 nbBytesInBuffer;
	s32 cursorPosition;					// In bytes
	s32 nbBytesFromCurrentPosition = 0;
	s32 nbBytesFromEnd = 0;
	s32 nbBytesInPreviousBuffers = 0;
	s32 earliestDisposableBuffer = -1;	// Buffer containing position = current cursor + safety margin.
	s32 earliestDisposablePosition = 0;	// Position of current cursor + safety margin in 'earliestBuffer'

	// Get a safety margin (in bytes) equivalent to VOX_NATIVE_LATENCY_SAFETY_MARGIN driver callbacks
	s32 safetyMargin = ((s_driverSampleRate * (s_driverCallbackPeriod + 1)) >> VOX_FX1814_FRACT_SHIFT) + 1;	
	safetyMargin = static_cast<s32> ((static_cast<f32> (safetyMargin) * static_cast<f32> (m_effectivePitch) / static_cast<f32> (VOX_FX1814_ONE))) + 1;
	safetyMargin *= VOX_NATIVE_LATENCY_SAFETY_MARGIN * m_bytesPerSample;
	
	// Determine the the earliest buffer (and position) where data can be overwritten
	bufferIndex = m_currentReadBuffer;
	for(s32 i = 0; i < m_numBuffer; i++)
	{
		if(!m_bufferList[bufferIndex].free)
		{
			nbBytesInBuffer = m_bufferList[bufferIndex].m_usedSize;
			cursorPosition = m_bufferList[bufferIndex].m_cursorOffset * m_bytesPerSample;
			nbBytesFromCurrentPosition += nbBytesInBuffer - cursorPosition;

			if(nbBytesFromCurrentPosition > safetyMargin)
			{
				earliestDisposableBuffer = bufferIndex;
				earliestDisposablePosition = cursorPosition + safetyMargin - nbBytesInPreviousBuffers;
				break;
			}
		}

		bufferIndex = (bufferIndex + 1) % m_numBuffer;
		nbBytesInPreviousBuffers = nbBytesFromCurrentPosition;
	}

	// Free buffers starting with buffer following read buffer
	nbBytesInPreviousBuffers = 0;
	bufferIndex = m_currentReadBuffer == 0 ? m_numBuffer - 1 : m_currentReadBuffer - 1;

	for(s32 i = 0; i < m_numBuffer; i++)
	{
		if(!m_bufferList[bufferIndex].free)
		{
			nbBytesInBuffer = m_bufferList[bufferIndex].m_usedSize;
			cursorPosition = m_bufferList[bufferIndex].m_cursorOffset * m_bytesPerSample;
			nbBytesFromEnd += nbBytesInBuffer - cursorPosition;

			if(bufferIndex == earliestDisposableBuffer)
			{
				if(cursorPosition + nbBytesFromEnd - maxNbBytes < earliestDisposablePosition)
				{
					m_bufferList[bufferIndex].m_usedSize = earliestDisposablePosition;
					if(earliestDisposablePosition == 0)
					{
						m_bufferList[bufferIndex].free = true;
						nbBuffersFreed++;
						m_currentWriteBuffer = bufferIndex;
					}
					else
					{
						m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
					}
				}
				else
				{
					m_bufferList[bufferIndex].m_usedSize = cursorPosition + nbBytesFromEnd - maxNbBytes;
					m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
				}
				nbBytesFreed += nbBytesInBuffer - m_bufferList[bufferIndex].m_usedSize;
				break;
			}
			else // Buffer is not the earliest disposable buffer
			{
				if(nbBytesFromEnd < maxNbBytes) // Buffer can be freed completely
				{
					m_bufferList[bufferIndex].free = true;
					nbBuffersFreed++;
					nbBytesFreed += nbBytesInBuffer;
				}
				else // Part of the buffer can be overwritten
				{
					m_bufferList[bufferIndex].m_usedSize = cursorPosition + nbBytesFromEnd - maxNbBytes;
					nbBytesFreed += nbBytesInBuffer - m_bufferList[bufferIndex].m_usedSize;
					m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
					break;
				}
			}
			nbBytesInPreviousBuffers = nbBytesFromEnd;
		}

		bufferIndex = bufferIndex == 0 ? m_numBuffer - 1 : bufferIndex - 1;
	}
}



bool DriverCallbackSourceInterface::NeedData()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::NeedData", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	bool result = false;

	if(m_state != DriverSource::STATE_ERROR && m_bufferList.size() > 0) //Check if next buffer is free
	{
		result = m_bufferList[m_currentWriteBuffer].free;
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

void DriverCallbackSourceInterface::UploadData(void* soundData, s32 bufferSize)//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::UploadData", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_state == DriverSource::STATE_ERROR  || bufferSize <= 0)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}
	
	//check that current writebuffer is free
	if(!m_bufferList[m_currentWriteBuffer].free)
	{
		VOX_WARNING_LEVEL_3("Trying to upload to source %d, but no buffer free", m_sourceId);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	m_bufferList[m_currentWriteBuffer].m_data = (u8*)soundData;
	m_bufferList[m_currentWriteBuffer].m_usedSize = bufferSize;
	m_bufferList[m_currentWriteBuffer].m_totalSize = bufferSize;
	m_bufferList[m_currentWriteBuffer].free = false;
	m_bufferList[m_currentWriteBuffer].m_cursorPos = 0;
	m_bufferList[m_currentWriteBuffer].m_cursorOffset = 0;

	m_currentWriteBuffer++;
	m_currentWriteBuffer %= m_numBuffer;

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


void DriverCallbackSourceInterface::SetGain(f32 gain)//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::SetGain", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(gain > 1.0f)
		m_gain = VOX_FX1814_ONE;
	else if(gain < 0.0)
		m_gain = 0;
	else
		m_gain = (fx1814)(gain * VOX_FX1814_ONE);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverCallbackSourceInterface::SetPitch(f32 pitch)//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::SetPitch", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	if(pitch > m_userPitchUpperLimit)
	{
		// Don't allow user pitch to exceed "m_effectivePitchUpperLimit / m_dataPitch / MAX_DOPPLER_PITCH"
		pitch = m_userPitchUpperLimit;
		VOX_WARNING_LEVEL_4("Clamping a too high user pitch at %1.2f", pitch);
	}
	else if(pitch <= 0.0f)
	{
		// Limit user pitch so that m_userPitch is floored at 1.
		pitch = 1.5f / static_cast<f32> (VOX_FX1814_ONE);
		VOX_WARNING_LEVEL_4("Limiting a too low user pitch at %1.2f", 1.0f / static_cast<f32> (VOX_FX1814_ONE));
	}

	// Convert user pitch in fixed point
	m_userPitch = static_cast<fx1814> (pitch * static_cast<f32> (VOX_FX1814_ONE));

	if(m_state == DriverSource::STATE_PLAYING)
	{
		// Determine the pitch step to apply at each callback until the target (m_userPitch) is reached
		f32 deltaPitch = static_cast<f32> (m_userPitch - m_effectiveUserPitch) / static_cast<f32> (VOX_FX1814_ONE);
		if(m_averageDt > s_driverCallbackPeriod)
		{
			deltaPitch *= static_cast<f32> (s_driverCallbackPeriod) / static_cast<f32> (m_averageDt);
		}

		m_deltaPitch = static_cast<fx1814> (deltaPitch * static_cast<f32> (VOX_FX1814_ONE));
	}
	else // Sound not playing. Reach target user pitch immediately.
	{
		m_effectiveUserPitch = m_userPitch; 
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

f32 DriverCallbackSourceInterface::GetGain()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::GetGain", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 result =  (float)m_gain/(float)VOX_FX1814_ONE;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;	
}

f32 DriverCallbackSourceInterface::GetPitch()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::GetPitch", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 result =  (float)m_userPitch/(float)VOX_FX1814_ONE;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;		
}
	
long DriverCallbackSourceInterface::GetByteOffset()//**-** (more or less precise, depends on driver's buffer length)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::GetByteOffset", vox::VoxThread::GetCurThreadId());

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	s32 value = m_processedBytes;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return value;
}

void DriverCallbackSourceInterface::SetByteOffset(s32 offset)//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::SetByteOffset", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_processedBytes = offset;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


void DriverCallbackSourceInterface::Init()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Init", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	m_gain = VOX_FX1814_ONE;
	m_userPitch = VOX_FX1814_ONE;
	m_dataPitch = static_cast<f32> (m_trackParams.samplingRate) / static_cast<f32> (s_driverSampleRate);
	
	// Determine effective pitch upper limit so that one callback cannot exceed one buffer length
	f32 extendedCallbackPeriod = 1.02f * static_cast<f32> (s_driverCallbackPeriod) / static_cast<f32> (VOX_FX1814_ONE);
	m_effectivePitchUpperLimit = (static_cast<f32> (VOX_EMITTER_BUFFER_DURATION_MS) / 1000.0f) / extendedCallbackPeriod;
	
	// Determine the user pitch upper limit considering data and max doppler pitches.
	m_userPitchUpperLimit = (m_effectivePitchUpperLimit / m_dataPitch) / MAX_DOPPLER_PITCH;

	// 3D and doppler parameters
	m_position.x = 0.0f;
	m_position.y = 0.0f;
	m_position.z = 0.0f;
	m_velocity.x = 0.0f;
	m_velocity.y = 0.0f;
	m_velocity.z = 0.0f;
	m_direction.x = 0.0;
	m_direction.y = 0.0;
	m_direction.z = 0.0;
	m_relativeToListener = 0;
	m_maxDistance = 3.40282346638528860e+38;
	m_referenceDistance = 1.0f;
	m_rolloffFactor = 1.0f;
	m_innerConeAngle = 360.0f;
	m_outerConeAngle = 360.0f;
	m_outerConeGain = 0.0f;
	m_cullingDistance = 3.40282346638528860e+38;
	
	m_currentWriteBuffer = 0;
	m_currentReadBuffer = 0;

#if VOX_ENHANCED_3D
	m_leftSideDelay = 0;
	for(int i=0; i<128; i++)
		m_delayBuffer[i] = 0;
	m_delayWriteCounter = 0;
	m_delayReadCounter = 64;
	for(int i=0; i<4; i++)
		m_filter[i].x1 = m_filter[i].x2 = m_filter[i].y1 = m_filter[i].y2 = 0.f;
	m_enable3dSimulation = true;
#else
	m_enable3dSimulation = false;
#endif

	s32 buffersize = VOX_EMITTER_BUFFER_DURATION_MS * m_trackParams.samplingRate * m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3) / 1000;
	//make buffersize a multiple of sample size
	buffersize -= (buffersize % (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3)));
	
	if(m_sourceId)
	{
		for(int i = 0; i < m_numBuffer; i++)
		{
			DriverBuffer newBuffer;
			newBuffer.free = true;
			newBuffer.m_cursorPos = 0;
			newBuffer.m_cursorOffset = 0;
			newBuffer.m_totalSize = buffersize;
			newBuffer.m_usedSize = 0;
			m_bufferList.push_back(newBuffer);
		}
		if(m_numBuffer != (s32) m_bufferList.size())
		{
			VOX_WARNING_LEVEL_3("Could not allocate all buffer for source % d : %d allocated on %d", m_sourceId, (s32)m_bufferList.size(), m_numBuffer);
		}

		m_numBuffer = (s32) m_bufferList.size();

		if(m_numBuffer <= 0)
		{
			m_state = DriverSource::STATE_ERROR; // No buffer allocated
		}
	}
	m_processedBytes = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverCallbackSourceInterface::Cleanup()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Cleanup", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_bufferList.clear();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


void DriverCallbackSourceInterface::Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Set3DParameter", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		switch(paramId)
		{
			case Vox3DEmitterParameter::k_nRelativeToListener:
			{
				s32 value = *((s32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Relative to listener' for %d to %d", m_sourceId, value);
				m_relativeToListener = value;
				break;
			}
			case Vox3DEmitterParameter::k_nMaxDistance:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Max distance' for %d to %f", m_sourceId, value);
				m_maxDistance = value;
				break;
			}
			case Vox3DEmitterParameter::k_nReferenceDistance:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Reference distance' for %d to %f", m_sourceId, value);
				m_referenceDistance = value;
				break;
			}
			case Vox3DEmitterParameter::k_nRolloffFactor:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Rolloff factor' for %d to %f", m_sourceId, value);
				m_rolloffFactor = value;
				break;
			}
			case Vox3DEmitterParameter::k_nInnerConeAngle:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Inner cone angle' for %d to %f", m_sourceId, value);
				m_innerConeAngle = value;
				break;
			}
			case Vox3DEmitterParameter::k_nOuterConeAngle:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Outer cone angle' for %d to %f", m_sourceId, value);
				m_outerConeAngle = value;
				break;
			}
			case Vox3DEmitterParameter::k_nOuterConeGain:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Outer cone gain' for %d to %f", m_sourceId, value);
				m_outerConeGain = value;
				break;
			}
			case Vox3DEmitterParameter::k_nPosition:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				m_position.x = value->x;
				m_position.y = value->y;
				m_position.z = value->z;
				break;
			}
			case Vox3DEmitterParameter::k_nVelocity:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				m_velocity.x = value->x;
				m_velocity.y = value->y;
				m_velocity.z = value->z;
				break;
			}
			case Vox3DEmitterParameter::k_nDirection:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				m_direction.x = value->x;
				m_direction.y = value->y;
				m_direction.z = value->z;
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("Remote IO source doesn't support property %d", paramId);
				break;
			}
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


void DriverCallbackSourceInterface::SetDSPParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::SetDSPParameter", vox::VoxThread::GetCurThreadId());
	// No need for mutex here (putting one creates a deadlock with buffer filling process)

	if(m_sourceId >= 0)
	{
		switch(paramId)
		{
			case VoxDSPEmitterParameter::k_nBusId:
			{
				s32 busId;
				c8* value = (c8*)param;
				VOX_WARNING_LEVEL_5("Setting source %d to bus %s", m_sourceId, value);
				if(STRICMP(value, "AUX1") == 0)
					busId = VOX_MINIBUS_AUX1;
				else if(STRICMP(value, "AUX2") == 0)
					busId = VOX_MINIBUS_AUX2;
				else
					busId = VOX_MINIBUS_MASTER;

				MiniBusManager *pBusManager = MiniBusManager::GetInstance();

				if(pBusManager)
					pBusManager->AttachDataGeneratorToBus(busId, &m_dataGenerator);
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("DriverCallback source doesn't support property %d", paramId);
				break;
			}
		}
	}
}

void DriverCallbackSourceInterface::Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Update", vox::VoxThread::GetCurThreadId());
	fx1814 lastDt = (fx1814) (dt * VOX_FX1814_ONE);
	
	// Get the average from last 8 dt values (average += 1/8 * (dt - averageDt)).
	m_averageDt += (lastDt - m_averageDt) >> 3;
}


void DriverCallbackSourceInterface::FillBuffer(s32* buffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::FillBuffer", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);
	
	if(m_state == DriverSource::STATE_PLAYING && !m_bufferList[m_currentReadBuffer].free)
	{
		if(m_effectiveUserPitch != m_userPitch)
		{
			if(abs(m_userPitch - m_effectiveUserPitch) < abs(m_deltaPitch))
			{
				m_effectiveUserPitch = m_userPitch;
			}
			else
			{
				m_effectiveUserPitch += m_deltaPitch;
			}
		}

		f32 dopplerPitch = 1.0f;
		if(m_trackParams.numChannels == 1)
		{
			dopplerPitch = GetDopplerPitch();
		}

		// Calculate effective pitch in floating point
		f32 effectiveUserPitch = static_cast<f32> (m_effectiveUserPitch) / static_cast<f32> (VOX_FX1814_ONE);
		f32 effectivePitch = effectiveUserPitch * m_dataPitch * dopplerPitch;
		if(effectivePitch > m_effectivePitchUpperLimit)
		{
			effectivePitch = m_effectivePitchUpperLimit;
		}

		// Convert effective pitch in fixed point
		m_effectivePitch = static_cast<fx1814> (effectivePitch * static_cast<f32> (VOX_FX1814_ONE));

		if(m_effectivePitch == 0)
			m_effectivePitch = 1;

		if(m_effectivePitch == VOX_FX1814_ONE)
		{
			if(m_trackParams.numChannels == 1)
			{
				if(m_trackParams.bitsPerSample == 8)
				{
					FillBufferMono8NoInter(buffer, nbSample);
				}
				else if(m_trackParams.bitsPerSample == 16)
				{
#if VOX_ENHANCED_3D
					bool positioned;
					if(m_relativeToListener &&
					   m_position.x == 0.f && 
					   m_position.y == 0.f && 
					   m_position.z == 0.f)
					{
						positioned = false;
					}
					else
					{
						positioned = true;
					}

					if(positioned && s_enable3dSimulation && m_enable3dSimulation)
					{
						FillBufferMono16Biquad(buffer, nbSample);
					}
					else
					{
						FillBufferMono16NoInter(buffer, nbSample);
					}
#else
					FillBufferMono16NoInter(buffer, nbSample);
#endif
				}
			}
			else if(m_trackParams.numChannels == 2)
			{
				if(m_trackParams.bitsPerSample == 8)
				{
					FillBufferStereo8NoInter(buffer, nbSample);
				}
				else if(m_trackParams.bitsPerSample == 16)
				{
					FillBufferStereo16NoInter(buffer, nbSample);
				}				
			}
		}
		else
		{
			if(m_trackParams.numChannels == 1)
			{
				if(m_trackParams.bitsPerSample == 8)
				{
					FillBufferMono8(buffer, nbSample);
				}
				else if(m_trackParams.bitsPerSample == 16)
				{
#if VOX_ENHANCED_3D
					bool positioned;
					if(m_relativeToListener &&
					   m_position.x == 0.f && 
					   m_position.y == 0.f && 
					   m_position.z == 0.f)
					{
						positioned = false;
					}
					else
					{
						positioned = true;
					}

					if(positioned && s_enable3dSimulation && m_enable3dSimulation)
					{
						FillBufferMono16Biquad(buffer, nbSample);
					}
					else
					{
						FillBufferMono16(buffer, nbSample);
					}
#else
					FillBufferMono16(buffer, nbSample);
#endif
				}
			}
			else if(m_trackParams.numChannels == 2)
			{
				if(m_trackParams.bitsPerSample == 8)
				{
					FillBufferStereo8(buffer, nbSample);
				}
				else if(m_trackParams.bitsPerSample == 16)
				{
					FillBufferStereo16(buffer, nbSample);
				}				
			}			
		}
	}
}
	
void DriverCallbackSourceInterface::FillBufferStereo16(s32* buffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::FillBufferStereo16", vox::VoxThread::GetCurThreadId());
	
	if(m_state == DriverSource::STATE_PLAYING && !m_bufferList[m_currentReadBuffer].free)
	{
		// Created temp buffer
		fx1814 sourceSampleNeeded = nbSample * m_effectivePitch;
		s32 bytesToFetch = ((sourceSampleNeeded >> VOX_FX1814_FRACT_SHIFT) + 3) << 2; //get 3 more sample in case first and last are incomplete sample
		fx1814 currentSample = m_bufferList[m_currentReadBuffer].m_cursorPos;
			
		DriverInternalBuffer* m_workBuffer = DriverCallbackInterface::GetWorkBuffer(bytesToFetch);
		if(m_workBuffer->m_size == 0)
		{
			m_state = DriverSource::STATE_ERROR;
			return;								//could not get work buffer
		}
			
		s32 sampleAvailable = ((GetWorkData(m_workBuffer->m_buffer, bytesToFetch, sourceSampleNeeded) / 4) << VOX_FX1814_FRACT_SHIFT) / m_effectivePitch;
			
		s16* data = (s16*)m_workBuffer->m_buffer;

		s32 sampleBefore;
		fx1814 fract;
		s32 sampleToProcess;
		
		// Determine limits and lengths of starving ramp-down
		s32 starvingRampStart = nbSample + 1;	// Out-of-bound value (a priori, no ramp-down).
		s32 starvingRampLength = 0;				// A priori, no ramp-down.
		if(nbSample <= sampleAvailable)
		{
			sampleToProcess = nbSample;
		}
		else // Data starving. Ramp-down samples.
		{
			sampleToProcess = sampleAvailable - 1; // Fix to avoid missing a sample in for loop.
			starvingRampStart = sampleToProcess - m_nominalRampLength;
			starvingRampLength = m_nominalRampLength;
			if(starvingRampStart < 0)
			{
				starvingRampStart = 0;
				starvingRampLength = sampleToProcess;
			}
		}
		
		// Determine length of volume change ramping
		s32 volumeChangeRampLength = m_nominalRampLength;
		if(starvingRampStart < volumeChangeRampLength)
		{
			volumeChangeRampLength = starvingRampStart;
		}
		else if(volumeChangeRampLength > nbSample)
		{
			volumeChangeRampLength = nbSample;
		}

		fx1814 currentGain = m_previousLeftGain;
		fx1814 gainIncrement = 0;

#if VOX_NEON_MIXER
		if(neonInstructionsPresent())
		{
			if(m_gain > 16383)
				m_gain = 16383;
		}
#endif


		if(m_isFirstBufferFilled) // Ramping is allowed only if not the first buffer filling.
		{
			// If volume change ramping is not totally overridden by ramp-down, determine its parameters.
			if(volumeChangeRampLength > 0)
			{
				// Set increments used for volume change ramping
				gainIncrement = (m_gain - m_previousLeftGain) / volumeChangeRampLength;

				if(gainIncrement == 0)
				{
					if(m_gain > m_previousLeftGain)
					{
						volumeChangeRampLength = m_gain - m_previousLeftGain;
						gainIncrement = 1;
					}
					else if(m_gain < m_previousLeftGain)
					{
						volumeChangeRampLength = m_previousLeftGain - m_gain;
						gainIncrement = -1;
					}
				}
			}
		}
		else // First buffer being filled for this source. No ramping allowed
		{
			m_isFirstBufferFilled = true;
			currentGain = m_gain;
		}

#if !(VOX_NEON_MIXER)
		if(gainIncrement != 0 || starvingRampLength > 0)	// Samples calculation with volume ramping.
		{
			for(int i = 0; i < sampleToProcess; i++)
			{
				// When starving ramp-down is due, change increments.
				if(i == starvingRampStart)
				{
					gainIncrement = -abs(currentGain / starvingRampLength);
				}

				// During volume change ramping or starving ramp-down, update the volume increments.
				if(i < volumeChangeRampLength || i >= starvingRampStart)
				{
					currentGain += gainIncrement;
				}

				sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
				fract = currentSample & VOX_FX1814_FRACT_MASK;
				
				// Fill left channel
				*buffer += ((data[2*sampleBefore] + ((fract * (data[2*(sampleBefore + 1)] - data[2*sampleBefore])) >> VOX_FX1814_FRACT_SHIFT)) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
				buffer++;
				
				// Fill right channel
				*buffer += ((data[2*sampleBefore + 1] + ((fract * (data[2*(sampleBefore + 1) + 1] - data[2*sampleBefore + 1])) >> VOX_FX1814_FRACT_SHIFT)) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
				buffer++;

				currentSample += m_effectivePitch;
			}
		}
		else // Samples calculation without volume ramping.
		{
			currentGain = m_gain;

			if(currentGain != 0)
			{
				for(int i = 0; i < sampleToProcess; i++)
				{
					sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
					fract = currentSample & VOX_FX1814_FRACT_MASK;
					
					// Fill left channel
					*buffer += ((data[2*sampleBefore] + ((fract * (data[2*(sampleBefore + 1)] - data[2*sampleBefore])) >> VOX_FX1814_FRACT_SHIFT)) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
					buffer++;
					
					// Fill right channel
					*buffer += ((data[2*sampleBefore + 1] + ((fract * (data[2*(sampleBefore + 1) + 1] - data[2*sampleBefore + 1])) >> VOX_FX1814_FRACT_SHIFT)) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
					buffer++;
					
					currentSample += m_effectivePitch;
				}
			}
		}
#else // VOX_NEON_MIXER = 1

		int volumeChangeRampRemaining;
		int noRampRemaining;
		int starvingRampRemaining;
		if (volumeChangeRampLength <= sampleToProcess)
		{
			volumeChangeRampRemaining = volumeChangeRampLength;
		}
		else
		{
			volumeChangeRampRemaining = sampleToProcess;
		}
		noRampRemaining = sampleToProcess - volumeChangeRampLength;
		if(starvingRampLength <= noRampRemaining)
		{
			noRampRemaining -= starvingRampLength;
			starvingRampRemaining = starvingRampLength;
		}
		else
		{
			starvingRampRemaining = noRampRemaining;
			noRampRemaining = 0;
		}

		bool done;
		if(sampleToProcess > 0)
			done = false;
		else
			done = true;
		
		while(!done)
		{
			int segmentLength;
			if(volumeChangeRampRemaining > 0) // Process ramp in
			{
				segmentLength = volumeChangeRampRemaining;
			}
			else if (noRampRemaining > 0) // Process straight segment
			{
				segmentLength = noRampRemaining;
				gainIncrement = 0;
			}
			else // Process ramp out
			{
				segmentLength = starvingRampRemaining;
				// Change ramp elsewhere!
			}
			
			bool neonSegment = true;
			
			if((int)buffer & 0xf)
			{
				neonSegment = false;
				if((int)buffer & 0x7)
				{
					VOX_WARNING_LEVEL_3("%s", "Vox neon mixer with non-aligned mix buffer!");
				}
				else
				{
					if(segmentLength > 0)
					{
						segmentLength = 1; // process 1 sample in C, then the others in NEON
					}
				}
			}
			else
			{
				if(segmentLength < 16)
				{
					neonSegment = false;
				}
				else
				{
					segmentLength = segmentLength - (segmentLength & 0xf);
				}
			}
			if(!neonInstructionsPresent())
				neonSegment = false;
			if(!neonSegment)
			{
				VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Loop non neon", vox::VoxThread::GetCurThreadId());
				for(int i = 0; i < segmentLength; i++)
				{
					currentGain += gainIncrement;
					sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
					fract = currentSample & VOX_FX1814_FRACT_MASK;
					
					// Fill left channel
					*buffer += ((data[2*sampleBefore] + ((fract * (data[2*sampleBefore + 2] - data[2*sampleBefore])) >> VOX_FX1814_FRACT_SHIFT)) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
					buffer++;
				
					
					// Fill	right channel
					*buffer += ((data[2*sampleBefore+1]+((fract * (data[2*sampleBefore + 3] - data[2*sampleBefore+1]))>>VOX_FX1814_FRACT_SHIFT)) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
					buffer++;
					
					currentSample += m_effectivePitch;
					
				}
			}
			else // Neon segment
			{
				
				FillBufferNeonStereo16(data, currentSample, m_effectivePitch,
									   buffer, segmentLength,
									   currentGain, currentGain, gainIncrement, gainIncrement);
				currentSample += m_effectivePitch * segmentLength;
				buffer += segmentLength * 2;
				currentGain += gainIncrement * segmentLength;
			}
			if(volumeChangeRampRemaining > 0)
			{
				volumeChangeRampRemaining -= segmentLength;
			}
			else if(noRampRemaining > 0)
			{
				noRampRemaining -= segmentLength;
				if(noRampRemaining == 0)
				{
					if(starvingRampLength != 0)
					{
						gainIncrement = -abs(currentGain / starvingRampLength);
					}
				}
			}
			else
			{
				starvingRampRemaining -= segmentLength;
				if(starvingRampRemaining == 0)
				{
					done = true;
				}
			}
		}
#endif		
		m_previousLeftGain = currentGain;
	}
}


void DriverCallbackSourceInterface::FillBufferMono16(s32* buffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::FillBufferMono16", vox::VoxThread::GetCurThreadId());
	if(m_state == DriverSource::STATE_PLAYING && !m_bufferList[m_currentReadBuffer].free)
	{
		fx1814 leftGain = m_gain;
		fx1814 rightGain;
		fx1814 leftPan, rightPan;
		fx1814 gain3D;

		// Get volume attenuation caused by source to listener distance
		gain3D = GetDistanceGain();
		leftGain = (leftGain * gain3D) >> VOX_FX1814_FRACT_SHIFT;
	 
		// Get volume attenuation caused by source directional sound propagation
		gain3D = GetDirectionalGain();
		leftGain = (leftGain * gain3D) >> VOX_FX1814_FRACT_SHIFT;

#if VOX_NEON_MIXER
		if(neonInstructionsPresent())
		{
			if(leftGain > 16383)
				leftGain = 16383;
		}
#endif
	 
		// Get stereo panning due to source position relative to listener. Important to update rightGain before leftGain.
		GetStereoPanning(&leftPan, &rightPan);
		rightGain = (leftGain * rightPan) >> VOX_FX1814_FRACT_SHIFT;
		leftGain = (leftGain * leftPan) >> VOX_FX1814_FRACT_SHIFT;
	 
		// Created temp buffer
		fx1814 sourceSampleNeeded = nbSample * m_effectivePitch;
		s32 samplesToFetch = (sourceSampleNeeded >> VOX_FX1814_FRACT_SHIFT) + 3; //get 3 more sample in case first and last are incomplete sample
		fx1814 currentSample = m_bufferList[m_currentReadBuffer].m_cursorPos;

		DriverInternalBuffer* m_workBuffer = DriverCallbackInterface::GetWorkBuffer(samplesToFetch << 2);
		if(m_workBuffer->m_size == 0)
		{
			m_state = DriverSource::STATE_ERROR;
			return;								//could not get work buffer
		}
	 
		s32 sampleAvailable = ((GetWorkData(m_workBuffer->m_buffer, samplesToFetch << 1, sourceSampleNeeded) / 2) << VOX_FX1814_FRACT_SHIFT) / m_effectivePitch;

		s16* data = (s16*)m_workBuffer->m_buffer;
	 
		s32 sampleValue;
		s32 sampleBefore;
		fx1814 fract;
		s32 sampleToProcess;

		// Determine limits and lengths of starving ramp-down
		s32 starvingRampStart = nbSample + 1;	// Out-of-bound value (a priori, no ramp-down).
		s32 starvingRampLength = 0;				// A priori, no ramp-down.
		if(nbSample <= sampleAvailable)
		{
			sampleToProcess = nbSample;
		}
		else
		{
			sampleToProcess = sampleAvailable - 1; // Fix to avoid missing a sample in for loop.
			starvingRampStart = sampleToProcess - m_nominalRampLength;
			starvingRampLength = m_nominalRampLength;
			if(starvingRampStart < 0)
			{
				starvingRampStart = 0;
				starvingRampLength = sampleToProcess;
			}
		}
		
		// Determine length of volume change ramping
		s32 volumeChangeRampLength = m_nominalRampLength;
		if(starvingRampStart < volumeChangeRampLength)
		{
			volumeChangeRampLength = starvingRampStart;
		}
		else if(volumeChangeRampLength > nbSample)
		{
			volumeChangeRampLength = nbSample;
		}

		fx1814 currentLeftGain = m_previousLeftGain;
		fx1814 currentRightGain = m_previousRightGain;
		fx1814 leftGainIncrement = 0;
		fx1814 rightGainIncrement = 0;

		if(m_isFirstBufferFilled) // Ramping is allowed only if not the first buffer filling.
		{
			// If volume change ramping is not totally overridden by ramp-down, determine its parameters.
			if(volumeChangeRampLength > 0)
			{
				// Set increments used for volume change ramping
				leftGainIncrement = (leftGain - m_previousLeftGain) / volumeChangeRampLength;
				rightGainIncrement = (rightGain - m_previousRightGain) / volumeChangeRampLength;

				if(leftGainIncrement == 0)
				{
					if(leftGain > m_previousLeftGain)
					{
						volumeChangeRampLength = leftGain - m_previousLeftGain;
						leftGainIncrement = 1;
					}
					else if(leftGain < m_previousLeftGain)
					{
						volumeChangeRampLength = m_previousLeftGain - leftGain;
						leftGainIncrement = -1;
					}
				}

				if(rightGainIncrement == 0)
				{
					if(rightGain > m_previousRightGain)
					{
						volumeChangeRampLength = rightGain - m_previousRightGain;
						rightGainIncrement = 1;
					}
					else if(rightGain < m_previousRightGain)
					{
						volumeChangeRampLength = m_previousRightGain - rightGain;
						rightGainIncrement = -1;
					}
				}
			}
		}
		else // First buffer being filled for this source. No ramping allowed
		{
			m_isFirstBufferFilled = true;
			currentLeftGain = leftGain;
			currentRightGain = rightGain;
		}
		 
		s32 diff = 0;
#if !(VOX_NEON_MIXER)
		if(leftGainIncrement != 0 || rightGainIncrement != 0 || starvingRampLength > 0)	// Ramping.
		{
			for(int i = 0; i < sampleToProcess; i++)
			{
				// When starving ramp-down is due, change increments.
				if(i == starvingRampStart)
				{
					leftGainIncrement = -abs(currentLeftGain / starvingRampLength);
					rightGainIncrement = -abs(currentRightGain / starvingRampLength);
				}

				// During volume change ramping or starving ramp-down, update the gain increments.
				if(i < volumeChangeRampLength || i >= starvingRampStart)
				{
					currentLeftGain += leftGainIncrement;
					currentRightGain += rightGainIncrement;
				}

				// Interpolate sample value
				sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
				fract = currentSample & VOX_FX1814_FRACT_MASK;

				//do not merge the following 2 lines, it breaks interpolation on Vita Release
				diff = (data[sampleBefore + 1] - data[sampleBefore]);
				sampleValue = data[sampleBefore] + ((fract * diff) >> VOX_FX1814_FRACT_SHIFT);
				
				// Fill left channel
				*buffer += ((sampleValue * currentLeftGain) >> VOX_FX1814_FRACT_SHIFT);
				buffer++;
				
				// Fill right channel
				*buffer += ((sampleValue * currentRightGain) >> VOX_FX1814_FRACT_SHIFT);
				buffer++;

				currentSample += m_effectivePitch;
			}
		}
		else // No ramping needed
		{
			currentLeftGain = leftGain;
			currentRightGain = rightGain;

			if(currentLeftGain != 0 || currentRightGain != 0)
			{
#if defined(SN_TARGET_PSP2)
				// speed increase by using a 64 inner loop
				// sampleToProcess is always a multiple of 64 on VITA
				for(int k = 0; k < sampleToProcess / 64; k++)
					for(int i = 0; i < 64; i++)
#else
				for(int i = 0; i < sampleToProcess; i++)
#endif
				{
					// Interpolate sample value
					sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
					fract = currentSample & VOX_FX1814_FRACT_MASK;

					//do not merge the following 2 lines, it breaks interpolation on Vita Release
					diff = (data[sampleBefore + 1] - data[sampleBefore]);
					sampleValue = data[sampleBefore] + ((fract * diff) >> VOX_FX1814_FRACT_SHIFT);
					
					// Fill left channel
					*buffer += ((sampleValue * currentLeftGain) >> VOX_FX1814_FRACT_SHIFT);
					buffer++;
					
					// Fill right channel
					*buffer += ((sampleValue * currentRightGain) >> VOX_FX1814_FRACT_SHIFT);
					buffer++;
					
					currentSample += m_effectivePitch;
				}
			}
		}
#else // VOX_NEON_MIXER = 1
		int volumeChangeRampRemaining;
		int noRampRemaining;
		int starvingRampRemaining;
		if (volumeChangeRampLength <= sampleToProcess)
		{
			volumeChangeRampRemaining = volumeChangeRampLength;
		}
		else
		{
			volumeChangeRampRemaining = sampleToProcess;
		}
		noRampRemaining = sampleToProcess - volumeChangeRampLength;
		if(starvingRampLength <= noRampRemaining)
		{
			noRampRemaining -= starvingRampLength;
			starvingRampRemaining = starvingRampLength;
		}
		else
		{
			starvingRampRemaining = noRampRemaining;
			noRampRemaining = 0;
		}

		bool done;
		if(sampleToProcess > 0)
			done = false;
		else
			done = true;
		while(!done)
		{
			int segmentLength;
			if(volumeChangeRampRemaining > 0) // Process ramp in
			{
				segmentLength = volumeChangeRampRemaining;
			}
			else if (noRampRemaining > 0) // Process straight segment
			{
				segmentLength = noRampRemaining;
				leftGainIncrement = 0;
				rightGainIncrement = 0;
			}
			else // Process ramp out
			{
				segmentLength = starvingRampRemaining;
				// Change ramp elsewhere!
			}
			bool neonSegment = true;
			 
			if((int)buffer & 0xf)
			{
				neonSegment = false;
				if((int)buffer & 0x7)
				{
					VOX_WARNING_LEVEL_3("%s", "Vox neon mixer with non-aligned mix buffer!");
				}
				else
				{
					if(segmentLength > 0)
					{
						segmentLength = 1; // process 1 sample in C, then the others in NEON
					}
				}
			}
			else
			{
				if(segmentLength < 16)
				{
					neonSegment = false;
				}
				else
				{
					segmentLength = segmentLength - (segmentLength & 0xf);
				}
			}
			if(!neonInstructionsPresent())
				neonSegment = false;
			if(!neonSegment)
			{
				VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Loop non neon", vox::VoxThread::GetCurThreadId());
				for(int i = 0; i < segmentLength; i++)
				{
					currentLeftGain += leftGainIncrement;
					currentRightGain += rightGainIncrement;
					// Interpolate sample value
					sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
					fract = currentSample & VOX_FX1814_FRACT_MASK;

					//do not merge the following 2 lines, it breaks interpolation on Vita Release
					diff = (data[sampleBefore + 1] - data[sampleBefore]);
					sampleValue = data[sampleBefore] + ((fract * diff) >> VOX_FX1814_FRACT_SHIFT);
				
					// Fill left channel
					*buffer += ((sampleValue * currentLeftGain) >> VOX_FX1814_FRACT_SHIFT);
					buffer++;
				
					// Fill right channel
					*buffer += ((sampleValue * currentRightGain) >> VOX_FX1814_FRACT_SHIFT);
					buffer++;
				
					currentSample += m_effectivePitch;
				}
			}
			else // Neon segment
			{
				FillBufferNeonMono16(data, currentSample, m_effectivePitch,
					buffer, segmentLength,
					currentLeftGain, currentRightGain, leftGainIncrement, rightGainIncrement);
				currentSample += m_effectivePitch * segmentLength;
				buffer += segmentLength * 2;
				currentLeftGain  += leftGainIncrement  * segmentLength;
				currentRightGain += rightGainIncrement * segmentLength;
			}
			if(volumeChangeRampRemaining > 0)
			{
				volumeChangeRampRemaining -= segmentLength;
			}
			else if(noRampRemaining > 0)
			{
				noRampRemaining -= segmentLength;
				if(noRampRemaining == 0)
				{
					if(starvingRampLength != 0)
					{
						leftGainIncrement  = -abs(currentLeftGain / starvingRampLength);
						rightGainIncrement = -abs(currentRightGain / starvingRampLength);
					}
				}
			}
			else
			{
				starvingRampRemaining -= segmentLength;
				if(starvingRampRemaining == 0)
				{
					done = true;
				}
			}
		}
#endif
		m_previousLeftGain = currentLeftGain;
		m_previousRightGain = currentRightGain;		
	}
}







#if VOX_ENHANCED_3D
void DriverCallbackSourceInterface::FillBufferMono16Biquad(s32* buffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::FillBufferMono16Biquad", vox::VoxThread::GetCurThreadId());
	if(m_state == DriverSource::STATE_PLAYING && !m_bufferList[m_currentReadBuffer].free)
	{
		fx1814 leftGain = m_gain;
		fx1814 rightGain;
		fx1814 gain3D;

		// Get volume attenuation caused by source to listener distance
		gain3D = GetDistanceGain();
		leftGain = (leftGain * gain3D) >> VOX_FX1814_FRACT_SHIFT;
	 
		// Get volume attenuation caused by source directional sound propagation
		gain3D = GetDirectionalGain();
		leftGain = (leftGain * gain3D) >> VOX_FX1814_FRACT_SHIFT;

#if VOX_NEON_MIXER
		if(neonInstructionsPresent())
		{
			if(leftGain > 16383)
				leftGain = 16383;
		}
#endif


		f32 positionX;
		f32 positionY;
		f32 positionZ;

		GetNormalizedPosition(&positionX, &positionY, &positionZ);

		f32 rightPanLaw = sqrt(0.5f + positionX*(s_tweakParameters.enhanced3dStereoPanningPower - 0.5f));
		f32 leftPanLaw  = sqrt(0.5f - positionX*(s_tweakParameters.enhanced3dStereoPanningPower - 0.5f));
		rightGain = (fx1814)(leftGain * rightPanLaw);
		leftGain  = (fx1814)(leftGain * leftPanLaw);


		f32 maxDelay;
		if(positionZ < 0)
			maxDelay = s_driverSampleRate * 0.001f * s_tweakParameters.enhanced3dStereoMaxDelayFront;
		else
			maxDelay = s_driverSampleRate * 0.001f * s_tweakParameters.enhanced3dStereoMaxDelayBack;
		f32 delay = positionX * maxDelay;
		if(delay > 120)
			delay = 120;
		if(delay < -120)
			delay = -120;
		if(delay >= 0)
		{
			m_delayReadCounter = (m_delayWriteCounter - ((int)(delay + 0.5))) & 0x7f;
			m_leftSideDelay = 1;
		}
		else
		{
			m_delayReadCounter = (m_delayWriteCounter - ((int)(-delay + 0.5))) & 0x7f;
			m_leftSideDelay = 0;
		}

		f32 frontness;
		if (positionZ > 0.4f)
		{
			frontness = 1;
		}
		else if (positionZ < -0.4f)
		{
			frontness = -1;
		}
		else
		{
			frontness = positionZ * 2.5f;
			frontness = 1.5f * frontness - 0.5f * frontness * frontness * frontness;
		}

		f32 rightness;
		if (positionX > 0.4f)
		{
			rightness = 1;
		}
		else if (positionX < -0.4f)
		{
			rightness = -1;
		}
		else
		{
			rightness = positionX * 2.5f;
			rightness = 1.5f * rightness - 0.5f * rightness * rightness * rightness;
		}


		f32 notch = 8280.f;
		notch += (positionY * 0.996f - positionZ * 0.087f) * 3200;

		f32 nDiff = (positionZ + 1) * 0.5f;
		nDiff = 1 + nDiff + nDiff*nDiff;
		nDiff *= 1000;
		nDiff *= positionX;

		f32 qDiffL = 0.5f - (rightness)*0.5f;
		f32 qDiffR = 0.5f + (rightness)*0.5f;
		qDiffL    *= 0.5f - (frontness)*0.5f;
		qDiffR    *= 0.5f - (frontness)*0.5f;

		f32 attenuation = (f32)GetDistanceGain() / VOX_FX1814_ONE;
		if (attenuation > 1)
			attenuation = 1;

		m_filter[0].setNotch(notch - nDiff,
			(-1 - s_tweakParameters.enhanced3dNotchDepthSide     * qDiffL
				- s_tweakParameters.enhanced3dNotchDepthBack     * (0.5f - frontness*0.5f)
				+ s_tweakParameters.enhanced3dNotchDepthDistance * attenuation)
				* s_tweakParameters.enhanced3dNotchDepth,
			(1  + s_tweakParameters.enhanced3dNotchWidthSide     * qDiffL
				+ s_tweakParameters.enhanced3dNotchWidthBack     * (0.5f - frontness*0.5f )
				- s_tweakParameters.enhanced3dNotchWidthDistance * attenuation)
				* s_tweakParameters.enhanced3dNotchWidth,
			float(s_driverSampleRate));
		m_filter[1].setNotch(notch + nDiff,
			(-1 - s_tweakParameters.enhanced3dNotchDepthSide     * qDiffR
				- s_tweakParameters.enhanced3dNotchDepthBack     * (0.5f - frontness*0.5f)
				+ s_tweakParameters.enhanced3dNotchDepthDistance * attenuation)
				* s_tweakParameters.enhanced3dNotchDepth,
			(1  + s_tweakParameters.enhanced3dNotchWidthSide     * qDiffR
				+ s_tweakParameters.enhanced3dNotchWidthBack     * (0.5f - frontness*0.5f )
				- s_tweakParameters.enhanced3dNotchWidthDistance * attenuation)
				* s_tweakParameters.enhanced3dNotchWidth,
			float(s_driverSampleRate));

		f32 bandwidth;
		bandwidth = attenuation 
				  * (1 - s_tweakParameters.enhanced3dDistanceWidthSide * (0.5f - qDiffL*0.5f) )
				  * (1 - s_tweakParameters.enhanced3dDistanceWidthBack * (0.5f - frontness*0.5f) );
		bandwidth = 1 - bandwidth;
		bandwidth = pow(bandwidth, s_tweakParameters.enhanced3dDistanceWidthCurve);
		bandwidth = 1 - bandwidth;
		bandwidth = s_tweakParameters.enhanced3dDistanceWidthMinimum * (1.0f - bandwidth)
		          + s_tweakParameters.enhanced3dDistanceWidthMaximum * bandwidth;
        m_filter[2].setDistanceBandpass(bandwidth,
			s_tweakParameters.enhanced3dDistanceFrequency,
			float(s_driverSampleRate));

		bandwidth = attenuation 
				  * (1 - s_tweakParameters.enhanced3dDistanceWidthSide * (0.5f - qDiffR*0.5f) )
				  * (1 - s_tweakParameters.enhanced3dDistanceWidthBack * (0.5f - frontness*0.5f) );
		bandwidth = 1 - bandwidth;
		bandwidth = pow(bandwidth, s_tweakParameters.enhanced3dDistanceWidthCurve);
		bandwidth = 1 - bandwidth;
		bandwidth = s_tweakParameters.enhanced3dDistanceWidthMinimum * (1.0f - bandwidth)
		          + s_tweakParameters.enhanced3dDistanceWidthMaximum * bandwidth;
        m_filter[3].setDistanceBandpass(bandwidth,
			s_tweakParameters.enhanced3dDistanceFrequency,
			float(s_driverSampleRate));

		// Created temp buffer
		fx1814 sourceSampleNeeded = nbSample * m_effectivePitch;
		s32 samplesToFetch = (sourceSampleNeeded >> VOX_FX1814_FRACT_SHIFT) + 3; //get 3 more sample in case first and last are incomplete sample
		fx1814 currentSample = m_bufferList[m_currentReadBuffer].m_cursorPos;


		DriverInternalBuffer* m_workBuffer = DriverCallbackInterface::GetWorkBuffer(samplesToFetch << 2);
		if(m_workBuffer->m_size == 0)
		{
			m_state = DriverSource::STATE_ERROR;
			return;								//could not get work buffer
		}
	 
		s32 sampleAvailable = ((GetWorkData(m_workBuffer->m_buffer, samplesToFetch << 1, sourceSampleNeeded) / 2) << VOX_FX1814_FRACT_SHIFT) / m_effectivePitch;

		s16* data = (s16*)m_workBuffer->m_buffer;
	 
		s32 sampleValue;
		s32 sampleBefore;
		fx1814 fract;
		s32 sampleToProcess;

		// Determine limits and lengths of starving ramp-down
		s32 starvingRampStart = nbSample + 1;	// Out-of-bound value (a priori, no ramp-down).
		s32 starvingRampLength = 0;				// A priori, no ramp-down.
		if(nbSample <= sampleAvailable)
		{
			sampleToProcess = nbSample;
		}
		else
		{
			sampleToProcess = sampleAvailable - 1; // Fix to avoid missing a sample in for loop.
			starvingRampStart = sampleToProcess - m_nominalRampLength;
			starvingRampLength = m_nominalRampLength;
			if(starvingRampStart < 0)
			{
				starvingRampStart = 0;
				starvingRampLength = sampleToProcess;
			}
		}
		
		// Determine length of volume change ramping
		s32 volumeChangeRampLength = m_nominalRampLength;
		if(starvingRampStart < volumeChangeRampLength)
		{
			volumeChangeRampLength = starvingRampStart;
		}
		else if(volumeChangeRampLength > nbSample)
		{
			volumeChangeRampLength = nbSample;
		}

		fx1814 currentLeftGain = m_previousLeftGain;
		fx1814 currentRightGain = m_previousRightGain;
		fx1814 leftGainIncrement = 0;
		fx1814 rightGainIncrement = 0;

		if(m_isFirstBufferFilled) // Ramping is allowed only if not the first buffer filling.
		{
			// If volume change ramping is not totally overridden by ramp-down, determine its parameters.
			if(volumeChangeRampLength > 0)
			{
				// Set increments used for volume change ramping
				leftGainIncrement = (leftGain - m_previousLeftGain) / volumeChangeRampLength;
				rightGainIncrement = (rightGain - m_previousRightGain) / volumeChangeRampLength;

				if(leftGainIncrement == 0)
				{
					if(leftGain > m_previousLeftGain)
					{
						volumeChangeRampLength = leftGain - m_previousLeftGain;
						leftGainIncrement = 1;
					}
					else if(leftGain < m_previousLeftGain)
					{
						volumeChangeRampLength = m_previousLeftGain - leftGain;
						leftGainIncrement = -1;
					}
				}

				if(rightGainIncrement == 0)
				{
					if(rightGain > m_previousRightGain)
					{
						volumeChangeRampLength = rightGain - m_previousRightGain;
						rightGainIncrement = 1;
					}
					else if(rightGain < m_previousRightGain)
					{
						volumeChangeRampLength = m_previousRightGain - rightGain;
						rightGainIncrement = -1;
					}
				}
			}
		}
		else // First buffer being filled for this source. No ramping allowed
		{
			m_isFirstBufferFilled = true;
			currentLeftGain = leftGain;
			currentRightGain = rightGain;
		}
		 
		s32 diff = 0;

		int volumeChangeRampRemaining;
		int noRampRemaining;
		int starvingRampRemaining;
		if (volumeChangeRampLength <= sampleToProcess)
		{
			volumeChangeRampRemaining = volumeChangeRampLength;
		}
		else
		{
			volumeChangeRampRemaining = sampleToProcess;
		}
		noRampRemaining = sampleToProcess - volumeChangeRampLength;
		if(starvingRampLength <= noRampRemaining)
		{
			noRampRemaining -= starvingRampLength;
			starvingRampRemaining = starvingRampLength;
		}
		else
		{
			starvingRampRemaining = noRampRemaining;
			noRampRemaining = 0;
		}

		bool done;
		if(sampleToProcess > 0)
			done = false;
		else
			done = true;
		while(!done)
		{
			int segmentLength;
			if(volumeChangeRampRemaining > 0) // Process ramp in
			{
				segmentLength = volumeChangeRampRemaining;
			}
			else if (noRampRemaining > 0) // Process straight segment
			{
				segmentLength = noRampRemaining;
				leftGainIncrement = 0;
				rightGainIncrement = 0;
			}
			else // Process ramp out
			{
				segmentLength = starvingRampRemaining;
				// Change ramp elsewhere!
			}

#if VOX_NEON_MIXER
			bool neonSegment = true;
			 
			if((int)buffer & 0xf)
			{
				neonSegment = false;
				if((int)buffer & 0x7)
				{
					VOX_WARNING_LEVEL_3("%s", "Vox neon mixer with non-aligned mix buffer!");
				}
				else
				{
					if(segmentLength > 0)
					{
						segmentLength = 1; // process 1 sample in C, then the others in NEON
					}
				}
			}
			else
			{
				if(segmentLength < 8)
				{
					neonSegment = false;
				}
				else
				{
					segmentLength = segmentLength - (segmentLength & 0x1);
				}
			}
			if(!neonInstructionsPresent())
				neonSegment = false;
			if(!neonSegment)
#endif // VOX_NEON_MIXER
#if VOX_ENHANCED_3D_FLOAT
			{
				VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Resampler with float biquad", vox::VoxThread::GetCurThreadId());
				// float32 version
				s32 delayOutput;
				f32 tempLeft;
				f32 tempRight;
				f32 tempLeft2;
				f32 tempRight2;

				for(int i = 0; i < segmentLength; i++)
				{
					currentLeftGain += leftGainIncrement;
					currentRightGain += rightGainIncrement;
					// Interpolate sample value
					sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
					fract = currentSample & VOX_FX1814_FRACT_MASK;
	
					//do not merge the following 2 lines, it breaks interpolation on Vita Release
					diff = (data[sampleBefore + 1] - data[sampleBefore]);
					sampleValue = data[sampleBefore] + ((fract * diff) >> VOX_FX1814_FRACT_SHIFT);

					// Delay
					m_delayBuffer[m_delayWriteCounter] = sampleValue;
					m_delayWriteCounter += 1;
					m_delayWriteCounter &= 0x7f;
					delayOutput = m_delayBuffer[m_delayReadCounter];
					m_delayReadCounter += 1;
					m_delayReadCounter &= 0x7f;

					if (m_leftSideDelay)
					{
						tempLeft = (float)delayOutput;
						tempRight = (float)sampleValue;
					}
					else
					{
						tempLeft = (float)sampleValue;
						tempRight = (float)delayOutput;
					}

					// Filter time!
					tempLeft2	= tempLeft*m_filter[0].a0
								+ m_filter[0].x1*m_filter[0].a1 + m_filter[0].x2*m_filter[0].a2 
								+ m_filter[0].y1*m_filter[0].b1 + m_filter[0].y2*m_filter[0].b2;
					m_filter[0].x2 = m_filter[0].x1;
					m_filter[0].x1 = tempLeft;
					m_filter[0].y2 = m_filter[0].y1;
					m_filter[0].y1 = tempLeft2;

					tempRight2	= tempRight*m_filter[1].a0
								+ m_filter[1].x1*m_filter[1].a1 + m_filter[1].x2*m_filter[1].a2
								+ m_filter[1].y1*m_filter[1].b1 + m_filter[1].y2*m_filter[1].b2;
					m_filter[1].x2 = m_filter[1].x1;
					m_filter[1].x1 = tempRight;
					m_filter[1].y2 = m_filter[1].y1;
					m_filter[1].y1 = tempRight2;

					tempLeft	= tempLeft2*m_filter[2].a0
								+ m_filter[2].x1*m_filter[2].a1 + m_filter[2].x2*m_filter[2].a2
								+ m_filter[2].y1*m_filter[2].b1 + m_filter[2].y2*m_filter[2].b2;
					m_filter[2].x2 = m_filter[2].x1;
					m_filter[2].x1 = tempLeft2;
					m_filter[2].y2 = m_filter[2].y1;
					m_filter[2].y1 = tempLeft;

					tempRight	= tempRight2*m_filter[3].a0
								+ m_filter[3].x1*m_filter[3].a1 + m_filter[3].x2*m_filter[3].a2
								+ m_filter[3].y1*m_filter[3].b1 + m_filter[3].y2*m_filter[3].b2;
					m_filter[3].x2 = m_filter[3].x1;
					m_filter[3].x1 = tempRight2;
					m_filter[3].y2 = m_filter[3].y1;
					m_filter[3].y1 = tempRight;

					if(tempLeft > 32767)
						tempLeft = 32767;
					else if(tempLeft < -32768)
						tempLeft = -32768;

					if(tempRight > 32767)
						tempRight = 32767;
					else if(tempRight < -32768)
						tempRight = -32768;
		
					// Fill left channel
					*buffer += (( (int)tempLeft * currentLeftGain) >> VOX_FX1814_FRACT_SHIFT);
					buffer++;
				
					// Fill right channel
					*buffer += (( (int)tempRight * currentRightGain) >> VOX_FX1814_FRACT_SHIFT);
					buffer++;
			
					currentSample += m_effectivePitch;
				}

			}
#else // VOX_ENHANCED_3D_FLOAT = 0
			{
				int delayOutput;
				int tempLeft;
				int tempRight;
				int tempLeft2;
				int tempRight2;
				VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Resampler with integer biquad", vox::VoxThread::GetCurThreadId());
				// int32 accumulator version with error dithering
				VoxFilterInteger sf[4];
				for(int i =0; i < 4; i++)
				{
					if(i < 2)
					{
						sf[i].a0 = (int)(m_filter[i].a0 * 16384.f);
						sf[i].a1 = (int)(m_filter[i].a1 * 16384.f);
						sf[i].a2 = (int)(m_filter[i].a2 * 16384.f);
						sf[i].x1 = (int)(m_filter[i].x1 * 1.f);
						sf[i].x2 = (int)(m_filter[i].x2 * 1.f);
					}
					else
					{
						sf[i].a0 = (int)(m_filter[i].a0 * 65536.f);
						sf[i].a1 = (int)(m_filter[i].a1 * 65536.f);
						sf[i].a2 = (int)(m_filter[i].a2 * 65536.f);
						sf[i].x1 = (int)(m_filter[i].x1 * 0.25f);
						sf[i].x2 = (int)(m_filter[i].x2 * 0.25f);
					}
					sf[i].b1 = (int)(m_filter[i].b1 * 65536.f);
					sf[i].b2 = (int)(m_filter[i].b2 * 65536.f);
					sf[i].y1 = (int)(m_filter[i].y1 * 0.25f);
					sf[i].y2 = (int)(m_filter[i].y2 * 0.25f);
					sf[i].err = m_filter[i].err;
				}
				for(int i = 0; i < segmentLength; i++)
				{
				
					currentLeftGain += leftGainIncrement;
					currentRightGain += rightGainIncrement;
					// Interpolate sample value
					sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
					fract = currentSample & VOX_FX1814_FRACT_MASK;
					
					//do not merge the following 2 lines, it breaks interpolation on Vita Release
					diff = (data[sampleBefore + 1] - data[sampleBefore]);
					sampleValue = data[sampleBefore] + ((fract * diff) >> VOX_FX1814_FRACT_SHIFT);
				
					// Delay
					m_delayBuffer[m_delayWriteCounter] = sampleValue;
					m_delayWriteCounter += 1;
					m_delayWriteCounter &= 0x7f;
					delayOutput = m_delayBuffer[m_delayReadCounter];
					m_delayReadCounter += 1;
					m_delayReadCounter &= 0x7f;
				
					if (m_leftSideDelay)
					{
						tempLeft = delayOutput;
						tempRight = sampleValue;
					}
					else
					{
						tempLeft = sampleValue;
						tempRight = delayOutput;
					}

					// Filter time!
					tempLeft2 = tempLeft*sf[0].a0 + sf[0].x1*sf[0].a1 + sf[0].x2*sf[0].a2 + sf[0].y1*sf[0].b1 + sf[0].y2*sf[0].b2 + sf[0].err;
					sf[0].err = tempLeft2 & 0xffff;
					tempLeft2 >>= 16;
					sf[0].x2 = sf[0].x1;
					sf[0].x1 = tempLeft;
					sf[0].y2 = sf[0].y1;
					sf[0].y1 = tempLeft2;
				
					tempRight2 = tempRight*sf[1].a0 + sf[1].x1*sf[1].a1 + sf[1].x2*sf[1].a2 + sf[1].y1*sf[1].b1 + sf[1].y2*sf[1].b2 + sf[1].err;
					sf[1].err = tempRight2 & 0xffff;
					tempRight2 >>= 16;
					sf[1].x2 = sf[1].x1;
					sf[1].x1 = tempRight;
					sf[1].y2 = sf[1].y1;
					sf[1].y1 = tempRight2;
				
					tempLeft = tempLeft2*sf[2].a0 + sf[2].x1*sf[2].a1 + sf[2].x2*sf[2].a2 + sf[2].y1*sf[2].b1 + sf[2].y2*sf[2].b2 + sf[2].err;
					sf[2].err = tempLeft & 0xffff;
					tempLeft >>= 16;
					sf[2].x2 = sf[2].x1;
					sf[2].x1 = tempLeft2;
					sf[2].y2 = sf[2].y1;
					sf[2].y1 = tempLeft;
				
					tempRight = tempRight2*sf[3].a0 + sf[3].x1*sf[3].a1 + sf[3].x2*sf[3].a2 + sf[3].y1*sf[3].b1 + sf[3].y2*sf[3].b2 + sf[3].err;
					sf[3].err = tempRight & 0xffff;
					tempRight >>= 16;
					sf[3].x2 = sf[3].x1;
					sf[3].x1 = tempRight2;
					sf[3].y2 = sf[3].y1;
					sf[3].y1 = tempRight;
				
					// Fill left channel
					*buffer += ( (int)tempLeft * currentLeftGain) >> (VOX_FX1814_FRACT_SHIFT-2);
					buffer++;
					
					// Fill right channel
					*buffer += ( (int)tempRight * currentRightGain) >> (VOX_FX1814_FRACT_SHIFT-2);
					buffer++;
					
					currentSample += m_effectivePitch;
				}
				for(int i =0; i < 4; i++)
				{
					if(i < 2)
					{
						m_filter[i].x1 = (f32)sf[i].x1;
						m_filter[i].x2 = (f32)sf[i].x2;
					}
					else
					{
						m_filter[i].x1 = (f32)sf[i].x1 * 4.f;
						m_filter[i].x2 = (f32)sf[i].x2 * 4.f;
					}
					m_filter[i].y1 = sf[i].y1 * 4.f;
					m_filter[i].y2 = sf[i].y2 * 4.f;
					m_filter[i].err = sf[i].err;
				}
			}
#endif // VOX_ENHANCED_3D_FLOAT = 0
#if VOX_NEON_MIXER
			else // Neon segment
			{
				FillBufferNeonMono16Biquad(data, currentSample, m_effectivePitch,
					buffer, segmentLength,
					currentLeftGain, currentRightGain, leftGainIncrement, rightGainIncrement);

				currentSample += m_effectivePitch * segmentLength;
	
				m_delayWriteCounter += segmentLength;
				m_delayWriteCounter &= 0x7f;
				m_delayReadCounter += segmentLength;
				m_delayReadCounter &= 0x7f;

				currentLeftGain += leftGainIncrement * segmentLength;
				currentRightGain += rightGainIncrement * segmentLength;
	
				buffer += segmentLength*2;

			}
#endif // VOX_NEON_MIXER
			if(volumeChangeRampRemaining > 0)
			{
				volumeChangeRampRemaining -= segmentLength;
			}
			else if(noRampRemaining > 0)
			{
				noRampRemaining -= segmentLength;
				if(noRampRemaining == 0)
				{
					if(starvingRampLength != 0)
					{
						leftGainIncrement  = -abs(currentLeftGain / starvingRampLength);
						rightGainIncrement = -abs(currentRightGain / starvingRampLength);
					}
				}
			}
			else
			{
				starvingRampRemaining -= segmentLength;
				if(starvingRampRemaining == 0)
				{
					done = true;
				}
			}
		}

		m_previousLeftGain = currentLeftGain;
		m_previousRightGain = currentRightGain;		
	}
}
#endif // VOX_ENHANCED_3D



void DriverCallbackSourceInterface::FillBufferStereo16NoInter(s32* buffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::FillBufferStereo16NoInter", vox::VoxThread::GetCurThreadId());
	s32 remainingSample;
	s32 sampleNeeded;
	s16* data;
	
	
	if(m_state == DriverSource::STATE_PLAYING && !m_bufferList[m_currentReadBuffer].free)
	{
		// No interpolation needed userPitch*dataPitch = 1
		if(m_bufferList[m_currentReadBuffer].m_cursorPos) //We want to skip interpolation. If between 2 samples => go to next
		{
			m_bufferList[m_currentReadBuffer].m_cursorOffset++;
			m_bufferList[m_currentReadBuffer].m_cursorPos = 0;
		}
		
		// Determine limits and lengths of starving ramp-down
		s32 sampleAvailable = GetNbAvailableSamples(nbSample);
		s32 starvingRampStart = nbSample + 1;					// Out-of-bound value (a priori, no ramp-down).
		s32 starvingRampLength = 0;								// A priori, no ramp-down.
		if(sampleAvailable < nbSample)							// Data starving. Ramp-down samples.
		{
			starvingRampStart = sampleAvailable - m_nominalRampLength;
			starvingRampLength = m_nominalRampLength;
			if(starvingRampStart < 0)
			{
				starvingRampStart = 0;
				starvingRampLength = sampleAvailable;
			}
		}
		
		// Determine length of volume change ramping
		s32 volumeChangeRampLength = m_nominalRampLength;
		if(starvingRampStart < volumeChangeRampLength)
		{
			volumeChangeRampLength = starvingRampStart;
		}
		else if(volumeChangeRampLength > nbSample)
		{
			volumeChangeRampLength = nbSample;
		}

		fx1814 currentGain = m_previousLeftGain;
		fx1814 gainIncrement = 0;

#if VOX_NEON_MIXER
		if(neonInstructionsPresent())
		{
			if(m_gain > 16383)
				m_gain = 16383;
		}
#endif

		if(m_isFirstBufferFilled) // Ramping is allowed only if not the first buffer filling.
		{
			// If volume change ramping is not totally overridden by ramp-down, determine its parameters.
			if(volumeChangeRampLength > 0)
			{
				// Set increments used for volume change ramping
				gainIncrement = (m_gain - m_previousLeftGain) / volumeChangeRampLength;

				if(gainIncrement == 0)
				{
					if(m_gain > m_previousLeftGain)
					{
						volumeChangeRampLength = m_gain - m_previousLeftGain;
						gainIncrement = 1;
					}
					else if(m_gain < m_previousLeftGain)
					{
						volumeChangeRampLength = m_previousLeftGain - m_gain;
						gainIncrement = -1;
					}
				}
			}
		}
		else // First buffer being filled for this source. No ramping allowed
		{
			m_isFirstBufferFilled = true;
			currentGain = m_gain;
		}

		s32 currentSample = 0;

		while(nbSample > 0)
		{			
			remainingSample = (m_bufferList[m_currentReadBuffer].m_usedSize >> 2) - m_bufferList[m_currentReadBuffer].m_cursorOffset;
			sampleNeeded = (nbSample <= remainingSample) ? nbSample : remainingSample;
			data = (s16*)(&m_bufferList[m_currentReadBuffer].m_data[m_bufferList[m_currentReadBuffer].m_cursorOffset << 2]);

#if !(VOX_NEON_MIXER)
			if(gainIncrement != 0 || starvingRampLength > 0)	// Samples calculation with volume ramping.
			{
				for(int i = 0; i < sampleNeeded; i++)
				{
					// When starving ramp-down is due, change increments.
					if(currentSample == starvingRampStart)
					{
						gainIncrement = -abs(currentGain / starvingRampLength);
					}

					// During volume change ramping or starving ramp-down, update the gain increments.
					if(currentSample < volumeChangeRampLength || currentSample >= starvingRampStart)
					{
						currentGain += gainIncrement;
					}

					// Fill left channel
					*buffer += ((*data) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
					buffer++;
					data++;
					
					// Fill right channel
					*buffer += ((*data) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
					buffer++;
					data++;

					currentSample++;
				}
			}
			else // No ramping needed
			{
				currentGain = m_gain;

				if(currentGain != 0)
				{
					for(int i = 0; i < sampleNeeded; i++)
					{
						// Fill left channel
						*buffer += ((*data) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
						buffer++;
						data++;
						
						// Fill right channel
						*buffer += ((*data) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
						buffer++;
						data++;
					}
				}
			}
#else // VOX_NEON_MIXER = 1
			
			int volumeChangeRampRemaining;
			int noRampRemaining;
			int starvingRampRemaining;
			if (volumeChangeRampLength <= sampleNeeded)
			{
				volumeChangeRampRemaining = volumeChangeRampLength;
			}
			else
			{
				volumeChangeRampRemaining = sampleNeeded;
			}
			noRampRemaining = sampleNeeded - volumeChangeRampLength;
			if(starvingRampLength <= noRampRemaining)
			{
				noRampRemaining -= starvingRampLength;
				starvingRampRemaining = starvingRampLength;
			}
			else
			{
				starvingRampRemaining = noRampRemaining;
				noRampRemaining = 0;
			}

			bool done;
			if(sampleNeeded > 0)
				done = false;
			else
				done = true;

			while(!done)
			{
				int segmentLength;
				if(volumeChangeRampRemaining > 0) // Process ramp in
				{
					segmentLength = volumeChangeRampRemaining;
				}
				else if (noRampRemaining > 0) // Process straight segment
				{
					segmentLength = noRampRemaining;
					gainIncrement = 0;
				}
				else // Process ramp out
				{
					segmentLength = starvingRampRemaining;
					// Change ramp elsewhere!
				}

				bool neonSegment = true;
				 
				if((int)buffer & 0xf)
				{
					neonSegment = false;
					if((int)buffer & 0x7)
					{
						VOX_WARNING_LEVEL_3("%s", "Vox neon mixer with non-aligned mix buffer!");
					}
					else
					{
						if(segmentLength > 0)
						{
							segmentLength = 1; // process 1 sample in C, then the others in NEON
						}
					}
				}
				else
				{
					if(segmentLength < 16)
					{
						neonSegment = false;
					}
					else
					{
						segmentLength = segmentLength - (segmentLength & 0xf);
					}
				}
				if(!neonInstructionsPresent())
					neonSegment = false;
				if(!neonSegment)
				{
					VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Loop non neon", vox::VoxThread::GetCurThreadId());
					for(int i = 0; i < segmentLength; i++)
					{
						currentGain += gainIncrement;

						// Fill left channel
						*buffer += ((*data) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
						buffer++;
						data++;
				
						// Fill	right channel
						*buffer += ((*data) * currentGain) >> VOX_FX1814_FRACT_SHIFT;
						buffer++;
						data++;
					}
				}
				else // Neon segment
				{
					FillBufferNeonStereo16NoInter(data, buffer, segmentLength, currentGain, currentGain, gainIncrement, gainIncrement);
					data += segmentLength * 2;
					buffer += segmentLength * 2;
					currentGain += gainIncrement * segmentLength;
				}
				if(volumeChangeRampRemaining > 0)
				{
					volumeChangeRampRemaining -= segmentLength;
				}
				else if(noRampRemaining > 0)
				{
					noRampRemaining -= segmentLength;
					if(noRampRemaining == 0)
					{
						if(starvingRampLength != 0)
						{
							gainIncrement = -abs(currentGain / starvingRampLength);
						}
						
					}
				}
				else
				{
					starvingRampRemaining -= segmentLength;
					if(starvingRampRemaining == 0)
					{
						done = true;
					}
				}
			}
			
#endif // VOX_NEON_MIXER
			
			m_processedBytes += (sampleNeeded << 2);

			if(sampleNeeded == remainingSample)
			{
				m_bufferList[m_currentReadBuffer].free = true;
				++m_currentReadBuffer;
				m_currentReadBuffer %= m_numBuffer;
				if(m_bufferList[m_currentReadBuffer].free) //no more data
					break;
			}
			else
			{
				m_bufferList[m_currentReadBuffer].m_cursorOffset += sampleNeeded;
			}

			nbSample -= sampleNeeded;
		}
		
		m_previousLeftGain = currentGain;
		
	}
	
	
}
	
		
void DriverCallbackSourceInterface::FillBufferMono16NoInter(s32* buffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::FillBufferMono16NoInter", vox::VoxThread::GetCurThreadId());
	if(m_state == DriverSource::STATE_PLAYING && !m_bufferList[m_currentReadBuffer].free)
	{
		s16* data;
		s32 sampleNeeded;
		s32 remainingSample;
		fx1814 leftGain = m_gain;
		fx1814 rightGain;
		fx1814 leftPan, rightPan;
		fx1814 gain3D;
		
		// No interpolation needed userPitch*dataPitch = 1
		if(m_bufferList[m_currentReadBuffer].m_cursorPos) //We want to skip interpolation. If between 2 samples => go to next
		{
			m_bufferList[m_currentReadBuffer].m_cursorOffset++;
			m_bufferList[m_currentReadBuffer].m_cursorPos = 0;
		}

		// Get volume attenuation caused by source to listener distance
		gain3D = GetDistanceGain();											
		leftGain = (leftGain * gain3D) >> VOX_FX1814_FRACT_SHIFT;
			
		// Get volume attenuation caused by source directional sound propagation
		gain3D = GetDirectionalGain();
		leftGain = (leftGain * gain3D) >> VOX_FX1814_FRACT_SHIFT;

#if VOX_NEON_MIXER
		if(neonInstructionsPresent())
		{
			if(leftGain > 16383)
				leftGain = 16383;
		}
#endif

		// Get stereo panning due to source position relative to listener. Important to update rightGain before leftGain.
		GetStereoPanning(&leftPan, &rightPan);
		rightGain = (leftGain * rightPan) >> VOX_FX1814_FRACT_SHIFT;
		leftGain = (leftGain * leftPan) >> VOX_FX1814_FRACT_SHIFT;
			
		// Determine limits and lengths of starving ramp-down
		s32 sampleAvailable = GetNbAvailableSamples(nbSample);
		s32 starvingRampStart = nbSample + 1;	// Out-of-bound value (a priori, no ramp-down).
		s32 starvingRampLength = 0;				// A priori, no ramp-down.
		if(sampleAvailable < nbSample)
		{
			starvingRampStart = sampleAvailable - m_nominalRampLength;
			starvingRampLength = m_nominalRampLength;
			if(starvingRampStart < 0)
			{
				starvingRampStart = 0;
				starvingRampLength = sampleAvailable;
			}
		}
		
		// Determine length of volume change ramping
		s32 volumeChangeRampLength = m_nominalRampLength;
		if(starvingRampStart < volumeChangeRampLength)
		{
			volumeChangeRampLength = starvingRampStart;
		}
		else if(volumeChangeRampLength > nbSample)
		{
			volumeChangeRampLength = nbSample;
		}

		fx1814 currentLeftGain = m_previousLeftGain;
		fx1814 currentRightGain = m_previousRightGain;
		fx1814 leftGainIncrement = 0;
		fx1814 rightGainIncrement = 0;

		if(m_isFirstBufferFilled) // Ramping is allowed only if not the first buffer filling.
		{
			// If volume change ramping is not totally overridden by ramp-down, determine its parameters.
			if(volumeChangeRampLength > 0)
			{
				// Set increments used for volume change ramping
				leftGainIncrement = (leftGain - m_previousLeftGain) / volumeChangeRampLength;
				rightGainIncrement = (rightGain - m_previousRightGain) / volumeChangeRampLength;

				if(leftGainIncrement == 0)
				{
					if(leftGain > m_previousLeftGain)
					{
						volumeChangeRampLength = leftGain - m_previousLeftGain;
						leftGainIncrement = 1;
					}
					else if(leftGain < m_previousLeftGain)
					{
						volumeChangeRampLength = m_previousLeftGain - leftGain;
						leftGainIncrement = -1;
					}
				}

				if(rightGainIncrement == 0)
				{
					if(rightGain > m_previousRightGain)
					{
						volumeChangeRampLength = rightGain - m_previousRightGain;
						rightGainIncrement = 1;
					}
					else if(rightGain < m_previousRightGain)
					{
						volumeChangeRampLength = m_previousRightGain - rightGain;
						rightGainIncrement = -1;
					}
				}
			}
		}
		else // First buffer being filled for this source. No ramping allowed
		{
			m_isFirstBufferFilled = true;
			currentLeftGain = leftGain;
			currentRightGain = rightGain;
		}

		s32 currentSample = 0;

		while(nbSample > 0)
		{
			remainingSample = (m_bufferList[m_currentReadBuffer].m_usedSize >> 1) - m_bufferList[m_currentReadBuffer].m_cursorOffset;
			
			sampleNeeded = (nbSample <= remainingSample) ? nbSample : remainingSample;			
			data = (s16*)(&m_bufferList[m_currentReadBuffer].m_data[m_bufferList[m_currentReadBuffer].m_cursorOffset << 1]);

#if !(VOX_NEON_MIXER)
			if(leftGainIncrement != 0 || rightGainIncrement != 0 || starvingRampLength > 0)	// Ramping.
			{
				for(int i = 0; i < sampleNeeded; i++)
				{
					// When starving ramp-down is due, change increments.
					if(currentSample == starvingRampStart)
					{
						leftGainIncrement = -abs(currentLeftGain / starvingRampLength);
						rightGainIncrement = -abs(currentRightGain / starvingRampLength);
					}

					// During volume change ramping or starving ramp-down, update the volume increments.
					if(currentSample < volumeChangeRampLength || currentSample >= starvingRampStart)
					{
						currentLeftGain += leftGainIncrement;
						currentRightGain += rightGainIncrement;
					}

					// Fill left channel
					*buffer += ((*data) * currentLeftGain) >> VOX_FX1814_FRACT_SHIFT;
					buffer++;
					
					// Fill right channel
					*buffer += ((*data) * currentRightGain) >> VOX_FX1814_FRACT_SHIFT;
					buffer++;

					currentSample++;
					data++;
				}
			}
			else // No ramping needed
			{
				currentLeftGain = leftGain;
				currentRightGain = rightGain;

				if(currentLeftGain != 0 || currentRightGain != 0)
				{
					for(int i = 0; i < sampleNeeded; i++)
					{
						// Fill left channel
						*buffer += ((*data) * currentLeftGain) >> VOX_FX1814_FRACT_SHIFT;
						buffer++;
						
						// Fill right channel
						*buffer += ((*data) * currentRightGain) >> VOX_FX1814_FRACT_SHIFT;
						buffer++;

						data++;
					}
				}
			}

#else // VOX_NEON_MIXER = 1

			int volumeChangeRampRemaining;
			int noRampRemaining;
			int starvingRampRemaining;
			if (volumeChangeRampLength <= sampleNeeded)
			{
				volumeChangeRampRemaining = volumeChangeRampLength;
			}
			else
			{
				volumeChangeRampRemaining = sampleNeeded;
			}
			noRampRemaining = sampleNeeded - volumeChangeRampLength;
			if(starvingRampLength <= noRampRemaining)
			{
				noRampRemaining -= starvingRampLength;
				starvingRampRemaining = starvingRampLength;
			}
			else
			{
				starvingRampRemaining = noRampRemaining;
				noRampRemaining = 0;
			}

			bool done;
			if(sampleNeeded > 0)
				done = false;
			else
				done = true;

			while(!done)
			{
				int segmentLength;
				if(volumeChangeRampRemaining > 0) // Process ramp in
				{
					segmentLength = volumeChangeRampRemaining;
				}
				else if (noRampRemaining > 0) // Process straight segment
				{
					segmentLength = noRampRemaining;
					leftGainIncrement = 0;
					rightGainIncrement = 0;
				}
				else // Process ramp out
				{
					segmentLength = starvingRampRemaining;
					// Change ramp elsewhere!
				}

				bool neonSegment = true;
				 
				if((int)buffer & 0xf)
				{
					neonSegment = false;
					if((int)buffer & 0x7)
					{
						VOX_WARNING_LEVEL_3("%s", "Vox neon mixer with non-aligned mix buffer!");
					}
					else
					{
						if(segmentLength > 0)
						{
							segmentLength = 1; // process 1 sample in C, then the others in NEON
						}
					}
				}
				else
				{
					if(segmentLength < 16)
					{
						neonSegment = false;
					}
					else
					{
						segmentLength = segmentLength - (segmentLength & 0xf);
					}
				}
				if(!neonInstructionsPresent())
					neonSegment = false;
				if(!neonSegment)
				{
					VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Loop non neon", vox::VoxThread::GetCurThreadId());
					for(int i = 0; i < segmentLength; i++)
					{
						currentLeftGain += leftGainIncrement;
						currentRightGain += rightGainIncrement;

						// Fill left channel
						*buffer += ((*data) * currentLeftGain) >> VOX_FX1814_FRACT_SHIFT;
						buffer++;
				
						// Fill	right channel
						*buffer += ((*data) * currentRightGain) >> VOX_FX1814_FRACT_SHIFT;
						buffer++;
						data++;
					}
				}
				else // Neon segment
				{
					FillBufferNeonMono16NoInter(data, buffer, segmentLength, currentLeftGain, currentRightGain, leftGainIncrement, rightGainIncrement);
					data += segmentLength;
					buffer += segmentLength * 2;
					currentLeftGain  += leftGainIncrement  * segmentLength;
					currentRightGain += rightGainIncrement * segmentLength;
				}
				if(volumeChangeRampRemaining > 0)
				{
					volumeChangeRampRemaining -= segmentLength;
				}
				else if(noRampRemaining > 0)
				{
					noRampRemaining -= segmentLength;
					if(noRampRemaining == 0)
					{
						if(starvingRampLength != 0)
						{
							leftGainIncrement  = -abs(currentLeftGain / starvingRampLength);
							rightGainIncrement = -abs(currentRightGain / starvingRampLength);
						}
					}
				}
				else
				{
					starvingRampRemaining -= segmentLength;
					if(starvingRampRemaining == 0)
					{
						done = true;
					}
				}
			}
#endif

			m_processedBytes += (sampleNeeded << 1);

			if(sampleNeeded == remainingSample)
			{
				m_bufferList[m_currentReadBuffer].free = true;
				++m_currentReadBuffer;
				m_currentReadBuffer %= m_numBuffer;
				if(m_bufferList[m_currentReadBuffer].free)//no more data
					break;
			}
			else
			{
				m_bufferList[m_currentReadBuffer].m_cursorOffset += sampleNeeded;
			}

			nbSample -= sampleNeeded;
		}

		m_previousLeftGain = currentLeftGain;
		m_previousRightGain = currentRightGain;
	}
}
	
		
	
// Method 'GetDirectionalGain()' calculates the source gain related to direction of propagation. The gain is related to
// the angle between the source-to-listener and source direction vectors as follow:
//
// 1) If the angle is smaller than the cone inner angle, gain = 1.0f
// 2) If the angle is larger than the cone outer angle, gain = m_outerConeGain.
// 3) If the angle is between the cone inner and outer angles, gain is interpolated between 1.0f and m_outerConeGain.
//
// The angle between source-to-listener and sourceDirection vectors is calculted according to:
//
// angle = arccos(sqrt((slVector.sourceDirection)^2 / (slVector^2 * sourceDirection^2)),
//
// when scalar product slVector.sourceDirection is positive. When scalar product is negative, the calculated angle is
// transformed according to "angle = 180 - angle;".
	
fx1814 DriverCallbackSourceInterface::GetDirectionalGain(void)
{		
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::GetDirectionalGain", vox::VoxThread::GetCurThreadId());
	// Calculate gain only if source is directional (but not omni-directional).
	if(m_innerConeAngle < 360.0f && (m_direction.x != 0.0f || m_direction.y != 0.0f || m_direction.z != 0.0f))
	{
		f32 angle;				// Angle between sourceDirection and sourceToListener vectors.
		f32 scalarProduct;
		f32 numerator;
		f32 denominator;
		f32 slVectorX;			// x component of source to listener vector.
		f32 slVectorY;			// y component of source to listener vector.
		f32 slVectorZ;			// z component of source to listener vector.
		f32 slVectorSquare;
		f32 sourceDirectionSquare;
			
		if(m_relativeToListener) // Source position is relative to listener.
		{
			slVectorX = -m_position.x;
			slVectorY = -m_position.y;
			slVectorZ = -m_position.z;
		}
		else // Source position is not relative to listener.
		{
			slVectorX = s_listenerParameters.m_position.x - m_position.x;
			slVectorY = s_listenerParameters.m_position.y - m_position.y;
			slVectorZ = s_listenerParameters.m_position.z - m_position.z;
		}
			
		// Calculate square of scalar product between sourceToListener and sourceDirection vectors.
		scalarProduct = slVectorX * m_direction.x + slVectorY * m_direction.y +	slVectorZ * m_direction.z;
			
		f32 scalarProductSquare = scalarProduct * scalarProduct;	
			
		// Calculate square of length of source-to-listener vector.
		slVectorSquare = slVectorX * slVectorX + slVectorY * slVectorY + slVectorZ * slVectorZ;			
			
		// Calculate square of length of source direction vector.
		sourceDirectionSquare = m_direction.x * m_direction.x + m_direction.y * m_direction.y +
								m_direction.z * m_direction.z;	
			
		// Calculate the angle between source-to-listener and direction vectors (in degrees).
		angle = acos(sqrt(scalarProductSquare / (slVectorSquare * sourceDirectionSquare)));
		angle = angle * ANGLE_180_DEGREES / M_PI; 	// Conversion from radians to degrees.
			
		// Convert angle when scalar product is negative (because argument of acos is positive).
		if(scalarProduct < 0.0f)
		{
			angle = ANGLE_180_DEGREES - angle;
		}
			
		// Get the angle between direction vector and inner cone (half the cone inner angle).
		f32 halfInConeAngle = m_innerConeAngle / 2.0f;
			
		if(angle > halfInConeAngle)
		{
			// Get the angle between direction vector and outer cone (half the cone outer angle).
			f32 halfOutConeAngle = m_outerConeAngle / 2.0f;
				
			// If the source-to-listener vector is located between the inner and outer cones,
			// interpolate the gain between 1.0f and coneOuterGain.
			if(angle < halfOutConeAngle)
			{
				numerator = (halfOutConeAngle - angle) + m_outerConeGain * (angle - halfInConeAngle);
				denominator = halfOutConeAngle - halfInConeAngle;
				if(denominator > 0.0f)
				{
					return((fx1814) (numerator / denominator * VOX_FX1814_ONE));
				}
			}
			else // Angle is larger than halfOutConeAngle, gain = m_outerConeGain.
			{
				return((fx1814) (m_outerConeGain * VOX_FX1814_ONE));
			}
		}
	}
		
	// If source is non-directional or if angle <= halfInConeAngle, gain = 1.0f.
	return(VOX_FX1814_ONE);
}
	
	
// Method 'GetDistanceGain()' calculates volume attenuation induced by source to listener distance. The calculation is
// dependent upon the current distance model.
	
fx1814 DriverCallbackSourceInterface::GetDistanceGain(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::GetDistanceGain", vox::VoxThread::GetCurThreadId());
	f32 distanceX;
	f32 distanceY;
	f32 distanceZ;
	f32 distance;
	f32 numerator = 1.0f;
	f32 denominator = 1.0f;
	f32 attenuation;
	f32 effectiveRolloff = m_rolloffFactor;
#if VOX_ENHANCED_3D
	if(m_trackParams.numChannels == 1)
	{
		if(!(m_relativeToListener &&
		   m_position.x == 0.f && 
		   m_position.y == 0.f && 
		   m_position.z == 0.f))
		{
			effectiveRolloff *= s_tweakParameters.enhanced3dRolloffFactor;
		}
	}
#endif // VOX_ENHANCED_3D

	if(m_relativeToListener) // Source position is relative to listener.
	{
		distanceX = m_position.x;
		distanceY = m_position.y;
		distanceZ = m_position.z;
	}
	else // Source position is not relative to listener.
	{
		distanceX = m_position.x - s_listenerParameters.m_position.x;
		distanceY = m_position.y - s_listenerParameters.m_position.y;
		distanceZ = m_position.z - s_listenerParameters.m_position.z;
	}
	
	distance = sqrt(distanceX * distanceX + distanceY * distanceY + distanceZ * distanceZ);
	
	// Evaluate volume attenuation according to distance model.
	if(s_distanceModel == Vox3DDistanceModel::k_nInverseDistanceClamped)
	{
		if(distance < m_referenceDistance)
		{
			distance = m_referenceDistance;
		}
		else if(distance > m_maxDistance)
		{
			distance = m_maxDistance;
		}
		
		denominator = m_referenceDistance + effectiveRolloff * (distance - m_referenceDistance);
		
		if(denominator > 0.0f)
		{			
			return((fx1814) (m_referenceDistance / denominator * VOX_FX1814_ONE));
		}
	}
	else if(s_distanceModel == Vox3DDistanceModel::k_nLinearDistanceClamped)
	{
		if(distance < m_referenceDistance)
		{
			distance = m_referenceDistance;
		}
		else if(distance > m_maxDistance)
		{
			distance = m_maxDistance;
		}
		
		numerator = (distance - m_referenceDistance) * effectiveRolloff;
		denominator = m_maxDistance - m_referenceDistance;
		
		if(denominator > 0.0f)
		{
			attenuation = 1.0f - (numerator / denominator);
			if(attenuation < 0.0f)
			{
				attenuation = 0.0f;
			}
			return((fx1814) (attenuation * VOX_FX1814_ONE));
		}		
	}
	else if(s_distanceModel == Vox3DDistanceModel::k_nExponentDistanceClamped)
	{	
		if(effectiveRolloff > 0.0f && m_referenceDistance > 0.0f)
		{		
			if(distance < m_referenceDistance)
			{
				distance = m_referenceDistance;
			}
			else if(distance > m_maxDistance)
			{
				distance = m_maxDistance;
			}
			
			attenuation = pow(distance / m_referenceDistance, -effectiveRolloff);
			return((fx1814) (attenuation * VOX_FX1814_ONE));
		}					
	}
	
	return VOX_FX1814_ONE;
}
	

// Method 'GetDopplerPitch()' calculates doppler shift based on a formula taken from the OpenAL 1.1 Specification.
// However, calculations differ slightly from the specification in order to minimize multiplications and divisions
// (while keeping the same result). The implemented formula is :
//	
// dopplerShitf = (psv - plv) / ((speedOfSound / dopplerFactor) * slVectorLength - psv)
// and
// psv = projected source velocity (projected on source to listener vector).
// plv = projected listener velocity (projected on source to listener vector).
// m_speedOfSound = speed of sound
// DopplerFactor = doppler factor.
// slVectorLength = magnitude of source to listener vector.
	
f32 DriverCallbackSourceInterface::GetDopplerPitch(void)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::GetDopplerPitch", vox::VoxThread::GetCurThreadId());
	if(s_dopplerFactor > 0.0f)
	{
		f32 slVectorX;
		f32 slVectorY;
		f32 slVectorZ;
		f32 plv = 0.0f;
		f32	psv;
		
		// Calculate source to listener vector.
		if(m_relativeToListener)				// Source position is relative to listener.
		{
			slVectorX = -m_position.x;
			slVectorY = -m_position.y;
			slVectorZ = -m_position.z;
		}
		else // Source position is not relative to listener.
		{
			slVectorX = s_listenerParameters.m_position.x - m_position.x;
			slVectorY = s_listenerParameters.m_position.y - m_position.y;
			slVectorZ = s_listenerParameters.m_position.z - m_position.z;
			
			// Calculate projection of listener velocity on sourceToListener vector.
			plv = (s_listenerParameters.m_velocity.x * slVectorX +
				   s_listenerParameters.m_velocity.y * slVectorY +
				   s_listenerParameters.m_velocity.z * slVectorZ);
		}
			
		// Calculate the length of source to listener vector.
		f32 slVectorLength = sqrt(slVectorX * slVectorX + slVectorY * slVectorY + slVectorZ * slVectorZ);

		// Calculate projection of source velocity on sourceToListener vector.
		psv = (m_velocity.x * slVectorX + m_velocity.y * slVectorY + m_velocity.z * slVectorZ);
			
		// Limit source and listener absolute velocities with the speedOfSound/dopplerFactor ratio.
		f32 speedOfSoundFactor = s_alteredSpeedOfSound * slVectorLength;
		
		// Limit projected listener velocity to speedOfSoundFactor
		if(plv > speedOfSoundFactor)
		{
			plv = speedOfSoundFactor;
		}

		f32 denominator = speedOfSoundFactor - psv;
			
		// Return calculated pitch only is denominator is larger than 0.
		if(denominator > 0.0f)
		{
			float dopplerPitch = (1.0f + (psv - plv) / denominator);
			if(dopplerPitch > MAX_DOPPLER_PITCH)
			{
				dopplerPitch = MAX_DOPPLER_PITCH;
			}
			else if(dopplerPitch < MIN_DOPPLER_PITCH)
			{
				dopplerPitch = MIN_DOPPLER_PITCH;
			}
			
			return dopplerPitch;
		}
	}
	
	return 1.0f;
}


// Method 'GetStereoPanning()' returns gains for the left and right channels according to the source position relative
// to listener orientation. Calculations are performed using the following steps:
//
// 1) The relative position between source and listener is calculated and the 'listener to source' vector is normalized.
// 2) Vector product between the listener's 'at' and 'up' orientation vectors is performed and the calculated vector is
//	  normalized. This vector is orthogonal to both the 'at' and 'up' vector and points to the right of the listener.
// 3) The normalized 'listener to source' vector is projected upon the vector calculated in item (2) by taking the scalar
//	  of both vectors, providing a value between -1.0 and 1.0.
// 4) Right gain is calculated from the projection generated in item (3) through rightGain = sqrt(0.5f * (1.0f + projection));
// 5) Left gain is calculated from the right gain through leftGain = sqrt(1.0f - rightGain^2);
//
// NOTE : When source is relative to listener, the 'at x up' vector equals (1, 0, 0) thus the projected vector calculated in
//        item (3) simply corresponds to the 'x' coordinate of the source position.
	
void DriverCallbackSourceInterface::GetStereoPanning(fx1814 *leftPan, fx1814 *rightPan)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::GetStereoPanning", vox::VoxThread::GetCurThreadId());
	f32 positionX;
	f32 positionY;
	f32 positionZ;
	f32 leftPanFloat;
	f32 rightPanFloat;
		
	if(m_relativeToListener)
	{
		// Calculate the norm of the source (relative) position vector.
		f32 positionNorm = sqrt(m_position.x * m_position.x + m_position.y * m_position.y + m_position.z * m_position.z);
			
		if(positionNorm > 0.0f)
		{
			positionX = m_position.x / positionNorm;
		}
		else
		{
			positionX = 0.0f;
		}
			
	}
	else // Source position is not relative to listener.
	{
		// Get source position relative to listener.
		positionX = m_position.x - s_listenerParameters.m_position.x;
		positionY = m_position.y - s_listenerParameters.m_position.y;
		positionZ = m_position.z - s_listenerParameters.m_position.z;
		
		// Calculate the norm of the source (relative) position vector.
		f32 positionNorm = sqrt(positionX * positionX + positionY * positionY +	positionZ * positionZ);
		
		// Calculate vector product between 'at' and 'up' vectors
		f32 atUpVectorProductX = s_listenerParameters.m_atOrientation.y * s_listenerParameters.m_upOrientation.z -
								 s_listenerParameters.m_atOrientation.z * s_listenerParameters.m_upOrientation.y;
		f32 atUpVectorProductY = s_listenerParameters.m_atOrientation.z * s_listenerParameters.m_upOrientation.x -
								 s_listenerParameters.m_atOrientation.x * s_listenerParameters.m_upOrientation.z;
		f32 atUpVectorProductZ = s_listenerParameters.m_atOrientation.x * s_listenerParameters.m_upOrientation.y - 
								 s_listenerParameters.m_atOrientation.y * s_listenerParameters.m_upOrientation.x;

		// Calculate the norm of the ('at' x 'up') vector product.
		f32 atUpNorm = sqrt(atUpVectorProductX * atUpVectorProductX + atUpVectorProductY * atUpVectorProductY +
							atUpVectorProductZ * atUpVectorProductZ);
			
		if(positionNorm > 0.0f && atUpNorm > 0.0f)
		{
			// Normalize source (relative) position
			positionX /= positionNorm;
			positionY /= positionNorm;
			positionZ /= positionNorm;
				
			// Normalize ('at' x 'up') vector product.
			atUpVectorProductX /= atUpNorm;
			atUpVectorProductY /= atUpNorm;
			atUpVectorProductZ /= atUpNorm;
				
			// Project the 'listener to source' vector upon the 'at' x 'up' vector product.
			positionX = positionX * atUpVectorProductX + positionY * atUpVectorProductY + positionZ * atUpVectorProductZ;
		}
		else
		{
			positionX = 0.0f;
		}
	}

	// Transform the projected vector 'positionX' to left and right panning values.
	rightPanFloat = sqrt(((VOX_MAX_STEREO_PANNING_POWER - 0.5f) * positionX) + 0.5f);
	leftPanFloat = sqrt(1.0f - rightPanFloat * rightPanFloat);
	*leftPan = (fx1814) (leftPanFloat * VOX_FX1814_ONE);
	*rightPan = (fx1814) (rightPanFloat * VOX_FX1814_ONE);
}
	


void DriverCallbackSourceInterface::GetNormalizedPosition(f32 *resultX, f32 *resultY, f32 *resultZ)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::GetStereoPanning", vox::VoxThread::GetCurThreadId());
	f32 positionX;
	f32 positionY;
	f32 positionZ;

		
	if(m_relativeToListener)
	{
		// Calculate the norm of the source (relative) position vector.
		f32 positionNorm = sqrt(m_position.x * m_position.x + m_position.y * m_position.y + m_position.z * m_position.z);
			
		if(positionNorm > 0.0f)
		{
			*resultX = m_position.x / positionNorm;
			*resultY = m_position.y / positionNorm;
			*resultZ = m_position.z / positionNorm;
			return;
		}
		else
		{
			*resultX = 0.0f;
			*resultY = 0.0f;
			*resultZ = 0.0f;
			return;
		}
			
	}
	else // Source position is not relative to listener.
	{
		// Get source position relative to listener.
		positionX = m_position.x - s_listenerParameters.m_position.x;
		positionY = m_position.y - s_listenerParameters.m_position.y;
		positionZ = m_position.z - s_listenerParameters.m_position.z;
		
		// Calculate the norm of the source (relative) position vector.
		f32 positionNorm = sqrt(positionX * positionX + positionY * positionY +	positionZ * positionZ);
		
		// Calculate vector product between 'at' and 'up' vectors
		f32 atUpVectorProductX = s_listenerParameters.m_atOrientation.y * s_listenerParameters.m_upOrientation.z -
								 s_listenerParameters.m_atOrientation.z * s_listenerParameters.m_upOrientation.y;
		f32 atUpVectorProductY = s_listenerParameters.m_atOrientation.z * s_listenerParameters.m_upOrientation.x -
								 s_listenerParameters.m_atOrientation.x * s_listenerParameters.m_upOrientation.z;
		f32 atUpVectorProductZ = s_listenerParameters.m_atOrientation.x * s_listenerParameters.m_upOrientation.y - 
								 s_listenerParameters.m_atOrientation.y * s_listenerParameters.m_upOrientation.x;

		// Recalculate up vector to make sure it is at 90 degrees from the "look at" vector
		f32 upCrossX = s_listenerParameters.m_atOrientation.z * atUpVectorProductY -
					   s_listenerParameters.m_atOrientation.y * atUpVectorProductZ;
		f32 upCrossY = s_listenerParameters.m_atOrientation.x * atUpVectorProductZ -
					   s_listenerParameters.m_atOrientation.z * atUpVectorProductX;
		f32 upCrossZ = s_listenerParameters.m_atOrientation.y * atUpVectorProductX -
					   s_listenerParameters.m_atOrientation.x * atUpVectorProductY;

		// Calculate the norm of the ('up') vector.
		f32 upNorm = sqrt( upCrossX * upCrossX
		                 + upCrossY * upCrossY
		                 + upCrossZ * upCrossZ);

		// Calculate the norm of the ('at') vector.
		f32 atNorm = sqrt( s_listenerParameters.m_atOrientation.x * s_listenerParameters.m_atOrientation.x
		                 + s_listenerParameters.m_atOrientation.y * s_listenerParameters.m_atOrientation.y
		                 + s_listenerParameters.m_atOrientation.z * s_listenerParameters.m_atOrientation.z);

		// Calculate the norm of the ('at' x 'up') vector product.
		f32 atUpNorm = sqrt(atUpVectorProductX * atUpVectorProductX + atUpVectorProductY * atUpVectorProductY +
							atUpVectorProductZ * atUpVectorProductZ);
			
		if(positionNorm>0.0f && atNorm>0.0f && upNorm>0.0f && atUpNorm>0.0f)
		{
			// Normalize source (relative) position
			positionX /= positionNorm;
			positionY /= positionNorm;
			positionZ /= positionNorm;
			
			*resultX = positionX * atUpVectorProductX
			         + positionY * atUpVectorProductY
			         + positionZ * atUpVectorProductZ;

			*resultY = positionX * upCrossX
			         + positionY * upCrossY
			         + positionZ * upCrossZ;

			*resultZ = positionX * s_listenerParameters.m_atOrientation.x
			         + positionY * s_listenerParameters.m_atOrientation.y
			         + positionZ * s_listenerParameters.m_atOrientation.z;

			// Multiply by norm for correct result;
			*resultX /= atUpNorm;
			*resultY /= upNorm;
			*resultZ /= atNorm;
			return;
		}
		else
		{
			*resultX = 0.0f;
			*resultY = 0.0f;
			*resultZ = 0.0f;
			return;
		}
	}

	// This code should be unreachable
	*resultX = 0.0f;
	*resultY = 0.0f;
	*resultZ = 0.0f;
	return;

}

s32 DriverCallbackSourceInterface::GetNbAvailableSamples(s32 nbSamplesNeeded)
{
	s32 nbAvailableSamples = 0;
	s32 currentBuffer = m_currentReadBuffer;

	for(s32 i = 0; i < m_numBuffer; i++)
	{
		if(m_bufferList[currentBuffer].free)
		{
			return nbAvailableSamples;
		}
		else // Buffer is not free, 
		{
			nbAvailableSamples += (m_bufferList[currentBuffer].m_usedSize / m_bytesPerSample) - m_bufferList[currentBuffer].m_cursorOffset;
			if(nbAvailableSamples >= nbSamplesNeeded)
			{
				// No starving, do not ramp down.
				return nbSamplesNeeded;
			}
			else // Still needing samples, get next buffer
			{
				currentBuffer++;
				currentBuffer %= m_numBuffer;
			}
		}
	}
	// Should never get here ! Means that no buffer is free and their total samples is smaller than request
	return -1;
}


s32 DriverCallbackSourceInterface::GetWorkData(u8* outbuf, s32 nbBytes, fx1814 nbSamples)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackSourceInterface::GetWorkData", vox::VoxThread::GetCurThreadId());
	if( m_bufferList[m_currentReadBuffer].free)
		return 0;

	s32 neededBytes = nbBytes;

	while(neededBytes > 0)
	{
		s32 currentBufferPos = m_bufferList[m_currentReadBuffer].m_cursorOffset * m_bytesPerSample;
		s32 currentBufferBytes = m_bufferList[m_currentReadBuffer].m_usedSize - currentBufferPos;
		s32 currentOutputPos = nbBytes - neededBytes;
		if(currentBufferBytes > neededBytes)
		{
			memcpy(outbuf + currentOutputPos, &(m_bufferList[m_currentReadBuffer].m_data[currentBufferPos]), neededBytes);
			neededBytes = 0;
			m_bufferList[m_currentReadBuffer].m_cursorPos += nbSamples;
			m_bufferList[m_currentReadBuffer].m_cursorOffset += (m_bufferList[m_currentReadBuffer].m_cursorPos >> VOX_FX1814_FRACT_SHIFT);
			m_bufferList[m_currentReadBuffer].m_cursorPos &= VOX_FX1814_FRACT_MASK;
		}
		else
		{
			memcpy(outbuf + currentOutputPos, &(m_bufferList[m_currentReadBuffer].m_data[currentBufferPos]), currentBufferBytes);
			neededBytes -= currentBufferBytes;
			m_bufferList[m_currentReadBuffer].m_cursorPos += nbSamples;
			m_bufferList[m_currentReadBuffer].m_cursorOffset += (m_bufferList[m_currentReadBuffer].m_cursorPos >> VOX_FX1814_FRACT_SHIFT);
			m_bufferList[m_currentReadBuffer].m_cursorPos &= VOX_FX1814_FRACT_MASK;

			fx1814 totalBufferSample = m_bufferList[m_currentReadBuffer].m_usedSize / m_bytesPerSample;
			nbSamples = ((m_bufferList[m_currentReadBuffer].m_cursorOffset - totalBufferSample) << VOX_FX1814_FRACT_SHIFT) + m_bufferList[m_currentReadBuffer].m_cursorPos;

			if(m_bufferList[m_currentReadBuffer].m_cursorOffset < (u32) totalBufferSample)
			{
				s32 nextBuffer = (m_currentReadBuffer + 1) % m_numBuffer;
				if(m_bufferList[nextBuffer].free)
				{
					m_bufferList[m_currentReadBuffer].free = true; //No next data so consider current buffer completed
					m_currentReadBuffer++;
					m_currentReadBuffer %= m_numBuffer;
				}
				else if(neededBytes > 0)
				{
					memcpy(outbuf + currentOutputPos + currentBufferBytes, m_bufferList[nextBuffer].m_data, m_bytesPerSample);
					neededBytes -= m_bytesPerSample;
				}
				break;
			}
			else
			{
				m_bufferList[m_currentReadBuffer].free = true;
				m_currentReadBuffer++;
				m_currentReadBuffer %= m_numBuffer;
				if(m_bufferList[m_currentReadBuffer].free)
					break;
			}
		}
	}

	m_processedBytes += (nbBytes - neededBytes);
	return (nbBytes - neededBytes);
}

void DriverCallbackSourceInterface::FreeAllBuffer()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::FreeAllBuffer", vox::VoxThread::GetCurThreadId());
	for(int i = 0; i < m_numBuffer; i++)
	{
		m_bufferList[i].free = true;
		m_currentReadBuffer = 0;
		m_currentWriteBuffer = 0;
	}
}

void DriverCallbackSourceInterface::Set3DParameters(ListenerParameters listenerParameters, Vox3DGeneralParameters parameters3D)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackSourceInterface::Set3DParameters", vox::VoxThread::GetCurThreadId());
	s_listenerParameters = listenerParameters;
	s_distanceModel = parameters3D.distanceModel;
	s_dopplerFactor = parameters3D.dopplerFactor;
	s_enable3dSimulation = parameters3D.enhanced3d;

	s_tweakParameters.enhanced3dStereoPanningPower  = parameters3D.enhanced3dStereoPanningPower;
	s_tweakParameters.enhanced3dStereoMaxDelayFront = parameters3D.enhanced3dStereoMaxDelayFront;
	s_tweakParameters.enhanced3dStereoMaxDelayBack  = parameters3D.enhanced3dStereoMaxDelayBack;
	
	s_tweakParameters.enhanced3dNotchDepth         = parameters3D.enhanced3dNotchDepth;
	s_tweakParameters.enhanced3dNotchDepthSide     = parameters3D.enhanced3dNotchDepthSide;
	s_tweakParameters.enhanced3dNotchDepthBack     = parameters3D.enhanced3dNotchDepthBack;
	s_tweakParameters.enhanced3dNotchDepthDistance = parameters3D.enhanced3dNotchDepthDistance;

	s_tweakParameters.enhanced3dNotchWidth         = parameters3D.enhanced3dNotchWidth;
	s_tweakParameters.enhanced3dNotchWidthSide     = parameters3D.enhanced3dNotchWidthSide;
	s_tweakParameters.enhanced3dNotchWidthBack     = parameters3D.enhanced3dNotchWidthBack;
	s_tweakParameters.enhanced3dNotchWidthDistance = parameters3D.enhanced3dNotchWidthDistance;

	s_tweakParameters.enhanced3dDistanceWidthMinimum = parameters3D.enhanced3dDistanceWidthMinimum;
	s_tweakParameters.enhanced3dDistanceWidthMaximum = parameters3D.enhanced3dDistanceWidthMaximum;
	s_tweakParameters.enhanced3dDistanceWidthCurve   = parameters3D.enhanced3dDistanceWidthCurve;
	s_tweakParameters.enhanced3dDistanceWidthSide    = parameters3D.enhanced3dDistanceWidthSide;
	s_tweakParameters.enhanced3dDistanceWidthBack    = parameters3D.enhanced3dDistanceWidthBack;
	s_tweakParameters.enhanced3dDistanceFrequency    = parameters3D.enhanced3dDistanceFrequency;

	s_tweakParameters.enhanced3dRolloffFactor = parameters3D.enhanced3dRolloffFactor;

	if(s_dopplerFactor > 0.0f)
	{
		s_alteredSpeedOfSound = parameters3D.speedOfSound / s_dopplerFactor;
	}
	else
	{
		s_alteredSpeedOfSound = parameters3D.speedOfSound;
	}
}


void DriverCallbackSourceInterface::SetDriverCallbackPeriod(f32 period)
{
	s_driverCallbackPeriod = static_cast<fx1814> (period * VOX_FX1814_ONE);
	MinibusDataGeneratorInterface::s_driverCallbackPeriod = fx1814 (period * VOX_FX1814_ONE);
}


void DriverCallbackSourceInterface::SetDriverSampleRate(s32 sampleRate)
{
	s_driverSampleRate = sampleRate;
	MinibusDataGeneratorInterface::s_driverSampleRate = sampleRate;

	// Provide bus manager with driver sample rate
	MiniBusManager *pBusManager = MiniBusManager::GetInstance();
	if(pBusManager)
	{
		pBusManager->SetDriverSampleRate(sampleRate);
	}
}


//*** DriverCallbackInterface ***//

DriverInternalBuffer DriverCallbackInterface::m_sWorkBuffer = DriverInternalBuffer();
DriverMixingBuffer DriverCallbackInterface::m_sMixingBuffer = DriverMixingBuffer();
	
DriverCallbackInterface::DriverCallbackInterface():
m_audioUnitActive(false)
,m_nextSourceId(1)
{
}

DriverCallbackInterface::~DriverCallbackInterface()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::~DriverCallbackInterface", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	m_sWorkBuffer.m_size = 0;
	if(m_sWorkBuffer.m_buffer)
		VOX_FREE(m_sWorkBuffer.m_buffer);
	m_sWorkBuffer.m_buffer = 0;

	m_sMixingBuffer.m_nbSample = 0; 
	if(m_sMixingBuffer.m_mixingBuffer)
		VOX_FREE(m_sMixingBuffer.m_mixingBuffer);
	m_sMixingBuffer.m_mixingBuffer = 0;

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverCallbackInterface::Init(void* param)
{
	// Initialize static buffer
	m_sWorkBuffer.m_size = 0;
	m_sWorkBuffer.m_buffer = 0;
	m_sMixingBuffer.m_nbSample = 0; 
	m_sMixingBuffer.m_mixingBuffer = 0;
	
}

void DriverCallbackInterface::Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::Update", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	_Update(dt);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverCallbackInterface::_Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::_Update", vox::VoxThread::GetCurThreadId());
	MiniBusManager *pBusManager = MiniBusManager::GetInstance();
	if(pBusManager)
	{
		pBusManager->Update(dt);
	}
}

DriverSourceInterface* DriverCallbackInterface::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::CreateDriverSource", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);
	
	DriverCallbackSourceInterface* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverCallbackSourceInterface(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_nextSourceId++;

			// Register driver source to master bus by default (can be overriden with source's SetDSPParameter()).
			MiniBusManager *pBusManager = MiniBusManager::GetInstance();
			if(pBusManager)
			{
				pBusManager->AttachDataGeneratorToBus(VOX_MINIBUS_MASTER, &driverSource->m_dataGenerator);
			}
			else
			{
				VOX_DELETE(driverSource);
				driverSource = 0;
			}
		}
	}

	return driverSource;
}

void DriverCallbackInterface::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::DestroyDriverSource", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);
	
	if(driverSource)
	{
		MiniBusManager *pBusManager = MiniBusManager::GetInstance();
		if(pBusManager)
		{
			DriverCallbackSourceInterface *driverCallbackSource = static_cast<DriverCallbackSourceInterface*> (driverSource);
			pBusManager->DetachDataGeneratorFromBus(&driverCallbackSource->m_dataGenerator);
		}

		VOX_DELETE(static_cast<DriverCallbackSourceInterface*> (driverSource));

	}

}


void DriverCallbackInterface::Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::Set3DParameter", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	_Set3DParameter(paramId, param);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverCallbackInterface::_Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::_Set3DParameter", vox::VoxThread::GetCurThreadId());
	//if(m_audioUnitActive)
	{
		switch(paramId)
		{
			case Vox3DGeneralParameter::k_nDopplerFactor:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Doppler factor' to %f", value);
				m_3DGeneralParameters.dopplerFactor = value;
				break;
			}
			case Vox3DGeneralParameter::k_nSpeedOfSound:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Speed of sound' to %f", value);
				m_3DGeneralParameters.speedOfSound = value;
				break;
			}
			case Vox3DGeneralParameter::k_nDistanceModel: 
			{
				u32 value = *((u32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Distance model' to %x", value);
				m_3DGeneralParameters.distanceModel = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3d: 
			{
				u32 value = *((u32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Enhanced 3d' to %x", value);
				m_3DGeneralParameters.enhanced3d = value;
				break;
			}

			case Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'StereoPanningPower' to %f", value);
				m_3DGeneralParameters.enhanced3dStereoPanningPower = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'StereoMaxDelayFront' to %f", value);
				m_3DGeneralParameters.enhanced3dStereoMaxDelayFront = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'StereoMaxDelayBack' to %f", value);
				m_3DGeneralParameters.enhanced3dStereoMaxDelayBack = value;
				break;
			}
	
			case Vox3DGeneralParameter::k_nEnhanced3dNotchDepth:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'NotchDepth' to %f", value);
				m_3DGeneralParameters.enhanced3dNotchDepth = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'NotchDepthSide' to %f", value);
				m_3DGeneralParameters.enhanced3dNotchDepthSide = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'NotchDepthBack' to %f", value);
				m_3DGeneralParameters.enhanced3dNotchDepthBack = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'NotchDepthDistance' to %f", value);
				m_3DGeneralParameters.enhanced3dNotchDepthDistance = value;
				break;
			}


			case Vox3DGeneralParameter::k_nEnhanced3dNotchWidth:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'NotchWidth' to %f", value);
				m_3DGeneralParameters.enhanced3dNotchWidth = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'NotchWidthSide' to %f", value);
				m_3DGeneralParameters.enhanced3dNotchWidthSide = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'NotchWidthBack' to %f", value);
				m_3DGeneralParameters.enhanced3dNotchWidthBack = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'NotchWidthDistance' to %f", value);
				m_3DGeneralParameters.enhanced3dNotchWidthDistance = value;
				break;
			}


			case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'DistanceWidthMinimum' to %f", value);
				m_3DGeneralParameters.enhanced3dDistanceWidthMinimum = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'DistanceWidthMaximum' to %f", value);
				m_3DGeneralParameters.enhanced3dDistanceWidthMaximum = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'DistanceWidthCurve' to %f", value);
				m_3DGeneralParameters.enhanced3dDistanceWidthCurve = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'DistanceWidthSide' to %f", value);
				m_3DGeneralParameters.enhanced3dDistanceWidthSide = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'DistanceWidthBack' to %f", value);
				m_3DGeneralParameters.enhanced3dDistanceWidthBack = value;
				break;
			}
			case Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'DistanceFrequency' to %f", value);
				m_3DGeneralParameters.enhanced3dDistanceFrequency = value;
				break;
			}


			case Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting Enhanced 3d tweak parameter 'RolloffFactor' to %f", value);
				m_3DGeneralParameters.enhanced3dRolloffFactor = value;
				break;
			}


			case Vox3DGeneralParameter::k_nListenerPosition:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				m_listener.m_position.x = vector->x;
				m_listener.m_position.y = vector->y;
				m_listener.m_position.z = vector->z;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerVelocity:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				m_listener.m_velocity.x = vector->x;
				m_listener.m_velocity.y = vector->y;
				m_listener.m_velocity.z = vector->z;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerOrientation:
			{
				VoxVector3f* vector = (VoxVector3f*)param;

				m_listener.m_atOrientation.x = vector[0].x;
				m_listener.m_atOrientation.y = vector[0].y;
				m_listener.m_atOrientation.z = vector[0].z;
				m_listener.m_upOrientation.x = vector[1].x;
				m_listener.m_upOrientation.y = vector[1].y;
				m_listener.m_upOrientation.z = vector[1].z;
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("Driver doesn't support property %d", paramId);
				break;
			}
		}
	}
}

void DriverCallbackInterface::SetDefaultParameter()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::SetDefaultParameter", vox::VoxThread::GetCurThreadId());
	VOX_WARNING_LEVEL_5("%s", "Setting default parameter to callback driver");
	f32 fvalue;
	u32 uivalue;

	// Doppler factor
	fvalue = VOX_DEFAULT_3D_DOPPLER_FACTOR;
	_Set3DParameter(Vox3DGeneralParameter::k_nDopplerFactor, &fvalue);

	// Speed of sound
	fvalue = VOX_DEFAULT_3D_SPEED_OF_SOUND;
	_Set3DParameter(Vox3DGeneralParameter::k_nSpeedOfSound, &fvalue);

	// 3D attenuation model
	uivalue = VOX_DEFAULT_3D_MODEL;
	_Set3DParameter(Vox3DGeneralParameter::k_nDistanceModel, &uivalue);	
	
	// 3D enhanced processing
	uivalue = VOX_DEFAULT_3D_ENHANCED_3D;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3d, &uivalue);	

	// Listener position
	f32 position[3] = VOX_DEFAULT_3D_LISTENER_POSITION;
	VoxVector3f positionv = VoxVector3f(position);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerPosition, &positionv);

	// Listener velocity
	f32 velocity[3] = VOX_DEFAULT_3D_LISTENER_VELOCITY;
	VoxVector3f velocityv = VoxVector3f(velocity);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerVelocity, &velocityv);

	// Listener Orientation
	f32 lookat[3] = VOX_DEFAULT_3D_LISTENER_LOOKAT;
	f32 up[3] = VOX_DEFAULT_3D_LISTENER_UP;
	VoxVector3f orientationv[2];
	orientationv[0] = VoxVector3f(lookat);
	orientationv[1] = VoxVector3f(up);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerOrientation, &orientationv);

	// Enhanced 3d tweaking parameters
	fvalue = VOX_DEFAULT_ENHANCED_3D_STEREO_PANNING_POWER;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower, &fvalue);	
	fvalue = VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_FRONT;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront, &fvalue);
	fvalue = VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_BACK;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack, &fvalue); 
	
	fvalue = VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchDepth, &fvalue);        
	fvalue = VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_SIDE;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide, &fvalue);    
	fvalue = VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_BACK;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack, &fvalue);    
	fvalue = VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_DISTANCE;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance, &fvalue);

	fvalue = VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchWidth, &fvalue);        
	fvalue = VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_SIDE;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide, &fvalue);    
	fvalue = VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_BACK;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack, &fvalue);    
	fvalue = VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_DISTANCE;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance, &fvalue);

	fvalue = VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MINIMUM;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum, &fvalue);
	fvalue = VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MAXIMUM;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum, &fvalue);
	fvalue = VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_CURVE;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve, &fvalue); 
	fvalue = VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_SIDE;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide, &fvalue);   
	fvalue = VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_BACK;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack, &fvalue);   
	fvalue = VOX_DEFAULT_ENHANCED_3D_DISTANCE_FREQUENCY;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency, &fvalue);   

	fvalue = VOX_DEFAULT_ENHANCED_3D_ROLLOFF_FACTOR;
	_Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor, &fvalue);

}
	

void DriverCallbackInterface::SetDSPParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCallbackInterface::SetDSPParameter", vox::VoxThread::GetCurThreadId());

	switch(paramId)
	{
		case VoxDSPGeneralParameter::k_nRoutingVolume:
		{
			MiniBusManager *pBusManager = MiniBusManager::GetInstance();
			if(pBusManager)
				pBusManager->SetBusRoutingVolumeChange((BusRoutingChange*)param);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("PS3 MultiStream driver doesn't support dsp property %d", paramId);
			break;
		}
	}
}

void DriverCallbackInterface::FillBuffer(s16* outBuffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackInterface::FillBuffer", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();
	if(m_audioUnitActive)
	{
		_FillBuffer(outBuffer, nbSample);
	}
	m_mutex.Unlock();
}


void DriverCallbackInterface::_FillBuffer(s16* outBuffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackInterface::_FillBuffer", vox::VoxThread::GetCurThreadId());
	s32 totalSamples = nbSample << 1;	// << 1 to include left and right channels.
	
	// Provide listener and general 3D parameters to all sources
	DriverCallbackSourceInterface::Set3DParameters(m_listener, m_3DGeneralParameters);
		
	if(nbSample > m_sMixingBuffer.m_nbSample)
	{
		//reallocate buffer
		if(m_sMixingBuffer.m_mixingBuffer)
		{
			VOX_FREE(m_sMixingBuffer.m_mixingBuffer);
		}
			
		m_sMixingBuffer.m_mixingBuffer = (s32*)VOX_ALLOC(sizeof(s32) * totalSamples);

		if(m_sMixingBuffer.m_mixingBuffer)
		{
			m_sMixingBuffer.m_nbSample = nbSample;
		}
		else
		{
			m_sMixingBuffer.m_nbSample = 0;
			nbSample = 0;
		}
	}
		
	if(m_sMixingBuffer.m_nbSample > 0)
	{
		memset(m_sMixingBuffer.m_mixingBuffer, 0, totalSamples * sizeof(s32)); //clear buffer

		MiniBusManager *pBusManager = MiniBusManager::GetInstance();
		if(pBusManager)
		{
			MiniMasterBus *pMasterBus = pBusManager->GetMasterBus();
			if(pMasterBus)
				pMasterBus->FillBuffer(m_sMixingBuffer.m_mixingBuffer, nbSample);
		}
		
		s32 *mixingBufferCursor = m_sMixingBuffer.m_mixingBuffer;
		s16 *outBufferCursor = outBuffer;
		for(int i = 0; i < totalSamples; i++)
		{
			if ((u32) (*mixingBufferCursor + 32768) > 65535)
				*outBufferCursor = (s16)(*mixingBufferCursor < 0 ? -32768 : 32767);
			else
				*outBufferCursor = (s16) (*mixingBufferCursor);
			outBufferCursor++;
			mixingBufferCursor++;
		}
	}
}
	

DriverInternalBuffer* DriverCallbackInterface::GetWorkBuffer(int size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCallbackInterface::GetWorkBuffer", vox::VoxThread::GetCurThreadId());
	if(m_sWorkBuffer.m_size < size)
	{
		//Reallocate buffer
		if(m_sWorkBuffer.m_buffer)
		{
			VOX_FREE(m_sWorkBuffer.m_buffer);
		}
		
		m_sWorkBuffer.m_buffer = (u8*)VOX_ALLOC(sizeof(u8) * size);

		if(m_sWorkBuffer.m_buffer)
			m_sWorkBuffer.m_size = size;
		else
			m_sWorkBuffer.m_size = 0;
	}

	return &m_sWorkBuffer;
}

VoxFilter::VoxFilter()
{
	a0 = 1.f;
	a1 = 0.f;
	a2 = 0.f;
	b1 = 0.f;
	b2 = 0.f;
	err = 0;
}


// DistanceShelft isn't used. DistanceBandpass is used: see below
void VoxFilter::setDistanceShelf(f32 attenuation, f32 sampleRate)
{
	
	attenuation = attenuation < 0.1f ? 0.0f : (attenuation - 0.1f)/ 0.9f;
	attenuation = 2*attenuation - attenuation*attenuation;
	f32 cutoff = 6000.0f * (1.0f - attenuation) + 25000.f * attenuation;

	if(cutoff >= sampleRate*0.49f) // over nyquist or in "junk band", no filtering possible
	{
		a0 = 1.f;
		a1 = 0.f;
		a2 = 0.f;
		b1 = 0.f;
		b2 = 0.f;
		return;
	}

	f32 A  = pow(10, -16.f/40);
	f32 w0 = 2 * 3.14159268f * cutoff / sampleRate;
	f32 S = 1;
	f32 alpha =  sin(w0)/2 * sqrt( (A + 1/A)*(1/S - 1) + 2 );
	f32 b0;

	a0 =    A*( (A+1) + (A-1)*cos(w0) + 2*sqrt(A)*alpha );
	a1 = -2*A*( (A-1) + (A+1)*cos(w0)                   );
	a2 =    A*( (A+1) + (A-1)*cos(w0) - 2*sqrt(A)*alpha );
	b0 =        (A+1) - (A-1)*cos(w0) + 2*sqrt(A)*alpha  ;
	b1 =    2*( (A-1) - (A+1)*cos(w0)                   );
	b2 =        (A+1) - (A-1)*cos(w0) - 2*sqrt(A)*alpha  ;
	b0 = 1/b0;
	a0 *=  b0;
	a1 *=  b0;
	a2 *=  b0;
	b1 *= -b0;
	b2 *= -b0;
	
}

void VoxFilter::setDistanceBandpass(f32 bandwidth, f32 cutoff, f32 sampleRate)
{

	if(bandwidth > 30)
		bandwidth = 30;
	if(bandwidth < 0.01f)
		bandwidth = 0.01f;

	if(cutoff >= sampleRate*0.48f) // over nyquist or in "junk band", no filtering possible
	{
		a0 = 1.f;
		a1 = 0.f;
		a2 = 0.f;
		b1 = 0.f;
		b2 = 0.f;
		return;
	}

	if(cutoff < 0.1f) // Clamp low range to 0.1hz
	{
		cutoff = 0.1f;
	}

	f32 w0 = 2 * 3.14159268f * cutoff / sampleRate;
	f32 alpha = sin(w0)*sinh( log(2.f)/2 * bandwidth * w0/sin(w0) );
	f32 b0;

    a0 =   alpha;
    a1 =   0;
    a2 =  -alpha;
    b0 =   1 + alpha;
    b1 =  -2*cos(w0);
    b2 =   1 - alpha;

	b0 = 1/b0;
	a0 *=  b0;
	a1 *=  b0;
	a2 *=  b0;
	b1 *= -b0;
	b2 *= -b0;
	
}



void VoxFilter::setNotch(f32 cutoff, f32 gain, f32 bandwidth, f32 sampleRate)
{

	if(gain > 0) // cannot amplify, that will cause filter to overflow!
	{
		a0 = 1.f;
		a1 = 0.f;
		a2 = 0.f;
		b1 = 0.f;
		b2 = 0.f;
		return;
	}
	if(gain < -160) // clamp filter depth
		gain = -160;

	if(cutoff >= sampleRate*0.48f) // over nyquist or in "junk band", no filtering possible
	{
		a0 = 1.f;
		a1 = 0.f;
		a2 = 0.f;
		b1 = 0.f;
		b2 = 0.f;
		return;
	}
	if(cutoff < 0.1f) // Clamp low range to 0.1hz
		cutoff = 0.1f;

	if(bandwidth > 30)  // Anything over 10 is already pretty much all the spectrum
		bandwidth = 30; // over 30 starts causing rounding problems
	if(bandwidth < 0.0001f) // make sure nobody tries a negative bandwidth
		bandwidth = 0.0001f;

	f32 A     = pow(10,(gain/40));
    f32 w0    = 2*3.14159268f*cutoff/sampleRate;
	f32 alpha = sin(w0)*sinh( log(2.f)/2 * bandwidth * w0/sin(w0) );
	f32 b0;

    a0 =   1 + alpha*A;
    a1 =  -2*cos(w0);
    a2 =   1 - alpha*A;
    b0 =   1 + alpha/A;
    b1 =  -2*cos(w0);
    b2 =   1 - alpha/A;
	b0 = 1/b0;
	a0 *=  b0;
	a1 *=  b0;
	a2 *=  b0;
	b1 *= -b0;
	b2 *= -b0;
}

}//namespace vox


