#include "StdAfx.h"

#include "vox_default_config.h"

#if VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM

#include "vox_driver_iphone_remoteio.h"
#include "vox_driver_iphone_remoteio_helper.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox.h"
#include "vox_profiler.h"
#import "AudioToolBox/AudioToolBox.h"


namespace vox {

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverIPhoneRemoteIO();
}
	

	
//*** DriverIphoneRemoteIO ***//

#define AU_OUTPUT_BUS			0
#define AU_INPUT_BUS			1
#define AU_REACTIVATION_LIMIT	5
	
DriverIPhoneRemoteIO::DriverIPhoneRemoteIO()
:m_resampleBuffer(0)
,m_resampleBufferSize(0)
,m_resamplePos(0)
,m_prevLeft(0)
,m_prevRight(0)
,m_needResampling(false)
,m_interruptionLevel(0)
#if VOX_MICROPHONE_INPUT
,m_defaultAudioSessionCategory(kAudioSessionCategory_PlayAndRecord)
#else
,m_defaultAudioSessionCategory(kAudioSessionCategory_AmbientSound)
#endif
,m_timeSinceOtherAudioCheck(0.0f)
,m_checkThreshold(0)
,m_microphoneReceptor(0)
,m_recordingBuffer(0)
,m_inResamplingBuffer(0)
,m_inResamplingBufferSize(0)
,m_inResamplingPointer(0)
{
	for(int i=0; i < VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS; i++)
	{
		m_inResamplingMemory[i] = 0;
		m_inResamplingAccum [i] = 0;
	}

	m_audioCallbackActive = false;
	m_audioUnitInitialized = false;
	m_driverSuspended = false;
	m_nbAudioUnitReactivationTrials = 0;
	m_reactivationTrialInterval = 0.0f;
	m_needRampOut = false;
	m_needRampIn = false;
	m_isMuted = false;
	Init(0);
}

DriverIPhoneRemoteIO::~DriverIPhoneRemoteIO()
{
	Shutdown();
	
	m_mutex.Lock(); //Relock in case callback was called during shutdown
	if(m_resampleBuffer)
		VOX_FREE(m_resampleBuffer);
	if(m_recordingBuffer)
    {
        for(u32 i=0; i < m_recordingBuffer->mNumberBuffers; i++)
            if(m_recordingBuffer->mBuffers[i].mData)
                VOX_FREE(m_recordingBuffer->mBuffers[i].mData);
		VOX_DELETE(m_recordingBuffer);
		m_recordingBuffer = 0;
	}
	if(m_inResamplingBuffer)
	{
		VOX_FREE(m_inResamplingBuffer);
		m_inResamplingBuffer = 0;
	}
    m_mutex.Unlock();
}

void DriverIPhoneRemoteIO::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverIPhoneRemoteIO::Init", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();
	
	DriverCallbackInterface::Init(param);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE);
	
	SetDefaultParameter();
	
	_InitializeAudioUnit();
	
	// Get the actual callback buffer duration (in seconds) and provide it to the driver.
	f32 bufferDuration;
	UInt32 size = sizeof(f32);
	AudioSessionGetProperty(kAudioSessionProperty_CurrentHardwareIOBufferDuration, &size, &bufferDuration);

	if(m_needResampling)
	{
		bufferDuration *= m_hwSampleRate / VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE;
	}
	DriverCallbackSourceInterface::SetDriverCallbackPeriod(bufferDuration);	

	m_mutex.Unlock();
}

void DriverIPhoneRemoteIO::Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverIPhoneRemoteIO::Update", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();

	if(m_interruptionLevel == -1)
	{
		m_timeSinceOtherAudioCheck += dt;
		
		if(m_timeSinceOtherAudioCheck > 0.5f)
		{
			m_timeSinceOtherAudioCheck = 0.0f;
			++m_checkThreshold;
			if(m_checkThreshold >= 3)
			{
				m_checkThreshold = 0;
				ForceEndAudioInterruption();
			}
		}
		
	}



	m_reactivationTrialInterval += dt;

	if(m_nbAudioUnitReactivationTrials < AU_REACTIVATION_LIMIT && m_reactivationTrialInterval > 1.0f)
	{
		if(!m_audioUnitInitialized && !m_driverSuspended)
		{
			_InitializeAudioUnit();
			if(!m_audioUnitInitialized)
			{
				m_nbAudioUnitReactivationTrials++;
				VOX_WARNING_LEVEL_2("Audio unit reactivation attempt no %d failed", m_nbAudioUnitReactivationTrials);
				if(m_nbAudioUnitReactivationTrials == AU_REACTIVATION_LIMIT)
				{
					VOX_WARNING_LEVEL_1("%s", "Audio unit reactivation failed, no further attemp will be done");
				}
			}
			m_reactivationTrialInterval = 0.0f;
		}
		else if(m_audioUnitActive && !m_driverSuspended && !m_audioCallbackActive)
		{
			OSStatus status = AudioOutputUnitStart(m_audioUnit);
			AU_CHECKSTATUS(status);
			if(status == 0)
			{
				m_audioCallbackActive = true;
			}
			else
			{
				m_nbAudioUnitReactivationTrials++;
				VOX_WARNING_LEVEL_2("Audio unit reactivation attempt no %d failed", m_nbAudioUnitReactivationTrials);
				if(m_nbAudioUnitReactivationTrials == AU_REACTIVATION_LIMIT)
				{
					VOX_WARNING_LEVEL_1("%s", "Audio unit reactivation failed, no further attemp will be done");
				}
			}
			m_reactivationTrialInterval = 0.0f;
		}
	}
	
	DriverCallbackInterface::_Update(dt);
	m_mutex.Unlock();
}
	
void DriverIPhoneRemoteIO::_InitializeAudioUnit()
{
	if(m_audioUnitInitialized)
		return;
	
	AudioSessionInitialize(NULL, NULL, DriverIPhoneRemoteIO::interruptionListenerCallback, this);
#if VOX_MICROPHONE_INPUT
	int asFlag = 0;
    UInt32 asFlagSize = sizeof(asFlag);
	AudioSessionGetProperty(kAudioSessionProperty_AudioInputAvailable, &asFlagSize, &asFlag);
	if(!asFlag)
		m_defaultAudioSessionCategory = kAudioSessionCategory_AmbientSound;
#endif
	AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(m_defaultAudioSessionCategory), &m_defaultAudioSessionCategory);
#if VOX_MICROPHONE_INPUT
	AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryDefaultToSpeaker, sizeof(asFlag), &asFlag);    
	AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryMixWithOthers, sizeof(asFlag), &asFlag);
#endif
	AudioSessionSetActive(true);

#if VOX_IPHONE_REMOTEIO_OVERRIDE_HW_IO_BUFFER_LENGTH	
	f32 aBufferLength = VOX_IPHONE_REMOTEIO_DRIVER_BUFFER_LENGTH; // In seconds
	AudioSessionSetProperty(kAudioSessionProperty_PreferredHardwareIOBufferDuration, 
							sizeof(aBufferLength), &aBufferLength);
#endif	
	
	UInt32 size = sizeof(Float64);
	Float64 smplrate;
	
	AudioSessionGetProperty(kAudioSessionProperty_CurrentHardwareSampleRate, 
							&size, &smplrate);

	// SOFTWARE RESAMPLING NOW ALWAYS ON (NO CHOICE)
	m_hwSampleRate = smplrate;
	f64 aBufferSamplingRate = smplrate;
	m_needResampling = true;

	if(aBufferSamplingRate == VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE)
		m_needResampling = false; // same rate as hw (usually 44khz)

	OSStatus status = 0;
	bool error = 0;
	
	// Describe audio component
	AudioComponentDescription desc;
	desc.componentType = kAudioUnitType_Output;
	desc.componentSubType = kAudioUnitSubType_RemoteIO;
	desc.componentFlags = 0;
	desc.componentFlagsMask = 0;
	desc.componentManufacturer = kAudioUnitManufacturer_Apple;
	
	// Get component
	AudioComponent outputComponent = AudioComponentFindNext(NULL, &desc);
	
	// Get audio units
	status = AudioComponentInstanceNew(outputComponent, &m_audioUnit);
	AU_CHECKSTATUS(status);
	error = error | (status != 0);
	
	if(error) //Could not get audio component
	{
		m_mutex.Unlock();
		return;
	}

#if VOX_MICROPHONE_INPUT
	if(!error)
	{
		UInt32 flag = 1;
		// Enable IO for recording
		status = AudioUnitSetProperty(m_audioUnit, 
									  kAudioOutputUnitProperty_EnableIO, 
									  kAudioUnitScope_Input, 
									  AU_INPUT_BUS,
									  &flag, 
									  sizeof(flag));
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
#endif // VOX_MICROPHONE_INPUT

	if(!error)
	{
		UInt32 flag = 1;
		// Enable IO for playback
		status = AudioUnitSetProperty(m_audioUnit, 
									  kAudioOutputUnitProperty_EnableIO, 
									  kAudioUnitScope_Output, 
									  AU_OUTPUT_BUS,
									  &flag, 
									  sizeof(flag));
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
	
	if(!error)
	{
		// Describe format
		AudioStreamBasicDescription audioFormat;
		
		f64 auSamplingRate = aBufferSamplingRate;//VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE;
		/*if((GetMajorOSVersion() < 3 || Is1stGenDevice()) && auSamplingRate != 44100.0)
		 {
		 auSamplingRate = 44100.0;
		 m_needResampling = true;
		 }*/
		
		audioFormat.mSampleRate			= auSamplingRate;
		audioFormat.mFormatID			= kAudioFormatLinearPCM;
		audioFormat.mFormatFlags		= kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
		audioFormat.mFramesPerPacket	= 1;
		audioFormat.mChannelsPerFrame	= 2; //Final mix is always stereo
		audioFormat.mBitsPerChannel		= 16; //16 bit per sample per channel
		audioFormat.mBytesPerPacket		= 4; // 2 bytes per channel
		audioFormat.mBytesPerFrame		= 4; // 1 packet per frame
		
		// Apply format
		
		status = AudioUnitSetProperty(m_audioUnit, 
									  kAudioUnitProperty_StreamFormat, 
									  kAudioUnitScope_Input, 
									  AU_OUTPUT_BUS, 
									  &audioFormat, 
									  sizeof(audioFormat));
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}

#if VOX_MICROPHONE_INPUT
	if(!error)
	{
		// Describe format
		AudioStreamBasicDescription audioFormat;
		
		
		// use HW sampling rate - apple's resampler is slow so it's better to avoid it
		f64 auSamplingRate = aBufferSamplingRate; 
		
		audioFormat.mSampleRate			= auSamplingRate;
		audioFormat.mFormatID			= kAudioFormatLinearPCM;
		audioFormat.mFormatFlags		= kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
		audioFormat.mFramesPerPacket	= 1;
		audioFormat.mChannelsPerFrame	= VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS; // normally mono or stereo
		audioFormat.mBitsPerChannel		= 16;
		audioFormat.mBytesPerPacket		= 2 * audioFormat.mChannelsPerFrame; // 2 bytes per chn
		audioFormat.mBytesPerFrame		= 2 * audioFormat.mChannelsPerFrame; // 1 packet per frame

		// Apply format
		status = AudioUnitSetProperty(m_audioUnit, 
									  kAudioUnitProperty_StreamFormat, 
									  kAudioUnitScope_Output, 
									  AU_INPUT_BUS, 
									  &audioFormat, 
									  sizeof(audioFormat));
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}

	if(!error)
	{
		// Set input callback
		AURenderCallbackStruct callbackStruct;
		callbackStruct.inputProc = recordingCallback;
		callbackStruct.inputProcRefCon = this;
		status = AudioUnitSetProperty(m_audioUnit, 
									  kAudioOutputUnitProperty_SetInputCallback, 
									  kAudioUnitScope_Global, 
									  AU_INPUT_BUS,
									  &callbackStruct, 
									  sizeof(callbackStruct));
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}

#endif // VOX_MICROPHONE_INPUT

	if(!error)
	{
		// Set output callback
		AURenderCallbackStruct callbackStruct;
		callbackStruct.inputProc = playbackCallback;
		callbackStruct.inputProcRefCon = this;
		status = AudioUnitSetProperty(m_audioUnit, 
									  kAudioUnitProperty_SetRenderCallback, 
									  kAudioUnitScope_Global, 
									  AU_OUTPUT_BUS,
									  &callbackStruct, 
									  sizeof(callbackStruct));
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}


	// Initialise
	if(!error)
	{
		status = AudioUnitInitialize(m_audioUnit);
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
	
	if(error) //Could not initialize audio unit
	{
		status = AudioComponentInstanceDispose(m_audioUnit);
		AU_CHECKSTATUS(status);
		m_mutex.Unlock();
		return;
	}
	
	if(!error)
	{
		status = AudioOutputUnitStart(m_audioUnit);
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
    
#if VOX_MICROPHONE_INPUT
	if(!error)
	{
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
#endif // VOX_MICROPHONE_INPUT
	
	if(error) //Could not start audio unit
	{
		status = AudioUnitUninitialize(m_audioUnit);
		AU_CHECKSTATUS(status);
		status = AudioComponentInstanceDispose(m_audioUnit);
		AU_CHECKSTATUS(status);
		m_mutex.Unlock();
		return;
	}
	else
	{
		m_audioUnitActive = true;
		m_audioUnitInitialized = true;
		m_audioCallbackActive = true;
	}
}

void DriverIPhoneRemoteIO::Shutdown()
{
	m_audioCallbackActive = false;
	m_mutex.Lock();

	if(m_audioUnitActive)
	{
		m_audioUnitActive =	false;			
		OSStatus status = AudioOutputUnitStop(m_audioUnit);
		AU_CHECKSTATUS(status);
		status = AudioUnitUninitialize(m_audioUnit);
		AU_CHECKSTATUS(status);
		status = AudioComponentInstanceDispose(m_audioUnit);
		AU_CHECKSTATUS(status);
	}

	m_mutex.Unlock();
}

void DriverIPhoneRemoteIO::Suspend()
{
	m_mutex.Lock();
	_Suspend();
	m_mutex.Unlock();
}

void DriverIPhoneRemoteIO::_Suspend()
{
	m_driverSuspended = true;
	if(m_audioUnitActive)
	{
		if(m_audioCallbackActive)
		{
			OSStatus status = AudioOutputUnitStop(m_audioUnit);
			m_audioCallbackActive = false;
			AU_CHECKSTATUS(status);
		}
	}
}

void DriverIPhoneRemoteIO::Resume()
{
	m_mutex.Lock();
	_Resume();
	m_mutex.Unlock();	
}

void DriverIPhoneRemoteIO::_Resume()
{
	if(m_audioUnitActive)
	{
		if(m_nbAudioUnitReactivationTrials < AU_REACTIVATION_LIMIT)
		{
			OSStatus status = AudioOutputUnitStart(m_audioUnit);
			AU_CHECKSTATUS(status);
			if(status == 0)
			{
				m_needRampIn = true;
				m_audioCallbackActive = true;
			}
			else
			{
				m_nbAudioUnitReactivationTrials++;
				VOX_WARNING_LEVEL_2("Audio unit reactivation attempt no %d failed", m_nbAudioUnitReactivationTrials);
				if(m_nbAudioUnitReactivationTrials == AU_REACTIVATION_LIMIT)
				{
					VOX_WARNING_LEVEL_1("%s", "Audio unit reactivation failed, no further attemp will be done");
				}
			}
			m_reactivationTrialInterval = 0.0f;
		}
	}
	m_driverSuspended = false;
}



void DriverIPhoneRemoteIO::PrintDebug()
{
}

void DriverIPhoneRemoteIO::FillBuffer(s16* outBuffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverIPhoneRemoteIO::FillBuffer", vox::VoxThread::GetCurThreadId());
	
	if(!m_audioCallbackActive || m_isMuted)
	{
		memset(outBuffer, 0, (nbSample << 1) * sizeof(s16));
		
		// First callback following a Resume() is muted because sounds stopped at Suspend() time are
		// actually stopped after the first FillBuffer() following a Resume().
		if(m_needRampIn)
		{
			m_isMuted = false;
		}
		return;
	}
	
	if(m_needResampling)
	{
		ScopeMutex sm(&m_mutex);
		s32 previousResampleBufferSize = m_resampleBufferSize;
		if(m_resampleBufferSize == 0)
		{
			if(m_resampleBuffer)
			{
				VOX_FREE(m_resampleBuffer);
			}

			m_resampleBufferSize = nbSample << 2;

			m_resampleBuffer = (s16*)VOX_ALLOC(m_resampleBufferSize);
			m_resamplePos = 0;
			
			if(!m_resampleBuffer)
			{
				m_resampleBufferSize = -1; //error
				if(m_resampleBufferSize != previousResampleBufferSize)
				{
					VOX_WARNING_LEVEL_2("%s", "Could not create RemoteIO resample buffer");
				}
			}
			else
			{
				DriverCallbackInterface::_FillBuffer(m_resampleBuffer, nbSample);
			}
		}

		if(m_resampleBufferSize > 0)
		{
			s32 realrate = (s32)VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE;
			s32 hwRate = m_hwSampleRate;
			fx1814 idxiter = (realrate << VOX_FX1814_FRACT_SHIFT) / hwRate;

			s32 bufferSamples = m_resampleBufferSize >> 2;
			
			s32 outSampleIndex = 0;
			s32 bufferSampleIndex = 0;

			fx1814 idxratio;

			s16 nextLeft, nextRight;
			s32 tempSample;

			s32 stereoSample = nbSample * 2; //hack to avoid *2 every iter

			while(stereoSample > outSampleIndex)
			{			
				while(((m_resamplePos) < ((bufferSamples) << VOX_FX1814_FRACT_SHIFT)) && (stereoSample > outSampleIndex))
				{
					idxratio = m_resamplePos & VOX_FX1814_FRACT_MASK;
					bufferSampleIndex = (m_resamplePos >> VOX_FX1814_FRACT_SHIFT) << 1;

					nextLeft = m_resampleBuffer[bufferSampleIndex];
					nextRight = m_resampleBuffer[bufferSampleIndex + 1];

					tempSample = m_prevLeft + (((nextLeft - m_prevLeft) * idxratio) >> VOX_FX1814_FRACT_SHIFT);
					outBuffer[outSampleIndex++] = (s16)tempSample;
					tempSample = m_prevRight + (((nextRight - m_prevRight) * idxratio) >> VOX_FX1814_FRACT_SHIFT);
					outBuffer[outSampleIndex++] = (s16)tempSample;
					m_resamplePos += idxiter;
					if(bufferSampleIndex != ((m_resamplePos >> VOX_FX1814_FRACT_SHIFT) << 1))
					{
						m_prevLeft = nextLeft;
						m_prevRight = nextRight;
					}
				} 
        				            
				if(!(m_resamplePos < ((bufferSamples) << VOX_FX1814_FRACT_SHIFT))) 
				{
					DriverCallbackInterface::_FillBuffer(m_resampleBuffer, bufferSamples);
					m_resamplePos &= VOX_FX1814_FRACT_MASK;
				}
			}
		}
		else
		{
			memset(outBuffer, 0, (nbSample << 1) * sizeof(s16));
			return;
		}
	}
	else
	{
		DriverCallbackInterface::FillBuffer(outBuffer, nbSample);
	}
	
	if(m_needRampIn && nbSample != 0)
	{
		m_needRampIn = false;
		m_needRampOut = false;
		
		fx1814 rampDelta = VOX_FX1814_ONE / nbSample;
		fx1814 rampLevel = 0;

		for(s32 i = 0 ; i < (nbSample<<1) ; i+=2)
		{
			outBuffer[i]   = ((s32)outBuffer[i]   * rampLevel) >> VOX_FX1814_FRACT_SHIFT;
			outBuffer[i+1] = ((s32)outBuffer[i+1] * rampLevel) >> VOX_FX1814_FRACT_SHIFT;
			rampLevel += rampDelta;
		}	
	}
	else if(m_needRampOut && nbSample != 0)
	{
		m_needRampOut = false;

		fx1814 rampDelta = -VOX_FX1814_ONE / nbSample;
		fx1814 rampLevel = VOX_FX1814_ONE;

		for(s32 i = 0 ; i < (nbSample<<1) ; i+=2)
		{
			outBuffer[i]   = ((s32)outBuffer[i]   * rampLevel) >> VOX_FX1814_FRACT_SHIFT;
			outBuffer[i+1] = ((s32)outBuffer[i+1] * rampLevel) >> VOX_FX1814_FRACT_SHIFT;
			rampLevel += rampDelta;
		}
		
		// Mute driver and reset resampling buffer
		m_isMuted = true;
		m_resampleBufferSize = 0;
		m_prevLeft = 0;
		m_prevRight = 0;
	}
}
	
OSStatus DriverIPhoneRemoteIO::playbackCallback(void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags, const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber, UInt32 inNumberFrames, AudioBufferList *ioData)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverIPhoneRemoteIO::playbackCallback", vox::VoxThread::GetCurThreadId());
	if(inRefCon)
	{
		for(u32 i = 0; i < ioData->mNumberBuffers; i++)
		{
			s16* data = (s16*)ioData->mBuffers[i].mData;			
			((DriverIPhoneRemoteIO*)inRefCon)->FillBuffer(data, ioData->mBuffers[i].mDataByteSize >> 2/*inNumberFrames*/);
		}
	}

	return 0;
}


OSStatus DriverIPhoneRemoteIO::recordingCallback(void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags, const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber, UInt32 inNumberFrames, AudioBufferList *ioData)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverIPhoneRemoteIO::recordingCallback", vox::VoxThread::GetCurThreadId());

	if(!inRefCon)
	{
		return 0;
	}

    DriverIPhoneRemoteIO* driver = (DriverIPhoneRemoteIO*)inRefCon;
	if(!driver->m_recordingBuffer)
	{
        driver->m_recordingBuffer =  VOX_NEW AudioBufferList;
        if(!driver->m_recordingBuffer)
            return 0;
        driver->m_recordingBuffer->mNumberBuffers = 1;
        driver->m_recordingBuffer->mBuffers[0].mNumberChannels = VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS;
        driver->m_recordingBuffer->mBuffers[0].mData = 0;
        driver->m_recordingBuffer->mBuffers[0].mDataByteSize = 0;
	}
    
    if(!driver->m_recordingBuffer->mBuffers[0].mData 
       || inNumberFrames * 2 * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS > driver->m_recordingBuffer->mBuffers[0].mDataByteSize)
    {
        if(driver->m_recordingBuffer->mBuffers[0].mData)
            VOX_FREE(driver->m_recordingBuffer->mBuffers[0].mData);
        driver->m_recordingBuffer->mBuffers[0].mData = VOX_ALLOC(inNumberFrames * 2 * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS);
        if(driver->m_recordingBuffer->mBuffers[0].mData)
            driver->m_recordingBuffer->mBuffers[0].mDataByteSize = inNumberFrames * 2 * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS;
        else
        {
            driver->m_recordingBuffer->mBuffers[0].mDataByteSize = 0;
            VOX_DELETE(driver->m_recordingBuffer);
            return 0;
        }
    }

	
#if VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_INPUT
	bool doResampling = true;
	fx1814 resampleDelta = (VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_RATE << VOX_FX1814_FRACT_SHIFT) / driver->m_hwSampleRate;

	if(resampleDelta == VOX_FX1814_ONE)
		doResampling = false;

	s32 reportedSampleRate = VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_RATE;

	// allocate resampling buffer
	if(doResampling)
	{
		s32 resamplingSamples = (inNumberFrames * resampleDelta) >> VOX_FX1814_FRACT_SHIFT;
		// 8 for resampling overshoot, 1 for jitter
		resamplingSamples += 8 + 1;

		s32 resamplingDataSize = 2 * resamplingSamples * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS;
		
		if(!driver->m_inResamplingBuffer || driver->m_inResamplingBufferSize < resamplingDataSize)
		{
			// must allocate or reallocate buffer
			if(driver->m_inResamplingBuffer)
				VOX_FREE(driver->m_inResamplingBuffer);

			driver->m_inResamplingBuffer = (s16 *)VOX_ALLOC(resamplingDataSize);

			if(!driver->m_inResamplingBuffer)
			{
				VOX_WARNING_LEVEL_1("Failed to allocate input resampling buffer! (%d bytes)", resamplingDataSize);
				return 0;
			}

			// clear buffer
			memset(driver->m_inResamplingBuffer, 0, resamplingDataSize);

			// reset interpolator
			driver->m_inResamplingPointer = 0;
			for(int i=0; i<VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS; i++)
			{
				driver->m_inResamplingMemory[i] = 0;
				driver->m_inResamplingAccum [i] = 0;
			}
            driver->m_inResamplingBufferSize = resamplingDataSize;
		}
	}
#else  //  VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_INPUT

	s32 reportedSampleRate = (int)driver->m_hwSampleRate;

#endif //  VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_INPUT



    OSStatus status = AudioUnitRender(driver->m_audioUnit, ioActionFlags, inTimeStamp, inBusNumber, inNumberFrames, driver->m_recordingBuffer);
    AU_CHECKSTATUS(status);
    
    if(status != 0)
        return 0;

	
#if VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_INPUT
	if(doResampling)
	{
		u32 resamplingPointerStart = driver->m_inResamplingPointer;
		s32 numSamplesOut = 0;

		for(int chn = 0; chn < VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS; chn++)
		{
			s16* data = (s16*)(driver->m_recordingBuffer->mBuffers[0].mData) + chn;
			s16* dataStop = data + VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS * inNumberFrames;
		
			driver->m_inResamplingPointer = resamplingPointerStart;

			while(data < dataStop)
			{
				u32 sp = driver->m_inResamplingPointer >> VOX_FX1814_FRACT_SHIFT;
				sp *= VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS;
				sp += chn;
				u32 sf = driver->m_inResamplingPointer && VOX_FX1814_FRACT_MASK;
				driver->m_inResamplingPointer += resampleDelta;

				int new_val = *data;
				data += VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS;

				int delta = new_val - driver->m_inResamplingMemory[chn];
				driver->m_inResamplingMemory[chn] = new_val;

				int partial_delta = (delta * sf) >> VOX_FX1814_FRACT_SHIFT;
				driver->m_inResamplingBuffer[sp]   += delta - partial_delta;
				sp += VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS;
				driver->m_inResamplingBuffer[sp] += partial_delta;

			}

			numSamplesOut = driver->m_inResamplingPointer >> VOX_FX1814_FRACT_SHIFT;
			s16* integralData = driver->m_inResamplingBuffer + chn;
			s16* integralStop = driver->m_inResamplingBuffer + chn + numSamplesOut * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS;

			while (integralData < integralStop)
			{
				*integralData = driver->m_inResamplingAccum[chn] += *integralData;
				integralData += VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS;
			}
		}
		
		driver->m_recordingMutex.Lock();
		RecordedAudioReceptor *receptor = driver->m_microphoneReceptor;
		if(receptor && !driver->m_isMuted)
			receptor->GetData(driver->m_inResamplingBuffer, numSamplesOut, reportedSampleRate, VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS);
		driver->m_recordingMutex.Unlock();

		
		// preserve the last 8 samples (the non integrated ones)
		memcpy(driver->m_inResamplingBuffer,
			driver->m_inResamplingBuffer + numSamplesOut * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS,
			2 * 8 * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS);

		// clear rest of buffer
		memset(driver->m_inResamplingBuffer + 8 * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS,
			0,
			2 * numSamplesOut * VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS);
		
		// reduce pointer
		driver->m_inResamplingPointer -= numSamplesOut << VOX_FX1814_FRACT_SHIFT;

	}
	else
#endif //  VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_RESAMPLE_INPUT
	{
		s16* data = (s16*)(driver->m_recordingBuffer->mBuffers[0].mData);

		driver->m_recordingMutex.Lock();
		RecordedAudioReceptor *receptor = driver->m_microphoneReceptor;
		if(receptor && !driver->m_isMuted)
			receptor->GetData(data, inNumberFrames, reportedSampleRate, VOX_IPHONE_REMOTEIO_DRIVER_RECORDING_CHANNELS);
		driver->m_recordingMutex.Unlock();
	}
	

	return 0;
}







void DriverIPhoneRemoteIO::interruptionListenerCallback(void *inUserData,UInt32 interruptionState)
{
	if ( interruptionState == kAudioSessionBeginInterruption )
	{	
		((DriverIPhoneRemoteIO*)inUserData)->beginInterruption();
	}
	else if(interruptionState == kAudioSessionEndInterruption)
	{
		((DriverIPhoneRemoteIO*)inUserData)->endInterruption();
	}
}

void DriverIPhoneRemoteIO::beginInterruption()
{
	VOX_WARNING_LEVEL_2("%s", "Begin AudioSession Interruption");
	m_mutex.Lock();

	if(m_interruptionLevel == 0)
	{
		AudioSessionSetActive(false);
		_Suspend();
	}
	if(m_interruptionLevel != -1) // Do not increment if in autoresume mode
		m_interruptionLevel++;

	m_checkThreshold = 0;
	m_timeSinceOtherAudioCheck = 0;

	m_mutex.Unlock();
}
	
void DriverIPhoneRemoteIO::endInterruption()
{
	m_mutex.Lock();
	
	if(m_driverSuspended) // MIGHT BE ALWAYS TRUE - check if need to be changed
	{
		// Application is not yet ready for sound to be resumed!
		// Set interruption level to "autoresume"
		m_interruptionLevel = -1;
		VOX_WARNING_LEVEL_2("%s", "End AudioSession Interruption: application inactive -> autoresume.");	
	}
	else
	{
		if(m_interruptionLevel != -1) // Don't change interruption level in autoresume mode.
			m_interruptionLevel--;
		if(m_interruptionLevel <= 0) // Audio should be resumed
		{
			m_interruptionLevel = 0;
			AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(m_defaultAudioSessionCategory), &m_defaultAudioSessionCategory);
#if VOX_MICROPHONE_INPUT
			int asFlag = 1;
			AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryDefaultToSpeaker, sizeof(asFlag), &asFlag);            
			AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryMixWithOthers, sizeof(asFlag), &asFlag);
#endif
			AudioSessionSetActive(true);
			_Resume();
			VOX_WARNING_LEVEL_2("%s", "End AudioSession Interruption: application active -> fast resume.");	
		}
	}
	
	m_mutex.Unlock();
}

void DriverIPhoneRemoteIO::ForceEndAudioInterruption()
{
	VOX_WARNING_LEVEL_2("%s\n", __FUNCTION__);
	VOX_WARNING_LEVEL_2("Interrupt level : %d\n", m_interruptionLevel);

	m_interruptionLevel = 0;
	AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(m_defaultAudioSessionCategory), &m_defaultAudioSessionCategory);
#if VOX_MICROPHONE_INPUT
	int asFlag = 1;
	AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryDefaultToSpeaker, sizeof(asFlag), &asFlag);    
	AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryMixWithOthers, sizeof(asFlag), &asFlag);
#endif
	AudioSessionSetActive(true);
	_Resume();
	VOX_WARNING_LEVEL_1("%s", "Autoresumed AudioSession");	

}


bool DriverIPhoneRemoteIO::SetMicrophoneCallback(RecordedAudioReceptor *generator)
{
#if VOX_MICROPHONE_INPUT
	m_recordingMutex.Lock();
	m_microphoneReceptor = generator;
	m_recordingMutex.Unlock();
	return true;
#else
	return false;
#endif 
}

void DriverIPhoneRemoteIO::RemoveMicrophoneCallback()
{
#if VOX_MICROPHONE_INPUT
	m_recordingMutex.Lock();
	m_microphoneReceptor = 0;
	m_recordingMutex.Unlock();
#endif 
}



}//namespace vox

#endif //VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM


