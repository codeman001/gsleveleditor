
#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM

#include "vox_driver_mmsystem.h"
#include "vox_macro.h"
#include "vox_profiler.h"

#define VOX_MMSYSTEM_MIN_NB_BUFFERS		2
#define VOX_MMSYSTEM_MIN_BUFFER_SIZE	2048	// In bytes (= 512 samples * 2 channels * 2 bytes/sample)
#define VOX_MMSYSTEM_V5_MIN_LATENCY		10240	// In bytes (= 5 * 512 samples). For versions 5 and earlier.
#define VOX_MMSYSTEM_V6_MIN_LATENCY		14336	// In bytes (= 7 * 512 samples). For versions 6 and later.

#define VOX_MMSYSTEM_RECORDING_MIN_NB_BUFFERS		2
// In bytes (= 512 samples * 2 bytes/sample)
#define VOX_MMSYSTEM_RECORDING_MIN_BUFFER_SIZE	( 1024 * VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS )	
// In bytes (= 5 * 512 samples * 2). For versions 5 and earlier.
#define VOX_MMSYSTEM_RECORDING_V5_MIN_LATENCY	( 5120 * VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS )	
// In bytes (= 7 * 512 samples * 2). For versions 6 and later.
#define VOX_MMSYSTEM_RECORDING_V6_MIN_LATENCY	( 7168 * VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS )	

namespace vox 
{

//*** DriverMMSystem ***//

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverMMSystem();
}

DriverMMSystem::DriverMMSystem()
:m_nbBuffers(0)
,m_bufferSize(0)
,m_currentBuffer(0)
,m_pOutBuffers(0)
,m_pWaveBlocks(0)
,m_updateThread(0)
,m_isThreadRunning(false)
{

	input.m_nbBuffers = 0;
	input.m_bufferSize = 0;
	input.m_currentBuffer = 0;
	input.m_pOutBuffers = 0;
	input.m_pWaveBlocks = 0;
	input.m_updateThread = 0;
	input.m_isThreadRunning = false;
	input.m_microphoneReceptor = 0;
	input.m_audioUnitActive = false;

	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::DriverMMSystem", vox::VoxThread::GetCurThreadId());
	Init(0);
}

DriverMMSystem::~DriverMMSystem()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::~DriverMMSystem", vox::VoxThread::GetCurThreadId());
	Shutdown();
}



void DriverMMSystem::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::Init", vox::VoxThread::GetCurThreadId());

	DriverCallbackInterface::Init(param);
	SetDefaultParameter();
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_MMSYSTEM_DRIVER_PREFERRED_RATE);

	m_bufferSize = (static_cast<s32> (VOX_MMSYSTEM_DRIVER_BUFFER_LENGTH * VOX_MMSYSTEM_DRIVER_PREFERRED_RATE)) << 2;

	// Force buffer size to the next multiple of 512 samples
	m_bufferSize += VOX_MMSYSTEM_MIN_BUFFER_SIZE - (m_bufferSize % VOX_MMSYSTEM_MIN_BUFFER_SIZE);

	// Set a lower limit to buffer size
	if(m_bufferSize < VOX_MMSYSTEM_MIN_BUFFER_SIZE)
	{
		m_bufferSize = VOX_MMSYSTEM_MIN_BUFFER_SIZE;
	}

	// Set a lower limit to nb of buffers
	if(m_nbBuffers < VOX_MMSYSTEM_MIN_NB_BUFFERS)
	{
		m_nbBuffers = VOX_MMSYSTEM_MIN_NB_BUFFERS;
	}

	// Get major version of mmsystem
    DWORD dwMajorVersion = 0;
    dwMajorVersion = (DWORD)(LOBYTE(LOWORD(GetVersion())));

	if(dwMajorVersion >= 6)
	{
		// Total buffer size must be higher or equal to 7 x 512 samples
		if(m_nbBuffers * m_bufferSize < VOX_MMSYSTEM_V6_MIN_LATENCY)
		{
			s32 nbExtraBytesNeeded = VOX_MMSYSTEM_V6_MIN_LATENCY - (m_nbBuffers * m_bufferSize);
			s32 nbExtraBuffersFloor = nbExtraBytesNeeded / m_bufferSize;
			m_nbBuffers += nbExtraBuffersFloor + ((nbExtraBytesNeeded % m_bufferSize) > 0);
		}
	}
	else // dwMajorVersion <= 5
	{
		// Total buffer size must be higher or equal to 5 x 512 samples
		if(m_nbBuffers * m_bufferSize < VOX_MMSYSTEM_V5_MIN_LATENCY)
		{
			s32 nbExtraBytesNeeded = VOX_MMSYSTEM_V5_MIN_LATENCY - (m_nbBuffers * m_bufferSize);
			s32 nbExtraBuffersFloor = nbExtraBytesNeeded / m_bufferSize;
			m_nbBuffers += nbExtraBuffersFloor + ((nbExtraBytesNeeded % m_bufferSize) > 0);
		}
	}

	// Create buffers
	m_pOutBuffers = static_cast<u8**> (VOX_ALLOC(m_nbBuffers * sizeof(u8*)));

	if(!m_pOutBuffers)
	{
		m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem buffers.", __FUNCTION__, __LINE__);
		return;
	}

	for(u32 i = 0; i < m_nbBuffers; i++)
	{
		m_pOutBuffers[i] = static_cast<u8*> (VOX_ALLOC(m_bufferSize));
		if(!m_pOutBuffers[i])
		{
			m_bufferSize = 0;
			VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem buffers.", __FUNCTION__, __LINE__);
			for(u32 j = 0; j < i; j++)
			{
				VOX_FREE(m_pOutBuffers[j]);
			}
			VOX_FREE(m_pOutBuffers);
			m_pOutBuffers = 0;
			return;
		}
		memset(m_pOutBuffers[i], 0, m_bufferSize);
	}
	m_pWaveBlocks = static_cast<WAVEHDR*> (VOX_ALLOC(m_nbBuffers * sizeof(WAVEHDR)));

	if(!m_pWaveBlocks)
	{
		m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem wave blocks.", __FUNCTION__, __LINE__);
		for(u32 i = 0; i < m_nbBuffers; i++)
		{
			VOX_FREE(m_pOutBuffers[i]);
		}
		VOX_FREE(m_pOutBuffers);
		m_pOutBuffers = 0;
		return;
	}

	// Set up the WAVEFORMATEX structure.
	memset(&m_waveformat, 0, sizeof(m_waveformat));
	m_waveformat.wFormatTag = WAVE_FORMAT_PCM;
	m_waveformat.wBitsPerSample = 16;
	m_waveformat.nChannels = 2;
	m_waveformat.nSamplesPerSec = VOX_MMSYSTEM_DRIVER_PREFERRED_RATE;
	m_waveformat.nBlockAlign = m_waveformat.nChannels * (m_waveformat.wBitsPerSample >> 3);
	m_waveformat.nAvgBytesPerSec = m_waveformat.nSamplesPerSec * m_waveformat.nBlockAlign;

	if(waveOutOpen(&m_waveOut, WAVE_MAPPER, &m_waveformat, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR)
	{
		m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not open MMSystem wave out.", __FUNCTION__, __LINE__);
		
		for(u32 i = 0; i < m_nbBuffers; i++)
		{
			VOX_FREE(m_pOutBuffers[i]);
		}
		VOX_FREE(m_pOutBuffers);
		m_pOutBuffers = 0;

		VOX_FREE(m_pWaveBlocks);
		m_pWaveBlocks = 0;
		return;
	}

	// Initialize buffers with silence
	for(u32 i = 0; i < m_nbBuffers; i++)
	{
		memset(&m_pWaveBlocks[i], 0, sizeof(WAVEHDR));
		m_pWaveBlocks[i].dwBufferLength = m_bufferSize;
		m_pWaveBlocks[i].lpData = (LPSTR) m_pOutBuffers[i];
		waveOutPrepareHeader(m_waveOut, &m_pWaveBlocks[i], sizeof(WAVEHDR));
		waveOutWrite(m_waveOut, &m_pWaveBlocks[i], sizeof(WAVEHDR));
	}

	// Inform parent class about driver's callback period (used for pitch ramping)
	DriverCallbackSourceInterface::SetDriverCallbackPeriod(static_cast<float> (m_bufferSize / m_waveformat.nBlockAlign) / static_cast<float> (VOX_MMSYSTEM_DRIVER_PREFERRED_RATE));

	// Start thread used to provide data to mmsystem.
	m_updateThread = VOX_NEW VoxThread(&vox::DriverMMSystem::UpdateThreaded, this, 0, "DriverMMSystem::Update");
	if(!m_updateThread)
	{
		m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not start MMSystem update thread.", __FUNCTION__, __LINE__);
		
		for(u32 i = 0; i < m_nbBuffers; i++)
		{
			VOX_FREE(m_pOutBuffers[i]);
		}
		VOX_FREE(m_pOutBuffers);
		m_pOutBuffers = 0;

		VOX_FREE(m_pWaveBlocks);
		m_pWaveBlocks = 0;
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}
	m_isThreadRunning = true;

	m_audioUnitActive = true;


}







void DriverMMSystem::InitInput()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::InitInput", vox::VoxThread::GetCurThreadId());

	input.m_bufferSize = (static_cast<s32> (VOX_MMSYSTEM_DRIVER_RECORDING_BUFFER_LENGTH * VOX_MMSYSTEM_DRIVER_RECORDING_PREFERRED_RATE * VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS)) << 1;

	// Force buffer size to the next multiple of 512 samples
	input.m_bufferSize += VOX_MMSYSTEM_RECORDING_MIN_BUFFER_SIZE - (input.m_bufferSize % VOX_MMSYSTEM_RECORDING_MIN_BUFFER_SIZE);

	// Set a lower limit to buffer size
	if(input.m_bufferSize < VOX_MMSYSTEM_RECORDING_MIN_BUFFER_SIZE)
	{
		input.m_bufferSize = VOX_MMSYSTEM_RECORDING_MIN_BUFFER_SIZE;
	}

	// Set a lower limit to nb of buffers
	if(input.m_nbBuffers < VOX_MMSYSTEM_RECORDING_MIN_NB_BUFFERS)
	{
		input.m_nbBuffers = VOX_MMSYSTEM_RECORDING_MIN_NB_BUFFERS;
	}

	// Get major version of mmsystem
    DWORD dwMajorVersion = 0;
    dwMajorVersion = (DWORD)(LOBYTE(LOWORD(GetVersion())));

	if(dwMajorVersion >= 6)
	{
		// Total buffer size must be higher or equal to 7 x 512 samples
		if(input.m_nbBuffers * input.m_bufferSize < VOX_MMSYSTEM_RECORDING_V6_MIN_LATENCY)
		{
			s32 nbExtraBytesNeeded = VOX_MMSYSTEM_RECORDING_V6_MIN_LATENCY - (input.m_nbBuffers * input.m_bufferSize);
			s32 nbExtraBuffersFloor = nbExtraBytesNeeded / input.m_bufferSize;
			input.m_nbBuffers += nbExtraBuffersFloor + ((nbExtraBytesNeeded % input.m_bufferSize) > 0);
		}
	}
	else // dwMajorVersion <= 5
	{
		// Total buffer size must be higher or equal to 5 x 512 samples
		if(input.m_nbBuffers * input.m_bufferSize < VOX_MMSYSTEM_RECORDING_V5_MIN_LATENCY)
		{
			s32 nbExtraBytesNeeded = VOX_MMSYSTEM_RECORDING_V5_MIN_LATENCY - (input.m_nbBuffers * input.m_bufferSize);
			s32 nbExtraBuffersFloor = nbExtraBytesNeeded / input.m_bufferSize;
			input.m_nbBuffers += nbExtraBuffersFloor + ((nbExtraBytesNeeded % input.m_bufferSize) > 0);
		}
	}

	// Create buffers
	input.m_pOutBuffers = static_cast<u8**> (VOX_ALLOC(input.m_nbBuffers * sizeof(u8*)));

	if(!input.m_pOutBuffers)
	{
		input.m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem input buffers.", __FUNCTION__, __LINE__);
		return;
	}

	for(u32 i = 0; i < input.m_nbBuffers; i++)
	{
		input.m_pOutBuffers[i] = static_cast<u8*> (VOX_ALLOC(input.m_bufferSize));
		if(!input.m_pOutBuffers[i])
		{
			input.m_bufferSize = 0;
			VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem input buffers.", __FUNCTION__, __LINE__);
			for(u32 j = 0; j < i; j++)
			{
				VOX_FREE(input.m_pOutBuffers[j]);
			}
			VOX_FREE(input.m_pOutBuffers);
			input.m_pOutBuffers = 0;
			return;
		}
		memset(input.m_pOutBuffers[i], 0, input.m_bufferSize);
	}
	input.m_pWaveBlocks = static_cast<WAVEHDR*> (VOX_ALLOC(input.m_nbBuffers * sizeof(WAVEHDR)));

	if(!input.m_pWaveBlocks)
	{
		input.m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem input wave blocks.", __FUNCTION__, __LINE__);
		for(u32 i = 0; i < input.m_nbBuffers; i++)
		{
			VOX_FREE(input.m_pOutBuffers[i]);
		}
		VOX_FREE(input.m_pOutBuffers);
		input.m_pOutBuffers = 0;
		return;
	}

	// Set up the WAVEFORMATEX structure.
	memset(&input.m_waveformat, 0, sizeof(input.m_waveformat));
	input.m_waveformat.wFormatTag = WAVE_FORMAT_PCM;
	input.m_waveformat.wBitsPerSample = 16;
	input.m_waveformat.nChannels = VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS;
	input.m_waveformat.nSamplesPerSec = VOX_MMSYSTEM_DRIVER_RECORDING_PREFERRED_RATE;
	input.m_waveformat.nBlockAlign = input.m_waveformat.nChannels * (input.m_waveformat.wBitsPerSample >> 3);
	input.m_waveformat.nAvgBytesPerSec = input.m_waveformat.nSamplesPerSec * input.m_waveformat.nBlockAlign;

	if(waveInOpen(&input.m_waveOut, WAVE_MAPPER, &input.m_waveformat, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR)
	{
		input.m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not open MMSystem wave in.", __FUNCTION__, __LINE__);
		
		for(u32 i = 0; i < input.m_nbBuffers; i++)
		{
			VOX_FREE(input.m_pOutBuffers[i]);
		}
		VOX_FREE(input.m_pOutBuffers);
		input.m_pOutBuffers = 0;

		VOX_FREE(input.m_pWaveBlocks);
		input.m_pWaveBlocks = 0;
		return;
	}

	// Initialize buffers with silence
	for(u32 i = 0; i < input.m_nbBuffers; i++)
	{
		memset(&input.m_pWaveBlocks[i], 0, sizeof(WAVEHDR));
		input.m_pWaveBlocks[i].dwBufferLength = input.m_bufferSize;
		input.m_pWaveBlocks[i].lpData = (LPSTR) input.m_pOutBuffers[i];
		waveInPrepareHeader(input.m_waveOut, &input.m_pWaveBlocks[i], sizeof(WAVEHDR));
		waveInAddBuffer(input.m_waveOut, &input.m_pWaveBlocks[i], sizeof(WAVEHDR));
	}

	// Start thread used to provide data to mmsystem.
	input.m_updateThread = VOX_NEW VoxThread(&vox::DriverMMSystem::UpdateInputThreaded, this, 0, "DriverMMSystem::UpdateInput");
	if(!input.m_updateThread)
	{
		input.m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not start MMSystem input update thread.", __FUNCTION__, __LINE__);
		
		for(u32 i = 0; i < input.m_nbBuffers; i++)
		{
			VOX_FREE(input.m_pOutBuffers[i]);
		}
		VOX_FREE(input.m_pOutBuffers);
		input.m_pOutBuffers = 0;

		VOX_FREE(input.m_pWaveBlocks);
		input.m_pWaveBlocks = 0;
		VOX_MUTEX_LEVEL_1(input.m_mutex.Unlock());
		return;
	}

	waveInStart(input.m_waveOut);
	input.m_isThreadRunning = true;
	input.m_audioUnitActive = true;

}

void DriverMMSystem::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::Shutdown", vox::VoxThread::GetCurThreadId());

	if(m_audioUnitActive)
	{
		// Terminate update thread
		m_isThreadRunning = false;
		if(m_updateThread)
		{
			VOX_DELETE(m_updateThread);
			m_updateThread = 0;
		}

		waveOutReset(m_waveOut);

		// Close mmsystem output device
		waveOutClose(m_waveOut);

		// Free allocated memory
		if(m_pWaveBlocks)
		{
			VOX_FREE(m_pWaveBlocks);
			m_pWaveBlocks = 0;
		}

		if(m_pOutBuffers)
		{
			for(u32 i = 0; i < m_nbBuffers; i++)
			{
				VOX_FREE(m_pOutBuffers[i]);
			}
			VOX_FREE(m_pOutBuffers);
			m_pOutBuffers = 0;
		}

		m_audioUnitActive = false;
	}

	if(input.m_audioUnitActive)
		ShutdownInput();
}

void DriverMMSystem::ShutdownInput()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::ShutdownInput", vox::VoxThread::GetCurThreadId());

	if(input.m_audioUnitActive)
	{
		// Terminate update thread
		input.m_isThreadRunning = false;
		if(input.m_updateThread)
		{
			VOX_DELETE(input.m_updateThread);
			input.m_updateThread = 0;
		}

		waveInReset(input.m_waveOut);

		// Close mmsystem output device
		waveInClose(input.m_waveOut);

		// Free allocated memory
		if(input.m_pWaveBlocks)
		{
			VOX_FREE(input.m_pWaveBlocks);
			input.m_pWaveBlocks = 0;
		}

		if(input.m_pOutBuffers)
		{
			for(u32 i = 0; i < input.m_nbBuffers; i++)
			{
				VOX_FREE(input.m_pOutBuffers[i]);
			}
			VOX_FREE(input.m_pOutBuffers);
			input.m_pOutBuffers = 0;
		}

		input.m_audioUnitActive = false;
	}
}



void DriverMMSystem::Suspend()
{
	// TODO : See if thread should be stopped
}

void DriverMMSystem::Resume()
{
	// TODO : Resume thread if it has been stopped by Suspend().
}

void DriverMMSystem::UpdateData(void)
{
	// Sleep 80% of buffer size
	u32 sleepTime = static_cast<DWORD> (static_cast<f32> (m_bufferSize >> 2) / static_cast<f32> (VOX_MMSYSTEM_DRIVER_PREFERRED_RATE) * 800.0f);

	while(m_isThreadRunning)
	{	
		while((m_pWaveBlocks[m_currentBuffer].dwFlags & WHDR_DONE) && m_isThreadRunning)
		{
			if(m_pWaveBlocks[m_currentBuffer].dwFlags & WHDR_PREPARED)
				waveOutUnprepareHeader(m_waveOut, &m_pWaveBlocks[m_currentBuffer], sizeof(WAVEHDR));

			// Get a buffer of samples
			FillBuffer(reinterpret_cast<s16*> (m_pOutBuffers[m_currentBuffer]), m_bufferSize >> 2);
			

			m_pWaveBlocks[m_currentBuffer].dwBufferLength = m_bufferSize;
			m_pWaveBlocks[m_currentBuffer].lpData = (LPSTR) m_pOutBuffers[m_currentBuffer];

			waveOutPrepareHeader(m_waveOut, &m_pWaveBlocks[m_currentBuffer], sizeof(WAVEHDR));

			waveOutWrite(m_waveOut, &m_pWaveBlocks[m_currentBuffer], sizeof(WAVEHDR));

			m_currentBuffer = (m_currentBuffer + 1) % m_nbBuffers;

			Sleep(sleepTime);
		}
	}
}

void DriverMMSystem::UpdateThreaded(void* caller, void* param)
{
	VOX_PROFILING_START_FRAME_LAZY;
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverMMSystem::Run", 0);

	((DriverMMSystem*)caller)->UpdateData();
}


void DriverMMSystem::UpdateInputData(void)
{
	// Sleep 80% of buffer size
	u32 sleepTime = static_cast<DWORD> (static_cast<f32> (input.m_bufferSize >> 1)
		/ static_cast<f32> (VOX_MMSYSTEM_DRIVER_RECORDING_PREFERRED_RATE)
		/ static_cast<f32> (VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS) * 800.0f);

	while(input.m_isThreadRunning)
	{	
		while((input.m_pWaveBlocks[input.m_currentBuffer].dwFlags & WHDR_DONE) && input.m_isThreadRunning)
		{
			if(input.m_pWaveBlocks[input.m_currentBuffer].dwFlags & WHDR_PREPARED)
				waveInUnprepareHeader(input.m_waveOut, &input.m_pWaveBlocks[input.m_currentBuffer], sizeof(WAVEHDR));

			// Get a buffer of samples
			input.m_mutex.Lock();
			if(input.m_microphoneReceptor)
				input.m_microphoneReceptor->GetData(
					(s16 *)input.m_pOutBuffers[input.m_currentBuffer],
					input.m_bufferSize / 2 / VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS,
					VOX_MMSYSTEM_DRIVER_RECORDING_PREFERRED_RATE,
					VOX_MMSYSTEM_DRIVER_RECORDING_CHANNELS);
			input.m_mutex.Unlock();
			
			input.m_pWaveBlocks[input.m_currentBuffer].dwBufferLength = input.m_bufferSize;
			input.m_pWaveBlocks[input.m_currentBuffer].lpData = (LPSTR) input.m_pOutBuffers[input.m_currentBuffer];

			waveInPrepareHeader(input.m_waveOut, &input.m_pWaveBlocks[input.m_currentBuffer], sizeof(WAVEHDR));

			waveInAddBuffer(input.m_waveOut, &input.m_pWaveBlocks[input.m_currentBuffer], sizeof(WAVEHDR));

			input.m_currentBuffer = (input.m_currentBuffer + 1) % input.m_nbBuffers;

			Sleep(sleepTime);
		}
	}
}

void DriverMMSystem::UpdateInputThreaded(void* caller, void* param)
{
	VOX_PROFILING_START_FRAME_LAZY;
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverMMSystem::Run (input)", 0);

	((DriverMMSystem*)caller)->UpdateInputData();
}

bool DriverMMSystem::SetMicrophoneCallback(RecordedAudioReceptor *receptor)
{
#if VOX_MICROPHONE_INPUT
	if(!input.m_audioUnitActive)
		InitInput();

	input.m_mutex.Lock();
	input.m_microphoneReceptor = receptor;
	input.m_mutex.Unlock();
	
	return true;
#else
	return false;
#endif // VOX_MICROPHONE_INPUT
}

void DriverMMSystem::RemoveMicrophoneCallback()
{
#if VOX_MICROPHONE_INPUT
	input.m_mutex.Lock();
	input.m_microphoneReceptor = 0;
	input.m_mutex.Unlock();

	if(input.m_audioUnitActive)
		ShutdownInput();

#endif // VOX_MICROPHONE_INPUT
}

}//namespace vox

#endif // VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM


