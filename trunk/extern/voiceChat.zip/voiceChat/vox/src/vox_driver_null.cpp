#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_NULL && VOX_NULL_DRIVER_PLATFORM

#include "vox_driver_null.h"

vox::DriverInterface* vox::CreateDriver()
{
	return VOX_NEW vox::DriverNull();
}

#endif // VOX_DRIVER_USE_NULL && VOX_NULL_DRIVER_PLATFORM
