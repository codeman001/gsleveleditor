
#include "StdAfx.h"
#include "vox_filesystem.h"
#include "vox_memory.h"
#include "vox_macro.h"
#if !defined(_NN_CTR)
#include "vox_zip_reader.h"
#endif
#include <stdlib.h>
#include <cstring>
#include "vox_profiler.h"

#include VOX_LIST_INCLUDE
#include VOX_STRING_INCLUDE
#include VOX_VECTOR_INCLUDE

namespace vox
{

struct FileInterfaceInternalData
{
	VOX_STRING m_filePath;
	void* m_filePtr;
	VoxFileType m_type;
};

struct FileSystemInterfaceInternalData
{
	VOX_LIST<VOX_STRING, SAllocator<VOX_STRING> > directoryStack;

#if !defined(_NN_CTR)
	VOX_VECTOR<CZipReader *, SAllocator<CZipReader *> > m_archive;
#else
	void* m_archive; // Archive not used
#endif

};

IOFunc FileSystemInterface::m_IOFunc = IOFunc();
FileSystemInterface* FileSystemInterface::m_instance = 0;

FileSystemInterface::FileSystemInterface()
:m_archiveFirst(false)
{
	m_internalData = VOX_NEW FileSystemInterfaceInternalData;
	if(!m_internalData)
	{
		VOX_WARNING_LEVEL_1("Could not allocate file system internal data! (%d byte allocation failed) Most sound files will probably be missing!", (int)sizeof(FileSystemInterfaceInternalData) );
	}

}

FileSystemInterface* FileSystemInterface::GetInstance()
{
	if(!m_instance)
	{
		m_instance = VoxNewFileSystem();
	}
	return m_instance;
}

void FileSystemInterface::DestroyInstance()
{

	VOX_DELETE(m_instance);
	m_instance = 0;
}

FileSystemInterface::~FileSystemInterface()
{
#if defined(_NN_CTR)
	// No zip archive
#else
	for(u32 i=0; i<m_internalData->m_archive.size(); i++)
	{
		VOX_DELETE(m_internalData->m_archive[i]);
		m_internalData->m_archive[i] = 0;
	}
#endif


	VOX_DELETE(m_internalData);
	m_internalData = 0;

}

FileInterface* FileSystemInterface::OpenFile(c8* filename, VoxFileAccessMode mode)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::OpenFile", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	return _OpenFile(filename, mode);
}

FileInterface* FileSystemInterface::_OpenFile(c8* filename, VoxFileAccessMode mode)
{

	void* fileptr = 0;
	FileInterface* fileinterface = 0;
	VOX_STRING fullpath("");

	if(m_internalData)
	{
		if(m_internalData->directoryStack.size() > 0)
		{
			fullpath = m_internalData->directoryStack.back();
		}
	}

	fullpath.append(filename);
	
#if !defined(_NN_CTR)
	if(m_internalData->m_archive.size() > 0 && m_archiveFirst)
	{
		for(u32 i=0; i<m_internalData->m_archive.size() && !fileptr; i++)
		{
			if(m_internalData->m_archive[i])
			{
				s32 baseOffset, fileSize;
				if(m_internalData->m_archive[i]->getFileInfo(fullpath.c_str(), baseOffset, fileSize))
				{
					fileptr = FileSystemInterface::m_IOFunc.open(m_internalData->m_archive[i]->getZipFileName(), mode);
					if(fileptr)
						fileinterface = VOX_NEW FileLimited(fileptr, fullpath.c_str(), baseOffset, fileSize);
				}
			}
		}
	}
#endif

	if(!fileptr)
	{
		fileptr = FileSystemInterface::m_IOFunc.open(fullpath.c_str(), mode);
		if(fileptr)
			fileinterface = VOX_NEW FileInterface(fileptr, fullpath.c_str());
	}

#if !defined(_NN_CTR)
	if(m_internalData->m_archive.size() > 0 && !m_archiveFirst && !fileptr)
	{
		for(u32 i=0; i<m_internalData->m_archive.size() && !fileptr; i++)
		{
			if(m_internalData->m_archive[i])
			{
				s32 baseOffset, fileSize;
				if(m_internalData->m_archive[i]->getFileInfo(fullpath.c_str(), baseOffset, fileSize))
				{
					fileptr = FileSystemInterface::m_IOFunc.open(m_internalData->m_archive[i]->getZipFileName(), mode);
					if(fileptr)
						fileinterface = VOX_NEW FileLimited(fileptr, fullpath.c_str(), baseOffset, fileSize);
				}
			}
		}
	}
#endif
	
	if(!fileinterface && fileptr)
	{
		FileSystemInterface::m_IOFunc.close(fileptr);
	}

	return fileinterface;
}

s32 FileSystemInterface::CloseFile(FileInterface* fileInterface)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::CloseFile", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	return _CloseFile(fileInterface);
}


s32 FileSystemInterface::_CloseFile(FileInterface* fileInterface)
{

	if(fileInterface)
	{
		void* filePtr= fileInterface->GetFilePtr();
		if(filePtr)
			FileSystemInterface::m_IOFunc.close(filePtr);
		VOX_DELETE(fileInterface);
		return 0;
	}

	return -1;
}


s32 FileSystemInterface::SetArchive(const c8* zipFileName, bool ignoreCase, bool ignorePath, bool tryArchiveFirst)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::SetArchive", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

#if defined(_NN_CTR)
	return -1;
#else

	for(u32 i=0; i<m_internalData->m_archive.size(); i++)
	{
		VOX_DELETE(m_internalData->m_archive[i]);
		m_internalData->m_archive[i] = 0;
	}

	m_internalData->m_archive.resize(0);

	m_internalData->m_archive.push_back(VOX_NEW CZipReader(zipFileName, ignoreCase, ignorePath));
	m_archiveFirst = tryArchiveFirst;

	if(!m_internalData->m_archive.back())
	{
		m_internalData->m_archive.pop_back();
		return -1;
	}

	if(!m_internalData->m_archive.back()->isValid())
	{
		VOX_DELETE(m_internalData->m_archive.back());
		m_internalData->m_archive.back() = 0;
		m_internalData->m_archive.pop_back();
		return -1;
	}
	else
	{
		return 0;
	}

#endif
}

s32 FileSystemInterface::AddArchive(const c8* zipFileName, bool ignoreCase, bool ignorePath, bool tryArchiveFirst)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::AddArchive", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

#if defined(_NN_CTR)
	return -1;
#else

	m_internalData->m_archive.push_back(VOX_NEW CZipReader(zipFileName, ignoreCase, ignorePath));

	m_archiveFirst = tryArchiveFirst;

	if(!m_internalData->m_archive.back())
	{
		m_internalData->m_archive.pop_back();
		return -1;
	}

	if(!m_internalData->m_archive.back()->isValid())
	{
		VOX_DELETE(m_internalData->m_archive.back());
		m_internalData->m_archive.back() = 0;
		m_internalData->m_archive.pop_back();
		return -1;
	}
	else
	{
		return 0;
	}

#endif
}

s32 FileSystemInterface::PushDirectory(c8* directory)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::PushDirectory", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);
	if(directory && m_internalData)

	{
		m_internalData->directoryStack.push_back(VOX_STRING(directory));
		return 0;
	}
	return -1;
}

s32 FileSystemInterface::PopDirectory()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::PopDirectory", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	if(m_internalData)
	{
		if(m_internalData->directoryStack.size() > 0)
		{
			m_internalData->directoryStack.pop_back();
			return((s32)m_internalData->directoryStack.size());
		}
		else
		{
			return -1;
		}
	}

	return -1;
}

s32 FileSystemInterface::GetDirectory(c8* dest, s32 size, c8* fullPath)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::GetDirectory", vox::VoxThread::GetCurThreadId());

	if(!dest || !fullPath)
	{
		return -1;
	}

	c8* marker = std::strrchr(fullPath, '/');
	
	if(marker)
	{
		s32 directorySize = marker - fullPath;
		directorySize++;
		if(directorySize + 1 > size)//doesn't fit
		{
			return -1;
		}
		
		std::memcpy(dest, fullPath, directorySize);
		dest[directorySize] = 0;
		return 0;
	}
	else
	{
		std::strcpy(dest, "");
	}

	return -1;
}

// FileInterface

FileInterface::FileInterface()
{
	dat = VOX_NEW FileInterfaceInternalData();
	
	if(dat)
	{
		dat->m_filePtr = 0;
		dat->m_type = k_nNormalFile;
	}
	else
	{
		VOX_WARNING_LEVEL_2("Could not allocate file handling data! (%d byte allocation failed) File will be missing!", (int)sizeof(FileInterfaceInternalData));
	}
}

FileInterface::FileInterface(void* filePtr, const char* fullpath)
{
	dat = VOX_NEW FileInterfaceInternalData();
	
	if(dat)
	{
		dat->m_filePtr = filePtr;
		dat->m_type = k_nNormalFile;
		if(fullpath)
			dat->m_filePath = fullpath;
	}
	else
	{
		VOX_WARNING_LEVEL_2("Could not allocate file handling data! File %s will be missing!", fullpath);
	}
}

FileInterface::~FileInterface()
{
	VOX_DELETE(dat);
	dat = 0;
}


s32 FileInterface::Read(void* dest, s32 size, s32 count)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileInterface::Read", vox::VoxThread::GetCurThreadId());

	if(!dat)
	{
		VOX_WARNING_LEVEL_2("Missing file handle data, could not carry file operation! (read %d bytes)", size*count);
		return -1;
	}

	if(dat->m_filePtr && dest && FileSystemInterface::m_IOFunc.read)
	{
		return FileSystemInterface::m_IOFunc.read(dest, size, count, dat->m_filePtr);
	}

	return 0;
}

s32 FileInterface::Seek(s32 offset, VoxFileSeekOrigin origin)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileInterface::Seek", vox::VoxThread::GetCurThreadId());

	if(!dat)
	{
		VOX_WARNING_LEVEL_2("Missing file handle data, could not carry file operation! (seek %d bytes, mode %d)", offset, origin);
		return -1;
	}

	if(dat->m_filePtr && FileSystemInterface::m_IOFunc.seek)
	{
		return FileSystemInterface::m_IOFunc.seek(dat->m_filePtr, offset, origin);
	}

	return -1;
}

s32 FileInterface::Tell()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileInterface::Tell", vox::VoxThread::GetCurThreadId());

	if(!dat)
	{
		VOX_WARNING_LEVEL_2("Missing file handle data, could not carry file operation! (tell %d)", 0);
		return -1;
	}

	if(dat->m_filePtr && FileSystemInterface::m_IOFunc.tell)
	{
		return FileSystemInterface::m_IOFunc.tell(dat->m_filePtr);
	}
	return -1;
}

s32 FileInterface::Write(const void * dest, s32 size, s32 count)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileInterface::Write", vox::VoxThread::GetCurThreadId());

	if(!dat)
	{
		VOX_WARNING_LEVEL_2("Missing file handle data, could not carry file operation! (write %d bytes)", size*count);
		return -1;
	}

	if(dat->m_filePtr && dest && FileSystemInterface::m_IOFunc.write)
	{
		return FileSystemInterface::m_IOFunc.write(dest, size, count, dat->m_filePtr);
	}

	return 0;
}


const char* FileInterface::GetFilePath()
{
	if(!dat)
	{
		VOX_WARNING_LEVEL_2("Missing file handle data, could not carry file operation! (get file path %d)",0);
		return 0;
	}

	return dat->m_filePath.c_str();
}

void* FileInterface::GetFilePtr()
{
	if(!dat)
	{
		VOX_WARNING_LEVEL_2("Missing file handle data, could not carry file operation! (get file pointer %d)",0);
		return 0;
	}

	return dat->m_filePtr;
}

//

FileLimited::FileLimited()
:FileInterface()
, m_baseOffset(0)
, m_fileSize(0)
, m_filePosition(0)
{
	if(dat)
	{
		dat->m_type = k_nLimitedFile;
	}
}

FileLimited::FileLimited(void* filePtr, const char* fullpath, s32 baseOffset, s32 fileSize)
:FileInterface(filePtr, fullpath)
, m_baseOffset(baseOffset)
, m_fileSize(fileSize)
, m_filePosition(0)
{
	if(dat)
	{
		dat->m_type = k_nLimitedFile;
		Seek(0, k_nSeekSet);
	}
}

s32 FileLimited::Read(void* dest, s32 size, s32 count)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileLimited::Read", vox::VoxThread::GetCurThreadId());

	if(!dat)
	{
		return 0;
	}

	if( size* count + m_filePosition <= m_fileSize)
	{
		s32 readcount = FileSystemInterface::m_IOFunc.read(dest, size, count, dat->m_filePtr);
		m_filePosition += readcount * size;
		return readcount;
	}
	else
	{
		s32 remainingcount = (m_fileSize - m_filePosition) / size;
		if( remainingcount > 0)
		{
			s32 readcount = FileSystemInterface::m_IOFunc.read(dest, size, remainingcount, dat->m_filePtr);
			m_filePosition += readcount * size;
			return readcount;
		}
	}

	return 0;
}

s32 FileLimited::Seek(s32 offset, VoxFileSeekOrigin origin)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileLimited::Seek", vox::VoxThread::GetCurThreadId());
	s32 pos;
	s32 nextPos;

	if(!dat)
	{
		return 0;
	}

	switch(origin)
	{
		case k_nSeekSet:
		{
			if( offset > m_fileSize )
			{
				m_filePosition = m_fileSize;
				return -1;
			}
			else if (offset < 0)
			{
				m_filePosition = -1;
				return -1;
			}
			else
			{
				pos = m_baseOffset + offset;
				nextPos = offset;
			}		
			break;
		}
		case k_nSeekCur:
		{
			if( m_filePosition + offset > m_fileSize )
			{
				m_filePosition = m_fileSize;
				return -1;
			}
			else if (m_filePosition + offset < 0)
			{
				m_filePosition = -1;
				return -1;
			}
			else
			{
				pos = m_baseOffset + m_filePosition + offset;
				nextPos = m_filePosition + offset;
			}	
			break;
		}
		case k_nSeekEnd:
		{
			if( (-offset) > m_fileSize )
			{
				m_filePosition = -1;
				return -1;
			}
			else if (offset > 0)
			{
				m_filePosition = m_fileSize;
				return -1;
			}
			else
			{
				pos = m_baseOffset + m_fileSize + offset;
				nextPos = m_fileSize + offset;
			}		
			break;
		}
		default:
			return -1;
	}

	s32 result = FileSystemInterface::m_IOFunc.seek(dat->m_filePtr, pos, k_nSeekSet);
	if(result == 0)
		m_filePosition = nextPos;

	return result;
}

s32 FileLimited::Tell()
{
	return m_filePosition;
}

//*** ZipTableSerializer ***//

const s32 ZipTableSerializer::k_extensionHeaderSize = 8;

ZipTableSerializer::ZipTableSerializer(const c8* filename, VoxZipStreamMode mode)
:m_fp(0)
,m_streamMode(mode)
,m_streamSize(0)
,m_cursorPosition(0)
,m_status(k_nZipInvalid)
,m_cacheData(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::ZipTableSerializer", vox::VoxThread::GetCurThreadId());

	if(filename)
	{
		FileSystemInterface* pFS = FileSystemInterface::GetInstance();

		if(mode == k_nZipExtensionRead)
		{
			m_fp = pFS->_OpenFile((c8*)filename); // Open in binary read mode

			if(m_fp)
			{
				// If there is an extension, seek to its start.
				if(ParseExtensionHeader())
				{
					m_fp->Seek(-m_streamSize - k_extensionHeaderSize, k_nSeekEnd);
#if VOX_ZIP_TABLE_CACHE
					m_cacheData = (u8 *)malloc(m_streamSize);
					if(m_cacheData)
					{
						m_fp->Read(m_cacheData, 1, m_streamSize);
					}
#endif // VOX_ZIP_TABLE_CACHE
				}
			}
		}
		else if(m_streamMode == k_nZipExtensionWrite)
		{
			m_fp = pFS->_OpenFile((c8*)filename, k_nReadWriteBinary);

			if(m_fp)
			{
				// If there is already an extension, do not allow writing in file
				if(ParseExtensionHeader())
				{
					Close();
				}
				else // No extension, file can be opened for writing. Seek to end of file
				{
					m_fp->Seek(0, k_nSeekEnd);
				}
			}
		}
		else if(m_streamMode == k_nZipExtensionCreateWrite)
		{
			m_fp = pFS->_OpenFile((c8*)filename, k_nCreateReadWriteBinary);
			if(m_fp)
			{
				m_status = k_nZipWithoutExtension;
			}
		}
	}

	if(!m_fp)
	{
		VOX_WARNING_LEVEL_2( "Could not load file %s\n", filename);
	}
}

ZipTableSerializer::~ZipTableSerializer()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::~ZipTableSerializer", vox::VoxThread::GetCurThreadId());

  if(m_fp)
	{
		// If in writing mode, transfer buffer content to end of file
		if(m_status != k_nZipInvalid && (m_streamMode == k_nZipExtensionWrite || m_streamMode == k_nZipExtensionCreateWrite))
		{
			// Write zip extension signature to file
			u8 signature[5] = "ZET_";
			m_fp->Write(&signature, 1, 4);

			// Write extension length to file
			s32 extensionSize = m_cursorPosition + k_extensionHeaderSize;
#if VOX_BIG_ENDIAN
			ChangeIntEndianness(extensionSize);
#endif
			m_fp->Write(&extensionSize, 4, 1);
		}

		FileSystemInterface* pFS = vox::FileSystemInterface::GetInstance();
		pFS->_CloseFile(m_fp);

#if VOX_ZIP_TABLE_CACHE
		free(m_cacheData);
#endif
	}
}

bool ZipTableSerializer::ParseExtensionHeader(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::ParseExtensionHeader", vox::VoxThread::GetCurThreadId());

  if(m_fp)
	{
		u8 signature[4] = "xxx";
		s32 extensionSize;

		// Seek to the start of the last 8 bytes
		m_fp->Seek(-k_extensionHeaderSize, k_nSeekEnd);

		// Verify if zip extension signature is present
		m_fp->Read(&signature, 1, 4);

		if(signature[0] == 'Z' && signature[1] == 'E' && signature[2] == 'T' && signature[3] == '_')
		{
			m_fp->Read(&extensionSize, 4, 1);
#if VOX_BIG_ENDIAN
			ChangeIntEndianness(extensionSize);
#endif

			m_streamSize = extensionSize - k_extensionHeaderSize;
			if(m_streamSize > 0)
			{
				m_status = k_nZipWithExtension;
				return true;
			}
		}
		else
		{
			m_status = k_nZipWithoutExtension;
		}
	}

	return false;
}

void ZipTableSerializer::Close()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::Close", vox::VoxThread::GetCurThreadId());

  if(m_fp)
	{
		FileSystemInterface* pFS = vox::FileSystemInterface::GetInstance();
		pFS->_CloseFile(m_fp);
		m_fp = 0;
		m_status = k_nZipInvalid;
	}
}

size_t ZipTableSerializer::Read(void* buffer, size_t size)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::Read", vox::VoxThread::GetCurThreadId());

	if(m_status == k_nZipWithExtension && m_streamMode == k_nZipExtensionRead)
	{
#if VOX_ZIP_TABLE_CACHE
		if(m_cacheData)
		{
			if(m_cursorPosition+size <= m_streamSize)
			{
				memcpy(buffer, m_cacheData+m_cursorPosition, size);
				m_cursorPosition += size;
				return size;
			}
		}
#endif // VOX_ZIP_TABLE_CACHE
		{
			s32 nbRead = m_fp->Read(buffer, 1, size);
			if(nbRead == size)
			{
				m_cursorPosition += size;
				return size;
			}
		}
	}
	return 0;
}

size_t ZipTableSerializer::ReadByte(u8 &byteValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::ReadByte", vox::VoxThread::GetCurThreadId());

  if(m_status == k_nZipWithExtension && m_streamMode == k_nZipExtensionRead)
	{
#if VOX_ZIP_TABLE_CACHE
		if(m_cacheData)
		{
			if(m_cursorPosition+1 <= m_streamSize)
			{
				byteValue = m_cacheData[m_cursorPosition];
				m_cursorPosition += 1;
				return 1;
			}
		}
		else
#endif // VOX_ZIP_TABLE_CACHE
		{
			s32 nbRead = m_fp->Read(&byteValue, 1, 1);
			if(nbRead == 1)
			{
				m_cursorPosition++;
				return 1;
			}
		}
	}
	return 0;
}

size_t ZipTableSerializer::ReadInt(s32 &intValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::ReadInt", vox::VoxThread::GetCurThreadId());

  if(m_status == k_nZipWithExtension && m_streamMode == k_nZipExtensionRead)
	{
#if VOX_ZIP_TABLE_CACHE
		if(m_cacheData)
		{
			if(m_cursorPosition+4 <= m_streamSize)
			{
				intValue	= (m_cacheData[m_cursorPosition])
							+ (m_cacheData[m_cursorPosition+1] << 8)
							+ (m_cacheData[m_cursorPosition+2] << 16)
							+ (m_cacheData[m_cursorPosition+3] << 24);
				m_cursorPosition += 4;
				return 1;
			}
		}
		else
#endif // VOX_ZIP_TABLE_CACHE
		{
			s32 nbRead = m_fp->Read(&intValue, sizeof(s32), 1);
			if(nbRead == 1)
			{
#if VOX_BIG_ENDIAN
				ChangeIntEndianness(intValue);
#endif
				m_cursorPosition += sizeof(s32);
				return 1;
			}
		}
	}

	return 0;
}

size_t ZipTableSerializer::ReadShort(s16 &shortValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::ReadShort", vox::VoxThread::GetCurThreadId());

  if(m_status == k_nZipWithExtension && m_streamMode == k_nZipExtensionRead)
	{
#if VOX_ZIP_TABLE_CACHE
		if(m_cacheData)
		{
			if(m_cursorPosition+2 <= m_streamSize)
			{
				shortValue	= (m_cacheData[m_cursorPosition])
							+ (m_cacheData[m_cursorPosition+1] << 8);
				m_cursorPosition += 2;
				return 1;
			}
		}
		else
#endif // VOX_ZIP_TABLE_CACHE
		{
			s32 nbRead = m_fp->Read(&shortValue, sizeof(s16), 1);
			if(nbRead == 1)
			{
#if VOX_BIG_ENDIAN
				ChangeShortEndianness(shortValue);
#endif
				m_cursorPosition += sizeof(s16);
				return 1;
			}
		}
	}

	return 0;
}

size_t ZipTableSerializer::Write(const void* buffer, size_t size)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::Write", vox::VoxThread::GetCurThreadId());

  if(m_status == k_nZipWithoutExtension && (m_streamMode == k_nZipExtensionWrite || m_streamMode == k_nZipExtensionCreateWrite))
	{
		s32 written = m_fp->Write(buffer, 1, size);
		if(written == size)
		{
			m_cursorPosition += size;
			return size;
		}
	}
	return 0;
}

size_t ZipTableSerializer::WriteByte(u8 byteValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::WriteByte", vox::VoxThread::GetCurThreadId());

  if(m_status == k_nZipWithoutExtension && (m_streamMode == k_nZipExtensionWrite || m_streamMode == k_nZipExtensionCreateWrite))
	{
		s32 written = m_fp->Write(&byteValue, 1, 1);
		if(written == 1)
		{
			m_cursorPosition++;
			return 1;
		}
	}
	return 0;
}

size_t ZipTableSerializer::WriteInt(s32 intValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::WriteInt", vox::VoxThread::GetCurThreadId());

  if(m_status == k_nZipWithoutExtension && (m_streamMode == k_nZipExtensionWrite || m_streamMode == k_nZipExtensionCreateWrite))
	{
#if VOX_BIG_ENDIAN
		ChangeIntEndianness(intValue);
#endif

		s32 written = m_fp->Write(&intValue, sizeof(s32), 1);
		if(written == 1)
		{
			m_cursorPosition += sizeof(s32);
			return 1;
		}
	}

	return 0;
}

size_t ZipTableSerializer::WriteShort(s16 shortValue)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::WriteShort", vox::VoxThread::GetCurThreadId());

  if(m_status == k_nZipWithoutExtension && (m_streamMode == k_nZipExtensionWrite || m_streamMode == k_nZipExtensionCreateWrite))
	{
#if VOX_BIG_ENDIAN
		ChangeShortEndianness(shortValue);
#endif

		s32 written = m_fp->Write(&shortValue, sizeof(s16), 1);
		if(written == 1)
		{
			m_cursorPosition += sizeof(s16);
			return 1;
		}
	}

	return 0;
}

VoxZipStreamStatus ZipTableSerializer::GetStatus(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::GetStatus", vox::VoxThread::GetCurThreadId());

  return m_status;
}

const char* ZipTableSerializer::GetFilePath()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "ZipTableSerializer::GetFilePath", vox::VoxThread::GetCurThreadId());

  if(m_fp)
		return m_fp->GetFilePath();

	return 0;
}

} // namespace vox


