
#include "StdAfx.h"
#include "vox_filesystem_stdio.h"

#if !defined(_PS3)&& !defined(_NN_CTR) && !VOX_USE_GLF && !(defined(VOX_TARGET_OS_IPHONE) && VOX_USE_POSIX_FILESYSTEM)

#include "vox_memory.h"
#include <stdio.h>


namespace vox
{

/// Reads size bytes of data into buffer at ptr.
s32 readStdIO( void * ptr, s32 size, s32 count, void * stream )
{
	return fread(ptr, size, count, (FILE*) stream);
}

s32 writeStdIO ( const void * ptr, s32 size, s32 count, void * stream )
{
	return fwrite( ptr, size, count, (FILE*) stream);
}

/// Seeks to byte position offset.
s32 seekStdIO ( void * stream, s32 offset, VoxFileSeekOrigin origin )
{
	return fseek((FILE*)stream, offset, origin == k_nSeekEnd ? SEEK_END : origin == k_nSeekCur ? SEEK_CUR : SEEK_SET);
}

/// Returns the current byte offset in the stream.
s32 tellStdIO ( void * stream )
{
	return ftell((FILE*)stream);
}

void* openStdIO ( const c8 * filename, VoxFileAccessMode mode )
{
	FILE* file = 0;

	switch(mode)
	{
		case k_nRead:
			file = fopen(filename, "r");
			break;
		case k_nCreateWrite:
			file = fopen(filename, "w");
			break;
		case k_nAppend:
			file = fopen(filename, "a");
			break;
		case k_nReadWrite:
			file = fopen(filename, "r+");
			break;
		case k_nCreateReadWrite:
			file = fopen(filename, "w+");
			break;
		case k_nReadAndAppend:
			file = fopen(filename, "a+");
			break;
		case k_nReadBinary:
			file = fopen(filename, "rb");
			break;
		case k_nCreateWriteBinary:
			file = fopen(filename, "wb");
			break;
		case k_nAppendBinary:
			file = fopen(filename, "ab");
			break;
		case k_nReadWriteBinary:
			file = fopen(filename, "r+b");
			break;
		case k_nCreateReadWriteBinary:
			file = fopen(filename, "w+b");
			break;
		case k_nReadAndAppendBinary:
			file = fopen(filename, "a+b");
			break;
		default:
			file = 0;
	}

	return file;
}

s32 closeStdIO ( void * stream )
{
	return fclose((FILE*) stream);
}


FileSystemInterface* VoxNewFileSystem()
{
	return VOX_NEW FileSystemStdio();
}

FileSystemStdio::FileSystemStdio()
{
	FileSystemInterface::m_IOFunc.open = openStdIO;
	FileSystemInterface::m_IOFunc.close = closeStdIO;
	FileSystemInterface::m_IOFunc.read = readStdIO;
	FileSystemInterface::m_IOFunc.write = writeStdIO;
	FileSystemInterface::m_IOFunc.seek = seekStdIO;
	FileSystemInterface::m_IOFunc.tell = tellStdIO;
}

FileSystemStdio::~FileSystemStdio()
{
}

}
#endif // !defined(_PS3)&& !defined(_NN_CTR) && !VOX_USE_GLF && !(defined(VOX_TARGET_OS_IPHONE) && VOX_USE_POSIX_FILESYSTEM)


