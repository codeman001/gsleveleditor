#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_USE_GLF_DEBUGGER_MODULE

#include <vox_glf_debugger_module.h>
#include <vox_profiler.h>
#include <vox_macro.h>

#define VOX_MESSAGES_BUFFER_SIZE	8192

// Define the update thread rate
#define VOX_GLF_DEBUGGER_MODULE_SLEEP_TIME	50 // In milliseconds

namespace vox
{

VoxGlfDebuggerModule* VoxGlfDebuggerModule::s_pInstance = 0;
Mutex VoxGlfDebuggerModule::s_instanceMutex;
const c8 VoxGlfDebuggerModule::k_messageSeparator = '\n';

VoxGlfDebuggerModule* VoxGlfDebuggerModule::GetInstance()
{
	ScopeMutex sm(&s_instanceMutex);

	if(!s_pInstance)
	{
		s_pInstance = VOX_NEW VoxGlfDebuggerModule();

		// Create and register vox message sender module upon glf debugger
		if(s_pInstance)
		{
			glf::debugger::Debugger *pGlfDebugger = glf::debugger::Debugger::GetInstance();
			if(pGlfDebugger)
			{
				// Register module upon glf debugger
				pGlfDebugger->RegisterModule(s_pInstance);

				// Get module running
				if(!s_pInstance->Start())
				{
					pGlfDebugger->UnregisterModule(s_pInstance);
					VOX_DELETE(s_pInstance);
					s_pInstance = 0;
				}
			}
		}
	}

	return s_pInstance;
}

void VoxGlfDebuggerModule::ReleaseInstance()
{
	ScopeMutex sm(&s_instanceMutex);
	
	if(s_pInstance)
	{
		// Stop module from running
		s_pInstance->Stop();

		// Unregister module upon glf debugger
		glf::debugger::Debugger *pGlfDebugger = glf::debugger::Debugger::GetInstance();
		if(pGlfDebugger)
		{
			pGlfDebugger->UnregisterModule(s_pInstance);
		}

		// Release module
		VOX_DELETE(s_pInstance);
		s_pInstance = 0;
	}
}

VoxGlfDebuggerModule::VoxGlfDebuggerModule():
glf::debugger::Module("VXMODULE", "vox/Tools/VoxGlfDebuggerModule/vox_glf_debugger_module.jar")
,m_isFunctional(true)
,m_state(S_WAITING_FOR_CLIENT)
,m_updateThread(0)
,m_isActive(false)
,m_clientCommand(CS_STOP_DATA_TRANSFER)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "VoxGlfDebuggerModule::VoxGlfDebuggerModule", vox::VoxThread::GetCurThreadId());

	m_messagesBuffer.m_data = static_cast<c8*> (VOX_ALLOC(VOX_MESSAGES_BUFFER_SIZE));

	if(m_messagesBuffer.m_data != 0)
	{
		m_messagesBuffer.m_size = VOX_MESSAGES_BUFFER_SIZE;
	}
	else
	{
		m_isFunctional = false;
		glf::Console::Println("Cannot create buffer for vox glf debugger module.");
	}
}

VoxGlfDebuggerModule::~VoxGlfDebuggerModule()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "VoxGlfDebuggerModule::~VoxGlfDebuggerModule", vox::VoxThread::GetCurThreadId());

	// Stop module
	Stop();

	// Free message buffer memory
	if(m_messagesBuffer.m_data)
	{
		VOX_FREE(m_messagesBuffer.m_data);
		m_messagesBuffer.m_data = 0;
	}
}

void VoxGlfDebuggerModule::AddConsoleMessage(const char *message)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "VoxGlfDebuggerModule::AddConsoleMessage", vox::VoxThread::GetCurThreadId());

	ScopeMutex sm(&m_mutex);

	// Get the message length
	s32 messageLength = static_cast<s32> (strlen(message));

	// Remove potential end of lines from end of message
	s32 i = messageLength - 1;
	while(i >= 0 && message[i] == '\n')
	{
		messageLength--;
		i--;
	}

	// Add one byte for the separator appended at the message end
	s32 extendedMessageLength = messageLength + 1;

	s32 nbFreeBytes = m_messagesBuffer.m_size - m_messagesBuffer.m_nbValidBytes;

	// If extended message length exceeds buffer limits, clear buffer
	if(extendedMessageLength >= nbFreeBytes)
	{
		m_messagesBuffer.Clear();
		nbFreeBytes = m_messagesBuffer.m_size;
	}

	if(extendedMessageLength < nbFreeBytes) // Leave a space for appending a null character when sending message
	{
		// Determine the position where the message should be added
		s32 messageStartPosition = (m_messagesBuffer.m_startPosition + m_messagesBuffer.m_nbValidBytes) % m_messagesBuffer.m_size;
		s32 nbFreeBytesToBufferEnd = m_messagesBuffer.m_size - messageStartPosition;

		// Copy message in buffer and add a separator at the end
		memcpy(m_messagesBuffer.m_data + messageStartPosition, message, messageLength);
		m_messagesBuffer.m_data[messageStartPosition + messageLength] = k_messageSeparator;

		m_messagesBuffer.m_nbValidBytes += extendedMessageLength;
	}
}

void VoxGlfDebuggerModule::ConnectionClosed()
{
	Stop();
	glf::Console::Println("Glf debugger module client connection has been lost.");
}

void VoxGlfDebuggerModule::DebuggerDestroyed()
{
	
}

bool VoxGlfDebuggerModule::IsActive()
{
	ScopeMutex sm(&m_mutex);
	return m_isActive;
}

void VoxGlfDebuggerModule::Parse(int type, glf::debugger::PacketReader& in)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "VoxGlfDebuggerModule::Parse", vox::VoxThread::GetCurThreadId());

	ScopeMutex sm(&m_mutex);

	if(type == static_cast<int> (CS_START_DATA_TRANSFER))
	{
		m_state = S_CONFIRM_COMMAND;
		m_clientCommand = CS_START_DATA_TRANSFER;
	}
	else if(type == static_cast<int> (CS_STOP_DATA_TRANSFER))
	{
		m_state = S_CONFIRM_COMMAND;
		m_clientCommand = CS_STOP_DATA_TRANSFER;
	}
}

bool VoxGlfDebuggerModule::Start()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "VoxGlfDebuggerModule::Start", vox::VoxThread::GetCurThreadId());

	ScopeMutex sm(&m_mutex);

	if(!m_updateThread && m_isFunctional)
	{
		// Start update thread
		m_updateThread = VOX_NEW VoxThread(&vox::VoxGlfDebuggerModule::UpdateThreaded, this, 0, "VoxGlfDebuggerModule::Update");
		if(m_updateThread)
		{
			m_isActive = true;
		}
		else
		{
			m_isFunctional = false;
			glf::Console::Println("Cannot start vox glf debugger module thread.");
		}
	}

	return m_isFunctional;
}

void VoxGlfDebuggerModule::Stop()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "VoxGlfDebuggerModule::Stop", vox::VoxThread::GetCurThreadId());

	{
		ScopeMutex sm(&m_mutex);

		if(!m_isActive)
			return;

		// Clear message buffer so no more messages are sent
		m_messagesBuffer.Clear();

		// Stop update thread
		m_isActive = false;
	}

	// Release update thread
	if(m_updateThread)
	{
		VOX_DELETE(m_updateThread);
		m_updateThread = 0;
	}
}

void VoxGlfDebuggerModule::SendData()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "VoxGlfDebuggerModule::SendData", vox::VoxThread::GetCurThreadId());

	ScopeMutex sm(&m_mutex);

	if(m_messagesBuffer.m_nbValidBytes > 0)
	{
		glf::debugger::PacketWriter pw;
		pw.Init(static_cast<unsigned int> (SC_DATA_TRANSFER));
		
		// Append a null character to the end of data in buffer
		m_messagesBuffer.m_data[m_messagesBuffer.m_nbValidBytes] = 0;

		// Provide data to the packet writer and send it
		pw.Write(m_messagesBuffer.m_data);
		Send(pw);

		// Clear message buffer
		m_messagesBuffer.Clear();
	}
}

void VoxGlfDebuggerModule::Update()
{
	while(m_isActive)
	{
		VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "VoxGlfDebuggerModule::Update", vox::VoxThread::GetCurThreadId());
		if(m_isFunctional)
		{
			switch(m_state)
			{
				case S_CONFIRM_COMMAND:
				{
					// Send a confirmation to the client that connection has succeeded
					glf::debugger::PacketWriter pw;
					pw.Init(static_cast<unsigned int> (SC_COMMAND_CONFIRMATION));
					pw.Write(static_cast<int> (m_clientCommand)); 
					Send(pw);

					// Update server state
					if(m_clientCommand == CS_START_DATA_TRANSFER)
					{
						m_state = S_DATA_TRANSFER;
					}
					else
					{
						m_state = S_WAITING_FOR_CLIENT;
					}
					break;
				}
				case S_DATA_TRANSFER:
				{
					SendData();
					break;
				}
			}
		}

		VoxThread::Sleep(VOX_GLF_DEBUGGER_MODULE_SLEEP_TIME);
	}
}

void VoxGlfDebuggerModule::UpdateThreaded(void* caller, void* param)
{
	VOX_PROFILING_START_FRAME_LAZY;
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "VoxGlfDebuggerModule::UpdateThreaded", vox::VoxThread::GetCurThreadId());
	((VoxGlfDebuggerModule*) caller)->Update();
}

} // namespace vox

#endif // VOX_USE_GLF_DEBUGGER_MODULE