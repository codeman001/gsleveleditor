
#include "StdAfx.h"
#include "vox_group.h"
#include "vox_macro.h"

#if defined(_WIN32)
	#define VOX_STRNCASECMP _strnicmp
#else
	#define VOX_STRNCASECMP strncasecmp	
#endif


namespace vox
{
//*** Group ***//

Group::Group():
m_id(VOX_GROUP_INVALID_ID)
,m_volume(1.0f)
,m_parent(VOX_GROUP_INVALID_ID)
,m_enable(true)
,m_fader(1, 1, 0)
,m_effectiveVolume(1)
{
	m_name[0] = 0;	
}


Group::Group(u32 id, const char *name, u32 pParent):
m_id(id)
,m_volume(1.0f)
,m_parent(pParent)
,m_enable(true)
,m_fader(1, 1, 0)
,m_effectiveVolume(1)
{
	strncpy(m_name, name, VOX_GROUP_NAME_SIZE - 1); // Truncate name to 31 characters
	if(strlen(name) >= VOX_GROUP_NAME_SIZE)
	{
		VOX_WARNING_LEVEL_3("Group name too long : %s. Group is registered but name has been truncated to %d characters.", name, VOX_GROUP_NAME_SIZE - 1);
	}
}

Group::~Group()
{
}



void Group::Update(f32 dt)
{
	m_fader.Update(dt);
}

u32 Group::GetId(void) const
{
	return m_id;
}


const char *Group::GetName(void) const
{
	return m_name;
}



u32 Group::GetParent(void) const
{
	return m_parent;
}

f32 Group::GetVolume(void) const
{
	return m_volume;
}

f32 Group::GetFaderVolume(void) const
{
	return m_fader.GetCurrentValue();
}

bool Group::GetEnable(void) const
{
	return m_enable;
}


void Group::SetEnable(bool enable, f32 fadeTime)
{
	// fade only if enable really changes
	if(!m_enable && enable)
		m_fader = Fader(m_fader.GetCurrentValue(), m_volume, fadeTime);
	if(m_enable && !enable)
		m_fader = Fader(m_fader.GetCurrentValue(), 0, fadeTime);

	m_enable = enable;

}


void Group::SetVolume(f32 volume, f32 fadeTime)
{
	m_volume = volume < 0.0f ? 0.0f : (volume > 2.0f ? 2.0f : volume);

	if(m_enable)
		m_fader = Fader(m_fader.GetCurrentValue(), m_volume, fadeTime);
	else
		m_fader = Fader(m_fader.GetCurrentValue(), 0, fadeTime);

}






//*** GroupManager ***//


GroupManager::GroupManager():
m_groups(VOX_GROUP_MASTER_ID + 1)
{
	// Create master group, with id 0
	Group masterGroup(VOX_GROUP_MASTER_ID, "master", VOX_GROUP_INVALID_ID);
	m_groups[VOX_GROUP_MASTER_ID] = masterGroup;
}

GroupManager::~GroupManager()
{
}


u32 GroupManager::GetGroupId(const char *name) const
{
	if(!name)
	{
		VOX_WARNING_LEVEL_2("[%s:%d] : Could not get group id. Name not provided", __FUNCTION__, __LINE__);
		return VOX_GROUP_INVALID_ID;
	}

	for(u32 i = 0; i < m_groups.size(); i++)
	{
		if(m_groups[i].GetId() != VOX_GROUP_INVALID_ID &&
		   VOX_STRNCASECMP(name, m_groups[i].GetName(), VOX_GROUP_NAME_SIZE-1) == 0)
		{
			return i;
		}
	}

	// Group not found.
	VOX_WARNING_LEVEL_2("[%s:%d] : Could not get inexistant group %s.", __FUNCTION__, __LINE__, name);
	return VOX_GROUP_INVALID_ID;
}


bool GroupManager::GetGroupName(u32 id, char *stringData, s32 maxString) const
{
	if(id >= m_groups.size())
		return false;
	if(m_groups[id].GetId() == VOX_GROUP_INVALID_ID)
		return false;
	if(strlen(m_groups[id].GetName()) + 1 > (u32)maxString)
		return false;
	strncpy(stringData, m_groups[id].GetName(), maxString);
	return true;
}


bool GroupManager::IsChild(u32 candidateId, u32 matchId) const
{
	if(candidateId >= m_groups.size())
		return false;

	if(candidateId == matchId)
		return true;

	u32 parentId = m_groups[candidateId].GetParent();

	while(parentId != VOX_GROUP_INVALID_ID)
	{
		if(parentId == matchId)
			return true;
		parentId = m_groups[parentId].GetParent();
	}

	return false;
}


bool GroupManager::IsGroupValid(u32 id) const
{
	if(id >= m_groups.size())
		return false;
	if(m_groups[id].GetId() == VOX_GROUP_INVALID_ID)
		return false;
	return true;
}

u32 GroupManager::AddGroup(group::CreationSettings &cs)
{

	// Group name is mandatory
	if(!cs.m_name)
	{
		VOX_WARNING_LEVEL_2("[%s:%d] : Could not register group. Group name not provided.)", __FUNCTION__, __LINE__);
		return VOX_GROUP_INVALID_ID;
	}

	if(cs.m_parentId >= m_groups.size())
	{
		VOX_WARNING_LEVEL_2("[%s:%d] : Could not register group. Can't find parent with id %d.", __FUNCTION__, __LINE__, cs.m_parentId);
		return VOX_GROUP_INVALID_ID;
	}
	if(m_groups[cs.m_parentId].GetId() == VOX_GROUP_INVALID_ID)
	{
		VOX_WARNING_LEVEL_2("[%s:%d] : Could not register group. Can't find parent with id %d.", __FUNCTION__, __LINE__, cs.m_parentId);
		return VOX_GROUP_INVALID_ID;
	}


	// find first free id
	u32 i=0;
	while(i<m_groups.size() && m_groups[i].GetId() != VOX_GROUP_INVALID_ID)
		i++;
	u32 id = i;

	if(id > 500)
	{
		VOX_WARNING_LEVEL_2("[%s:%d] : Failed registering Group ID %d - Way too many registered group IDs!", __FUNCTION__, __LINE__, id);
		return VOX_GROUP_INVALID_ID;
	}
	else
	{
		if(id >= m_groups.size())
			m_groups.resize(id+1);
	}

	m_groups[id] = Group(id, cs.m_name, cs.m_parentId);
	m_groups[id].SetVolume(cs.m_volume, 0);
	m_groups[id].SetEnable(cs.m_enable, 0);

	return id;
}

bool GroupManager::ReconfigureGroup(u32 id, group::CreationSettings &cs)
{
	if(id < m_groups.size())
	{
		if(m_groups[id].GetId() != VOX_GROUP_INVALID_ID)
		{
			m_groups[id].SetEnable(cs.m_enable, 0);
			m_groups[id].SetVolume(cs.m_enable, 0);
			return true;
		}
	}
	
	// Group not found.
	VOX_WARNING_LEVEL_4("[%s:%d] : Could reconfigure inexistant group with id %d.", __FUNCTION__, __LINE__, id);
	return false;

}

bool GroupManager::GetEnable(u32 id) const
{
	if(id < m_groups.size())
	{
		if(m_groups[id].GetId() != VOX_GROUP_INVALID_ID)
		{
			return m_groups[id].GetEnable();
		}
	}
	
	// Group not found.
	VOX_WARNING_LEVEL_4("[%s:%d] : Could not get enable property of inexistant group with id %d.", __FUNCTION__, __LINE__, id);
	return false;
}

bool GroupManager::SetEnable(u32 id, bool enable, f32 fadeTime)
{
	if(id < m_groups.size())
	{
		if(m_groups[id].GetId() != VOX_GROUP_INVALID_ID)
		{
			m_groups[id].SetEnable(enable, fadeTime);
			return true;
		}
	}
	
	// Group not found.
	VOX_WARNING_LEVEL_4("[%s:%d] : Could not set enable property of inexistant group with id %d.", __FUNCTION__, __LINE__, id);
	return false;
}	


f32 GroupManager::GetVolume(u32 id) const
{
	if(id < m_groups.size())
	{
		if(m_groups[id].GetId() != VOX_GROUP_INVALID_ID)
		{
			return m_groups[id].GetVolume();
		}
	}
	
	// Group not found.
	VOX_WARNING_LEVEL_4("[%s:%d] : Could not get volume of inexistant group with id %d.", __FUNCTION__, __LINE__, id);
	return 0.f;
}

bool GroupManager::SetVolume(u32 id, f32 volume, f32 fadeTime)
{
	if(id < m_groups.size())
	{
		if(m_groups[id].GetId() != VOX_GROUP_INVALID_ID)
		{
			m_groups[id].SetVolume(volume, fadeTime);
			return true;
		}
	}
	
	// Group not found.
	VOX_WARNING_LEVEL_4("[%s:%d] : Could not set volume of inexistant group with id %d.", __FUNCTION__, __LINE__, id);
	return false;
}

void GroupManager::Update(f32 dt)
{
	for(u32 i=0; i<m_groups.size(); i++)
		if(m_groups[i].GetId() != VOX_GROUP_INVALID_ID)
			m_groups[i].Update(dt);
	
	// Must be done in two steps or else hierarchical volumes could lag depending on id order
	for(u32 i=0; i<m_groups.size(); i++)
		if(m_groups[i].GetId() != VOX_GROUP_INVALID_ID)
			m_groups[i].m_effectiveVolume = GetEffectiveVolume(i);
}

f32 GroupManager::GetEffectiveVolume(u32 id) const
{
	if(id >= m_groups.size())
		return 1;

	u32 parentId = m_groups[id].GetParent();
	f32 volume = m_groups[id].GetFaderVolume();

	while(parentId != VOX_GROUP_INVALID_ID)
	{
		volume *= m_groups[parentId].GetFaderVolume();
		parentId = m_groups[parentId].GetParent();
	}

	if(volume > 2.0f)
	{
		volume = 2.0f;
	}

	return volume;
}



} // namespace vox


