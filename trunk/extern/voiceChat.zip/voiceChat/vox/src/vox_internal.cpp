
#include "StdAfx.h"
#include "vox_internal.h"
#include "vox.h"
#include "vox_macro.h"
#include "vox_stream_memorybuffer.h"
#include "vox_decoder_raw.h"
#include <string.h>
#include "vox_filesystem.h"
#include "vox_minibus_system.h"
#include "vox_decoder_native.h"
#include "vox_driver.h"
#include "vox_detect_neon.h"
#include "vox_profiler.h"

extern vox::f64 _GetTime();

//*** VoxEngineInternal ***//
namespace vox {	
	
VoxEngineInternal* VoxEngineInternal::s_voxEngineInternal = 0;

VoxEngineInternal* VoxEngineInternal::GetVoxEngineInternal()
{
	if(s_voxEngineInternal)
		return s_voxEngineInternal;
	else
		s_voxEngineInternal = VOX_NEW VoxEngineInternal();

	VOX_ASSERT_MSG(s_voxEngineInternal, "VoxEngineInternal creation failed\n");
	return s_voxEngineInternal;
}

VoxEngineInternal::VoxEngineInternal() : m_streamTypeCount(0), m_decoderTypeCount(0)
{
	m_dyingEmitter.reserve(128);
	m_dyingDataSource.reserve(128);

	// Make sure the detection is done beforehand instead of in the middle of the mixing thread;
	neonInstructionsPresent(); 

	for(s32 i = 0; i < Vox3DGeneralParameter::k_nCount; i++)
	{
		m_3DNeedUpdate[i] = false;
	}

	_SetDefault3DParameters();

	m_pPriorityBankMgr = (PriorityBankManager*) VOX_NEW PriorityBankManager();
	m_groupManager = (GroupManager *) VOX_NEW GroupManager();
	m_hwDriver = 0;

	memset(m_timeStamps, 0, VOX_NB_TIMESTAMP_GROUP * sizeof(u32));
	m_nextTimeStamp = 0;
	m_suspendCount = 0;

#if VOX_DEBUG_SERVER_ENABLE
	m_debugServer = VOX_NEW DebugServer();
	m_debugRate = 0;
#else
	m_debugServer = 0;
	m_debugRate = 0;
#endif
}

u32 VoxEngineInternal::AddPriorityBank(priority_bank::CreationSettings &cs)
{
	if(m_pPriorityBankMgr)
	{
		return m_pPriorityBankMgr->AddPriorityBank(cs);
	}
	return VOX_BANK_INVALID_ID;
}

bool VoxEngineInternal::ReconfigurePriorityBank(u32 id, priority_bank::CreationSettings &cs)
{
	if(m_pPriorityBankMgr)
	{
		return m_pPriorityBankMgr->SetPriorityBank(id, cs);
	}
	return false;
}

u32 VoxEngineInternal::GetPriorityBankId(const char *name)
{
	if(m_pPriorityBankMgr)
	{
		return m_pPriorityBankMgr->GetPriorityBankId(name);
	}
	return VOX_BANK_INVALID_ID;
}

VoxEngineInternal::~VoxEngineInternal()
{
	_ReleaseAllDatasource();

	VOX_ASSERT_MSG((m_dataObjects.Size() == 0) && (m_emitterObjects.Size() == 0) && (m_dataObjectsToAdd.Size() == 0) && (m_emitterObjectsToAdd.Size() == 0), "Not all data was released"); //should already be released
	VoxNativeSubDecoder::Clean();
	VOX_DELETE(m_pPriorityBankMgr);
	VOX_DELETE(m_groupManager);
	VOX_DELETE (m_hwDriver);
	FileSystemInterface::DestroyInstance();
	if(m_debugServer)
		VOX_DELETE(m_debugServer);

	BusRoutingChange* brc;
	while(m_busRoutingChanges.size() > 0)
	{
		brc = m_busRoutingChanges.back();
		m_busRoutingChanges.pop_back();
		VOX_DELETE(brc);
	}

	s_voxEngineInternal = 0;
}

void VoxEngineInternal::Initialize()
{
	if(!m_hwDriver)
		m_hwDriver = CreateDriver();

	VOX_ASSERT_MSG(m_hwDriver, "Hardware driver could not be created");

	FileSystemInterface::GetInstance();
}

bool VoxEngineInternal::SetMicrophoneCallback(RecordedAudioReceptor *receptor)
{
	bool success = false;

	if(m_hwDriver)
	{
		VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
		success = m_hwDriver->SetMicrophoneCallback(receptor);
	}

	return success;
}

void VoxEngineInternal::RemoveMicrophoneCallback()
{
	if(m_hwDriver)
	{
		VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
		m_hwDriver->RemoveMicrophoneCallback();
	}

}

// Interruptions //

void VoxEngineInternal::Suspend()
{
	VOX_WARNING_LEVEL_2("%s", __FUNCTION__);

	if(m_hwDriver)
	{
		VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
		if(m_suspendCount == 0 && m_hwDriver)
		{
#if (defined(VOX_TARGET_OS_IPHONE))
			m_hwDriver->RampOut();
#else
			m_hwDriver->Suspend();
#endif
		}
		m_suspendCount++;
	}
}

void VoxEngineInternal::Resume()
{
	VOX_WARNING_LEVEL_2("%s", __FUNCTION__);

	if(m_suspendCount <= 0) 
	{
		VOX_WARNING_LEVEL_1("%s", "Trying to resume a non-suspended engine");
	}

	if(m_hwDriver)
	{
		VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));

		if(m_suspendCount > 1)
		{
			m_suspendCount--;
		}
		else if(m_suspendCount == 1)
		{
			KillEmittersOnResume();
			if(m_hwDriver)
#if (defined(VOX_TARGET_OS_IPHONE))
				m_hwDriver->RampIn();
#else
				m_hwDriver->Resume();
#endif
			m_suspendCount=0;
		}
	}
}

bool VoxEngineInternal::IsSuspended()
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	return m_suspendCount > 0;
}

s32 VoxEngineInternal::RegisterStreamType( StreamTypeFactoryFnPtr fnPtr )
{
	if( (m_streamTypeCount + 1) >= VOX_MAX_STREAM_TYPES)
	{
		VOX_WARNING_LEVEL_2("%s", "Maximum stream type reached, cannot add new stream type");
		return -1;
	}

	s32 currId = m_streamTypeCount++;
	m_streamTypes[ currId ] = fnPtr;
	return currId;
}
	
s32 VoxEngineInternal::RegisterDecoderType( DecoderTypeFactoryFnPtr fnPtr )
{
	if( (m_decoderTypeCount + 1) >= VOX_MAX_DECODER_TYPES)
	{
		VOX_WARNING_LEVEL_2("%s", "Maximum decoder type reached, cannot add new decoder type");
		return -1;
	}

	s32 currId = m_decoderTypeCount++;
	m_decoderTypes[ currId ] = fnPtr;
	return currId;
}

void VoxEngineInternal::UpdateSources()
{	
	VOX_PROFILING_SCOPED_EVENT( __SEL, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngineInternal::UpdateSources", vox::VoxThread::GetCurThreadId());
	DataObj* dataSource;

	if(m_suspendCount > 0)
		return;

	{
		VOX_PROFILING_SCOPED_EVENT( __SEL, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngineInternal::UpdateSources:Merge", vox::VoxThread::GetCurThreadId());
	
	//Merge to add list to main list
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetWriteAccess());
	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.GetWriteAccess());

	if(m_dataObjectsToAdd.Size() > 0)
	{		
		m_dataObjects.Merge(&m_dataObjectsToAdd);
		m_dataObjectsToAdd.EmptyContainer();		
	}

	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.ReleaseWriteAccess());
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseWriteAccess());
	}
	VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Lock());
	int size = m_dataSourceToUpdate.size(); //Only update elements that were in when update began

	VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Unlock());

	for(int i = 0; i < size; i++)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetWriteAccess());

		VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Lock());
		dataSource = m_dataSourceToUpdate.front();
		m_dataSourceToUpdate.pop_front();
		VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Unlock());

		if(dataSource->ShouldDie())
		{
			//m_dataObjects.Detach(dataSource->GetId());
			DetachDataObject(dataSource->GetId());
			VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseWriteAccess());
			ReleaseDatasource(dataSource);			
		}
		else
		{
			dataSource->SetUpdating(false);
			VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseWriteAccess());
			VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
			dataSource->Update();
			VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		}	
	}
}
	
void VoxEngineInternal::UpdateEmitters(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT( __SEL, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngineInternal::UpdateEmitters", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	if(m_suspendCount > 0)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	if(dt < 0.0f)
	{
		dt = 0.0f;
	}
	else if(dt > 0.1f)
	{
		dt = 0.1f;
	}

	//Update Listener
	Update3D();
	UpdateDSP(dt);
	//Update Gains

	if(m_groupManager)
	{
		m_groupManager->Update(dt);
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());

	//Merge to add list to main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetWriteAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetWriteAccess());

	if(m_emitterObjectsToAdd.Size() > 0)
	{		
		m_emitterObjects.Merge(&m_emitterObjectsToAdd);
		m_emitterObjectsToAdd.EmptyContainer();		
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseWriteAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseWriteAccess());

	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();

#if VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
	VoxEmitterStateChangedCallbackFunc stateChangedCallback;
	void* stateChangedCallbackUserData;
	EmitterExternState state;
#endif

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		if(m_groupManager)
			((EmitterObj*)iter->second)->SetGainModifier(m_groupManager->GetEffectiveVolume(((EmitterObj*)iter->second)->GetGroup()));
		((EmitterObj*)iter->second)->Update(dt);
#if VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
		if(((EmitterObj*)iter->second)->NeedToSendStateChangedCallback(stateChangedCallback, stateChangedCallbackUserData, state))
		{
			EmitterHandle _eh = EmitterHandle(((EmitterObj*)iter->second)->GetId(), &s_voxEngineInternal, ((EmitterObj*)iter->second), m_timeStamps[((EmitterObj*)iter->second)->GetTimeStampGroup()], ((EmitterObj*)iter->second)->GetTimeStampGroup());
			m_callbackManager.Add(VOX_NEW VoxEmitterStateChangedCallback(_eh, stateChangedCallback, stateChangedCallbackUserData, state));
		}
#endif
#else
		if(m_groupManager)
			((EmitterObj*)(*iter))->SetGainModifier(m_groupManager->GetEffectiveVolume(((EmitterObj*)(*iter))->GetGroup()) * masterGain );
		((EmitterObj*)(*iter))->Update(dt);
#if VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
		if(((EmitterObj*)(*iter))->NeedToSendStateChangedCallback(stateChangedCallback, stateChangedCallbackUserData, state))
		{
			EmitterHandle _eh = EmitterHandle(((EmitterObj*)(*iter))->GetId(), &s_voxEngineInternal, ((EmitterObj*)(*iter)), m_timeStamps[((EmitterObj*)(*iter))->GetTimeStampGroup()], ((EmitterObj*)(*iter))->GetTimeStampGroup());
			m_callbackManager.Add(VOX_NEW VoxEmitterStateChangedCallback(_eh, stateChangedCallback, stateChangedCallbackUserData, state));
		}
#endif
#endif
	}


	iter = m_emitterObjects.begin();
	last = m_emitterObjects.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		if(((EmitterObj*)iter->second)->ShouldDie())
		{
			m_dyingEmitter.push_back(((EmitterObj*)iter->second));
		}
#else
		if(((EmitterObj*)(*iter))->ShouldDie())
		{
			m_dyingEmitter.push_back((EmitterObj*)(*iter));
		}
#endif
	}

	//update prio bank
	if(m_pPriorityBankMgr)
		m_pPriorityBankMgr->Update();



	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());

	if(m_dyingEmitter.size() > 0)
	{
		VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetWriteAccess());

		while(m_dyingEmitter.size() > 0)
		{
			KillEmitter((EmitterObj*)m_emitterObjects.Detach(m_dyingEmitter.back()->GetId()));
			m_dyingEmitter.pop_back();
		}

		VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseWriteAccess());
	}
//#else
//	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
//#endif

#if VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
	//send callback
	m_callbackManager.SendAll();
#endif

#if VOX_DEBUG_SERVER_ENABLE
	UpdateDebugServer();
#endif
}

void VoxEngineInternal::UpdateDebugServer()
{
#if VOX_DEBUG_SERVER_ENABLE
	if(m_debugServer && m_debugRate == 0)
	{
		m_debugServer->Receive();

		if(m_debugServer->GetState() == DebugServerState::k_nSendingData)
		{
			char* cursor = m_debugServer->m_data;
			DebugPacketHeader* header =	(DebugPacketHeader*)m_debugServer->m_data;
			cursor += sizeof(DebugPacketHeader);
			header->pcktSize = sizeof(DebugPacketHeader) - 8;
			header->id;
			header->version;
			header->type;
			header->timestamp;
			
			DebugExtendedPacketHeader_data* extHeader = (DebugExtendedPacketHeader_data*)cursor;
			cursor += sizeof(DebugExtendedPacketHeader_data);
			extHeader->pcktSize = sizeof(DebugExtendedPacketHeader_data) - 8;
			
			DebugChunk_group* dbgchunk_group = (DebugChunk_group*)cursor;
			extHeader->groupChunkSize = sizeof(DebugChunk_group);
			extHeader->nGroupChunk = 1;
			cursor += extHeader->groupChunkSize;
			

			if(m_groupManager)
			{
				VOX_MUTEX_LEVEL_1(m_mutex.Lock());
				for(s32 i = 0; i < 32; i++)
					dbgchunk_group->currentGain[i] = m_groupManager->GetEffectiveVolume(i);
				VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
			}
			else
				for(s32 i = 0; i < 32; i++)
					dbgchunk_group->currentGain[i] = 0;

			for(s32 i = 0; i < 32; i++)
				dbgchunk_group->targetGain[i] = GetGroupVolume(i);


			DebugChunk_bank* dbgchunk_bank = (DebugChunk_bank*)cursor;
			extHeader->bankChunkSize = sizeof(DebugChunk_bank);
			extHeader->nBankChunk = VOX_NUM_PRIORITY_BANK;
			cursor += extHeader->bankChunkSize * extHeader->nBankChunk;
			
			if(((s32)cursor - (s32)m_debugServer->m_data) >= 60 * 1024)
			{
				VOX_WARNING_LEVEL_2("Too much data for packet to debug server (%d)", cursor); 
				return;
			}
			else if(m_pPriorityBankMgr)
			{
				m_pPriorityBankMgr->GetDebugInfo(dbgchunk_bank);
			}

			VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());

			DebugChunk_dataSource* dbgchunk_dataSource = (DebugChunk_dataSource*)cursor;
			s32 size = m_dataObjects.Size();
			extHeader->dataSourceChunkSize = sizeof(DebugChunk_dataSource);
			extHeader->nDataSourceChunk = size;
			cursor += extHeader->dataSourceChunkSize * extHeader->nDataSourceChunk;
			
			if(((s32)cursor - (s32)m_debugServer->m_data) >= 60 * 1024)
			{
				VOX_WARNING_LEVEL_2("Too much data for packet to debug server (%d)", cursor); 
				VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
				return;
			}
			else
			{
				HandlableContainerIterator iter = m_dataObjects.begin();
				HandlableContainerIterator last = m_dataObjects.end();

				for(;iter != last; iter++)
				{
#if VOX_USE_HANDLABLE_MAP
					((DataObj*)iter->second)->GetDebugInfo(*dbgchunk_dataSource);
#else
					((DataObj*)(*iter))->GetDebugInfo(*dbgchunk_dataSource);
#endif
					++dbgchunk_dataSource;
				}
			}

			VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

			VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());

			DebugChunk_emitter* dbgchunk_emitter = (DebugChunk_emitter*)cursor;
			size = m_emitterObjects.Size();
			extHeader->emitterChunkSize = sizeof(DebugChunk_emitter);
			extHeader->nEmitterChunk = size;
			cursor += extHeader->emitterChunkSize * extHeader->nEmitterChunk;
			
			if(((s32)cursor - (s32)m_debugServer->m_data) >= 60 * 1024)
			{
				VOX_WARNING_LEVEL_2("Too much data for packet to debug server (%d)", cursor); 
				VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
				return;
			}
			else
			{
				HandlableContainerIterator iter = m_emitterObjects.begin();
				HandlableContainerIterator last = m_emitterObjects.end();

				for(;iter != last; iter++)
				{
#if VOX_USE_HANDLABLE_MAP
					((EmitterObj*)iter->second)->GetDebugInfo(*dbgchunk_emitter);
#else
					((EmitterObj*)(*iter))->GetDebugInfo(*dbgchunk_emitter);
#endif
					++dbgchunk_emitter;
				}
			}

			VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());

			DebugChunk_general3d* dbgchunk_general3d = (DebugChunk_general3d*)cursor;
			extHeader->general3dChunkSize = sizeof(DebugChunk_general3d);
			extHeader->nGeneral3dChunk = 1;
			cursor += extHeader->general3dChunkSize * extHeader->nGeneral3dChunk;

			if(((s32)cursor - (s32)m_debugServer->m_data) >= 60 * 1024)
			{
				VOX_WARNING_LEVEL_2("Too much data for packet to debug server (%d)", cursor); 
				return;
			}
			else
			{
				VOX_MUTEX_LEVEL_1(m_mutex.Lock());

				m_position.ToArray(dbgchunk_general3d->listenerPosition);
				m_velocity.ToArray(dbgchunk_general3d->listenerVelocity);
				m_lookAt.ToArray(dbgchunk_general3d->listenerDirection);
				m_upVector.ToArray(dbgchunk_general3d->listenerUp);
				memcpy(&(dbgchunk_general3d->param3D), &m_3Dparameters, sizeof(Vox3DGeneralParameters));

				VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
			}

			m_debugServer->Send(m_debugServer->m_data, (s32)cursor - (s32)m_debugServer->m_data);
		}
	}
	m_debugRate = (++m_debugRate) % VOX_DEBUG_SERVER_UPDATE_RATE;
#endif
}

void VoxEngineInternal::Update3D()
{
	if(!m_hwDriver)
		return;
	
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nDopplerFactor])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nDopplerFactor, &m_3Dparameters.dopplerFactor);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nDopplerFactor] = false;
	}

	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nSpeedOfSound])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nSpeedOfSound, &m_3Dparameters.speedOfSound);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nSpeedOfSound] = false;
	}

	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nDistanceModel])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nDistanceModel, &m_3Dparameters.distanceModel);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nDistanceModel] = false;
	}

	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3d])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3d, &m_3Dparameters.enhanced3d);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3d] = false;
	}

	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerPosition])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nListenerPosition, &m_position);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerPosition] = false;
	}

	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerVelocity])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nListenerVelocity, &m_velocity);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerVelocity] = false;
	}

	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerOrientation])
	{
		VoxVector3f orientation[2];
		orientation[0] = m_lookAt;
		orientation[1] = m_upVector;
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nListenerOrientation, &orientation);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerOrientation] = false;
	}

	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower, &m_3Dparameters.enhanced3dStereoPanningPower);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront, &m_3Dparameters.enhanced3dStereoMaxDelayFront);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack, &m_3Dparameters.enhanced3dStereoMaxDelayBack);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepth])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchDepth, &m_3Dparameters.enhanced3dNotchDepth);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepth] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide, &m_3Dparameters.enhanced3dNotchDepthSide);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack, &m_3Dparameters.enhanced3dNotchDepthBack);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance, &m_3Dparameters.enhanced3dNotchDepthDistance);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidth])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchWidth, &m_3Dparameters.enhanced3dNotchWidth);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidth] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide, &m_3Dparameters.enhanced3dNotchWidthSide);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack, &m_3Dparameters.enhanced3dNotchWidthBack);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance, &m_3Dparameters.enhanced3dNotchWidthDistance);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum, &m_3Dparameters.enhanced3dDistanceWidthMinimum);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum, &m_3Dparameters.enhanced3dDistanceWidthMaximum);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve, &m_3Dparameters.enhanced3dDistanceWidthCurve);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide, &m_3Dparameters.enhanced3dDistanceWidthSide);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack, &m_3Dparameters.enhanced3dDistanceWidthBack);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency, &m_3Dparameters.enhanced3dDistanceFrequency);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency] = false;
	}
	if(m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor])
	{
		m_hwDriver->Set3DParameter(Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor, &m_3Dparameters.enhanced3dRolloffFactor);
		m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor] = false;
	}
	
}

void VoxEngineInternal::UpdateDSP(f32 dt)
{
	BusRoutingChange* brc;
	while(m_busRoutingChanges.size() > 0)
	{
		brc = m_busRoutingChanges.back();
		m_busRoutingChanges.pop_back();
		if(m_hwDriver)
			m_hwDriver->SetDSPParameter(VoxDSPGeneralParameter::k_nRoutingVolume, (void*)brc);
		VOX_DELETE(brc);
	}

	if(m_hwDriver)
		m_hwDriver->Update(dt);
}

DataHandle VoxEngineInternal::LoadDataSource( const data_source::CreationSettings& cs)
{
	DataHandle dh;
	if(cs.m_loadingFlags & k_nAsync)
		dh = LoadDataSourceAsync(cs.m_streamType,cs.m_pStreamParams,cs.m_decoderType,cs.m_pDecoderParams,cs.m_groupId,(VoxSourceLoadingFlags)(cs.m_loadingFlags & k_mLoadFlagMask));
	else if(cs.m_loadingFlags & k_nLoadToRam)
	{
		dh = LoadDataSource(cs.m_streamType,cs.m_pStreamParams,cs.m_decoderType,cs.m_pDecoderParams,cs.m_groupId);
		dh = ConvertToRawSource(dh);
	}
	else if(cs.m_loadingFlags == k_nLoadToRamAndDecode)
	{
		dh = LoadDataSource(cs.m_streamType,cs.m_pStreamParams,cs.m_decoderType,cs.m_pDecoderParams,cs.m_groupId);
		dh = ConvertToRamBufferSource(dh);
	}
	else
	{
		dh = LoadDataSource(cs.m_streamType,cs.m_pStreamParams,cs.m_decoderType,cs.m_pDecoderParams,cs.m_groupId);
	}
	SetUid(dh, cs.m_uid); // can do reentrant function because there's no mutex

	return dh;
}

DataHandle VoxEngineInternal::LoadDataSource( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, u32 groupId )
{
	// Function has its own mutex
	if(!IsGroupValid(groupId))
	{
		VOX_WARNING_LEVEL_3("Group id %d invalid! Adding to group 0 (master) instead.", groupId);
		groupId = 0;
	}

	StreamInterface* stream = 0;
	if ( ( streamType >= 0 ) && ( streamType < m_streamTypeCount ) )
	{
		// Call factory method
		StreamTypeFactoryFnPtr factory = m_streamTypes[streamType];
		if ( factory )
		{
			stream = (*factory)( streamParams );
		}
	}
	else
	{
		// no such stream type
		VOX_ASSERT( 0 );
	}

	if(!stream)
		return DataHandle(-1);

	DecoderInterface* decoder = 0;
	if ( ( decoderType >= 0 ) && ( decoderType < m_decoderTypeCount ) )
	{
		// Call factory method
		DecoderTypeFactoryFnPtr factory = m_decoderTypes[decoderType];
		if ( factory )
		{
			decoder = (*factory)( decoderParams );
		}
	}
	else
	{
		// no such decoder type
		VOX_ASSERT( 0 );
	}

	if(!decoder)
	{
		VOX_DELETE (stream);
		return DataHandle(-1);
	}

	DataObj* pdo = 0;
	StreamCursorInterface* streamCursor = stream->CreateNewCursor();
	if(streamCursor)
	{
		DecoderCursorInterface* decoderCursor = decoder->CreateNewCursor(streamCursor);
		if(decoderCursor)
		{
			TrackParams trackParam = decoderCursor->GetTrackParams();
			decoder->DestroyCursor(decoderCursor);
			if(trackParam.numChannels > 0)
				pdo = VOX_NEW DataObj(GetFreeDataObjectId(), stream, decoder, trackParam, groupId);
		}
		
		stream->DestroyCursor(streamCursor);
	}

	//if(!dod)
	//	dod = VOX_NEW DataObj(GetFreeDataObjectId(), stream, decoder, groupId);

	if(!pdo)
	{
		VOX_WARNING_LEVEL_2("%s", "Could not create DataSource");
		VOX_DELETE (stream);
		VOX_DELETE (decoder);
		return DataHandle(-1);
	}

	pdo->SetTimeStampGroup(m_nextTimeStamp);
	DataHandle dh = DataHandle(pdo->GetId(), &s_voxEngineInternal, pdo, m_timeStamps[m_nextTimeStamp], m_nextTimeStamp);
	m_nextTimeStamp = (m_nextTimeStamp + 1) % VOX_NB_TIMESTAMP_GROUP;

	//VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetWriteAccess());
	//m_dataObjects.Add(pdo);
	//VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseWriteAccess());

	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.GetWriteAccess());
	m_dataObjectsToAdd.Add(pdo);
	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.ReleaseWriteAccess());

	VOX_WARNING_LEVEL_5("Loaded data source %lld (%s). %s", pdo->GetId(), static_cast<c8*> (streamParams), pdo->GetUserData().ToString());
	return dh;
}

DataHandle VoxEngineInternal::LoadDataSourceAsync( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, u32 groupId, VoxSourceLoadingFlags loadingFlags )
{
	// Function has its own mutex
	if(!IsGroupValid(groupId))
	{
		VOX_WARNING_LEVEL_3("Group id %d invalid! Adding to group 0 (master) instead.", groupId);
		groupId = 0;
	}

	StreamInterface* stream = 0;
	if ( ( streamType >= 0 ) && ( streamType < m_streamTypeCount ) )
	{
		// Call factory method
		StreamTypeFactoryFnPtr factory = m_streamTypes[streamType];
		if ( factory )
		{
			stream = (*factory)( streamParams );
		}
	}
	else
	{
		// no such stream type
		VOX_ASSERT( 0 );
	}

	if(!stream)
		return DataHandle(-1);

	DecoderInterface* decoder = 0;
	if ( ( decoderType >= 0 ) && ( decoderType < m_decoderTypeCount ) )
	{
		// Call factory method
		DecoderTypeFactoryFnPtr factory = m_decoderTypes[decoderType];
		if ( factory )
		{
			decoder = (*factory)( decoderParams );
		}
	}
	else
	{
		// no such decoder type
		VOX_ASSERT( 0 );
	}

	if(!decoder)
	{
		VOX_DELETE (stream);
		return DataHandle(-1);
	}

	DataObj* pdo = 0;
	pdo = VOX_NEW DataObj(GetFreeDataObjectId(), stream, decoder, groupId, (VoxSourceLoadingFlags)(loadingFlags & k_mLoadFlagMask));

	if(!pdo)
	{
		VOX_DELETE (stream);
		VOX_DELETE (decoder);
		return DataHandle(-1);
	}

	pdo->SetTimeStampGroup(m_nextTimeStamp);
	DataHandle dh = DataHandle(pdo->GetId(), &s_voxEngineInternal, pdo, m_timeStamps[m_nextTimeStamp], m_nextTimeStamp);
	m_nextTimeStamp = (m_nextTimeStamp + 1) % VOX_NB_TIMESTAMP_GROUP;

	//VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetWriteAccess());
	//m_dataObjects.Add(pdo);
	//VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseWriteAccess());

	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.GetWriteAccess());
	m_dataObjectsToAdd.Add(pdo);
	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.ReleaseWriteAccess());

	VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Lock());
	pdo->SetUpdating(true);
	m_dataSourceToUpdate.push_back(pdo);
	VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Unlock());

	VOX_WARNING_LEVEL_5("Async loading data source %lld (%s). %s", pdo->GetId(), static_cast<c8*> (streamParams), pdo->GetUserData().ToString());

	return dh;
}

DataHandle VoxEngineInternal::ConvertToRawSource(DataHandle &handle )
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dobj = GetDataObject(handle);
	
	if(!dobj)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return DataHandle(-1);
	}

	DataHandle dataHandle;

	StreamCursorInterface* streamCursor = 0;
	DecoderCursorInterface* decoderCursor = 0;
	StreamInterface* stream = dobj->GetStream();
	DecoderInterface* decoder = dobj->GetDecoder();

	if(stream)
	{
		streamCursor = stream->CreateNewCursor();
	}

	if(streamCursor)
	{
		if(decoder)
			decoderCursor = decoder->CreateNewCursor(streamCursor);

		if(decoderCursor)
		{
			s32 size = decoderCursor->GetNumSamples() * decoderCursor->GetNumChannels() * (decoderCursor->GetBitsPerSample() >> 3);

			if(size <= 0)
			{
				decoder->DestroyCursor(decoderCursor);
				stream->DestroyCursor(streamCursor);
				VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
				return DataHandle(-1);
			}

			s32 readsize = 0;

			#if defined(_NN_CTR)
				u8* buf = (u8*)VOX_ALLOC_ALIGN(size, (vox::VoxMemHint)(vox::k_nVoxMemHint_Align32 | vox::k_nVoxMemHint_RamBuffer));
			#else
				u8* buf = (u8*)VOX_ALLOC(size);
			#endif

			if(buf)
			{
				decoderCursor->Seek(0);

				readsize = decoderCursor->Decode(buf, size);
				if(readsize != size)
				{
					VOX_WARNING_LEVEL_4("(%s) Data size not the size expected : %d B instead of %d B", __FUNCTION__, readsize, size);
				}
			}
			
			DecoderRawParams decoderParams;
			decoderParams.numChannels = decoderCursor->GetNumChannels();
			decoderParams.samplingRate = decoderCursor->GetSamplingRate();
			decoderParams.bitsPerSample = decoderCursor->GetBitsPerSample();
			decoderParams.numSamples = decoderCursor->GetNumSamples();

			decoder->DestroyCursor(decoderCursor);
			stream->DestroyCursor(streamCursor);
			VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

			if(buf)
			{
				StreamMemoryBufferParams streamParams;
				streamParams.buffer = buf;
				streamParams.size = readsize;
				streamParams.doCopy = false;
				streamParams.takeOwnership = true;

				dataHandle = LoadDataSource(vox::k_nStreamTypeMemoryBuffer, &streamParams, vox::k_nDecoderTypeRAW, &decoderParams, dobj->GetGroup());
			}
		}
		else
		{
			stream->DestroyCursor(streamCursor);
		}
	}
	else
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
	}

	return dataHandle;
}

DataHandle VoxEngineInternal::ConvertToRamBufferSource(DataHandle &handle )
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dobj = GetDataObject(handle);;
	
	if(!dobj)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return DataHandle(-1);
	}

	DataHandle dataHandle;

	StreamCursorInterface* streamCursor = 0;
	StreamInterface* stream = dobj->GetStream();
	DecoderInterface* decoder = dobj->GetDecoder();

	if(stream && decoder)
	{
		streamCursor = stream->CreateNewCursor();
	}

	if(streamCursor)
	{
		s32 size = stream->Size();

		if(size <= 0)
		{
			stream->DestroyCursor(streamCursor);
			VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
			return DataHandle(-1);
		}

		#if defined(_NN_CTR)
			u8* buf = (u8*)VOX_ALLOC_ALIGN(size, (vox::VoxMemHint)(vox::k_nVoxMemHint_Align32 | vox::k_nVoxMemHint_RamBuffer));
		#else
			u8* buf = (u8*)VOX_ALLOC(size);
		#endif

		if(buf)
		{
			streamCursor->Seek(0);
			s32 readsize = streamCursor->Read(buf, size);
			VOX_ASSERT_MSG(readsize == size, "Stream conversion error");
		}
		
		stream->DestroyCursor(streamCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		
		if(buf)
		{
			StreamMemoryBufferParams streamParams;
			streamParams.buffer = buf;
			streamParams.size = size;
			streamParams.doCopy = false;
			streamParams.takeOwnership = true;

			dataHandle = LoadDataSource(vox::k_nStreamTypeMemoryBuffer, &streamParams, decoder->GetType(), decoder->GetParam(), dobj->GetGroup());
		}
	}
	else
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
	}

	return dataHandle;
}

// Important requires to be used within AccessController protection
DataObj* VoxEngineInternal::GetDataObject( DataHandle& handle )
{
	DataObj* dobj = 0;

	u32 timeStamp, tsGroup;
	handle.GetTimeStamp(timeStamp, tsGroup);

	if(m_timeStamps[tsGroup] == timeStamp)
	{
		dobj = (DataObj*)handle.GetObjectPointer();
	}

	if(dobj == 0) //Could not get or timestamp expired
	{
		dobj = (DataObj*)m_dataObjects.Find(handle.GetId());
		if(dobj)
		{
			tsGroup = dobj->GetTimeStampGroup();
			handle.SetTimeStamp(m_timeStamps[tsGroup], tsGroup);
		}
		else //try the "to add list"
		{
			VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.GetReadAccess());
			dobj = (DataObj*)m_dataObjectsToAdd.Find(handle.GetId());
			VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.ReleaseReadAccess());
			if(dobj)
			{
				tsGroup = dobj->GetTimeStampGroup();
				handle.SetTimeStamp(m_timeStamps[tsGroup], tsGroup);
			}
		}
	}

	//if(handle.m_debugPointerToObjectThatIsNotGaranteedToExistAnymore)
	//	dobj = (DataObj*)handle.m_debugPointerToObjectThatIsNotGaranteedToExistAnymore;
	//else
	//	dobj = (DataObj*)m_dataObjects.Find(handle.GetId());
	return dobj;
}

// Important requires to be used within AccessController protection
DataObj* VoxEngineInternal::DetachDataObject( HandleId dataObjId )
{
	DataObj* dobj = 0;

	dobj = (DataObj*)m_dataObjects.Detach(dataObjId);
	if(!dobj) //try the "to add list"
	{
		VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.GetWriteAccess());
		dobj = (DataObj*)m_dataObjectsToAdd.Detach(dataObjId);
		VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.ReleaseWriteAccess());
	}

	return dobj;
}

void VoxEngineInternal::DecreaseDataObjectRefCount( DataHandle& handle )
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dobj = GetDataObject(handle);
	if(dobj)
	{
		dobj->Release();

		VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Lock());
		if(!dobj->IsUpdating())
		{
			dobj->SetUpdating(true);
			m_dataSourceToUpdate.push_back(dobj);
		}
		VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Unlock());
	}
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::IncreaseDataObjectRefCount( DataHandle& handle )
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dobj = GetDataObject(handle);
	if(dobj)
		dobj->Retain();
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
}

// Important requires to be used within AccessController protection
EmitterObj* VoxEngineInternal::GetEmitterObject( EmitterHandle& handle )
{
	EmitterObj* eobj = 0;

	u32 timeStamp, tsGroup;
	handle.GetTimeStamp(timeStamp, tsGroup);

	if(m_timeStamps[tsGroup] == timeStamp)
	{
		eobj = (EmitterObj*)handle.GetObjectPointer();
	}

	if(eobj == 0) //Could not get or timestamp expired
	{
		eobj = (EmitterObj*)m_emitterObjects.Find(handle.GetId());
		if(eobj)
		{
			tsGroup = eobj->GetTimeStampGroup();
			handle.SetTimeStamp(m_timeStamps[tsGroup], tsGroup);
		}
		else //try the "to add list" //TODO check
		{
			VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());
			eobj = (EmitterObj*)m_emitterObjectsToAdd.Find(handle.GetId());
			VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
			if(eobj)
			{
				tsGroup = eobj->GetTimeStampGroup();
				handle.SetTimeStamp(m_timeStamps[tsGroup], tsGroup);
			}
		}
	}

	//if(handle.m_debugPointerToObjectThatIsNotGaranteedToExistAnymore)
	//	eobj = (EmitterObj*)handle.m_debugPointerToObjectThatIsNotGaranteedToExistAnymore;
	//else
	//	eobj = (EmitterObj*)m_emitterObjects.Find(handle.GetId());
	return eobj;
}

// Important requires to be used within AccessController protection
EmitterObj* VoxEngineInternal::DetachEmitterObject( HandleId emitterId )
{
	EmitterObj* eobj = 0;

	eobj = (EmitterObj*)m_emitterObjects.Detach(emitterId);
	if(!eobj) //try the "to add list" //TODO check
	{
		VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetWriteAccess());
		eobj = (EmitterObj*)m_emitterObjectsToAdd.Detach(emitterId);
		VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseWriteAccess());
	}

	return eobj;
}

void VoxEngineInternal::DecreaseEmitterObjectRefCount( EmitterHandle& handle )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* eobj = GetEmitterObject(handle);
	if(eobj)
		eobj->Release();
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::IncreaseEmitterObjectRefCount( EmitterHandle& handle )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* eobj = GetEmitterObject(handle);
	if(eobj)
		eobj->Retain();
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

HandleId VoxEngineInternal::GetFreeDataObjectId()
{
	HandleId h = m_dataObjects.GetFreeHandleId();
	return h;
}

HandleId VoxEngineInternal::GetFreeEmitterObjectId()
{
	HandleId h = m_emitterObjects.GetFreeHandleId();
	return h;
}

void VoxEngineInternal::RegisterForEmitterStateChangeNotification( EmitterHandle &handle, VoxEmitterStateChangedCallbackFunc callback, void* userData)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* eobj = GetEmitterObject(handle);
	if(eobj)
	{
		eobj->RegisterStateChangedCallback(callback, userData);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::UnregisterForEmitterStateChangeNotification( EmitterHandle &handle)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* eobj = GetEmitterObject(handle);
	if(eobj)
	{
		eobj->UnregisterStateChangedCallback();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

EmitterHandle VoxEngineInternal::CreateEmitter( DataHandle &handle, const emitter::CreationSettings &cs)
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);

	if(!dataSource)
	{
		VOX_WARNING_LEVEL_3("%s", "Could not get a data source, cannot create emitter");
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	if(!dataSource->IsReady())
	{
		VOX_WARNING_LEVEL_3("Data source %lld not ready yet, cannot create emitter", dataSource->GetId());
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	StreamInterface* stream = dataSource->GetStream();
	DecoderInterface* decoder = dataSource->GetDecoder();

	if(!stream || !decoder)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	StreamCursorInterface* streamCursor = stream->CreateNewCursor();
	if(!streamCursor)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	DecoderCursorInterface* decoderCursor = decoder->CreateNewCursor(streamCursor);
	if(!decoderCursor)
	{
		stream->DestroyCursor(streamCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	TrackParams trackParam = decoderCursor->GetTrackParams();
	DriverSourceInterface* driverSource = 0;
	if(trackParam.numChannels > 0 && m_hwDriver)
	{
		driverSource = m_hwDriver->CreateDriverSource(&trackParam, 0, cs.m_priority);
	}

	if(!driverSource)
	{
		stream->DestroyCursor(streamCursor);
		decoder->DestroyCursor(decoderCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}
	long bufferSize;
	if(driverSource->AllowBufferReference() && decoderCursor->AllowBufferReference())
	{
		bufferSize = decoderCursor->GetNumSamples() * decoderCursor->GetBitsPerSample() / 8;
	}
	else
	{
		bufferSize = decoderCursor->GetNumChannels() * decoderCursor->GetBitsPerSample() / 8 * decoderCursor->GetSamplingRate() * VOX_EMITTER_BUFFER_DURATION_MS / 1000;
	}
	EmitterObj* emitter = 0;
	if(bufferSize > 0)
	{
		bufferSize -= (bufferSize % (decoderCursor->GetNumChannels() * decoderCursor->GetBitsPerSample() / 8)); //Needs to be a multiple of sampleSize*NumChannel
		emitter = VOX_NEW EmitterObj(GetFreeEmitterObjectId(), cs, bufferSize, driverSource, decoderCursor, dataSource);
	}
	if(!emitter)
	{
		stream->DestroyCursor(streamCursor);
		decoder->DestroyCursor(decoderCursor);
		if(m_hwDriver)
			m_hwDriver->DestroyDriverSource(driverSource);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}
	if(cs.m_groupId == VOX_GROUP_INVALID_ID)
		emitter->SetGroup(dataSource->GetGroup());//inherit from source
	else
		emitter->SetGroup(cs.m_groupId);//group specified in creation settings
	dataSource->RegisterEmitter(emitter->GetId());
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	emitter->SetTimeStampGroup(m_nextTimeStamp);
	EmitterHandle eh = EmitterHandle(emitter->GetId(), &s_voxEngineInternal, emitter, m_timeStamps[m_nextTimeStamp], m_nextTimeStamp);
	m_nextTimeStamp = (m_nextTimeStamp + 1) % VOX_NB_TIMESTAMP_GROUP;

	//VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetWriteAccess());
	//m_emitterObjects.Add(emitter);
	//VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseWriteAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetWriteAccess());
	m_emitterObjectsToAdd.Add(emitter);
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseWriteAccess());

	return eh; 
}


EmitterHandle VoxEngineInternal::CreateEmitter( DataHandle &handle, s32 priority, void* driverParam )
{ 
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);

	if(!dataSource)
	{
		VOX_WARNING_LEVEL_3("%s", "Could not get a data source, cannot create emitter");
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	if(!dataSource->IsReady())
	{
		VOX_WARNING_LEVEL_3("Data source %lld not ready yet, cannot create emitter", dataSource->GetId());
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	StreamInterface* stream = dataSource->GetStream();
	DecoderInterface* decoder = dataSource->GetDecoder();

	if(!stream || !decoder)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	StreamCursorInterface* streamCursor = stream->CreateNewCursor();
	if(!streamCursor)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	DecoderCursorInterface* decoderCursor = decoder->CreateNewCursor(streamCursor);
	if(!decoderCursor)
	{
		stream->DestroyCursor(streamCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	TrackParams trackParam = decoderCursor->GetTrackParams();
	DriverSourceInterface* driverSource = 0;
	if(trackParam.numChannels > 0 && m_hwDriver)
	{
		driverSource = m_hwDriver->CreateDriverSource(&trackParam, driverParam, priority);
	}

	if(!driverSource)
	{
		stream->DestroyCursor(streamCursor);
		decoder->DestroyCursor(decoderCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}
	long bufferSize;
	if(driverSource->AllowBufferReference() && decoderCursor->AllowBufferReference())
	{
		bufferSize = decoderCursor->GetNumSamples() * decoderCursor->GetBitsPerSample() / 8;
	}
	else
	{
		bufferSize = decoderCursor->GetNumChannels() * decoderCursor->GetBitsPerSample() / 8 * decoderCursor->GetSamplingRate() * VOX_EMITTER_BUFFER_DURATION_MS / 1000;
	}
	EmitterObj* emitter = 0;
	if(bufferSize > 0)
	{
		bufferSize -= (bufferSize % (decoderCursor->GetNumChannels() * decoderCursor->GetBitsPerSample() / 8)); //Needs to be a multiple of sampleSize*NumChannel
		emitter = VOX_NEW EmitterObj(GetFreeEmitterObjectId(), priority, dataSource->GetPriorityBank(), bufferSize, driverSource, decoderCursor, dataSource);
	}
	if(!emitter)
	{
		stream->DestroyCursor(streamCursor);
		decoder->DestroyCursor(decoderCursor);
		if(m_hwDriver)
			m_hwDriver->DestroyDriverSource(driverSource);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}
	emitter->SetGroup(dataSource->GetGroup());//inherit from source
	dataSource->RegisterEmitter(emitter->GetId());
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	emitter->SetTimeStampGroup(m_nextTimeStamp);
	EmitterHandle eh = EmitterHandle(emitter->GetId(), &s_voxEngineInternal, emitter, m_timeStamps[m_nextTimeStamp], m_nextTimeStamp);
	m_nextTimeStamp = (m_nextTimeStamp + 1) % VOX_NB_TIMESTAMP_GROUP;

	//VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetWriteAccess());
	//m_emitterObjects.Add(emitter);
	//VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseWriteAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetWriteAccess());
	m_emitterObjectsToAdd.Add(emitter);
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseWriteAccess());

	return eh; 
}

EmitterHandle VoxEngineInternal::CreateEmitterAsync( DataHandle &handle, const emitter::CreationSettings &cs )
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);

	if(!dataSource)
	{
		VOX_WARNING_LEVEL_3("%s", "Could not get a data source, cannot create emitter");
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	if(!dataSource->IsReady())
	{
		VOX_WARNING_LEVEL_3("Data source %lld not ready yet, cannot create emitter", dataSource->GetId());
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	StreamInterface* stream = dataSource->GetStream();
	DecoderInterface* decoder = dataSource->GetDecoder();

	if(!stream || !decoder)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	/*StreamCursorInterface* streamCursor = stream->CreateNewCursor();
	if(!streamCursor)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	DecoderCursorInterface* decoderCursor = decoder->CreateNewCursor(streamCursor);
	if(!decoderCursor)
	{
		stream->DestroyCursor(streamCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}*/

	TrackParams trackParam = dataSource->GetTrackParams();
	DriverSourceInterface* driverSource = 0;
	if(trackParam.numChannels > 0 && m_hwDriver)
	{
		driverSource = m_hwDriver->CreateDriverSource((void*)&trackParam, 0, cs.m_priority);
	}

	if(!driverSource)
	{
		//stream->DestroyCursor(streamCursor);
		//decoder->DestroyCursor(decoderCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}
	/*long bufferSize;
	if(driverSource->AllowBufferReference() && decoderCursor->AllowBufferReference())
	{
		bufferSize = decoderCursor->GetNumSamples() * decoderCursor->GetBitsPerSample() / 8;
	}
	else
	{
		bufferSize = decoderCursor->GetNumChannels() * decoderCursor->GetBitsPerSample() / 8 * decoderCursor->GetSamplingRate() * VOX_EMITTER_BUFFER_DURATION_MS / 1000;
	}*/
	EmitterObj* emitter = 0;
	//if(bufferSize > 0)
	{
		//bufferSize -= (bufferSize % (decoderCursor->GetNumChannels() * decoderCursor->GetBitsPerSample() / 8)); //Needs to be a multiple of sampleSize*NumChannel
		emitter = VOX_NEW EmitterObj(GetFreeEmitterObjectId(), cs, driverSource, dataSource);
	}

	if(!emitter)
	{
		//stream->DestroyCursor(streamCursor);
		//decoder->DestroyCursor(decoderCursor);
		if(m_hwDriver)
			m_hwDriver->DestroyDriverSource(driverSource);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}
	emitter->SetGroup(dataSource->GetGroup());//inherit from source
	dataSource->RegisterEmitter(emitter->GetId());
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	emitter->SetTimeStampGroup(m_nextTimeStamp);
	EmitterHandle eh = EmitterHandle(emitter->GetId(), &s_voxEngineInternal, emitter, m_timeStamps[m_nextTimeStamp], m_nextTimeStamp);
	m_nextTimeStamp = (m_nextTimeStamp + 1) % VOX_NB_TIMESTAMP_GROUP;

	//VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetWriteAccess());
	//m_emitterObjects.Add(emitter);
	//VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseWriteAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetWriteAccess());
	m_emitterObjectsToAdd.Add(emitter);
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseWriteAccess());

	return eh; 
}

EmitterHandle VoxEngineInternal::CreateEmitterAsync( DataHandle &handle, s32 priority, void* driverParam )
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);

	if(!dataSource)
	{
		VOX_WARNING_LEVEL_3("%s", "Could not get a data source, cannot create emitter");
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	if(!dataSource->IsReady())
	{
		VOX_WARNING_LEVEL_3("Data source %lld not ready yet, cannot create emitter", dataSource->GetId());
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	StreamInterface* stream = dataSource->GetStream();
	DecoderInterface* decoder = dataSource->GetDecoder();

	if(!stream || !decoder)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	/*StreamCursorInterface* streamCursor = stream->CreateNewCursor();
	if(!streamCursor)
	{
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}

	DecoderCursorInterface* decoderCursor = decoder->CreateNewCursor(streamCursor);
	if(!decoderCursor)
	{
		stream->DestroyCursor(streamCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}*/

	TrackParams trackParam = dataSource->GetTrackParams();
	DriverSourceInterface* driverSource = 0;
	if(trackParam.numChannels > 0 && m_hwDriver)
	{
		driverSource = m_hwDriver->CreateDriverSource((void*)&trackParam, driverParam, priority);
	}

	if(!driverSource)
	{
		//stream->DestroyCursor(streamCursor);
		//decoder->DestroyCursor(decoderCursor);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}
	/*long bufferSize;
	if(driverSource->AllowBufferReference() && decoderCursor->AllowBufferReference())
	{
		bufferSize = decoderCursor->GetNumSamples() * decoderCursor->GetBitsPerSample() / 8;
	}
	else
	{
		bufferSize = decoderCursor->GetNumChannels() * decoderCursor->GetBitsPerSample() / 8 * decoderCursor->GetSamplingRate() * VOX_EMITTER_BUFFER_DURATION_MS / 1000;
	}*/
	EmitterObj* emitter = 0;
	//if(bufferSize > 0)
	{
		//bufferSize -= (bufferSize % (decoderCursor->GetNumChannels() * decoderCursor->GetBitsPerSample() / 8)); //Needs to be a multiple of sampleSize*NumChannel
		emitter = VOX_NEW EmitterObj(GetFreeEmitterObjectId(), priority, dataSource->GetPriorityBank(),/* bufferSize,*/ driverSource, /*decoderCursor,*/ dataSource);
	}

	if(!emitter)
	{
		//stream->DestroyCursor(streamCursor);
		//decoder->DestroyCursor(decoderCursor);
		if(m_hwDriver)
			m_hwDriver->DestroyDriverSource(driverSource);
		VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
		return EmitterHandle(-1);
	}
	emitter->SetGroup(dataSource->GetGroup());//inherit from source
	dataSource->RegisterEmitter(emitter->GetId());
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	emitter->SetTimeStampGroup(m_nextTimeStamp);
	EmitterHandle eh = EmitterHandle(emitter->GetId(), &s_voxEngineInternal, emitter, m_timeStamps[m_nextTimeStamp], m_nextTimeStamp);
	m_nextTimeStamp = (m_nextTimeStamp + 1) % VOX_NB_TIMESTAMP_GROUP;

	//VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetWriteAccess());
	//m_emitterObjects.Add(emitter);
	//VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseWriteAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetWriteAccess());
	m_emitterObjectsToAdd.Add(emitter);
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseWriteAccess());

	return eh; 
}

void VoxEngineInternal::KillEmitter( EmitterObj* emitter )
{
	if(!emitter)
		return;

	u32 tsGroup;
	tsGroup = emitter->GetTimeStampGroup();
	++m_timeStamps[tsGroup];

	VOX_WARNING_LEVEL_5("Killing Emitter %lld. %s", (s64)emitter->GetId(), emitter->GetUserData().ToString());

	if(emitter->IsInPriorityBank())
	{
		m_pPriorityBankMgr->RemoveEmitter(emitter->GetPriorityBank(), emitter);
	}

	DriverSourceInterface* driverSource = emitter->GetDriverSource();
	if(driverSource && m_hwDriver)
	{
		m_hwDriver->DestroyDriverSource(driverSource);
	}

	emitter->CleanUp();

	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = emitter->GetDataSource();
	
	if(dataSource)
	{
		DecoderCursorInterface* decoderCursor = emitter->GetDecoderCursor();
		if(decoderCursor)
		{
			StreamCursorInterface* streamCursor = decoderCursor->GetStreamCursor();
			if(streamCursor)
			{
				StreamInterface* stream = dataSource->GetStreamEx();
				if(stream)
				{
					stream->DestroyCursor(streamCursor);
				}
				else
				{
					VOX_ASSERT(0); //stream cursor without a stream ...
					VOX_DELETE (streamCursor);
				}
			}

			DecoderInterface* decoder = dataSource->GetDecoderEx();
			if(decoder)
			{
				decoder->DestroyCursor(decoderCursor);
			}
			else
			{
				VOX_ASSERT(0); //decoder cursor without a decoder ...
				VOX_DELETE (decoderCursor);
			}
		}

		dataSource->UnregisterEmitter(emitter->GetId());

		VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Lock());
		if(!dataSource->IsUpdating())
		{		
			dataSource->SetUpdating(true);
			m_dataSourceToUpdate.push_back(dataSource);
		}
		VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Unlock());
	}	
	
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	VOX_DELETE (emitter);
}

void VoxEngineInternal::KillEmitter( EmitterHandle &handle )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetWriteAccess());
	//EmitterObj* emitter = (EmitterObj*)m_emitterObjects.Detach(handle.GetId());//Remove from list without deleting object
	EmitterObj* emitter = DetachEmitterObject(handle.GetId());//Remove from list without deleting object
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseWriteAccess());

	if(!emitter)
		return; //emitter doesn't exist anymore

	KillEmitter( emitter );
}
void VoxEngineInternal::ReleaseDatasource( DataObj* dataSource )
{
	if(!dataSource)
		return;//data source doesn't exist anymore

	u32 tsGroup;
	tsGroup = dataSource->GetTimeStampGroup();
	++m_timeStamps[tsGroup];

	VOX_WARNING_LEVEL_5("Releasing Data source %lld", (s64)dataSource->GetId());

	EmitterInternalList* emitterList = dataSource->GetRegisteredEmitters();

	if(emitterList)
	{
		while(emitterList->size() > 0)
		{
			VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetWriteAccess());
			//EmitterObj* emitter = (EmitterObj*)m_emitterObjects.Detach(emitterList->back());
			EmitterObj* emitter = DetachEmitterObject(emitterList->back());//Remove from list without deleting object
			VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseWriteAccess());
			KillEmitter(emitter); //More efficient to unqueue from back
		}
	}
	
	DecoderInterface* decoder = dataSource->GetDecoderEx();
	if(decoder)
	{
		VOX_DELETE (decoder);
	}

	StreamInterface* stream = dataSource->GetStreamEx();
	if(stream)
	{
		VOX_DELETE (stream);
	}
	
	VOX_DELETE (dataSource);
}

void VoxEngineInternal::ReleaseDatasource( DataHandle &handle )//**-**
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);

	if(dataSource)
	{
		dataSource->NeedToDie();
	
		VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Lock());
		if(!dataSource->IsUpdating())
		{		
			dataSource->SetUpdating(true);
			m_dataSourceToUpdate.push_back(dataSource);
		}
		VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Unlock());
	}
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::ReleaseDatasourceGroup(u32 groupId)
{
	DataObj* dataSource;

	// Main list
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	HandlableContainerIterator iter = m_dataObjects.begin();
	HandlableContainerIterator last = m_dataObjects.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		dataSource = ((DataObj*)iter->second);
#else
		dataSource = (DataObj*)(*iter);
#endif
		if(dataSource->IsChild(groupId))
		{
			dataSource->NeedToDie();
		
			VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Lock());
			if(!dataSource->IsUpdating())
			{		
				dataSource->SetUpdating(true);
				m_dataSourceToUpdate.push_back(dataSource);				
			}
			VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Unlock());
		}
	}

	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	// To add list
	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.GetReadAccess());
	iter = m_dataObjectsToAdd.begin();
	last = m_dataObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		dataSource = ((DataObj*)iter->second);
#else
		dataSource = (DataObj*)(*iter);
#endif
		if(dataSource->IsChild(groupId))
		{
			dataSource->NeedToDie();
		
			VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Lock());
			if(!dataSource->IsUpdating())
			{		
				dataSource->SetUpdating(true);
				m_dataSourceToUpdate.push_back(dataSource);				
			}
			VOX_MUTEX_LEVEL_1(m_dataSourceToUpdateMutex.Unlock());
		}
	}

	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::_ReleaseAllDatasource()
{
	DataObj* dataSource;

	// Main list
	HandlableContainerIterator iter = m_dataObjects.begin();
	HandlableContainerIterator last = m_dataObjects.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		dataSource = ((DataObj*)iter->second);
#else
		dataSource = (DataObj*)(*iter);
#endif
		ReleaseDatasource(dataSource);
	}

	m_dataObjects.EmptyContainer();

	// To add list
	iter = m_dataObjectsToAdd.begin();
	last = m_dataObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		dataSource = ((DataObj*)iter->second);
#else
		dataSource = (DataObj*)(*iter);
#endif
		ReleaseDatasource(dataSource);
	}

	m_dataObjectsToAdd.EmptyContainer();
}

s32  VoxEngineInternal::GetEmitterHandles( DataHandle &handle, EmitterHandle* handlesBuffer, s32 bufferCount )
{
	s32 count = 0;
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);

	if(dataSource)
	{
		//Main list
		VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
		VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

		HandlableContainerIterator iter = m_emitterObjects.begin();
		HandlableContainerIterator last = m_emitterObjects.end();

		for(;iter != last && count < bufferCount; iter++)
		{
#if VOX_USE_HANDLABLE_MAP
			if(((EmitterObj*)iter->second)->GetDataSource() == dataSource)
			{
				handlesBuffer[count] = EmitterHandle(((EmitterObj*)iter->second)->GetId(), &s_voxEngineInternal, ((EmitterObj*)iter->second), m_timeStamps[((EmitterObj*)iter->second)->GetTimeStampGroup()], ((EmitterObj*)iter->second)->GetTimeStampGroup());
				count++;
			}
#else
			if(((EmitterObj*)(*iter))->GetDataSource() == dataSource)
			{
				handlesBuffer[count] = EmitterHandle((*iter)->GetId(), &s_voxEngineInternal, ((EmitterObj*)(*iter)), m_timeStamps[((EmitterObj*)(*iter))->GetTimeStampGroup()], ((EmitterObj*)(*iter))->GetTimeStampGroup());
				count++;
			}
#endif
		}
		
		//To add list
		iter = m_emitterObjectsToAdd.begin();
		last = m_emitterObjectsToAdd.end();

		for(;iter != last && count < bufferCount; iter++)
		{
#if VOX_USE_HANDLABLE_MAP
			if(((EmitterObj*)iter->second)->GetDataSource() == dataSource)
			{
				handlesBuffer[count] = EmitterHandle(((EmitterObj*)iter->second)->GetId(), &s_voxEngineInternal, ((EmitterObj*)iter->second), m_timeStamps[((EmitterObj*)iter->second)->GetTimeStampGroup()], ((EmitterObj*)iter->second)->GetTimeStampGroup());
				count++;
			}
#else
			if(((EmitterObj*)(*iter))->GetDataSource() == dataSource)
			{
				handlesBuffer[count] = EmitterHandle((*iter)->GetId(), &s_voxEngineInternal, ((EmitterObj*)(*iter)), m_timeStamps[((EmitterObj*)(*iter))->GetTimeStampGroup()], ((EmitterObj*)(*iter))->GetTimeStampGroup());
				count++;
			}
#endif
		}
		VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
		VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	}

	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	return count;
}

s32 VoxEngineInternal::GetAllEmitters( EmitterHandle* handlesBuffer, s32 bufferCount )
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();

	s32 idx = 0;
	for(;iter != last && idx < bufferCount; iter++, idx++)
	{
#if VOX_USE_HANDLABLE_MAP
		handlesBuffer[idx] = EmitterHandle(((EmitterObj*)iter->second)->GetId(), &s_voxEngineInternal, ((EmitterObj*)iter->second), m_timeStamps[((EmitterObj*)iter->second)->GetTimeStampGroup()], ((EmitterObj*)iter->second)->GetTimeStampGroup());
#else
		handlesBuffer[idx] = EmitterHandle((*iter)->GetId(), &s_voxEngineInternal, ((EmitterObj*)(*iter)), m_timeStamps[((EmitterObj*)(*iter))->GetTimeStampGroup()], ((EmitterObj*)(*iter))->GetTimeStampGroup());
#endif
	}

	// To add list
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last && idx < bufferCount; iter++, idx++)
	{
#if VOX_USE_HANDLABLE_MAP
		handlesBuffer[idx] = EmitterHandle(((EmitterObj*)iter->second)->GetId(), &s_voxEngineInternal, ((EmitterObj*)iter->second), m_timeStamps[((EmitterObj*)iter->second)->GetTimeStampGroup()], ((EmitterObj*)iter->second)->GetTimeStampGroup());
#else
		handlesBuffer[idx] = EmitterHandle((*iter)->GetId(), &s_voxEngineInternal, ((EmitterObj*)(*iter)), m_timeStamps[((EmitterObj*)(*iter))->GetTimeStampGroup()], ((EmitterObj*)(*iter))->GetTimeStampGroup());
#endif
	}
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());

	return idx;
}

s32 VoxEngineInternal::GetAllDataSources( DataHandle* handlesBuffer, s32 bufferCount )
{
	//Main list
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	HandlableContainerIterator iter = m_dataObjects.begin();
	HandlableContainerIterator last = m_dataObjects.end();

	s32 idx = 0;
	for(;iter != last && idx < bufferCount; iter++, idx++)
	{
#if VOX_USE_HANDLABLE_MAP
		handlesBuffer[idx] = DataHandle(iter->second->GetId(), &s_voxEngineInternal, iter->second, m_timeStamps[iter->second->GetTimeStampGroup()], iter->second->GetTimeStampGroup());
#else
		handlesBuffer[idx] = DataHandle((*iter)->GetId(), &s_voxEngineInternal, (*iter), m_timeStamps[(*iter)->GetTimeStampGroup()], (*iter)->GetTimeStampGroup());
#endif
	}
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	// To add list
	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.GetReadAccess());
	iter = m_dataObjectsToAdd.begin();
	last = m_dataObjectsToAdd.end();

	for(;iter != last && idx < bufferCount; iter++, idx++)
	{
#if VOX_USE_HANDLABLE_MAP
		handlesBuffer[idx] = DataHandle(iter->second->GetId(), &s_voxEngineInternal, iter->second, m_timeStamps[iter->second->GetTimeStampGroup()], iter->second->GetTimeStampGroup());
#else
		handlesBuffer[idx] = DataHandle((*iter)->GetId(), &s_voxEngineInternal, (*iter), m_timeStamps[(*iter)->GetTimeStampGroup()], (*iter)->GetTimeStampGroup());
#endif
	}
	VOX_MUTEX_LEVEL_1(m_dataObjToAddAccessController.ReleaseReadAccess());

	return idx;
}


DataHandle VoxEngineInternal::GetData(EmitterHandle &handle)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject(handle);
	if(emitter)
	{
		DataObj* dataSource = emitter->GetDataSource();
		HandleId id;
		if(dataSource)
		{
			id = dataSource->GetId();
			VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
			return DataHandle(id, &s_voxEngineInternal);
		}
	}

	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return DataHandle(-1);
}

void VoxEngineInternal::SetAutoKillAfterDone( EmitterHandle &handle, bool kill)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		emitter->SetAutoKillAfterDone(kill);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::SetGain( EmitterHandle &handle, f32 gain, f32 fadeTime) 
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		emitter->SetGain(gain, fadeTime);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

f32 VoxEngineInternal::GetGain( EmitterHandle &handle )
{
	f32 result = 0.0f;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->GetGain();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

void  VoxEngineInternal::SetLoop( EmitterHandle &handle, bool loop )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		emitter->SetLoop(loop);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::SetPitch( EmitterHandle &handle, f32 pitch, f32 fadeTime)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		emitter->SetPitch(pitch, fadeTime);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

f32 VoxEngineInternal::GetPitch( EmitterHandle &handle )
{
	f32 result = 0.0f;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->GetPitch();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

bool VoxEngineInternal::GetLoop( EmitterHandle &handle )
{
	bool result = false;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->GetLoop();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

void VoxEngineInternal::SetPriority( EmitterHandle &handle, s32 priority)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		emitter->SetPriority(priority);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

s32  VoxEngineInternal::GetPriority( EmitterHandle &handle)
{
	s32 result = -(1<<30);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->GetPriority();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

void  VoxEngineInternal::Play( EmitterHandle &handle, bool loop, f32 fadeTime )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	Play(emitter, loop, fadeTime);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Play( EmitterHandle &handle, bool loop )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	Play(emitter, loop);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Play( EmitterHandle &handle )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
	{
		bool loop = emitter->GetLoop();
		Play(emitter, loop);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Stop( EmitterHandle &handle, f32 fadeTime )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	Stop(emitter, fadeTime);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Stop( EmitterHandle &handle )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	Stop(emitter);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Pause( EmitterHandle &handle, f32 fadeTime) 
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	Pause(emitter, fadeTime);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Pause( EmitterHandle &handle ) 
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	Pause(emitter);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Resume( EmitterHandle &handle, f32 fadeTime) 
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	Resume(emitter, fadeTime);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Resume( EmitterHandle &handle ) 
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	Resume(emitter);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void  VoxEngineInternal::Play( EmitterObj* pEmitter, bool loop, f32 fadeTime)
{
	if ( pEmitter )
	{
		if(pEmitter->IsInPriorityBank())
		{
			m_pPriorityBankMgr->RemoveEmitter(pEmitter->GetPriorityBank(), pEmitter);
			pEmitter->SetInPriorityBank(false);
		}

		if(m_pPriorityBankMgr)
		{
			if(m_pPriorityBankMgr->AddEmitter(pEmitter->GetPriorityBank(), pEmitter))
			{
				if(pEmitter->IsPlaying())
					pEmitter->Reset();
				pEmitter->Play(fadeTime);
				pEmitter->SetLoop(loop);
				pEmitter->SetInPriorityBank(true);
			}
			else
			{
				pEmitter->SetInPriorityBank(false);
				//could not insert in priority bank, set to stop to clean if f&f
				//sound not started yet => use 0 fade time
				pEmitter->Stop(0);
			}
		}
	}
}

void  VoxEngineInternal::Stop( EmitterObj* pEmitter, f32 fadeTime )
{
	if ( pEmitter )
	{
		if(pEmitter->IsInPriorityBank())
		{
			m_pPriorityBankMgr->RemoveEmitter(pEmitter->GetPriorityBank(), pEmitter);
		}
		pEmitter->SetInPriorityBank(false);
		pEmitter->Stop(fadeTime);
	}
}

void  VoxEngineInternal::Pause( EmitterObj* pEmitter, f32 fadeTime)
{
	if ( pEmitter )
	{
		pEmitter->Pause(fadeTime);
	}
}

void  VoxEngineInternal::Resume( EmitterObj* pEmitter, f32 fadeTime)
{
	if ( pEmitter )
	{
		pEmitter->Resume(fadeTime);
	}
}

void  VoxEngineInternal::Play( EmitterObj* pEmitter, bool loop)
{
	if ( pEmitter )
	{
		float fadeTime = pEmitter->GetFadeOnPlay();
		Play(pEmitter, loop, fadeTime);
	}
}

void  VoxEngineInternal::Stop( EmitterObj* pEmitter )
{
	if ( pEmitter )
	{
		float fadeTime = pEmitter->GetFadeOnStop();
		Stop(pEmitter, fadeTime);
	}
}

void  VoxEngineInternal::Pause( EmitterObj* pEmitter )
{
	if ( pEmitter )
	{
		float fadeTime = pEmitter->GetFadeOnStop();
		Pause(pEmitter, fadeTime);
	}
}

void  VoxEngineInternal::Resume( EmitterObj* pEmitter )
{
	if ( pEmitter )
	{
		float fadeTime = pEmitter->GetFadeOnStop();
		Resume(pEmitter, fadeTime);
	}
}

bool VoxEngineInternal::IsReady( EmitterHandle &handle )
{
	bool result = false;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->IsReady();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

bool VoxEngineInternal::IsValid( EmitterHandle &handle )
{
	bool result = false;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = true;
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

bool VoxEngineInternal::IsAlive( EmitterHandle &handle )
{
	bool result = false;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->IsAlive();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

bool VoxEngineInternal::IsPlaying( EmitterHandle &handle )
{
	bool result = false;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->IsPlaying();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

bool VoxEngineInternal::IsDone( EmitterHandle &handle )
{
	bool result = true;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->IsDone();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

u32 VoxEngineInternal::GetStatus( EmitterHandle &handle )
{
	u32 result = k_nError;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->GetStatus();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

f32 VoxEngineInternal::GetPlayCursor( EmitterHandle &handle )
{
	f32 result = 0.0f;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->GetPlayCursor();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

void VoxEngineInternal::SetPlayCursor( EmitterHandle &handle, f32 time )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		emitter->SetPlayCursor(time);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::PlayGroup( u32 groupId, f32 fadeTime)
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Play(emitter, emitter->GetLoop(), fadeTime);
	}

	// To add list	
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Play(emitter, emitter->GetLoop(), fadeTime);
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::PlayGroup(u32 groupId)
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Play(emitter, emitter->GetLoop());
	}

	// To add list	
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Play(emitter, emitter->GetLoop());
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::StopGroup( u32 groupId, f32 fadeTime)
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Stop(emitter, fadeTime);
	}

	// To add list
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Stop(emitter, fadeTime);
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::StopGroup(u32 groupId)
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Stop(emitter);
	}

	// To add list
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Stop(emitter);
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::PauseGroup( u32 groupId, f32 fadeTime)
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Pause(emitter, fadeTime);
	}

	// To add list
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Pause(emitter, fadeTime);
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::PauseGroup(u32 groupId)
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Pause(emitter);
	}

	// To add list
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Pause(emitter);
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::ResumeGroup(u32 groupId, f32 fadeTime)
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Resume(emitter, fadeTime);
	}

	// To add list
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Resume(emitter, fadeTime);
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::ResumeGroup(u32 groupId)
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Resume(emitter);
	}

	// To add list
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->IsChild(groupId))
			Resume(emitter);
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::KillEmittersOnResume()
{
	// Main list
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.GetReadAccess());

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	EmitterObj* emitter;

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->GetKillOnResume())
			Stop(emitter, 0);
	}

	// To add list
	iter = m_emitterObjectsToAdd.begin();
	last = m_emitterObjectsToAdd.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		emitter = ((EmitterObj*)iter->second);
#else
		emitter = (EmitterObj*)(*iter);
#endif
		if(emitter->GetKillOnResume())
			Stop(emitter, 0);
	}

	VOX_MUTEX_LEVEL_1(m_emittersToAddAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}


void VoxEngineInternal::SetGroup( EmitterHandle &handle, u32 groupId)
{
	// Function has its own mutex
	if(!IsGroupValid(groupId))
	{
		VOX_WARNING_LEVEL_3("Group id %d invalid! Adding to group 0 (master) instead.", groupId);
		groupId = 0;
	}
	
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->SetGroup(groupId);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}
u32 VoxEngineInternal::GetGroup( EmitterHandle &handle )
{ 
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	s32 group =	0;
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		group = emitter->GetGroup();
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return group; 
}

void  VoxEngineInternal::SetMasterGain( f32 gain, f32 fadeTime)
{
	if(gain < 0.0f)
	{
		VOX_WARNING_LEVEL_4("%s", "Trying to set master group gain lower than 0, set to 0");
		gain = 0.0f;
	}
	else if(gain > 1.0f)
	{
		VOX_WARNING_LEVEL_4("%s", "Trying to set master group gain higher than 1, set to 1");
		gain = 1.0f;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		m_groupManager->SetVolume(VOX_GROUP_MASTER_ID, gain, fadeTime);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

f32 VoxEngineInternal::GetMasterGain()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 masterGain = 0;
	if(m_groupManager)
		masterGain = m_groupManager->GetVolume(VOX_GROUP_MASTER_ID);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return masterGain;
}

u32 VoxEngineInternal::AddGroup(group::CreationSettings &cs)
{
	u32 groupId = VOX_GROUP_INVALID_ID;

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		groupId = m_groupManager->AddGroup(cs);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());

	return groupId;
}

bool VoxEngineInternal::ReconfigureGroup(u32 id, group::CreationSettings &cs)
{
	bool ok = false;

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		ok = m_groupManager->ReconfigureGroup(id, cs);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());

	return ok;
}

u32 VoxEngineInternal::GetGroupId( const char *name )
{
	u32 groupId = VOX_GROUP_INVALID_ID;

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		groupId = m_groupManager->GetGroupId(name);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	
	return groupId;
}

bool VoxEngineInternal::GetGroupName( u32 id, char *stringData, s32 maxString )
{
	bool ret = false;

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		ret = m_groupManager->GetGroupName( id, stringData, maxString );
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	
	return ret;
}

bool VoxEngineInternal::IsGroupValid(u32 id )
{
	bool valid = false;

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		valid = m_groupManager->IsGroupValid(id);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	
	return valid;
}

void VoxEngineInternal::SetGroupVolume( u32 groupId, f32 gain, f32 fadeTime)
{
	if(gain < 0.0f)
	{
		VOX_WARNING_LEVEL_4("Trying to set groups %d gain lower than 0, set to 0", groupId);
		gain = 0.0f;
	}
	else if(gain > 1.0f)
	{
		VOX_WARNING_LEVEL_4("Trying to set groups %d gain higher than 1, set to 1", groupId);
		gain = 1.0f;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		m_groupManager->SetVolume(groupId, gain, fadeTime);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

f32 VoxEngineInternal::GetGroupVolume( u32 groupId )
{
	f32 groupGain = 0.0f;

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		groupGain = m_groupManager->GetVolume(groupId);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	
	return groupGain;
}

void VoxEngineInternal::SetGroupEnable( u32 groupId, bool enable, f32 fadeTime)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		m_groupManager->SetEnable(groupId, enable, fadeTime);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

bool VoxEngineInternal::GetGroupEnable( u32 groupId )
{
	bool groupEnable = false;

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_groupManager)
		groupEnable = m_groupManager->GetEnable(groupId);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	
	return groupEnable;
}

void  VoxEngineInternal::Set3DEmitterPosition( EmitterHandle &handle, f32 x, f32 y, f32 z )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Set3DParameter3f(Vox3DEmitterParameter::k_nPosition, x, y, z);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Set3DEmitterVelocity( EmitterHandle &handle, f32 x, f32 y, f32 z )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Set3DParameter3f(Vox3DEmitterParameter::k_nVelocity, x, y, z);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Set3DEmitterDirection( EmitterHandle &handle, f32 x, f32 y, f32 z )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Set3DParameter3f(Vox3DEmitterParameter::k_nDirection, x, y, z);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Set3DEmitterParameters( EmitterHandle &handle, const Vox3DEmitterParameters &param)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
	{
		emitter->Set3DParameteri(Vox3DEmitterParameter::k_nRelativeToListener, param.relativeToListener);
		emitter->Set3DParameterf(Vox3DEmitterParameter::k_nMaxDistance, param.maxDistance);
		emitter->Set3DParameterf(Vox3DEmitterParameter::k_nReferenceDistance, param.referenceDistance);
		emitter->Set3DParameterf(Vox3DEmitterParameter::k_nRolloffFactor, param.rolloffFactor);
		emitter->Set3DParameterf(Vox3DEmitterParameter::k_nInnerConeAngle, param.innerConeAngle);
		emitter->Set3DParameterf(Vox3DEmitterParameter::k_nOuterConeAngle, param.outerConeAngle);
		emitter->Set3DParameterf(Vox3DEmitterParameter::k_nOuterConeGain, param.outerConeGain);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Set3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 floatValue )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Set3DParameterf(paramId, floatValue);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Set3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 intValue )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Set3DParameteri(paramId, intValue);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Get3DEmitterPosition( EmitterHandle &handle, f32 &x, f32 &y, f32 &z )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Get3DParameter3f(Vox3DEmitterParameter::k_nPosition, x, y, z);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Get3DEmitterVelocity( EmitterHandle &handle, f32 &x, f32 &y, f32 &z )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Get3DParameter3f(Vox3DEmitterParameter::k_nVelocity, x, y, z);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Get3DEmitterDirection( EmitterHandle &handle, f32 &x, f32 &y, f32 &z )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Get3DParameter3f(Vox3DEmitterParameter::k_nDirection, x, y, z);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Get3DEmitterParameters( EmitterHandle &handle, Vox3DEmitterParameters &param)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
	{
		emitter->Get3DParameteri(Vox3DEmitterParameter::k_nRelativeToListener, param.relativeToListener);
		emitter->Get3DParameterf(Vox3DEmitterParameter::k_nMaxDistance, param.maxDistance);
		emitter->Get3DParameterf(Vox3DEmitterParameter::k_nReferenceDistance, param.referenceDistance);
		emitter->Get3DParameterf(Vox3DEmitterParameter::k_nRolloffFactor, param.rolloffFactor);
		emitter->Get3DParameterf(Vox3DEmitterParameter::k_nInnerConeAngle, param.innerConeAngle);
		emitter->Get3DParameterf(Vox3DEmitterParameter::k_nOuterConeAngle, param.outerConeAngle);
		emitter->Get3DParameterf(Vox3DEmitterParameter::k_nOuterConeGain, param.outerConeGain);
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Get3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 &floatValue )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Get3DParameterf(paramId, floatValue);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void  VoxEngineInternal::Get3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 &intValue )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->Get3DParameteri(paramId, intValue);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}


void VoxEngineInternal::Set3DListenerPosition(f32 x, f32 y, f32 z)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_position.x = x;
	m_position.y = y;
	m_position.z = z;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerPosition] = true;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Set3DListenerVelocity(f32 x, f32 y, f32 z)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_velocity.x = x;
	m_velocity.y = y;
	m_velocity.z = z;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerVelocity] = true;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Set3DListenerOrientation(f32 x_at, f32 y_at, f32 z_at, f32 x_up, f32 y_up, f32 z_up)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_lookAt.x = x_at;
	m_lookAt.y = y_at;
	m_lookAt.z = z_at;
	m_upVector.x = x_up;
	m_upVector.y = y_up;
	m_upVector.z = z_up;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nListenerOrientation] = true;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Set3DGeneralParameter(const Vox3DGeneralParameters &param)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_3Dparameters = param;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nDopplerFactor] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nSpeedOfSound] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nDistanceModel] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3d] = true;

	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack] = true;
	
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepth] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance] = true;

	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidth] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance] = true;

	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack] = true;
	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency] = true;

	m_3DNeedUpdate[Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor] = true;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Set3DGeneralParameterf( s32 paramId, f32 floatValue )
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(paramId)
	{
		case Vox3DGeneralParameter::k_nDopplerFactor:
		{
			m_3Dparameters.dopplerFactor = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nSpeedOfSound:
		{
			m_3Dparameters.speedOfSound = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}

		case Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower:
		{
			m_3Dparameters.enhanced3dStereoPanningPower = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront:
		{
			m_3Dparameters.enhanced3dStereoMaxDelayFront = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack:
		{
			m_3Dparameters.enhanced3dStereoMaxDelayBack = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
	
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepth:
		{
			m_3Dparameters.enhanced3dNotchDepth = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide:
		{
			m_3Dparameters.enhanced3dNotchDepthSide = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack:
		{
			m_3Dparameters.enhanced3dNotchDepthBack = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance:
		{
			m_3Dparameters.enhanced3dNotchDepthDistance = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}

		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidth:
		{
			m_3Dparameters.enhanced3dNotchWidth = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide:
		{
			m_3Dparameters.enhanced3dNotchWidthSide = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack:
		{
			m_3Dparameters.enhanced3dNotchWidthBack = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance:
		{
			m_3Dparameters.enhanced3dNotchWidthDistance = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}

		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum:
		{
			m_3Dparameters.enhanced3dDistanceWidthMinimum = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum:
		{
			m_3Dparameters.enhanced3dDistanceWidthMaximum = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve:
		{
			m_3Dparameters.enhanced3dDistanceWidthCurve = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide:
		{
			m_3Dparameters.enhanced3dDistanceWidthSide = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack:
		{
			m_3Dparameters.enhanced3dDistanceWidthBack = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency:
		{
			m_3Dparameters.enhanced3dDistanceFrequency = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}

		case Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor:
		{
			m_3Dparameters.enhanced3dRolloffFactor = floatValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}

		case Vox3DGeneralParameter::k_nDistanceModel:
		case Vox3DGeneralParameter::k_nEnhanced3d:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take a f32 as value", paramId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", paramId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Set3DGeneralParameteri( s32 paramId, s32 intValue )
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(paramId)
	{
		case Vox3DGeneralParameter::k_nDistanceModel:
		{
			m_3Dparameters.distanceModel = intValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3d:
		{
			m_3Dparameters.enhanced3d = intValue;
			m_3DNeedUpdate[paramId] = true;
			break;
		}
		case Vox3DGeneralParameter::k_nDopplerFactor:
		case Vox3DGeneralParameter::k_nSpeedOfSound:
		case Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower:
		case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront:
		case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepth:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidth:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency:
		case Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take an int as value", paramId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", paramId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::_SetDefault3DParameters()
{

}

void VoxEngineInternal::Get3DListenerPosition(f32 &x, f32 &y, f32 &z)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	x = m_position.x;
	y = m_position.y;
	z = m_position.z;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Get3DListenerVelocity(f32 &x, f32 &y, f32 &z)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	x = m_velocity.x;
	y = m_velocity.y;
	z = m_velocity.z;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Get3DListenerOrientation(f32 &x_at, f32 &y_at, f32 &z_at, f32 &x_up, f32 &y_up, f32 &z_up)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	x_at = m_lookAt.x;
	y_at = m_lookAt.y;
	z_at = m_lookAt.z;
	x_up = m_upVector.x;
	y_up = m_upVector.y;
	z_up = m_upVector.z;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Get3DGeneralParameter(Vox3DGeneralParameters &param)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	param = m_3Dparameters;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Get3DGeneralParameterf( s32 paramId, f32 &floatValue )
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(paramId)
	{
		case Vox3DGeneralParameter::k_nDopplerFactor:
		{
			floatValue = m_3Dparameters.dopplerFactor;
			break;
		}
		case Vox3DGeneralParameter::k_nSpeedOfSound:
		{
			floatValue = m_3Dparameters.speedOfSound;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower:
		{
			floatValue = m_3Dparameters.enhanced3dStereoPanningPower;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront:
		{
			floatValue = m_3Dparameters.enhanced3dStereoMaxDelayFront;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack:
		{
			floatValue = m_3Dparameters.enhanced3dStereoMaxDelayBack;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepth:
		{
			floatValue = m_3Dparameters.enhanced3dNotchDepth;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide:
		{
			floatValue = m_3Dparameters.enhanced3dNotchDepthSide;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack:
		{
			floatValue = m_3Dparameters.enhanced3dNotchDepthBack;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance:
		{
			floatValue = m_3Dparameters.enhanced3dNotchDepthDistance;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidth:
		{
			floatValue = m_3Dparameters.enhanced3dNotchWidth;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide:
		{
			floatValue = m_3Dparameters.enhanced3dNotchWidthSide;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack:
		{
			floatValue = m_3Dparameters.enhanced3dNotchWidthBack;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance:
		{
			floatValue = m_3Dparameters.enhanced3dNotchWidthDistance;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum:
		{
			floatValue = m_3Dparameters.enhanced3dDistanceWidthMinimum;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum:
		{
			floatValue = m_3Dparameters.enhanced3dDistanceWidthMaximum;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve:
		{
			floatValue = m_3Dparameters.enhanced3dDistanceWidthCurve;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide:
		{
			floatValue = m_3Dparameters.enhanced3dDistanceWidthSide;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack:
		{
			floatValue = m_3Dparameters.enhanced3dDistanceWidthBack;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency:
		{
			floatValue = m_3Dparameters.enhanced3dDistanceFrequency;
			break;
		}
		case Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor:
		{
			floatValue = m_3Dparameters.enhanced3dRolloffFactor;
			break;
		}
		case Vox3DGeneralParameter::k_nDistanceModel:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take a f32 as value", paramId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", paramId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxEngineInternal::Get3DGeneralParameteri( s32 paramId, s32 &intValue )
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(paramId)
	{
		case Vox3DGeneralParameter::k_nDistanceModel:
		{
			intValue = m_3Dparameters.distanceModel;
			break;
		}
		case Vox3DGeneralParameter::k_nDopplerFactor:
		case Vox3DGeneralParameter::k_nSpeedOfSound:
		case Vox3DGeneralParameter::k_nEnhanced3dStereoPanningPower:
		case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayFront:
		case Vox3DGeneralParameter::k_nEnhanced3dStereoMaxDelayBack:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepth:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthSide:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthBack:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchDepthDistance:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidth:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthSide:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthBack:
		case Vox3DGeneralParameter::k_nEnhanced3dNotchWidthDistance:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMinimum:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthMaximum:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthCurve:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthSide:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceWidthBack:
		case Vox3DGeneralParameter::k_nEnhanced3dDistanceFrequency:
		case Vox3DGeneralParameter::k_nEnhanced3dRolloffFactor:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take an int as value", paramId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", paramId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void  VoxEngineInternal::SetRoutingVolume(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume, f32 fadeTime)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	BusRoutingChange* brc = 0;
	if(busFromName && busToName)
	{
		brc = VOX_NEW BusRoutingChange(busFromName, busToName, routingType, dryVolume, wetVolume, fadeTime);
	}
	if(brc)
	{
		m_busRoutingChanges.push_back(brc);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


bool VoxEngineInternal::AttachDSP( const char *busName, CustomDSP *dsp )
{
	bool retval = false;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	MiniBusManager* busManager = MiniBusManager::GetInstance();
	if(busManager)
		retval = busManager->AttachDSP(busName, dsp);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return retval;
}



void  VoxEngineInternal::SetDSPEmitterParameter( EmitterHandle &handle, s32 paramId, const void* param )
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if(emitter)
		emitter->SetDSPParameter(paramId, param);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());	
}

void VoxEngineInternal::SetInteractiveMusicState(EmitterHandle &handle, const char *stateLabel)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject(handle);
	if(emitter)
	{
		if(emitter->GetDataSource()->GetDecoder()->GetType() == k_nDecoderTypeInteractiveMusic)
		{
			DecoderNativeCursor* decoderCursor = (DecoderNativeCursor *) emitter->GetDecoderCursor();
	
			if(decoderCursor)
			{
				decoderCursor->SetInteractiveMusicState(stateLabel);
				emitter->SetInteractiveMusicStateChange(stateLabel);
			}
		}
	}

	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::SetKillOnResume(EmitterHandle &handle, bool value)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject(handle);
	if(emitter)
	{
		emitter->SetKillOnResume(value);
	}

	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

bool VoxEngineInternal::GetKillOnResume(EmitterHandle &handle)
{
	bool result = false;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject(handle);
	if(emitter)
	{
		result = emitter->GetKillOnResume();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;

}

VoxOutputMode VoxEngineInternal::GetOutputMode()
{
	if(m_hwDriver)
		return m_hwDriver->GetOutputMode();
	return k_nOutputModeUnknown;
}

bool VoxEngineInternal::SetOutputMode(VoxOutputMode mode)
{
	if(m_hwDriver)
		return m_hwDriver->SetOutputMode(mode);
	return false;
}

void VoxEngineInternal::PrintDebug()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_hwDriver)
		m_hwDriver->PrintDebug();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());

	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	HandlableContainerIterator iter = m_dataObjects.begin();
	HandlableContainerIterator last = m_dataObjects.end();

	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		((DataObj*)iter->second)->PrintDebug();
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		EmitterInternalList* emitterList = ((DataObj*)iter->second)->GetRegisteredEmitters();
#else
		((DataObj*)(*iter))->PrintDebug();
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		EmitterInternalList* emitterList = ((DataObj*)(*iter))->GetRegisteredEmitters();
#endif
		EmitterInternalList::iterator iter2 = emitterList->begin();
		EmitterInternalList::iterator last2 = emitterList->end();

		for(;iter2 != last2; iter2++)
		{
			EmitterObj* pEmitter = (EmitterObj*)m_emitterObjects.Find(*(iter2));
			if(pEmitter)
				pEmitter->PrintDebug();
		}
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());

	}

	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::GetDebugInfo(DebugInfo &info)
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	info.m_nDataSource = m_dataObjects.Size();
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());

	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	info.m_nEmitter = m_emitterObjects.Size();

	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();
	info.m_nPlayingEmitter = 0;
	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		if(((EmitterObj*)iter->second)->IsPlaying())
#else
		if(((EmitterObj*)(*iter))->IsPlaying())
#endif
			++info.m_nPlayingEmitter;
	}

	info.m_nApproxMem = -1;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

bool VoxEngineInternal::RegisterExternalDataGenerator(MinibusDataGeneratorInterface *pPlugin, const char* busLabel)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));

	if(pPlugin)
	{
		s32 busId;
		MiniBusManager *pBusManager = MiniBusManager::GetInstance();

		if(pBusManager)
		{
			if(STRICMP(busLabel, "AUX1") == 0)
			{
				busId = VOX_MINIBUS_AUX1;
			}
			else if(STRICMP(busLabel, "AUX2") == 0)
			{
				busId = VOX_MINIBUS_AUX2;
			}
			else
			{
				busId = VOX_MINIBUS_MASTER;
			}

			pBusManager->AttachDataGeneratorToBus(busId, pPlugin);
			return true;
		}
		else
		{
			VOX_WARNING_LEVEL_2("%s", "Could not register plugin on null minibus manager.\n");
		}
	}

	VOX_WARNING_LEVEL_2("%s", "Could not register null plugin upon minibus manager.\n");
	return false;
}

void VoxEngineInternal::UnregisterExternalDataGenerator(MinibusDataGeneratorInterface *pPlugin)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));

	if(pPlugin)
	{
		MiniBusManager *pBusManager = MiniBusManager::GetInstance();
		if(pBusManager)
		{
			pBusManager->DetachDataGeneratorFromBus(pPlugin);
			return;
		}
		else
		{
			VOX_WARNING_LEVEL_2("%s", "Could not unregister plugin on null minibus manager.\n");
		}
	}

	VOX_WARNING_LEVEL_2("%s", "Could not unregister null plugin upon minibus manager.\n");
}

bool VoxEngineInternal::IsReady( DataHandle &handle )
{
	bool result = false;
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);
	if(dataSource)
		result = dataSource->IsReady();
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
	return result;
}

bool VoxEngineInternal::IsValid( DataHandle &handle )
{
	bool result = false;
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);
	if(dataSource)
		result = true;
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
	return result;
}

f32 VoxEngineInternal::GetDuration( DataHandle &handle )
{
	f32 result = 0.0f;
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);
	if(dataSource)
		result = dataSource->GetDuration();
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
	return result;
}

void VoxEngineInternal::SetPriorityBankId( DataHandle &handle, u32 bankId)
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);
	if(dataSource)
		dataSource->SetPriorityBank(bankId);
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::SetPriorityBankId( EmitterHandle &handle, u32 bankId)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject(handle);
	if(emitter && m_pPriorityBankMgr)
	{
		if(emitter->IsInPriorityBank())
		{
			m_pPriorityBankMgr->RemoveEmitter(emitter->GetPriorityBank(), emitter);
			emitter->SetPriorityBank(bankId);
			m_pPriorityBankMgr->AddEmitter(emitter->GetPriorityBank(), emitter);
		}
		else
		{
			emitter->SetPriorityBank(bankId);
		}
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

void VoxEngineInternal::SetUid( DataHandle &handle, s32 Uid)
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);
	if(dataSource)
		dataSource->SetUid(Uid);
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
}

s32 VoxEngineInternal::GetUid( DataHandle &handle)
{
	s32 uid = -1;
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);
	if(dataSource)
		uid = dataSource->GetUid();
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
	return uid;
}

s32 VoxEngineInternal::GetUid( EmitterHandle &handle)
{
	s32 result = -1;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject( handle );
	if ( emitter )
	{
		result = emitter->GetUid();
	}
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}

void VoxEngineInternal::SetUserData( DataHandle &handle, DataHandleUserData &data)
{
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);
	if(dataSource)
		dataSource->SetUserData(data);
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
}

DataHandleUserData VoxEngineInternal::GetUserData( DataHandle &handle)
{
	DataHandleUserData result;
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.GetReadAccess());
	DataObj* dataSource = GetDataObject(handle);
	if(dataSource)
		result = dataSource->GetUserData();
	VOX_MUTEX_LEVEL_1(m_sourcesAccessController.ReleaseReadAccess());
	return result;
}

void VoxEngineInternal::SetUserData( EmitterHandle &handle, EmitterHandleUserData &data)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject(handle);
	if(emitter)
		emitter->SetUserData(data);
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}

EmitterHandleUserData VoxEngineInternal::GetUserData( EmitterHandle &handle)
{
	EmitterHandleUserData result;
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	EmitterObj* emitter = GetEmitterObject(handle);
	if(emitter)
		result = emitter->GetUserData();
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
	return result;
}
}//namespace vox

//*** Handle ***/
namespace vox {
bool Handle::operator==(const Handle &rhs) const
{
 	return m_id == rhs.m_id; 
}
}
//*** DataHandle ***//
namespace vox {
DataHandle::~DataHandle()
{
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			(*m_ppInternal)->DecreaseDataObjectRefCount((*this));
		}
	}
}

DataHandle::DataHandle(const DataHandle &handle) : Handle((Handle) handle)
{
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			(*m_ppInternal)->IncreaseDataObjectRefCount((*this));
		}
	}
}

DataHandle& DataHandle::operator=(const DataHandle &rhs)
{
    if (this == &rhs)      // Same object?
		return *this; 
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			(*m_ppInternal)->DecreaseDataObjectRefCount((*this));
		}
	}

	m_ppInternal = rhs.m_ppInternal;
	m_id = rhs.m_id;
	m_timestamp = rhs.m_timestamp;
	m_tsGroup = rhs.m_tsGroup;	
	m_pObject = rhs.m_pObject;
	m_debugPointerToObjectThatIsNotGaranteedToExistAnymore = rhs.m_debugPointerToObjectThatIsNotGaranteedToExistAnymore;
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			(*m_ppInternal)->IncreaseDataObjectRefCount((*this));
		}
	}
	return *this; 
}


DataHandle::DataHandle(HandleId id, VoxEngineInternal** ppInternal, Handlable* object, u32 timestamp, u32 tsGroup) : Handle(id, ppInternal, object, timestamp, tsGroup)
{
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			if(object)
			{
				((DataObj*)object)->Retain();
			}
			else
			{
				(*m_ppInternal)->IncreaseDataObjectRefCount((*this));
			}
		}
	}
}

}//namespace vox

//*** EmitterHandle ***//
namespace vox {
EmitterHandle::~EmitterHandle()
{
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			(*m_ppInternal)->DecreaseEmitterObjectRefCount((*this));
		}
	}
}

EmitterHandle::EmitterHandle(const EmitterHandle &handle) : Handle((Handle) handle)
{
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			(*m_ppInternal)->IncreaseEmitterObjectRefCount((*this));
		}
	}
}

EmitterHandle& EmitterHandle::operator=(const EmitterHandle &rhs)
{
    if (this == &rhs)      // Same object?
		return *this; 
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			(*m_ppInternal)->DecreaseEmitterObjectRefCount((*this));
		}
	}

	m_ppInternal = rhs.m_ppInternal;
	m_id = rhs.m_id;
	m_timestamp = rhs.m_timestamp;
	m_tsGroup = rhs.m_tsGroup;
	m_pObject = rhs.m_pObject;
	m_debugPointerToObjectThatIsNotGaranteedToExistAnymore = rhs.m_debugPointerToObjectThatIsNotGaranteedToExistAnymore;
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			(*m_ppInternal)->IncreaseEmitterObjectRefCount((*this));
		}
	}
	return *this;
}

EmitterHandle::EmitterHandle(HandleId id, VoxEngineInternal** ppInternal, Handlable* object, u32 timestamp, u32 tsGroup) : Handle(id, ppInternal, object, timestamp, tsGroup)
{
	if(m_ppInternal)
	{
		if((*m_ppInternal))
		{
			if(object)
			{
				((EmitterObj*)object)->Retain();
			}
			else
			{
				(*m_ppInternal)->IncreaseEmitterObjectRefCount((*this));
			}
		}
	}
}

}//namespace vox

//*** Handlable ***//
namespace vox {
void Handlable::Retain()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_refCount++;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void Handlable::Release()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_refCount>0)
		m_refCount--;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}
}//namespace vox

//*** DataObj ***//
namespace vox {
void DataObj::RegisterEmitter(HandleId hid)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_currentEmitters.push_back(hid);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DataObj::UnregisterEmitter(HandleId hid)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	EmitterInternalList::iterator iter = m_currentEmitters.begin();
	EmitterInternalList::iterator last = m_currentEmitters.end();

	for(;iter != last; iter++)
	{
		if((*iter) == hid)
		{
			m_currentEmitters.erase(iter);
			VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
			return;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DataObj::Update()
{
	if(m_state == DataSource::STATE_READY)
		return;

	VOX_PROFILING_SCOPED_EVENT( __SEL, VOX_PROFILER_EVENT_TYPE_SOURCE, "DataObj::Update", vox::VoxThread::GetCurThreadId());

	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));

	switch(m_state)
	{
		case DataSource::STATE_READY:
		{
			break;//Do nothing
		}
		case DataSource::STATE_INITIAL:
		{
			//StreamCursorInterface* streamCursor = m_pStream->CreateNewCursor();
			//if(streamCursor)
			//{
			//	DecoderCursorInterface* decoderCursor = m_pDecoder->CreateNewCursor(streamCursor);
			//	if(decoderCursor)
			//	{
			//		m_trackParams = decoderCursor->GetTrackParams();
			//		m_pDecoder->DestroyCursor(decoderCursor);
			//	}
			//	m_pStream->DestroyCursor(streamCursor);
			//}
			break;
		}
		case DataSource::STATE_LOADING_STATIC:
		{
			////stop all emitter - TODO

			//StreamCursorInterface* streamCursor = m_pStream->CreateNewCursor();
			//if(streamCursor)
			//{
			//	s32 size = m_pStream->Size();
			//	u8* buf = (u8*)VOX_ALLOC(size);
			//	if(buf)
			//	{
			//		streamCursor->Seek(0);
			//		s32 readsize = streamCursor->Read(buf, size);
			//		VOX_ASSERT_MSG(readsize == size, "Stream conversion error");
			//	}
			//	
			//	m_pStream->DestroyCursor(streamCursor);
			//	
			//	if(buf)
			//	{
			//		VOX_DELETE (m_pStream);
			//		StreamMemoryBufferParams streamParams;
			//		streamParams.buffer = buf;
			//		streamParams.size = size;
			//		streamParams.doCopy = true;

			//		m_pStream = StreamMemoryBufferFactory( &streamParams );
	
			//		VOX_FREE(buf);
			//	}
			//}

			//if(!m_pStream)
			//	NeedToDie();
			//else
			//{
			//	VOX_MUTEX_LEVEL_1(m_stateMutex.Lock());
			//	m_state = DataSource::STATE_READY;
			//	VOX_MUTEX_LEVEL_1(m_stateMutex.Unlock());
			//}

			break;//Do nothing
		}
		case DataSource::STATE_CONVERTING:
		{
			switch(m_loadingFlags)
			{
				case k_nNone:
				{
					StreamCursorInterface* streamCursor = m_pStream->CreateNewCursor();
					if(streamCursor)
					{
						DecoderCursorInterface* decoderCursor = m_pDecoder->CreateNewCursor(streamCursor);
						if(decoderCursor)
						{
							m_trackParams = decoderCursor->GetTrackParams();
							m_pDecoder->DestroyCursor(decoderCursor);
						}						
						m_pStream->DestroyCursor(streamCursor);
					}

					if(m_trackParams.numChannels > 0)
					{
						m_state = DataSource::STATE_READY;
					}
					else
					{
						VOX_WARNING_LEVEL_2("%s","Unable to load data source");
						m_state = DataSource::STATE_ERROR;
					}
					break;
				}
				case k_nLoadToRam:
				{
					if(!m_pStream || !m_pDecoder)
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}
					
					s32 streamSize = m_pStream->Size();

					if(streamSize <= 0)
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}

					#if defined(_NN_CTR)
						u8* buffer = (u8*)VOX_ALLOC_ALIGN(streamSize, (vox::VoxMemHint)(vox::k_nVoxMemHint_Align32 | vox::k_nVoxMemHint_RamBuffer));
					#else
						u8* buffer = (u8*)VOX_ALLOC(streamSize);
					#endif

					if(!buffer) //error
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}

					StreamCursorInterface* scursor =  m_pStream->CreateNewCursor();
					if(!scursor) //error
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}

					s32 readsize = scursor->Read(buffer, streamSize);
					m_pStream->DestroyCursor(scursor);

					if(streamSize != readsize) //error
					{
						VOX_FREE(buffer);
						m_state = DataSource::STATE_ERROR;
						break;
					}
					
					StreamMemoryBufferParams param;
					param.buffer = buffer;
					param.size = streamSize;
					param.doCopy = false;
					param.takeOwnership = true;

					StreamMemoryBuffer* pStream = VOX_NEW StreamMemoryBuffer(&param);

					if(!pStream)
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}

					VOX_DELETE(m_pStream);
					m_pStream = (StreamInterface*)pStream;

					scursor =  m_pStream->CreateNewCursor();
					if(!scursor) //error
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}

					DecoderCursorInterface* dcursor = m_pDecoder->CreateNewCursor(scursor);
					if(!dcursor) //error
					{
						m_pStream->DestroyCursor(scursor);
						m_state = DataSource::STATE_ERROR;
						break;
					}

					m_trackParams = dcursor->GetTrackParams();

					m_pDecoder->DestroyCursor(dcursor);
					m_pStream->DestroyCursor(scursor);

					m_state = DataSource::STATE_READY;

					break;
				}
				case k_nLoadToRamAndDecode:
				{
					if(!m_pStream || !m_pDecoder)
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}
					
					StreamCursorInterface* scursor = m_pStream->CreateNewCursor();
					if(!scursor)
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}

					DecoderCursorInterface* dcursor = m_pDecoder->CreateNewCursor(scursor);
					if(!dcursor) //error
					{
						m_pStream->DestroyCursor(scursor);
						m_state = DataSource::STATE_ERROR;
						break;
					}

					m_trackParams = dcursor->GetTrackParams();

					s32 streamSize = dcursor->GetNumSamples() * dcursor->GetNumChannels() * (dcursor->GetBitsPerSample() >> 3);

					if(streamSize <= 0)
					{
						m_pStream->DestroyCursor(scursor);
						m_pDecoder->DestroyCursor(dcursor);
						m_state = DataSource::STATE_ERROR;
						break;
					}

					#if defined(_NN_CTR)
						u8* buffer = (u8*)VOX_ALLOC_ALIGN(streamSize, (vox::VoxMemHint)(vox::k_nVoxMemHint_Align32 | vox::k_nVoxMemHint_RamBuffer));
					#else
						u8* buffer = (u8*)VOX_ALLOC(streamSize);
					#endif

					if(!buffer) //error
					{
						m_pStream->DestroyCursor(scursor);
						m_pDecoder->DestroyCursor(dcursor);
						m_state = DataSource::STATE_ERROR;
						break;
					}

					s32 decodeSize = dcursor->Decode(buffer, streamSize);
					m_pStream->DestroyCursor(scursor);
					m_pDecoder->DestroyCursor(dcursor);
					
					if(decodeSize <= 0) //cannot check for exact match since some adpcm encoders don't encode last chunk properly
					{						
						VOX_FREE(buffer);
						m_state = DataSource::STATE_ERROR;
						break;
					}

					StreamMemoryBufferParams param;
					param.buffer = buffer;
					param.size = streamSize;
					param.doCopy = false;
					param.takeOwnership = true;

					StreamMemoryBuffer* pStream = VOX_NEW StreamMemoryBuffer(&param);

					if(!pStream)
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}

					VOX_DELETE(m_pStream);
					m_pStream = (StreamInterface*)pStream;

					DecoderRaw* pDecoder = VOX_NEW DecoderRaw(&m_trackParams);
					if(!pDecoder)
					{
						m_state = DataSource::STATE_ERROR;
						break;
					}

					VOX_DELETE(m_pDecoder);
					m_pDecoder = (DecoderInterface*)pDecoder;

					m_state = DataSource::STATE_READY;

					break;
				}
				default: //no conversion possible, use as-is
				{
					m_state = DataSource::STATE_READY;
					break;
				}
			}

			break;//Do nothing
		}
		case DataSource::STATE_DYING:
		{
			break;//Do nothing
		}
	}
}

void DataObj::NeedToDie()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_needToDie = true;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	VOX_MUTEX_LEVEL_1(m_stateMutex.Lock());
	m_state = DataSource::STATE_DYING;
	VOX_MUTEX_LEVEL_1(m_stateMutex.Unlock());
}

bool DataObj::ShouldDie()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	bool result = ((m_currentEmitters.size() == 0) && ( m_refCount == 0)) || m_needToDie || m_state == DataSource::STATE_ERROR;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

u32 DataObj::GetGroup()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	s32 gid = m_groupId;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return gid;
}

bool DataObj::IsChild(u32 groupId)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	VoxEngineInternal *eng = VoxEngineInternal::GetVoxEngineInternal();
	bool result = false;

	if(eng->m_groupManager)
		result = eng->m_groupManager->IsChild(m_groupId, groupId);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

bool DataObj::IsReady()
{
	bool result;
	VOX_MUTEX_LEVEL_1(m_stateMutex.Lock());
	result = m_state == DataSource::STATE_READY;
	VOX_MUTEX_LEVEL_1(m_stateMutex.Unlock());
	return result;
}

f32 DataObj::GetDuration()
{
	if(!IsReady())
	{
		VOX_WARNING_LEVEL_4("Current data source state doesn't allow %s calls", __FUNCTION__);
		return 0.0f;
	}

	f32 duration;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	duration = ((f32)m_trackParams.numSamples) / ((f32)(m_trackParams.samplingRate));
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return duration;
}

void DataObj::SetUserData(DataHandleUserData &data)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_userData = data;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

DataHandleUserData DataObj::GetUserData()
{
	DataHandleUserData data;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	data = m_userData;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return data;
}

void DataObj::PrintDebug()
{
	f32 duration = GetDuration();
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	VOX_WARNING_LEVEL_1("%s", "###############################################################################");
	VOX_WARNING_LEVEL_1("%s", "############################      Data Source      ############################");
	VOX_WARNING_LEVEL_1("%s", "###############################################################################");
	VOX_WARNING_LEVEL_1("%s", "#");

	VOX_WARNING_LEVEL_1("#    Data source Id : %lld", (s64)m_id);
	VOX_WARNING_LEVEL_1("%s", "#");
	VOX_WARNING_LEVEL_1("#    Stream : %d", m_pStream->GetType());
	VOX_WARNING_LEVEL_1("#    Decoder : %d", m_pDecoder->GetType());
	VOX_WARNING_LEVEL_1("%s", "#");
	VOX_WARNING_LEVEL_1("#    Sampling Rate : %d", m_trackParams.samplingRate);
	VOX_WARNING_LEVEL_1("#    Channels : %d", m_trackParams.numChannels);
	VOX_WARNING_LEVEL_1("#    Bits per sample(per channel) : %d", m_trackParams.bitsPerSample);
	VOX_WARNING_LEVEL_1("#    Duration : %4.3f s", duration);
	VOX_WARNING_LEVEL_1("%s", "#");
	VOX_WARNING_LEVEL_1("#    GroupId : %d", m_groupId);
	VOX_WARNING_LEVEL_1("#    Reference count : %d", m_refCount);
	VOX_WARNING_LEVEL_1("#    Active Emitter : %d", (s32)m_currentEmitters.size());
	VOX_WARNING_LEVEL_1("%s", "#");
	VOX_WARNING_LEVEL_1("%s", "###############################################################################");

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DataObj::GetDebugInfo(DebugChunk_dataSource &info)
{
	f32 duration = GetDuration();
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	info.bank = m_priorityBank;
	info.id = m_id;
	info.decoderType = m_pDecoder->GetType();
	info.streamType = m_pStream->GetType();
	info.samplingRate = m_trackParams.samplingRate;
	info.channel = m_trackParams.numChannels;
	info.bps = m_trackParams.bitsPerSample;
	info.duration = duration;
	info.groupId = m_groupId;
	info.referenceCount = m_refCount;
}

}//namespace vox

//*** HandlableContainer ***//
namespace vox {
HandlableContainer::~HandlableContainer()
{
	Clear();
}

void HandlableContainer::Add(Handlable* pElement)
{
#if VOX_USE_HANDLABLE_MAP
	if(pElement)
		list[pElement->GetId()] = pElement;
#else
	if(pElement)
		list.push_back(pElement);
#endif
}

Handlable* HandlableContainer::Find(HandleId id)
{
#if VOX_USE_HANDLABLE_MAP
	HandlableContainerIterator it;
	it = list.find(id);
	if(it == list.end())
		return 0;
	else
		return it->second;
#else
	HandlableContainerIterator iter = list.begin();
	HandlableContainerIterator last = list.end();

	for(;iter != last; iter++)
	{
		if((*iter)->GetId() == id)
			return (*iter);
	}
#endif
	return 0;
}

void HandlableContainer::Erase(HandleId id)
{
#if VOX_USE_HANDLABLE_MAP
	HandlableContainerIterator it;
	it = list.find(id);
	if(it == list.end())
		return;
	else
	{
		VOX_DELETE(it->second);
		list.erase(it);
	}
#else
	HandlableContainerIterator iter = list.begin();
	HandlableContainerIterator last = list.end();

	for(;iter != last; iter++)
	{
		if((*iter)->GetId() == id)
		{
			Handlable* h = (*iter);
			list.erase(iter);
			VOX_DELETE(h);
			return;
		}
	}
#endif
}

void HandlableContainer::Clear()
{
#if VOX_USE_HANDLABLE_MAP
	HandlableContainerIterator iter = list.begin();
	HandlableContainerIterator last = list.end();

	for(;iter != last; iter++)
	{
		if(iter->second)
		{
			VOX_DELETE(iter->second);
		}
	}
	list.clear();
#else
	Handlable* h;
	while(list.size() > 0)
	{
		h = list.back();
		list.pop_back();
		VOX_DELETE(h);
	}
#endif
}

Handlable* HandlableContainer::Detach(HandleId id)
{
#if VOX_USE_HANDLABLE_MAP
	HandlableContainerIterator it;
	it = list.find(id);
	if(it == list.end())
		return 0;
	else
	{
		Handlable* h = it->second;
		list.erase(it);
		return h;
	}
#else
	HandlableContainerIterator iter = list.begin();
	HandlableContainerIterator last = list.end();

	for(;iter != last; iter++)
	{
		if((*iter)->GetId() == id)
		{
			Handlable* h = (*iter);
			list.erase(iter);
			return h;
		}
	}
	return 0;
#endif
}

void HandlableContainer::Merge(HandlableContainer* toMerge)
{
	//doesn't check the real type of the internal node
#if VOX_USE_HANDLABLE_MAP
	HandlableContainerIterator iter = toMerge->begin();
	HandlableContainerIterator last = toMerge->end();

	for(;iter != last; iter++)
	{
		if(iter->second)
		{
			Add(iter->second);
		}
	}
#else
	HandlableContainerIterator iter = toMerge->begin();
	HandlableContainerIterator last = toMerge->end();

	for(;iter != last; iter++)
	{
		if(*iter)
		{
			Add(*iter);
		}
	}
#endif
}

HandleId HandlableContainer::GetFreeHandleId()
{
	return m_nextId++;
}	

HandlableContainerIterator HandlableContainer::begin()
{
	return list.begin();
}

HandlableContainerIterator HandlableContainer::end()
{
	return list.end();
}
}//namespace vox

//*** EmitterObj ***// 
namespace vox {
EmitterObj::EmitterObj(HandleId id, s32 priority, s32 priorityBank, s32 bufferSize, DriverSourceInterface* phwSourceInterface, DecoderCursorInterface* pDecoderCursor, DataObj* pDataSource) :
		Handlable(id),
		m_needLoad(false),
		m_bytesPerSecond(1),
		m_groupId(VOX_GROUP_MASTER_ID),
		m_priority(priority),
		m_priorityBank(priorityBank),
		m_isInBank(false),
		
		m_gain(1.0f),
		m_desiredGain(1.0f),
		m_baseGain(VOX_DEFAULT_EMITTER_GAIN),
		m_gainModifier(1.0f),

		m_randomGain(false),
		m_randomGainMax(1),
		m_randomGainMin(1),

		m_pitch(VOX_DEFAULT_EMITTER_PITCH),	
		m_desiredPitch(VOX_DEFAULT_EMITTER_PITCH),

		m_basePitch(VOX_DEFAULT_EMITTER_PITCH),
		m_randomPitch(false),
		m_randomPitchMax(0),
		m_randomPitchMin(0),

		m_loop(false),
		m_desiredLoop(false),

		m_currentState(DriverSource::STATE_INITIAL),	
		m_desiredState(DriverSource::STATE_INITIAL),
		m_stateChanged(false),

		m_resetSource(false),
		m_killOnResume(true),
		m_fadeOnPlay(VOX_DEFAULT_FADE_TIME_PLAY),
		m_fadeOnStop(VOX_DEFAULT_FADE_TIME_STOP),

		m_currentBus(0),
		m_desiredBus(0),

		m_bufferSize(bufferSize),
		m_bufferPosition(0),

		m_phwSource(phwSourceInterface),
		m_pDecoderCursor(pDecoderCursor),
		m_pDataSource(pDataSource),

		m_needToDie(false),
		m_autoKill(false),

		m_uid(-1),

		m_stateChangedCallback(0),
		m_stateChangedCallbackUserData(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::EmitterObj", vox::VoxThread::GetCurThreadId());
	for(s32 i = 0; i < Vox3DEmitterParameter::k_nCount; i++)
	{
		m_3DNeedUpdate[i] = false;
	}

	m_bufferId = 0;
	m_bufferQty = 0;

	if(m_phwSource && pDecoderCursor)
	{
		m_bytesPerLoop = m_pDecoderCursor->GetNumSamples() * (m_pDecoderCursor->GetNumChannels() *  (m_pDecoderCursor->GetBitsPerSample() >> 3));
		m_bytesPerSecond = m_pDecoderCursor->GetNumChannels() *  (m_pDecoderCursor->GetBitsPerSample() >> 3) * m_pDecoderCursor->GetSamplingRate();

		if(m_phwSource->AllowBufferReference())
		{
			s32 sourceBuffer = m_phwSource->GetBufferCount();
			if(m_pDecoderCursor->AllowBufferReference())
			{
				m_bufferQty = 1;
				m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(m_bufferQty);
			}
			else
			{
				m_pSndBuffer.reserve(sourceBuffer + 1);
				for(int i = 0; i < sourceBuffer + 1; ++i)
				{
					m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
					if(!m_pSndBuffer[i])
					{
						VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", i, VOX_DRIVER_SOURCE_NUM_BUFFER + 1);
						break;
					}
					++m_bufferQty;
				}
			}
		}
		else
		{
			m_bufferQty = 1;
			if(m_pDecoderCursor->AllowBufferReference())
			{
				m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(1);
			}
			else
			{
				m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
				if(!m_pSndBuffer[0])
				{
					VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", 0, 1);
					m_bufferQty = 0;
				}
			}
		}

		if(!m_bufferQty)
			m_needToDie = true;

		SetDefaultParameters();
	}
	else
	{
		m_needToDie = true;
	}

	m_decoderType = m_pDataSource->GetDecoder()->GetType();

	m_hasNativeStateChanged = false;
	m_resetOnNativeStateChange = true;
	m_nativeStateLabel[0] = 0;
}

EmitterObj::EmitterObj(HandleId id, s32 priority, s32 priorityBank/*, s32 bufferSize*/, DriverSourceInterface* phwSourceInterface/*, DecoderCursorInterface* pDecoderCursor*/, DataObj* pDataSource) :
		Handlable(id),
		m_needLoad(true),
		m_bytesPerSecond(1),
		m_groupId(VOX_GROUP_MASTER_ID),
		m_priority(priority),
		m_priorityBank(priorityBank),
		m_isInBank(false),
		
		m_gain(1.0f),
		m_desiredGain(1.0f),
		m_baseGain(VOX_DEFAULT_EMITTER_GAIN),
		m_gainModifier(1.0f),

		m_randomGain(false),
		m_randomGainMax(1),
		m_randomGainMin(1),

		m_pitch(VOX_DEFAULT_EMITTER_PITCH),	
		m_desiredPitch(VOX_DEFAULT_EMITTER_PITCH),

		m_basePitch(VOX_DEFAULT_EMITTER_PITCH),
		m_randomPitch(false),
		m_randomPitchMax(0),
		m_randomPitchMin(0),

		m_loop(false),
		m_desiredLoop(false),

		m_currentState(DriverSource::STATE_INITIAL),	
		m_desiredState(DriverSource::STATE_INITIAL),
		m_stateChanged(false),

		m_resetSource(false),
		m_killOnResume(true),
		m_fadeOnPlay(VOX_DEFAULT_FADE_TIME_PLAY),
		m_fadeOnStop(VOX_DEFAULT_FADE_TIME_STOP),

		m_currentBus(0),
		m_desiredBus(0),

		m_bufferSize(0),
		m_bufferPosition(0),

		m_phwSource(phwSourceInterface),
		m_pDecoderCursor(0),
		m_pDataSource(pDataSource),

		m_needToDie(false),
		m_autoKill(false),

		m_uid(-1),

		m_stateChangedCallback(0),
		m_stateChangedCallbackUserData(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::EmitterObj", vox::VoxThread::GetCurThreadId());
	for(s32 i = 0; i < Vox3DEmitterParameter::k_nCount; i++)
	{
		m_3DNeedUpdate[i] = false;
	}

	m_bufferId = 0;
	m_bufferQty = 0;

	if(m_pDataSource)
	{
		TrackParams tp = m_pDataSource->GetTrackParams();		
		m_bytesPerLoop = tp.numSamples * (tp.numChannels *  (tp.bitsPerSample >> 3));
		m_bytesPerSecond = tp.numChannels *  (tp.bitsPerSample >> 3) * tp.samplingRate;
	}

	/*if(m_phwSource->AllowBufferReference())
	{
		s32 sourceBuffer = m_phwSource->GetBufferCount();
		if(m_pDecoderCursor->AllowBufferReference())
		{
			m_bufferQty = 1;
			m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(m_bufferQty);		
		}
		else
		{
			m_pSndBuffer.reserve(sourceBuffer + 1);
			for(int i = 0; i < sourceBuffer + 1; ++i)
			{
				m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
				if(!m_pSndBuffer[i])
				{
					VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", i, VOX_DRIVER_SOURCE_NUM_BUFFER + 1);
					break;
				}
				++m_bufferQty;
			}
		}
	}
	else
	{
		m_bufferQty = 1;
		if(m_pDecoderCursor->AllowBufferReference())
		{
			m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(1);
		}
		else
		{
			m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
			if(!m_pSndBuffer[0])
			{
				VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", 0, 1);
				m_bufferQty = 0;
			}
		}
	}
	if(!m_bufferQty)
		m_needToDie = true;*/

	SetDefaultParameters();
	m_decoderType = m_pDataSource->GetDecoder()->GetType();

	m_hasNativeStateChanged = false;
	m_resetOnNativeStateChange = true;
	m_nativeStateLabel[0] = 0;
}



EmitterObj::EmitterObj(HandleId id, const emitter::CreationSettings& cs, s32 bufferSize, DriverSourceInterface* phwSourceInterface, DecoderCursorInterface* pDecoderCursor, DataObj* pDataSource) :
		Handlable(id),
		m_needLoad(false),
		m_bytesPerSecond(1),
		m_groupId(VOX_GROUP_MASTER_ID),
		m_priority(cs.m_priority),
		m_priorityBank(cs.m_priorityBankId),
		m_isInBank(false),
		
		m_gain(1.0f),
		m_desiredGain(1.0f),
		m_baseGain(VOX_DEFAULT_EMITTER_GAIN),
		m_gainModifier(1.0f),

		m_randomGain(false),
		m_randomGainMax(1),
		m_randomGainMin(1),

		m_pitch(VOX_DEFAULT_EMITTER_PITCH),	
		m_desiredPitch(VOX_DEFAULT_EMITTER_PITCH),

		m_basePitch(VOX_DEFAULT_EMITTER_PITCH),
		m_randomPitch(false),
		m_randomPitchMax(0),
		m_randomPitchMin(0),

		m_loop(false),
		m_desiredLoop(false),

		m_currentState(DriverSource::STATE_INITIAL),	
		m_desiredState(DriverSource::STATE_INITIAL),
		m_stateChanged(false),

		m_resetSource(false),
		m_killOnResume(true),
		m_fadeOnPlay(VOX_DEFAULT_FADE_TIME_PLAY),
		m_fadeOnStop(VOX_DEFAULT_FADE_TIME_STOP),

		m_currentBus(0),
		m_desiredBus(0),

		m_bufferSize(bufferSize),
		m_bufferPosition(0),

		m_phwSource(phwSourceInterface),
		m_pDecoderCursor(pDecoderCursor),
		m_pDataSource(pDataSource),

		m_needToDie(false),
		m_autoKill(false),

		m_uid(-1),

		m_stateChangedCallback(0),
		m_stateChangedCallbackUserData(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::EmitterObj", vox::VoxThread::GetCurThreadId());
	for(s32 i = 0; i < Vox3DEmitterParameter::k_nCount; i++)
	{
		m_3DNeedUpdate[i] = false;
	}

	m_bufferId = 0;
	m_bufferQty = 0;

	if(m_phwSource && pDecoderCursor)
	{
		m_bytesPerLoop = m_pDecoderCursor->GetNumSamples() * (m_pDecoderCursor->GetNumChannels() *  (m_pDecoderCursor->GetBitsPerSample() >> 3));
		m_bytesPerSecond = m_pDecoderCursor->GetNumChannels() *  (m_pDecoderCursor->GetBitsPerSample() >> 3) * m_pDecoderCursor->GetSamplingRate();

		if(m_phwSource->AllowBufferReference())
		{
			s32 sourceBuffer = m_phwSource->GetBufferCount();
			if(m_pDecoderCursor->AllowBufferReference())
			{
				m_bufferQty = 1;
				m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(m_bufferQty);
			}
			else
			{
				m_pSndBuffer.reserve(sourceBuffer + 1);
				for(int i = 0; i < sourceBuffer + 1; ++i)
				{
					m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
					if(!m_pSndBuffer[i])
					{
						VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", i, VOX_DRIVER_SOURCE_NUM_BUFFER + 1);
						break;
					}
					++m_bufferQty;
				}
			}
		}
		else
		{
			m_bufferQty = 1;
			if(m_pDecoderCursor->AllowBufferReference())
			{
				m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(1);
			}
			else
			{
				m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
				if(!m_pSndBuffer[0])
				{
					VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", 0, 1);
					m_bufferQty = 0;
				}
			}
		}

		if(!m_bufferQty)
			m_needToDie = true;

		SetDefaultParameters();
	}
	else
	{
		m_needToDie = true;
	}

	m_decoderType = m_pDataSource->GetDecoder()->GetType();

	m_hasNativeStateChanged = false;
	m_resetOnNativeStateChange = true;
	m_nativeStateLabel[0] = 0;

	Parametrize(cs);

}

EmitterObj::EmitterObj(HandleId id, const emitter::CreationSettings &cs, DriverSourceInterface* phwSourceInterface, DataObj* pDataSource) :
		Handlable(id),
		m_needLoad(true),
		m_bytesPerSecond(1),
		m_groupId(VOX_GROUP_MASTER_ID),
		m_priority(cs.m_priority),
		m_priorityBank(cs.m_priorityBankId),
		m_isInBank(false),
		
		m_gain(1.0f),
		m_desiredGain(1.0f),
		m_baseGain(VOX_DEFAULT_EMITTER_GAIN),
		m_gainModifier(1.0f),

		m_randomGain(false),
		m_randomGainMax(1),
		m_randomGainMin(1),

		m_pitch(VOX_DEFAULT_EMITTER_PITCH),	
		m_desiredPitch(VOX_DEFAULT_EMITTER_PITCH),

		m_basePitch(VOX_DEFAULT_EMITTER_PITCH),
		m_randomPitch(false),
		m_randomPitchMax(0),
		m_randomPitchMin(0),

		m_loop(false),
		m_desiredLoop(false),

		m_currentState(DriverSource::STATE_INITIAL),	
		m_desiredState(DriverSource::STATE_INITIAL),
		m_stateChanged(false),

		m_resetSource(false),
		m_killOnResume(true),
		m_fadeOnPlay(VOX_DEFAULT_FADE_TIME_PLAY),
		m_fadeOnStop(VOX_DEFAULT_FADE_TIME_STOP),

		m_currentBus(0),
		m_desiredBus(0),

		m_bufferSize(0),
		m_bufferPosition(0),

		m_phwSource(phwSourceInterface),
		m_pDecoderCursor(0),
		m_pDataSource(pDataSource),

		m_needToDie(false),
		m_autoKill(false),

		m_uid(-1),

		m_stateChangedCallback(0),
		m_stateChangedCallbackUserData(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::EmitterObj", vox::VoxThread::GetCurThreadId());
	for(s32 i = 0; i < Vox3DEmitterParameter::k_nCount; i++)
	{
		m_3DNeedUpdate[i] = false;
	}

	m_bufferId = 0;
	m_bufferQty = 0;

	if(m_pDataSource)
	{
		TrackParams tp = m_pDataSource->GetTrackParams();		
		m_bytesPerLoop = tp.numSamples * (tp.numChannels *  (tp.bitsPerSample >> 3));
		m_bytesPerSecond = tp.numChannels *  (tp.bitsPerSample >> 3) * tp.samplingRate;
	}

	/*if(m_phwSource->AllowBufferReference())
	{
		s32 sourceBuffer = m_phwSource->GetBufferCount();
		if(m_pDecoderCursor->AllowBufferReference())
		{
			m_bufferQty = 1;
			m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(m_bufferQty);		
		}
		else
		{
			m_pSndBuffer.reserve(sourceBuffer + 1);
			for(int i = 0; i < sourceBuffer + 1; ++i)
			{
				m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
				if(!m_pSndBuffer[i])
				{
					VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", i, VOX_DRIVER_SOURCE_NUM_BUFFER + 1);
					break;
				}
				++m_bufferQty;
			}
		}
	}
	else
	{
		m_bufferQty = 1;
		if(m_pDecoderCursor->AllowBufferReference())
		{
			m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(1);
		}
		else
		{
			m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
			if(!m_pSndBuffer[0])
			{
				VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", 0, 1);
				m_bufferQty = 0;
			}
		}
	}
	if(!m_bufferQty)
		m_needToDie = true;*/

	SetDefaultParameters();
	m_decoderType = m_pDataSource->GetDecoder()->GetType();

	m_hasNativeStateChanged = false;
	m_resetOnNativeStateChange = true;
	m_nativeStateLabel[0] = 0;

	Parametrize(cs);

}

void EmitterObj::Parametrize(const emitter::CreationSettings &cs)
{
	//gain
	m_randomGain    = cs.m_enableRandomGain;
	m_randomGainMax = cs.m_maximumRandomGainRatio;
	m_randomGainMin = cs.m_minimumRandomGainRatio;
	SetGain(cs.m_gain);

	//Pitch
	m_randomPitch    = cs.m_enableRandomPitch;
	m_randomPitchMax = cs.m_maximumRandomPitchCents;
	m_randomPitchMin = cs.m_minimumRandomPitchCents;
	SetPitch(cs.m_pitch);
	
	//Loop
	SetLoop(cs.m_isLoop);

	//Group
	SetGroup(cs.m_groupId);

	//Bank
	SetPriorityBank(cs.m_priorityBankId);
	SetPriority(cs.m_priority);

	//3d parameters
	if(cs.m_is3d)
		Set3DParameteri(Vox3DEmitterParameter::k_nRelativeToListener, cs.m_pEmitter3DParameters.relativeToListener?1:0);
	else
		Set3DParameteri(Vox3DEmitterParameter::k_nRelativeToListener, -1); // Disables 3d

	Set3DParameterfv(Vox3DEmitterParameter::k_nPosition,  cs.m_pPosition );
	Set3DParameterfv(Vox3DEmitterParameter::k_nVelocity,  cs.m_pVelocity );
	Set3DParameterfv(Vox3DEmitterParameter::k_nDirection, cs.m_pDirection);

	Set3DParameterf (Vox3DEmitterParameter::k_nReferenceDistance, cs.m_pEmitter3DParameters.referenceDistance);
	Set3DParameterf (Vox3DEmitterParameter::k_nMaxDistance,       cs.m_pEmitter3DParameters.maxDistance);
	Set3DParameterf (Vox3DEmitterParameter::k_nRolloffFactor,     cs.m_pEmitter3DParameters.rolloffFactor);

	Set3DParameterf (Vox3DEmitterParameter::k_nInnerConeAngle,    cs.m_pEmitter3DParameters.innerConeAngle);
	Set3DParameterf (Vox3DEmitterParameter::k_nOuterConeAngle,    cs.m_pEmitter3DParameters.outerConeAngle);
	Set3DParameterf (Vox3DEmitterParameter::k_nOuterConeGain,     cs.m_pEmitter3DParameters.outerConeGain);

	// bus
	SetDSPParameter(VoxDSPEmitterParameter::k_nBusId, cs.m_busName);

	// misc
	SetKillOnResume(cs.m_killOnResume);
	m_fadeOnPlay = cs.m_fadeOnPlay;
	m_fadeOnStop = cs.m_fadeOnStop;

	m_uid = cs.m_uid;

	if(cs.m_pEmitterHandleUserData)
		SetUserData(*cs.m_pEmitterHandleUserData);
	if(cs.m_stateChangedCallback)
		this->RegisterStateChangedCallback(cs.m_stateChangedCallback, cs.m_pStateChangedCallbackUserData);
}

EmitterObj::~EmitterObj()
{

}

bool EmitterObj::LoadAsync()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::LoadAsync", vox::VoxThread::GetCurThreadId());
	if(!m_pDataSource || !m_phwSource)
	{
		m_currentState = DriverSource::STATE_ERROR;
		m_needToDie = true;
		return false;
	}

	StreamInterface* stream = m_pDataSource->GetStream();
	DecoderInterface* decoder = m_pDataSource->GetDecoder();

	if(!stream || !decoder)
	{
		m_currentState = DriverSource::STATE_ERROR;
		m_needToDie = true;
		return false;
	}

	StreamCursorInterface* streamCursor = stream->CreateNewCursor();
	if(!streamCursor)
	{
		m_currentState = DriverSource::STATE_ERROR;
		m_needToDie = true;
		return false;
	}

	DecoderCursorInterface* decoderCursor = decoder->CreateNewCursor(streamCursor);
	if(!decoderCursor)
	{
		stream->DestroyCursor(streamCursor);
		m_currentState = DriverSource::STATE_ERROR;
		m_needToDie = true;
		return false;
	}

	m_pDecoderCursor = decoderCursor;

	if(m_phwSource->AllowBufferReference() && m_pDecoderCursor->AllowBufferReference())
	{
		m_bufferSize = m_pDecoderCursor->GetNumSamples() * m_pDecoderCursor->GetBitsPerSample() / 8;
	}
	else
	{
		m_bufferSize = m_pDecoderCursor->GetNumChannels() * m_pDecoderCursor->GetBitsPerSample() / 8 * m_pDecoderCursor->GetSamplingRate() * VOX_EMITTER_BUFFER_DURATION_MS / 1000;
		m_bufferSize -= (m_bufferSize % (m_pDecoderCursor->GetNumChannels() * m_pDecoderCursor->GetBitsPerSample() / 8)); //Needs to be a multiple of sampleSize*NumChannel
	}

	if(m_bufferSize <= 0)
	{
		decoder->DestroyCursor(m_pDecoderCursor);
		m_pDecoderCursor = 0;
		stream->DestroyCursor(streamCursor);
		m_currentState = DriverSource::STATE_ERROR;
		m_needToDie = true;
		return false;
	}

	if(m_phwSource->AllowBufferReference())
	{
		s32 sourceBuffer = m_phwSource->GetBufferCount();
		if(m_pDecoderCursor->AllowBufferReference())
		{
			m_bufferQty = 1;
			m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(m_bufferQty);		
		}
		else
		{
			m_pSndBuffer.reserve(sourceBuffer + 1);
			for(int i = 0; i < sourceBuffer + 1; ++i)
			{
				m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
				if(!m_pSndBuffer[i])
				{
					VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", i, VOX_DRIVER_SOURCE_NUM_BUFFER + 1);
					break;
				}
				++m_bufferQty;
			}
		}
	}
	else
	{
		m_bufferQty = 1;
		if(m_pDecoderCursor->AllowBufferReference())
		{
			m_pSndBuffer = VOX_VECTOR<u8*, SAllocator<u8*> >(1);
		}
		else
		{
			m_pSndBuffer.push_back((u8*)VOX_ALLOC(m_bufferSize));
			if(!m_pSndBuffer[0])
			{
				VOX_WARNING_LEVEL_3("Could not allocate all emitter internal buffer (%d/%d)", 0, 1);
				m_bufferQty = 0;
			}
		}
	}
	if(!m_bufferQty)
	{
		m_needToDie = true;
		return false;
	}

	return true;
}

void EmitterObj::CleanUp()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::CleanUp", vox::VoxThread::GetCurThreadId());
	if(m_pDecoderCursor)
	{
		if(!m_pDecoderCursor->AllowBufferReference())
		{
			for(int i = 0; i < m_bufferQty; ++i)
			{
				if(m_pSndBuffer[i])
					VOX_FREE(m_pSndBuffer[i]);
			}
		}
	}

	if(m_currentBus)
		VOX_FREE(m_currentBus);
	if(m_desiredBus)
		VOX_FREE(m_desiredBus);
}

void EmitterObj::SetDefaultParameters()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::SetDefaultParameters", vox::VoxThread::GetCurThreadId());
	// Relative to listener
	Set3DParameteri(Vox3DEmitterParameter::k_nRelativeToListener, VOX_DEFAULT_3D_EMITTER_RELATIVE_TO_LISTENER);

	// Max distance
	Set3DParameterf(Vox3DEmitterParameter::k_nMaxDistance, VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE);

	// Reference Distance
	Set3DParameterf(Vox3DEmitterParameter::k_nReferenceDistance, VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE);

	// Rolloff factor
	Set3DParameterf(Vox3DEmitterParameter::k_nRolloffFactor, VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR);

	// Inner cone angle
	Set3DParameterf(Vox3DEmitterParameter::k_nInnerConeAngle, VOX_DEFAULT_3D_EMITTER_INNER_CONE_ANGLE);

	// Outer cone angle
	Set3DParameterf(Vox3DEmitterParameter::k_nOuterConeAngle, VOX_DEFAULT_3D_EMITTER_OUTER_CONE_ANGLE);

	// Outer cone gain
	Set3DParameterf(Vox3DEmitterParameter::k_nOuterConeGain, VOX_DEFAULT_3D_EMITTER_OUTER_CONE_GAIN);

	// culling distance - Not supported yet
	//Set3DParameterf(Vox3DEmitterParameter::k_nCullingDistance, VOX_DEFAULT_3D_EMITTER_CULLING_DISTANCE);

	//VoxVector3f vector;
	// Position
	f32 position[3] = VOX_DEFAULT_3D_EMITTER_POSITION;
	m_position = VoxVector3f(position);
	Set3DParameterfv(Vox3DEmitterParameter::k_nPosition, m_position);

	// Velocity
	f32 velocity[3] = VOX_DEFAULT_3D_EMITTER_VELOCITY;
	m_velocity = VoxVector3f(velocity);
	Set3DParameterfv(Vox3DEmitterParameter::k_nVelocity, m_velocity);

	// Direction
	f32 direction[3] = VOX_DEFAULT_3D_EMITTER_DIRECTION;
	m_direction = VoxVector3f(direction);
	Set3DParameterfv(Vox3DEmitterParameter::k_nDirection, m_direction);
}


void EmitterObj::ProcessNativeData(f32 dt)
{
	bool performNormalDecoding = true;

#if VOX_NATIVE_REDUCE_LATENCY
	if(m_hasNativeStateChanged)
	{
		// If a transition occurs when sound is not playing, reset decoder, driver source and emitter buffers.
		if(m_resetOnNativeStateChange)
		{
			// Reset decoder state
			m_pDecoderCursor->Reset();

			// Put back decoder's state to the last desired state (since it has been resetted)
			DecoderNativeCursor* decoderCursor = (DecoderNativeCursor *) m_pDecoderCursor;
			decoderCursor->SetInteractiveMusicState(m_nativeStateLabel);

			// Reset data source	
			m_phwSource->Reset();

			// Reset emitter buffers
			m_bufferId = 0;
			m_bufferPosition = 0;
		}
		else // A transition occured while sound is playing (i.e. driver source filling buffers)
		{
			s32 size;
			s32 nbEmitterDisposableBytes = 0;
			s32 nbDriverDisposableBytes = 0;
			s32 nbDriverBuffersDisposed = 0;

			// Get the maximum nb of bytes that the decoder can rewind
			s32 maxNbRewindBytes = m_pDecoderCursor->GetRewindLimit();

			// If in prefetch mode, get the number of bytes decoded in the current non-uploaded buffer
			#if VOX_USE_EMITTER_PREFETCH
				nbEmitterDisposableBytes = m_bufferPosition;
				if(nbEmitterDisposableBytes > maxNbRewindBytes)
				{
					nbEmitterDisposableBytes = maxNbRewindBytes;
				}
			#endif

			// Ask driver to dispose of data and provide how much has been disposed of.	
			m_phwSource->FreeDisposableData(maxNbRewindBytes - nbEmitterDisposableBytes, nbDriverBuffersDisposed, nbDriverDisposableBytes);

			// If driver contains disposable data, rewind, redecode, possibly overwrite and upload new data
			if(nbDriverDisposableBytes > 0)
			{
				// Free buffers that were uploaded and have been disposed of.
				if(m_bufferId >= nbDriverBuffersDisposed)
				{
					m_bufferId -= nbDriverBuffersDisposed;
				}
				else
				{
					m_bufferId += m_bufferQty - nbDriverBuffersDisposed;
				}

				m_pDecoderCursor->Rewind(nbDriverDisposableBytes + nbEmitterDisposableBytes);

				if(m_pSndBuffer[m_bufferId])
				{
					// Decode a full buffer and upload it in the first free buffer (if any)
					if(m_phwSource->NeedData())
					{
						size = m_pDecoderCursor->Decode((void*&)m_pSndBuffer[m_bufferId], m_bufferSize);
						if(size > 0)
						{
							m_phwSource->UploadData((void*)m_pSndBuffer[m_bufferId], size);
							m_bufferPosition = 0;
							m_bufferId = (++m_bufferId) % m_bufferQty;
						}
					}
				}
				performNormalDecoding = false;
			}
			else if(nbEmitterDisposableBytes > 0) // Driver hasn't any disposable data but emitter has some.
			{
				// Rewind the amount of bytes determined by emitter buffer position.
				m_pDecoderCursor->Rewind(nbEmitterDisposableBytes);
				m_bufferPosition -= nbEmitterDisposableBytes;
			}
		}
		m_hasNativeStateChanged = false;
	}
#endif // VOX_NATIVE_REDUCE_LATENCY

	if(performNormalDecoding) // No buffer disposal has been done => normal decoding processus
	{
#if VOX_USE_EMITTER_PREFETCH
		if(m_pSndBuffer[m_bufferId] && !m_phwSource->NeedData() && (m_bufferSize > m_bufferPosition) && m_pDecoderCursor->HasData())
		{
			s32 nbBytesPerFrame = m_pDecoderCursor->GetNumChannels() * (m_pDecoderCursor->GetBitsPerSample() >> 3);
			s32 readSize = (s32)((m_pDecoderCursor->GetSamplingRate() * nbBytesPerFrame) * dt);
			readSize = readSize <= (m_bufferSize - m_bufferPosition) ? readSize : (m_bufferSize - m_bufferPosition);
			readSize -= readSize % nbBytesPerFrame;

			if(readSize > 0)
			{
				s32 size = m_pDecoderCursor->Decode(m_pSndBuffer[m_bufferId] + m_bufferPosition, readSize);
				m_bufferPosition += size;
			}
		}
		else if(m_pSndBuffer[m_bufferId] && m_phwSource->NeedData())
		{
			if(m_pDecoderCursor->HasData() && (m_bufferSize > m_bufferPosition))
			{
				s32 readSize = m_bufferSize - m_bufferPosition;
				s32 size = m_pDecoderCursor->Decode(m_pSndBuffer[m_bufferId] + m_bufferPosition, readSize);
				m_bufferPosition += size;
			}

			if(m_bufferPosition > 0)
			{
				m_phwSource->UploadData((void*)m_pSndBuffer[m_bufferId], m_bufferPosition);
				m_bufferPosition = 0;
				m_bufferId = (++m_bufferId) % m_bufferQty;
			}
		}
		if(!m_pSndBuffer[m_bufferId])
		{
			m_desiredState = DriverSource::STATE_ERROR;
		}
#else // No prefetch
		if(m_phwSource->NeedData())
		{
			if(m_pDecoderCursor->HasData())
			{
				if(m_pSndBuffer[m_bufferId])
				{
					s32 size = m_pDecoderCursor->DecodeRef((void*&)m_pSndBuffer[m_bufferId], m_bufferSize);
					if(size > 0)
					{
						m_phwSource->UploadData((void*)m_pSndBuffer[m_bufferId], size);
						m_bufferId = (++m_bufferId) % m_bufferQty;
					}
				}
				else
				{
					m_desiredState = DriverSource::STATE_ERROR; //error
				}
			}
		}
#endif
	}
}


void EmitterObj::ProcessNonNativeData(f32 dt)
{
#if VOX_USE_EMITTER_PREFETCH
	if(!m_pDecoderCursor->AllowBufferReference())
	{
		if(m_pSndBuffer[m_bufferId] && !m_phwSource->NeedData() && (m_bufferSize > m_bufferPosition) && m_pDecoderCursor->HasData())
		{
			s32 nbBytesPerFrame = m_pDecoderCursor->GetNumChannels() * (m_pDecoderCursor->GetBitsPerSample() >> 3);
			s32 readSize = (s32)((m_pDecoderCursor->GetSamplingRate() * nbBytesPerFrame) * dt);
			readSize = readSize <= (m_bufferSize - m_bufferPosition) ? readSize : (m_bufferSize - m_bufferPosition);
			readSize -= readSize % nbBytesPerFrame;

			if(readSize > 0)
			{
				s32 size = m_pDecoderCursor->Decode(m_pSndBuffer[m_bufferId] + m_bufferPosition, readSize);
				m_bufferPosition += size;
			}
		}
		else if(m_pSndBuffer[m_bufferId] && m_phwSource->NeedData())
		{
			if(m_pDecoderCursor->HasData() && (m_bufferSize > m_bufferPosition))
			{
				s32 readSize = m_bufferSize - m_bufferPosition;
				s32 size = m_pDecoderCursor->Decode(m_pSndBuffer[m_bufferId] + m_bufferPosition, readSize);
				m_bufferPosition += size;
			}

			if(m_bufferPosition > 0)
			{
				m_phwSource->UploadData((void*)m_pSndBuffer[m_bufferId], m_bufferPosition);
				m_bufferPosition = 0;
				m_bufferId = (++m_bufferId) % m_bufferQty;
			}
		}
		if(!m_pSndBuffer[m_bufferId])
		{
			m_desiredState = DriverSource::STATE_ERROR;
		}
	}
	else // Decoder allows reference
	{
#endif
		if(m_phwSource->NeedData())
		{
			if(m_pDecoderCursor->HasData())
			{
				if(m_pSndBuffer[m_bufferId] || m_pDecoderCursor->AllowBufferReference())
				{
					s32 size = m_pDecoderCursor->DecodeRef((void*&)m_pSndBuffer[m_bufferId], m_bufferSize);
					if(size > 0)
					{
						m_phwSource->UploadData((void*)m_pSndBuffer[m_bufferId], size);
						m_bufferId = (++m_bufferId) % m_bufferQty;
					}
				}
				else
				{
					m_desiredState = DriverSource::STATE_ERROR; //error
				}
			}
		}
#if VOX_USE_EMITTER_PREFETCH
	}
#endif
}


void EmitterObj::Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT( __SEL, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::Update", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	s32 oldState = m_currentState;

	if(m_needLoad && m_currentState != DriverSource::STATE_ERROR)
	{
		if(!LoadAsync())
		{
			VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
			return;
		}
		m_needLoad = false;
	}

	if(m_resetSource)
	{
		m_resetSource = false;
		m_pDecoderCursor->Reset();
		m_currentState = m_phwSource->GetState();
		if(m_currentState != DriverSource::STATE_INITIAL)
		{
			m_phwSource->Reset();
			VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
			return;
		}
	}

	if(m_desiredLoop != m_loop)
	{
		m_pDecoderCursor->SetLoop(m_desiredLoop);
		m_loop = m_desiredLoop;
	}	

	if(m_pDecoderCursor->GetNumChannels() == 1)
		Update3D();
	UpdateDSP(dt);

	m_baseGainFader.Update(dt);
	m_playbackFader.Update(dt);
	m_desiredGain = m_gainModifier * m_playbackFader.GetCurrentValue() * m_baseGainFader.GetCurrentValue();
	//if(m_baseGainFader.IsFinished())
	//{
	//	m_desiredGain =	m_baseGain * m_gainModifier;
	//}
	//else
	//{
	//	m_desiredGain =	m_baseGainFader.GetCurrentValue() * m_gainModifier;
	//}
	m_gain = m_phwSource->GetGain();
	if(m_desiredGain != m_gain)
	{
		m_phwSource->SetGain(m_desiredGain);
		m_gain = m_desiredGain;
	}

	m_pitchFader.Update(dt);
	m_desiredPitch = m_pitchFader.GetCurrentValue();
	m_pitch = m_phwSource->GetPitch();
	if(m_desiredPitch != m_pitch)
	{
		m_phwSource->SetPitch(m_desiredPitch);
		m_pitch = m_desiredPitch;
	}

	m_currentState = m_phwSource->GetState();
	if(m_currentState == DriverSource::STATE_STOPPED && m_desiredState != DriverSource::STATE_STOPPED && !m_pDecoderCursor->HasData())
	{
		m_desiredState = DriverSource::STATE_STOPPED; //source ended playback
		m_resetOnNativeStateChange = true;
		m_resetSource = true;
	}
	else if(m_currentState == DriverSource::STATE_ERROR)
	{
		if(oldState != m_currentState)
			m_stateChanged = true;
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	// Decode data (and upload to driver if necessary)
	if(m_decoderType == k_nDecoderTypeInteractiveMusic)
	{
		ProcessNativeData(dt);
	}
	else
	{
		ProcessNonNativeData(dt);
	}

	if(m_desiredState != m_currentState)
	{
		switch(m_desiredState)
		{
			case DriverSource::STATE_PLAYING:
			{
				m_resetOnNativeStateChange = false;
				m_phwSource->Play();
				m_currentState = m_phwSource->GetState();
				break;
			}
			case DriverSource::STATE_PAUSED:
			{
				if(m_playbackFader.IsFinished()/* && (m_desiredGain == m_gain)*/)
				{
					m_phwSource->SetGain(0.0f);
					m_phwSource->Pause();
					m_currentState = m_phwSource->GetState();
				}
				break;
			}
			case DriverSource::STATE_STOPPED:
			{
				if(m_currentState == DriverSource::STATE_INITIAL)
				{
					m_desiredState = DriverSource::STATE_INITIAL;
				}
				else if(m_playbackFader.IsFinished())
				{
					m_phwSource->Stop();
					m_currentState = m_phwSource->GetState();
					if(m_currentState == DriverSource::STATE_INITIAL)
						m_currentState = DriverSource::STATE_STOPPED; //calling stop in state initial in openAL doesn't change state
					m_resetSource = true;
					m_resetOnNativeStateChange = true;
				}
				break;
			}
			case DriverSource::STATE_INITIAL:
			{
				//Not all driver support INITIAL_STATE, switch to their "initial" state
				m_desiredState = m_currentState;
				break;
			}
			default:
			{
				VOX_ASSERT(0);//Invalid request
				m_currentState = DriverSource::STATE_ERROR;
				m_desiredState = DriverSource::STATE_ERROR;
				break;
			}
		}
	}

	if(oldState != m_currentState && m_currentState != DriverSource::STATE_INITIAL)
		m_stateChanged = true;

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Update3D()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::Update3D", vox::VoxThread::GetCurThreadId());
	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nRelativeToListener])
	{
		if(m_3Dparameters.relativeToListener == -1) // Disable 3d
		{
			int valueOne = 1;
			m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nRelativeToListener, &valueOne);
		}
		else
		{
			m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nRelativeToListener, &m_3Dparameters.relativeToListener);
		}
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nRelativeToListener] = false;
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nPosition] = true;
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nMaxDistance])
	{
		m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nMaxDistance, &m_3Dparameters.maxDistance);
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nMaxDistance] = false;
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nReferenceDistance])
	{
		m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nReferenceDistance, &m_3Dparameters.referenceDistance);
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nReferenceDistance] = false;
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nRolloffFactor])
	{
		m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nRolloffFactor, &m_3Dparameters.rolloffFactor);
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nRolloffFactor] = false;
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nInnerConeAngle])
	{
		m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nInnerConeAngle, &m_3Dparameters.innerConeAngle);
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nInnerConeAngle] = false;
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nOuterConeAngle])
	{
		m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nOuterConeAngle, &m_3Dparameters.outerConeAngle);
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nOuterConeAngle] = false;
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nOuterConeGain])
	{
		m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nOuterConeGain, &m_3Dparameters.outerConeGain);
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nOuterConeGain] = false;
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nPosition])
	{
		if(m_3Dparameters.relativeToListener == -1) // Disable 3d
		{
			VoxVector3f zeroVector(0,0,0);
			m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nPosition, &zeroVector);
			m_3DNeedUpdate[Vox3DEmitterParameter::k_nPosition] = false;
		}
		else
		{
			m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nPosition, &m_position);
			m_3DNeedUpdate[Vox3DEmitterParameter::k_nPosition] = false;
		}
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nVelocity])
	{
		m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nVelocity, &m_velocity);
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nVelocity] = false;
	}

	if(m_3DNeedUpdate[Vox3DEmitterParameter::k_nDirection])
	{
		m_phwSource->Set3DParameter(Vox3DEmitterParameter::k_nDirection, &m_direction);
		m_3DNeedUpdate[Vox3DEmitterParameter::k_nDirection] = false;
	}
}

void EmitterObj::UpdateDSP(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::UpdateDSP", vox::VoxThread::GetCurThreadId());
	if(m_desiredBus != 0)
	{
		VOX_FREE(m_currentBus);
		m_currentBus = m_desiredBus;
		m_desiredBus = 0;
		if(m_phwSource)
		{
			m_phwSource->SetDSPParameter(VoxDSPEmitterParameter::k_nBusId, m_currentBus);
		}
	}

	if(m_phwSource)
	{
		m_phwSource->Update(dt);
	}
}

void EmitterObj::Play(f32 fadeIn)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	
	if(m_desiredState != DriverSource::STATE_PAUSED)
	{
		m_playbackFader = Fader(0.0f, 1.0f, fadeIn);
		m_desiredState = DriverSource::STATE_PLAYING;
	}
	else
	{
		m_playbackFader = Fader(m_playbackFader.GetCurrentValue(), 1.0f, fadeIn);
		m_desiredState = DriverSource::STATE_PLAYING;
	}

	if(m_randomGain)
	{
		float randVal = (rand() % 1001) / 1000.0f;
		randVal *= m_randomGainMax - m_randomGainMin;
		randVal += m_randomGainMin;
		randVal *= m_baseGain;
		
		m_baseGainFader = Fader(randVal, randVal, 0);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	

	if(m_randomPitch)
	{
		float randVal = (rand() % 1001) / 1000.0f;
		randVal *= m_randomPitchMax - m_randomPitchMin;
		randVal += m_randomPitchMin;
		randVal = pow(2.0f, randVal / 1200.0f);
		randVal *= m_basePitch;
		
		m_pitchFader = Fader(randVal, randVal, 0);
	}

	VOX_WARNING_LEVEL_4("Playing emitter %lld. %s", m_id, m_userData.ToString());
}

void EmitterObj::Stop(f32 fadeOut)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_currentState != DriverSource::STATE_PLAYING)
	{
		m_desiredState = DriverSource::STATE_STOPPED;
		m_playbackFader = Fader();
	}
	else if(m_desiredState != DriverSource::STATE_STOPPED)
	{
		m_desiredState = DriverSource::STATE_STOPPED;
		m_playbackFader = Fader(m_playbackFader.GetCurrentValue(), 0.0f, fadeOut);
	}
	else
	{
		if(m_playbackFader.GetRemainingTime() > fadeOut)
			m_playbackFader = Fader(m_playbackFader.GetCurrentValue(), 0.0f, fadeOut);
	}

	VOX_WARNING_LEVEL_4("Stopping emitter %lld. %s", m_id, m_userData.ToString());

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	
}

void EmitterObj::Pause(f32 fadeOut)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_desiredState == DriverSource::STATE_STOPPED || m_desiredState == DriverSource::STATE_PAUSED)
	{
		if(m_playbackFader.GetRemainingTime() > fadeOut)
			m_playbackFader = Fader(m_playbackFader.GetCurrentValue(), 0.0f, fadeOut);
	}
	else if(m_desiredState == DriverSource::STATE_PLAYING)
	{
		m_desiredState = DriverSource::STATE_PAUSED;
		if(m_currentState == DriverSource::STATE_PLAYING)
			m_playbackFader = Fader(m_playbackFader.GetCurrentValue(), 0.0f, fadeOut);
		else
			m_playbackFader = Fader();
	}

	VOX_WARNING_LEVEL_4("Pausing emitter %lld. %s", m_id, m_userData.ToString());

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	
}

void EmitterObj::Resume(f32 fadeIn)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(((m_desiredState == DriverSource::STATE_PAUSED) || (m_currentState == DriverSource::STATE_PAUSED)) && (m_desiredState != DriverSource::STATE_STOPPED))
	{
		m_desiredState = DriverSource::STATE_PLAYING;
		m_playbackFader = Fader(m_playbackFader.GetCurrentValue(), 1.0f, fadeIn);
	}

	VOX_WARNING_LEVEL_4("Resuming emitter %lld. %s", m_id, m_userData.ToString());

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::RegisterStateChangedCallback(VoxEmitterStateChangedCallbackFunc callback, void* userData)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex _sm(&m_mutex));
	m_stateChangedCallback = callback;
	m_stateChangedCallbackUserData = userData;
}

void EmitterObj::UnregisterStateChangedCallback()
{
	VOX_MUTEX_LEVEL_1(ScopeMutex _sm(&m_mutex));
	m_stateChangedCallback = 0;
	m_stateChangedCallbackUserData = 0;
}

bool EmitterObj::NeedToSendStateChangedCallback(VoxEmitterStateChangedCallbackFunc &callback, void* &userData, EmitterExternState &state)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex _sm(&m_mutex));
	if(m_stateChanged && m_stateChangedCallback != 0)
	{
		m_stateChanged = false;
		callback = m_stateChangedCallback;
		userData = m_stateChangedCallbackUserData;

		switch(m_currentState)
		{
			case DriverSource::STATE_INITIAL:
			{
				state = k_nStopped;
				break;
			}
			case DriverSource::STATE_PLAYING:
			{
				state = k_nPlaying;
				break;
			}
			case DriverSource::STATE_PAUSED:
			{
				state = k_nPaused;
				break;
			}
			case DriverSource::STATE_STOPPED:
			{
				state = k_nStopped;
				break;
			}
			//case DriverSource::STATE_ERROR:
			default:
			{
				state = k_nError;
				break;
			}
		}

		return true;
	}

	return false;
}

void EmitterObj::SetAutoKillAfterDone(bool autokill)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_autoKill = autokill;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::NeedToDie()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_needToDie = true;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

bool EmitterObj::ShouldDie()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	bool b = (_IsDone() && (m_refCount == 0)) || m_needToDie || (m_currentState == DriverSource::STATE_ERROR);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return b;
}

bool EmitterObj::GetKillOnResume()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	bool val = m_killOnResume;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return val;
}

void EmitterObj::SetKillOnResume(bool val)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_killOnResume = val;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

float EmitterObj::GetFadeOnPlay()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	float val = m_fadeOnPlay;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return val;
}

float EmitterObj::GetFadeOnStop()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	float val = m_fadeOnStop;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return val;
}

s32 EmitterObj::GetGroup()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	s32 gid = m_groupId;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return gid;
}

void EmitterObj::SetGroup(u32 groupId)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_groupId = groupId;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

bool EmitterObj::IsChild(u32 groupId)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	VoxEngineInternal *eng = VoxEngineInternal::GetVoxEngineInternal();
	bool result = false;

	if (eng->m_groupManager)
		result = eng->m_groupManager->IsChild(m_groupId, groupId);

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

f32 EmitterObj::GetGain()//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 gain = m_desiredGain;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return gain;
}

s32 EmitterObj::GetUid()//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	s32 uid = m_uid;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return uid;
}

void EmitterObj::SetGain(f32 gain, f32 fadeTime)//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_baseGain = gain;
	m_baseGainFader = Fader(m_baseGainFader.GetCurrentValue(), m_baseGain, fadeTime);
	VOX_WARNING_LEVEL_5("Setting emitter %lld gain to %1.4f. %s", m_id, gain, m_userData.ToString());
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::SetGainModifier(f32 gainModifier)
{
	m_gainModifier = gainModifier;
}

f32 EmitterObj::GetAttenuation()
{
	f32 x, y, z;
	VoxEngineInternal *voxEngine = VoxEngineInternal::GetVoxEngineInternal();

	if(m_3Dparameters.relativeToListener)
	{
		x = y = z = 0; // origin is zero in relative to listener mode
	}
	else
	{	
		voxEngine->Get3DListenerPosition(x, y, z); // Find listener
	}
	x = m_position.x - x; // Calculate vector from listener to source
	y = m_position.y - y;
	z = m_position.z - z;

	float distance = sqrt(x*x + y*y + z*z);
	float attenuation;

	int distanceMode;
	voxEngine->Get3DGeneralParameteri(Vox3DGeneralParameter::k_nDistanceModel, distanceMode);
	switch(distanceMode)
	{
	default:
	case Vox3DDistanceModel::k_nNone:
		attenuation = 1;
		break;
	case Vox3DDistanceModel::k_nInverseDistanceClamped:
		if(distance < m_3Dparameters.referenceDistance || m_3Dparameters.referenceDistance == 0)
			attenuation = 1;
		else
		{
			if(distance > m_3Dparameters.maxDistance)
				distance = m_3Dparameters.maxDistance;
			attenuation = (m_3Dparameters.referenceDistance 
				+ (distance - m_3Dparameters.referenceDistance)*m_3Dparameters.rolloffFactor)
				/ m_3Dparameters.referenceDistance;
		}
		break;
	case Vox3DDistanceModel::k_nLinearDistanceClamped:
		if(distance < m_3Dparameters.referenceDistance || m_3Dparameters.maxDistance - m_3Dparameters.referenceDistance <= 0)
			attenuation = 1;
		else
		{
			if(distance > m_3Dparameters.maxDistance)
				distance = m_3Dparameters.maxDistance;
			attenuation = 1 - m_3Dparameters.rolloffFactor * (distance - m_3Dparameters.referenceDistance) / (m_3Dparameters.maxDistance - m_3Dparameters.referenceDistance) ;
		}
		
		break;
	case Vox3DDistanceModel::k_nExponentDistanceClamped:
		if(distance < m_3Dparameters.referenceDistance || m_3Dparameters.referenceDistance >= 0 || m_3Dparameters.rolloffFactor < 0)
			attenuation = 1;
		else
		{
			if(distance > m_3Dparameters.maxDistance)
				distance = m_3Dparameters.maxDistance;
			attenuation = pow(distance / m_3Dparameters.referenceDistance, -m_3Dparameters.rolloffFactor);
		}
		break;
	}

	// See if cone gain computation should be added
	// See if enhanced 3d tweaks should be added
	return attenuation;
}

f32 EmitterObj::GetPitch()//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 pitch = m_desiredPitch;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return pitch;
}
void EmitterObj::SetPitch(f32 pitch, f32 fadeTime)//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_basePitch = pitch;
	m_desiredPitch = pitch;
	m_pitchFader = Fader(m_pitchFader.GetCurrentValue(), m_desiredPitch, fadeTime);
	VOX_WARNING_LEVEL_5("Setting emitter %lld pitch to %1.4f. %s", m_id, pitch, m_userData.ToString());
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

s32 EmitterObj::GetState()//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	s32 state = m_currentState;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return state;
}
void EmitterObj::SetState(s32 state)//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_desiredState = state;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

bool EmitterObj::GetLoop()//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	bool loop = m_desiredLoop;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return loop;
}
void EmitterObj::SetLoop(bool loop)//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_desiredLoop = loop;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Reset()//mutex
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_resetSource = true;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

bool EmitterObj::IsReady()
{
	return !m_needLoad;
}

bool EmitterObj::IsAlive()
{
	bool result;
	// VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	result = !ShouldDie();
	// VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

bool EmitterObj::IsPlaying()
{
	bool result;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	result = (m_currentState == DriverSource::STATE_PLAYING) || (m_desiredState == DriverSource::STATE_PLAYING);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

bool EmitterObj::IsDone()
{
	bool result;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	result = _IsDone();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

bool EmitterObj::_IsDone()
{
	return (m_currentState == DriverSource::STATE_STOPPED) && (m_desiredState == DriverSource::STATE_STOPPED)
		|| (m_currentState == DriverSource::STATE_INITIAL) && (m_desiredState == DriverSource::STATE_INITIAL);
}

u32 EmitterObj::GetStatus()
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	u32 result = k_nError;

	if(m_currentState == DriverSource::STATE_PLAYING)
	{
		result = k_nPlaying;
		if(!m_playbackFader.IsFinished())
		{
			if(m_desiredState == DriverSource::STATE_PLAYING)
			{
				result |= k_nFadingIn;
			}
			else //if((m_desiredState == DriverSource::STATE_PAUSED) || (m_desiredState == DriverSource::STATE_STOPPED))
			{
				result |= k_nFadingOut;
			}
		}
	}
	else if(m_currentState == DriverSource::STATE_PAUSED)
	{
		result = k_nPaused;
	}
	else if((m_currentState == DriverSource::STATE_INITIAL) || (m_currentState == DriverSource::STATE_STOPPED))
	{
		result = k_nStopped;
	}
	
	return result;
}

f32 EmitterObj::GetPlayCursor()
{
	f32 result = 0.0f;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	
	if(m_bytesPerLoop > 0)
	{
		long byteOffset = m_phwSource->GetByteOffset() % m_bytesPerLoop;
		result = ((f32) byteOffset) / ((f32)m_bytesPerSecond);
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

void  EmitterObj::SetPlayCursor(f32 time)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::SetPlayCursor", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_phwSource && m_pDecoderCursor)
	{
		if(m_pDecoderCursor->GetNumSamples() > 0 && m_pDataSource->GetDecoder()->GetType() != k_nDecoderTypeInteractiveMusic)
		{
			if(time < 0.0f)
				time = 0.0f;
			u32 sampleOffset = (u32)(time * ((f32)m_pDecoderCursor->GetSamplingRate()));
			m_phwSource->Reset();
			m_phwSource->SetByteOffset(sampleOffset * (m_pDecoderCursor->GetNumChannels() *  (m_pDecoderCursor->GetBitsPerSample() >> 3)));
			m_pDecoderCursor->Seek(sampleOffset);
			if(m_desiredState == DriverSource::STATE_PAUSED)
				m_desiredState = DriverSource::STATE_STOPPED;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::SetUserData(EmitterHandleUserData &data)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_userData = data;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

EmitterHandleUserData EmitterObj::GetUserData()
{
	EmitterHandleUserData data;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	data = m_userData;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return data;
}

void EmitterObj::Set3DParameteri(s32 parameterId, s32 intValue)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case Vox3DEmitterParameter::k_nRelativeToListener:
		{
			m_3Dparameters.relativeToListener = intValue;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nMaxDistance:
		case Vox3DEmitterParameter::k_nReferenceDistance:
		case Vox3DEmitterParameter::k_nRolloffFactor:
		case Vox3DEmitterParameter::k_nInnerConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeGain:
		case Vox3DEmitterParameter::k_nPosition:
		case Vox3DEmitterParameter::k_nVelocity:
		case Vox3DEmitterParameter::k_nDirection:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take an int as value", parameterId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Set3DParameterf(s32 parameterId, f32 floatValue)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case Vox3DEmitterParameter::k_nMaxDistance:
		{
			m_3Dparameters.maxDistance = floatValue;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nReferenceDistance:
		{
			m_3Dparameters.referenceDistance = floatValue;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nRolloffFactor:
		{
			m_3Dparameters.rolloffFactor = floatValue;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nInnerConeAngle:
		{
			m_3Dparameters.innerConeAngle = floatValue;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nOuterConeAngle:
		{
			m_3Dparameters.outerConeAngle = floatValue;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nOuterConeGain:
		{
			m_3Dparameters.outerConeGain = floatValue;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nPosition:
		case Vox3DEmitterParameter::k_nVelocity:
		case Vox3DEmitterParameter::k_nDirection:
		case Vox3DEmitterParameter::k_nRelativeToListener:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take an f32 as value", parameterId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Set3DParameter3f(s32 parameterId, f32 floatValue_0, f32 floatValue_1, f32 floatValue_2)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case Vox3DEmitterParameter::k_nPosition:
		{
			m_position.x = floatValue_0;
			m_position.y = floatValue_1;
			m_position.z = floatValue_2;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nVelocity:
		{
			m_velocity.x = floatValue_0;
			m_velocity.y = floatValue_1;
			m_velocity.z = floatValue_2;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nDirection:
		{
			m_direction.x = floatValue_0;
			m_direction.y = floatValue_1;
			m_direction.z = floatValue_2;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nRelativeToListener:
		case Vox3DEmitterParameter::k_nMaxDistance:
		case Vox3DEmitterParameter::k_nReferenceDistance:
		case Vox3DEmitterParameter::k_nRolloffFactor:
		case Vox3DEmitterParameter::k_nInnerConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeGain:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take 3 floats as value", parameterId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Set3DParameterfv(s32 parameterId, const VoxVector3f &vector)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case Vox3DEmitterParameter::k_nPosition:
		{
			m_position = vector;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nVelocity:
		{
			m_velocity = vector;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nDirection:
		{
			m_direction = vector;
			m_3DNeedUpdate[parameterId] = true;
			break;
		}
		case Vox3DEmitterParameter::k_nRelativeToListener:
		case Vox3DEmitterParameter::k_nMaxDistance:
		case Vox3DEmitterParameter::k_nReferenceDistance:
		case Vox3DEmitterParameter::k_nRolloffFactor:
		case Vox3DEmitterParameter::k_nInnerConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeGain:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take a VoxVector3f as value", parameterId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Get3DParameteri(s32 parameterId, s32 &intValue)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case Vox3DEmitterParameter::k_nRelativeToListener:
		{
			intValue = m_3Dparameters.relativeToListener;
			break;
		}
		case Vox3DEmitterParameter::k_nMaxDistance:
		case Vox3DEmitterParameter::k_nReferenceDistance:
		case Vox3DEmitterParameter::k_nRolloffFactor:
		case Vox3DEmitterParameter::k_nInnerConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeGain:
		case Vox3DEmitterParameter::k_nPosition:
		case Vox3DEmitterParameter::k_nVelocity:
		case Vox3DEmitterParameter::k_nDirection:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take an int as value", parameterId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Get3DParameterf(s32 parameterId, f32 &floatValue)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case Vox3DEmitterParameter::k_nMaxDistance:
		{
			floatValue = m_3Dparameters.maxDistance;
			break;
		}
		case Vox3DEmitterParameter::k_nReferenceDistance:
		{
			floatValue = m_3Dparameters.referenceDistance;
			break;
		}
		case Vox3DEmitterParameter::k_nRolloffFactor:
		{
			floatValue = m_3Dparameters.rolloffFactor;
			break;
		}
		case Vox3DEmitterParameter::k_nInnerConeAngle:
		{
			floatValue = m_3Dparameters.innerConeAngle;
			break;
		}
		case Vox3DEmitterParameter::k_nOuterConeAngle:
		{
			floatValue = m_3Dparameters.outerConeAngle;
			break;
		}
		case Vox3DEmitterParameter::k_nOuterConeGain:
		{
			floatValue = m_3Dparameters.outerConeGain;
			break;
		}
		case Vox3DEmitterParameter::k_nPosition:
		case Vox3DEmitterParameter::k_nVelocity:
		case Vox3DEmitterParameter::k_nDirection:
		case Vox3DEmitterParameter::k_nRelativeToListener:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take an f32 as value", parameterId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Get3DParameter3f(s32 parameterId, f32 &floatValue_0, f32 &floatValue_1, f32 &floatValue_2)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case Vox3DEmitterParameter::k_nPosition:
		{
			floatValue_0 = m_position.x;
			floatValue_1 = m_position.y;
			floatValue_2 = m_position.z;
			break;
		}
		case Vox3DEmitterParameter::k_nVelocity:
		{
			floatValue_0 = m_velocity.x;
			floatValue_1 = m_velocity.y;
			floatValue_2 = m_velocity.z;
			break;
		}
		case Vox3DEmitterParameter::k_nDirection:
		{
			floatValue_0 = m_direction.x;
			floatValue_1 = m_direction.y;
			floatValue_2 = m_direction.z;
			break;
		}
		case Vox3DEmitterParameter::k_nRelativeToListener:
		case Vox3DEmitterParameter::k_nMaxDistance:
		case Vox3DEmitterParameter::k_nReferenceDistance:
		case Vox3DEmitterParameter::k_nRolloffFactor:
		case Vox3DEmitterParameter::k_nInnerConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeGain:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take 3 floats as value", parameterId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::Get3DParameterfv(s32 parameterId, VoxVector3f &vector)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case Vox3DEmitterParameter::k_nPosition:
		{
			vector = m_position;
			break;
		}
		case Vox3DEmitterParameter::k_nVelocity:
		{
			vector = m_velocity;
			break;
		}
		case Vox3DEmitterParameter::k_nDirection:
		{
			vector = m_direction;
			break;
		}
		case Vox3DEmitterParameter::k_nRelativeToListener:
		case Vox3DEmitterParameter::k_nMaxDistance:
		case Vox3DEmitterParameter::k_nReferenceDistance:
		case Vox3DEmitterParameter::k_nRolloffFactor:
		case Vox3DEmitterParameter::k_nInnerConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeAngle:
		case Vox3DEmitterParameter::k_nOuterConeGain:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't take a VoxVector3f as value", parameterId);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::SetDSPParameter(s32 parameterId, const void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "EmitterObj::SetDSPParameter", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(parameterId)
	{
		case VoxDSPEmitterParameter::k_nBusId:
		{
			if(!param)
				param = "master";
			s32 strsize = strlen((const c8*)param);
			if(strsize > 0)
			{
				VOX_FREE(m_desiredBus);
				m_desiredBus = (c8*)VOX_ALLOC(strsize+1);
				if(m_desiredBus)
					strcpy(m_desiredBus, (const c8*)param);
			}			
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Emitter dsp parameter %d doesn't exist", parameterId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


void EmitterObj::SetInteractiveMusicStateChange(const char *stateLabel)
{
	if(strcmp(m_nativeStateLabel, stateLabel) != 0)
	{
		m_hasNativeStateChanged = true;
		strcpy(m_nativeStateLabel, stateLabel);
	}
}


void EmitterObj::PrintDebug()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	VOX_WARNING_LEVEL_1("%s", "  ###############################################################################");
	VOX_WARNING_LEVEL_1("%s", "  ##############################      Emitter      ##############################");
	VOX_WARNING_LEVEL_1("%s", "  ###############################################################################");
	VOX_WARNING_LEVEL_1("%s", "  #");

	VOX_WARNING_LEVEL_1("  #    Emitter Id : %lld", (s64)m_id);
	VOX_WARNING_LEVEL_1("%s", "  #");
	VOX_WARNING_LEVEL_1("  #    State : %d", m_currentState);
	VOX_WARNING_LEVEL_1("  #    Looping : %d", m_loop);
	VOX_WARNING_LEVEL_1("  #    GroupId : %d", m_groupId);
	VOX_WARNING_LEVEL_1("  #    Reference count : %d", m_refCount);
	VOX_WARNING_LEVEL_1("%s", "  #");
	VOX_WARNING_LEVEL_1("%s", "  ###############################################################################");

	if(m_phwSource)
		m_phwSource->PrintDebug();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void EmitterObj::GetDebugInfo(DebugChunk_emitter &info)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	info.id = m_id;
	info.dataSourceId = m_pDataSource->GetId();
	info.gain[0] = m_gain;
	info.gain[1] = m_gainModifier * m_playbackFader.GetEndValue() * m_baseGainFader.GetEndValue();
	info.pitch[0] = m_pitch;
	info.pitch[1] = m_desiredPitch;
	info.state = m_desiredState;
	m_position.ToArray(info.position);
	m_velocity.ToArray(info.velocity);
	m_direction.ToArray(info.direction);
	info.loop = m_loop;
	info.groupId = m_groupId;
	info.referenceCount = m_refCount;
	memcpy(&info.param3D, &m_3Dparameters, sizeof(Vox3DEmitterParameters));
	if(m_pDecoderCursor->GetNumChannels() > 1)
		info.param3D.relativeToListener = -1; //no 3d
}


DriverSourceParam::DriverSourceParam()
:numBuffer(VOX_DRIVER_SOURCE_NUM_BUFFER)
{}


} //namespace vox


//* VoxCallbackManager *//
namespace vox
{
VoxCallbackManager::~VoxCallbackManager()
{
	while(m_callbackList.size() > 0)
	{
		VoxCallback* cb = m_callbackList.front();
		m_callbackList.pop_front();
		VOX_DELETE(cb);
	}
}

void VoxCallbackManager::Add(VoxCallback* callback)
{
	if(callback)
		m_callbackList.push_back(callback);
}

void VoxCallbackManager::SendAll()
{
	while(m_callbackList.size() > 0)
	{
		VoxCallback* cb = m_callbackList.front();
		m_callbackList.pop_front();
		cb->Send();
		VOX_DELETE(cb);
	}
}

} // namespace vox


