#include "StdAfx.h"
#include "vox_memory.h"

// Allocator C wrapper for MPC decoder
#ifdef __cplusplus /* If this is a C++ compiler, use C linkage */
extern "C" {
#endif

void* VoxAlloc_c(size_t size, const char* filename, const char* function, int line)
{
	return VoxAlloc(size, filename, function, line);
}

void VoxFree_c(void* ptr)
{
	VoxFree(ptr);
}

#ifdef __cplusplus /* If this is a C++ compiler, use C linkage */
}
#endif // __cplusplus


