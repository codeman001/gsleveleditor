
#include "StdAfx.h"
#include "vox_default_config.h"
#include "vox_minibus_system.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox_profiler.h"

namespace vox
{

s32 MinibusDataGeneratorInterface::s_driverSampleRate = 44100;
fx1814 MinibusDataGeneratorInterface::s_driverCallbackPeriod = 0x7FFFFFFF;

//*** MiniBus ***//

s32 MiniBus::s_driverSampleRate;

MiniBus::MiniBus():
m_nbSamples(0)
,m_pWetBuffer(0)
,m_pDryBuffer(0)
,m_volumeDry(VOX_FX1814_ONE)
,m_volumeWet(0)
,m_id(-1)
{
}

MiniBus::~MiniBus()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBus::~MiniBus", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	m_nbSamples = 0;

	if(m_pDryBuffer)
		VOX_FREE(m_pDryBuffer);
	m_pDryBuffer = 0;

	if(m_pWetBuffer)
		VOX_FREE(m_pWetBuffer);
	m_pWetBuffer = 0;

	// At this point, the data generators list should already been cleared (from source destruction).
	m_dataGenerators.clear();
}

void MiniBus::RegisterDataGenerator(MinibusDataGeneratorInterface *pDataGenerator)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBus::RegisterDataGenerator", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	m_dataGenerators.push_back(pDataGenerator);
}

bool MiniBus::UnregisterDataGenerator(MinibusDataGeneratorInterface *pDataGenerator)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBus::UnregisterDataSource", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	// Get input from data sources
	VOX_LIST<MinibusDataGeneratorInterface *, SAllocator<MinibusDataGeneratorInterface *> >::iterator it = m_dataGenerators.begin();
	VOX_LIST<MinibusDataGeneratorInterface *, SAllocator<MinibusDataGeneratorInterface *> >::iterator end = m_dataGenerators.end();
			
	for(; it != end; it++)
	{
		if(*it == pDataGenerator)
		{
			m_dataGenerators.erase(it);
			return true;
		}
	}

	return false;
}

f32 MiniBus::GetVolume(VoxDSPGeneralParameter::BusRoutingType path)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBus::GetVolume", vox::VoxThread::GetCurThreadId());

	if(path == VoxDSPGeneralParameter::k_nDry)
	{
		return ((static_cast<f32> (m_volumeDry)) / (static_cast<f32> (VOX_FX1814_ONE)));
	}
	else if(path == VoxDSPGeneralParameter::k_nWet)
	{
		return ((static_cast<f32> (m_volumeWet)) / (static_cast<f32> (VOX_FX1814_ONE)));
	}
	return 0.0f;
}

void MiniBus::SetId(s32 id)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBus::SetId", vox::VoxThread::GetCurThreadId());

	if(id == VOX_MINIBUS_MASTER || id == VOX_MINIBUS_AUX1 || id == VOX_MINIBUS_AUX2)
	{
		m_id = id;
	}
}

void MiniBus::SetVolume(VoxDSPGeneralParameter::BusRoutingType path, f32 volume, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBus::SetVolume", vox::VoxThread::GetCurThreadId());

	if(path == VoxDSPGeneralParameter::k_nDry)
	{
		if(fadeTime > 0.0f)
		{
			m_dryVolumeFader = Fader(m_dryVolumeFader.GetCurrentValue(), volume, fadeTime);
		}
		else
		{
			m_dryVolumeFader = Fader(volume, volume, 0.0f);
		}
	}
	else if(path == VoxDSPGeneralParameter::k_nWet)
	{
		if(fadeTime > 0.0f)
		{
			m_wetVolumeFader = Fader(m_wetVolumeFader.GetCurrentValue(), volume, fadeTime);
		}
		else
		{
			m_wetVolumeFader = Fader(volume, volume, 0.0f);
		}
	}
}

//*** MiniAuxBus ***//

MiniAuxBus::MiniAuxBus():
m_pDsp(0)
,m_isDspActive(false)
,m_needRemoveDsp(false)
{
}

MiniAuxBus::~MiniAuxBus()
{
	
}


void MiniAuxBus::Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniAuxBus::Update", vox::VoxThread::GetCurThreadId());

	// Update dry volume
	if(!m_dryVolumeFader.IsFinished())
	{
		m_dryVolumeFader.Update(dt);
		f32 volume = m_dryVolumeFader.GetCurrentValue();
		m_volumeDry = static_cast<fx1814> (volume * VOX_FX1814_ONE);
	}

	// Update wet volume
	if(!m_wetVolumeFader.IsFinished())
	{
		m_wetVolumeFader.Update(dt);
		f32 volume = m_wetVolumeFader.GetCurrentValue();
		m_volumeWet = static_cast<fx1814> (volume * VOX_FX1814_ONE);
	}
}


s32 MiniAuxBus::GetDSPPresence(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniAuxBus::GetDSPPresence", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	if(m_isDspActive)
		return 1;

	return 0;
}

void MiniAuxBus::FillBuffer(s32* dryBuffer, s32* wetBuffer, s32 nbSamples)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniAuxBus::FillBuffer", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	s32 totalSamples = nbSamples << 1;	// << 1 to include left and right channels.

	if(nbSamples > m_nbSamples)
	{
		// Delete current buffers
		if(m_pDryBuffer)
		{
			VOX_FREE(m_pDryBuffer);
		}

		if(m_pWetBuffer)
		{
			VOX_FREE(m_pWetBuffer);
		}
			
		// Allocate new buffers
		m_pDryBuffer = (s32*)VOX_ALLOC(sizeof(s32) * totalSamples);
		m_pWetBuffer = (s32*)VOX_ALLOC(sizeof(s32) * totalSamples);

		if(m_pDryBuffer && m_pWetBuffer)
		{
			m_nbSamples = nbSamples;
		}
		else
		{
			m_nbSamples = 0;
			nbSamples = 0;
		}
	}

	if(m_nbSamples > 0)
	{
		memset(m_pDryBuffer, 0, totalSamples * sizeof(s32));
		memset(m_pWetBuffer, 0, totalSamples * sizeof(s32));

		// Get input from driver sources
		VOX_LIST<MinibusDataGeneratorInterface *, SAllocator<MinibusDataGeneratorInterface *> >::iterator generatorsIt = m_dataGenerators.begin();
		VOX_LIST<MinibusDataGeneratorInterface *, SAllocator<MinibusDataGeneratorInterface *> >::iterator generatorsEnd = m_dataGenerators.end();

		bool inputActive = false;
		bool outputActive = false;

		for(; generatorsIt != generatorsEnd; generatorsIt++)
		{
			(*generatorsIt)->GetData(m_pDryBuffer, nbSamples, s_driverSampleRate);
			inputActive = true;
		}

		// Apply dsp processing upon mixed sources (if any)
		if(m_isDspActive && m_pDsp!=0)
		{
			outputActive = m_pDsp->WillOutput(inputActive);
			if(outputActive)
			{
				m_pDsp->Update(m_pDryBuffer, m_pWetBuffer, nbSamples);
			}

			// Application is responsible to delete DSP objects. GetDSPPresence() informs it it's no longer used. 
			if(m_needRemoveDsp)
			{
				m_isDspActive = false;
				m_needRemoveDsp = false;
				if(m_pDsp) // Tell the DSP that it's getting disconnected
				{
					m_pDsp->DisconnectFromBus();
				}
				m_pDsp = 0;
			}
		}

		// Mix dry and wet buffers into outBuffer
		if(m_volumeDry != 0)
		{
			s32 *outDryBufferCursor = dryBuffer;
			s32 *dryBufferCursor = m_pDryBuffer;
			if(m_volumeDry != VOX_FX1814_ONE)
			{
				for(s32 i = 0; i < nbSamples; i++)
				{
					// Left channel (dry signal)
					*outDryBufferCursor += (*dryBufferCursor * m_volumeDry) >> VOX_FX1814_FRACT_SHIFT;
					outDryBufferCursor++;
					dryBufferCursor++;

					// Right channel (dry signal)
					*outDryBufferCursor += (*dryBufferCursor * m_volumeDry) >> VOX_FX1814_FRACT_SHIFT;
					outDryBufferCursor++;
					dryBufferCursor++;
				}
			}
			else
			{
				for(s32 i = 0; i < nbSamples; i++)
				{
					// Left channel (dry signal)
					*outDryBufferCursor += *dryBufferCursor;
					outDryBufferCursor++;
					dryBufferCursor++;

					// Right channel (dry signal)
					*outDryBufferCursor += *dryBufferCursor;
					outDryBufferCursor++;
					dryBufferCursor++;
				}
			}
		}
		if(m_volumeWet != 0 && outputActive)
		{
			s32 *outWetBufferCursor = wetBuffer;
			s32 *wetBufferCursor = m_pWetBuffer;

			if(m_volumeWet != VOX_FX1814_ONE)
			{
				for(s32 i = 0; i < nbSamples; i++)
				{
					// Left channel (wet signal)
					*outWetBufferCursor += (*wetBufferCursor * m_volumeWet) >> VOX_FX1814_FRACT_SHIFT;
					outWetBufferCursor++;
					wetBufferCursor++;

					// Right channel (wet signal)
					*outWetBufferCursor += (*wetBufferCursor * m_volumeWet) >> VOX_FX1814_FRACT_SHIFT;
					outWetBufferCursor++;
					wetBufferCursor++;
				}
			}
			else // Volume is 1, so no multiplication is required
			{
				for(s32 i = 0; i < nbSamples; i++)
				{
					// Left channel (wet signal)
					*outWetBufferCursor += *wetBufferCursor;
					outWetBufferCursor++;
					wetBufferCursor++;

					// Right channel (wet signal)
					*outWetBufferCursor += *wetBufferCursor;
					outWetBufferCursor++;
					wetBufferCursor++;
				}
			}
		}
	}
}

CustomDSP* MiniAuxBus::GetDSP(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniAuxBus::GetDSP", vox::VoxThread::GetCurThreadId());

	return m_pDsp;
}

void MiniAuxBus::SetDSP(CustomDSP *pDsp)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniAuxBus::SetDSP", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	if(pDsp) // adding DSP
	{
		if(pDsp->ConnectToBus(static_cast<f32> (s_driverSampleRate), 2, 0))
		{
			m_isDspActive = true;

			if(m_pDsp) // Tell the previous DSP that it's getting disconnected from the bus
			{
				m_pDsp->DisconnectFromBus();
			}
			m_pDsp = pDsp;
		}
	}
	else // removing DSP
	{
		this->m_isDspActive = false;
		if(m_pDsp) // Tell the previous DSP that it's getting disconnected from the bus
		{
			m_pDsp->DisconnectFromBus();
		}
		m_pDsp = 0;

	}
}

void MiniAuxBus::RemoveDSP(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniAuxBus::RemoveDSP", vox::VoxThread::GetCurThreadId());

	m_needRemoveDsp = true;
}


//*** MiniMasterBus ***//


MiniMasterBus::MiniMasterBus()
{
}

MiniMasterBus::~MiniMasterBus()
{
	ScopeMutex sm(&m_mutex);

	// Input buses list should already been cleared at this point (from bus manager destruction)
	m_inputBuses.clear();
}

void MiniMasterBus::FillBuffer(s32* outBuffer, s32 nbSamples)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniMasterBus::FillBuffer", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	s32 totalSamples = nbSamples << 1;	// << 1 to include left and right channels.

	if(nbSamples > m_nbSamples)
	{
		// Delete current buffers
		if(m_pDryBuffer)
		{
			VOX_FREE(m_pDryBuffer);
		}

		if(m_pWetBuffer)
		{
			VOX_FREE(m_pWetBuffer);
		}
			
		// Allocate new buffers
		m_pDryBuffer = (s32*)VOX_ALLOC(sizeof(s32) * totalSamples);
		m_pWetBuffer = (s32*)VOX_ALLOC(sizeof(s32) * totalSamples);

		if(m_pDryBuffer && m_pWetBuffer)
		{
			m_nbSamples = nbSamples;
		}
		else
		{
			m_nbSamples = 0;
			nbSamples = 0;
		}
	}

	if(m_nbSamples > 0)
	{
		// Clear buffers
		memset(m_pDryBuffer, 0, totalSamples * sizeof(s32));
		memset(m_pWetBuffer, 0, totalSamples * sizeof(s32));

		// Get input from driver sources
		VOX_LIST<MinibusDataGeneratorInterface *, SAllocator<MinibusDataGeneratorInterface *> >::iterator generatorsIt = m_dataGenerators.begin();
		VOX_LIST<MinibusDataGeneratorInterface *, SAllocator<MinibusDataGeneratorInterface *> >::iterator generatorsEnd = m_dataGenerators.end();

		for(; generatorsIt != generatorsEnd; generatorsIt++)
		{
			(*generatorsIt)->GetData(m_pDryBuffer, nbSamples, s_driverSampleRate);
		}

		// Get input from auxiliary buses
		VOX_LIST<MiniAuxBus*, SAllocator<MiniAuxBus*> >::iterator busesIt = m_inputBuses.begin();
		VOX_LIST<MiniAuxBus*, SAllocator<MiniAuxBus*> >::iterator busesEnd = m_inputBuses.end();
			
		for(; busesIt != busesEnd; busesIt++)
		{
			(*busesIt)->FillBuffer(m_pDryBuffer, m_pWetBuffer, nbSamples);
		}

		// Mix dry and wet buffers into outBuffer
		s32 *outBufferCursor = outBuffer;
		s32 *dryBufferCursor = m_pDryBuffer;
		s32 *wetBufferCursor = m_pWetBuffer;
		for(s32 i = 0; i < nbSamples; i++)
		{
			// Left channel
			*outBufferCursor = *dryBufferCursor + *wetBufferCursor;
			outBufferCursor++;
			dryBufferCursor++;
			wetBufferCursor++;

			// Right channel
			*outBufferCursor = *dryBufferCursor + *wetBufferCursor;
			outBufferCursor++;
			dryBufferCursor++;
			wetBufferCursor++;
		}
	}
}

void MiniMasterBus::RegisterInputBus(MiniAuxBus *pAuxiliaryBus)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniMasterBus::RegisterInputBus", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	m_inputBuses.push_back(pAuxiliaryBus);
}

void MiniMasterBus::UnregisterInputBus(MiniAuxBus *pAuxiliaryBus)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniMasterBus::UnregisterInputBus", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	// Get input from driver sources
	VOX_LIST<MiniAuxBus*, SAllocator<MiniAuxBus*> >::iterator it = m_inputBuses.begin();
	VOX_LIST<MiniAuxBus*, SAllocator<MiniAuxBus*> >::iterator end = m_inputBuses.end();
			
	for(; it != end; it++)
	{
		if(*it == pAuxiliaryBus)
		{
			m_inputBuses.erase(it);
			return;
		}
	}

	VOX_DELETE((MiniAuxBus*) pAuxiliaryBus);
}


//*** MiniBusManager ***//

MiniBusManager* MiniBusManager::s_pInstance = 0;
Mutex MiniBusManager::s_busManagerMutex;
bool MiniBusManager::s_isActive = false;

MiniBusManager* MiniBusManager::GetInstance()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::GetInstance", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&s_busManagerMutex);

	if(!s_pInstance)
	{
		s_pInstance = VOX_NEW MiniBusManager();
		if(!s_isActive)
		{
			VOX_DELETE(s_pInstance);
			s_pInstance = 0;
			VOX_WARNING_LEVEL_2("%s", "Could not create minibus manager");
		}
	}

	return s_pInstance;
}


void MiniBusManager::ReleaseInstance()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::ReleaseInstance", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&s_busManagerMutex);
	
	if(s_pInstance)
	{
		VOX_DELETE(s_pInstance);
	}
	s_pInstance = 0;
}

MiniBusManager::MiniBusManager()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::MiniBusManager", vox::VoxThread::GetCurThreadId());

	// Create master bus
	m_pMasterBus = VOX_NEW MiniMasterBus();

	if(m_pMasterBus)
	{
		m_pMasterBus->SetId(VOX_MINIBUS_MASTER);

		// Create auxiliary buses
		MiniAuxBus *pBus = (MiniAuxBus*) VOX_NEW MiniAuxBus();
		if(pBus)
		{
			pBus->SetId(VOX_MINIBUS_AUX1);
			m_pMasterBus->RegisterInputBus(pBus);
		}
		else
		{
			VOX_WARNING_LEVEL_2("%s", "Could not create auxiliary bus 1");
		}

		// Occupy a vector slot even if bus is not created (so that AUX1 and AUX2 are respectively in slots 0 and 1)
		m_auxBuses.push_back(pBus);

		pBus = (MiniAuxBus*) VOX_NEW MiniAuxBus();
		if(pBus)
		{
			pBus->SetId(VOX_MINIBUS_AUX2);
			m_pMasterBus->RegisterInputBus(pBus);
		}
		else
		{
			VOX_WARNING_LEVEL_2("%s", "Could not create auxiliary bus 2");
		}

		// Occupy a vector slot even if bus is not created (so that AUX1 and AUX2 are respectively in slots 0 and 1)
		m_auxBuses.push_back(pBus);

		s_isActive = true;
	}
}

MiniBusManager::~MiniBusManager()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::~MiniBusManager", vox::VoxThread::GetCurThreadId());

	// Unregister auxiliary bus AUX1 from master bus and release it.
	if(m_auxBuses[0])
	{
		m_pMasterBus->UnregisterInputBus(m_auxBuses[0]);
		VOX_DELETE(m_auxBuses[0]);
		m_auxBuses[0] = 0;
	}

	// Unregister auxiliary bus AUX2 from master bus and release it.
	if(m_auxBuses[1])
	{
		m_pMasterBus->UnregisterInputBus(m_auxBuses[1]);
		VOX_DELETE(m_auxBuses[1]);
		m_auxBuses[1] = 0;
	}

	// Clear auxiliary bus list
	m_auxBuses.clear();
	
	// Release master bus
	VOX_DELETE(m_pMasterBus);
	m_pMasterBus = 0;
}


MiniMasterBus * MiniBusManager::GetMasterBus(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::GetMasterBus", vox::VoxThread::GetCurThreadId());

	return m_pMasterBus;
}

void MiniBusManager::AttachDataGeneratorToBus(s32 busId, MinibusDataGeneratorInterface *pDataGenerator)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::AttachDataGeneratorToBus", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&s_busManagerMutex);

	// Unregister source from any other bus
	_DetachDataGeneratorFromBus(pDataGenerator);

	if(m_auxBuses[0] && busId == VOX_MINIBUS_AUX1)
	{
		m_auxBuses[0]->RegisterDataGenerator(pDataGenerator);
	}
	else if(m_auxBuses[1] && busId == VOX_MINIBUS_AUX2)
	{
		m_auxBuses[1]->RegisterDataGenerator(pDataGenerator);
	}
	else
	{
		// Register source with master bus
		m_pMasterBus->RegisterDataGenerator(pDataGenerator);
	}
}

void MiniBusManager::_DetachDataGeneratorFromBus(MinibusDataGeneratorInterface *pDataGenerator)
{
	// Since bus manager doesn't know to which bus source is attached, try them all.
	if(!m_pMasterBus->UnregisterDataGenerator(pDataGenerator))
	{
		if(m_auxBuses[0])
		{
			if(!m_auxBuses[0]->UnregisterDataGenerator(pDataGenerator))
			{
				if(m_auxBuses[1])
					m_auxBuses[1]->UnregisterDataGenerator(pDataGenerator);
			}
		}
	}
}

void MiniBusManager::DetachDataGeneratorFromBus(MinibusDataGeneratorInterface *pDataGenerator)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::DetachDataGeneratorFromBus", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&s_busManagerMutex);

	_DetachDataGeneratorFromBus(pDataGenerator);
}

bool MiniBusManager::AttachDSP(const char *busName, CustomDSP *dsp)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::AttachDSP", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&s_busManagerMutex);

	if(m_auxBuses[0] && STRICMP(busName, "AUX1") == 0)
	{	
		if(m_auxBuses[1] && dsp)
		{
			if(m_auxBuses[1]->GetDSP() == dsp)
			{
				VOX_WARNING_LEVEL_3("Can't set same DSP on multiple buses! (on bus %s)", busName);
				return false;
			}
		}
		m_auxBuses[0]->SetDSP(dsp);
		return true;
	}
	else if(m_auxBuses[1] && STRICMP(busName, "AUX2") == 0)
	{
		if(m_auxBuses[0] && dsp)
		{
			if(m_auxBuses[0]->GetDSP() == dsp)
			{
				VOX_WARNING_LEVEL_3("Can't set same DSP on multiple buses! (on bus %s)", busName);
				return false;
			}
		}
		m_auxBuses[1]->SetDSP(dsp);
		return true;
	}
	else
	{
		VOX_WARNING_LEVEL_4("%s", "Trying to set DSP on invalid bus");
		return false;
	}
		
}


void MiniBusManager::SetBusRoutingVolumeChange(BusRoutingChange* parameters)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::SetBusRoutingVolumeChange", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&s_busManagerMutex);

	switch(parameters->RoutingType)
	{
		case VoxDSPGeneralParameter::k_nWetAndDry:
		{
			if(m_auxBuses[0] && STRICMP(parameters->BusFrom, "AUX1") == 0)
			{
				m_auxBuses[0]->SetVolume(VoxDSPGeneralParameter::k_nDry, parameters->DryVolume, parameters->FadeTime);
				m_auxBuses[0]->SetVolume(VoxDSPGeneralParameter::k_nWet, parameters->WetVolume, parameters->FadeTime);
			}
			else if(m_auxBuses[1] && STRICMP(parameters->BusFrom, "AUX2") == 0)
			{
				m_auxBuses[1]->SetVolume(VoxDSPGeneralParameter::k_nDry, parameters->DryVolume, parameters->FadeTime);
				m_auxBuses[1]->SetVolume(VoxDSPGeneralParameter::k_nWet, parameters->WetVolume, parameters->FadeTime);
			}
			else
			{
				VOX_WARNING_LEVEL_4("%s", "Trying to set routing volume to invalid or unused bus");
			}
			break;
		}
		case VoxDSPGeneralParameter::k_nWet:
		{
			if(m_auxBuses[0] && STRICMP(parameters->BusFrom, "AUX1") == 0)
			{
				m_auxBuses[0]->SetVolume(VoxDSPGeneralParameter::k_nWet, parameters->WetVolume, parameters->FadeTime);
			}
			else if(m_auxBuses[1] && STRICMP(parameters->BusFrom, "AUX2") == 0)
			{
				m_auxBuses[1]->SetVolume(VoxDSPGeneralParameter::k_nWet, parameters->WetVolume, parameters->FadeTime);
			}
			else
			{
				VOX_WARNING_LEVEL_4("%s", "Trying to set routing volume to invalid or unused bus");
			}
			break;
		}
		case VoxDSPGeneralParameter::k_nDry:
		{
			if(m_auxBuses[0] && STRICMP(parameters->BusFrom, "AUX1") == 0)
			{
				m_auxBuses[0]->SetVolume(VoxDSPGeneralParameter::k_nDry, parameters->DryVolume, parameters->FadeTime);
			}
			else if(m_auxBuses[1] && STRICMP(parameters->BusFrom, "AUX2") == 0)
			{
				m_auxBuses[1]->SetVolume(VoxDSPGeneralParameter::k_nDry, parameters->DryVolume, parameters->FadeTime);
			}
			else
			{
				VOX_WARNING_LEVEL_4("%s", "Trying to set routing volume to invalid or unused bus");
			}
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("Minibus system doesn't support property %d", parameters->RoutingType);
			break;
		}
	}
}

void MiniBusManager::SetDriverSampleRate(s32 sampleRate)
{
	// Provide all minibus (master and aux) with driver sample rate
	MiniBus::SetDriverSampleRate(sampleRate);
}

void MiniBusManager::Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MiniBusManager::Update", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&s_busManagerMutex);

	// Update auxiliary buses
	if(m_auxBuses[0])
		m_auxBuses[0]->Update(dt);

	if(m_auxBuses[1])
		m_auxBuses[1]->Update(dt);
}

} // namespace vox


