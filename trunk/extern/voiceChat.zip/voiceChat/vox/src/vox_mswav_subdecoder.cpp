
#include "StdAfx.h"
#include "vox_mswav_subdecoder.h"

namespace vox
{

void VoxMSWavSubDecoder::GoToNextDataChunk()
{
	if(!(m_pWaveChunks && m_pStreamCursor))
		return;

	if(!m_currentDataNode)
	{
		m_currentDataNode = m_pWaveChunks->m_dataNodes;
	}
	else
	{
		if(m_currentDataNode->m_next)
		{
			m_currentDataNode = m_currentDataNode->m_next;
		}
		else
		{
			m_currentDataNode = 0;
			m_pWaveChunks->m_dataHeader.chunkSize = 0;
			return;
		}
	}

	m_pStreamCursor->Seek(m_currentDataNode->m_fileOffset + k_nChunkHeaderSize, ORIGIN_START);
	m_pWaveChunks->m_dataHeader.chunkSize = m_currentDataNode->m_byteSize;
	m_currentChunkPosition = 0;
}
}


