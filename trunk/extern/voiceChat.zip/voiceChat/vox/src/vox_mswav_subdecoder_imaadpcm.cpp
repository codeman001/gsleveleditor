
#include "StdAfx.h"
#include "vox_mswav_subdecoder_imaadpcm.h"
#include "AdpcmDecoder.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include  <cstring>
#include "vox_profiler.h"

// For NEON availability detection
#if VOX_NEON_DECODER_IMA
#include "vox_detect_neon.h"
#endif

namespace vox
{
#define MAX_BLOCK_ALIGN 2048

VoxMSWavSubDecoderIMAADPCM::VoxMSWavSubDecoderIMAADPCM(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks)
: VoxMSWavSubDecoder(pStreamCursor,pWaveChunks)
, m_readBuffer(0)
, m_totalDataBytesRead(0)
, m_samplesInBuffer(0)
, m_samplesInBufferConsumed(0)
, m_totalSampleDecoded(0)
, m_blockReadBuffer(0)
, m_extraReadBuffer(0)
, m_readBufferSpecialAlignment(0)
, m_extraReadBufferSpecialAlignment(0)
, m_extraBlockReadBuffer(0)
, m_samplesInExtraBuffer(0)
, m_samplesInExtraBufferConsumed(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::VoxMSWavSubDecoderIMAADPCM", vox::VoxThread::GetCurThreadId());

	VOX_ASSERT(pStreamCursor);
	
	GoToNextDataChunk();
	m_dataStartPosition = m_pStreamCursor->Tell();

	m_readBuffer = (u8*)VOX_ALLOC(sizeof(u8) * (pWaveChunks->m_formatHeader.blockAlign * 4));

	if(!m_readBuffer)
	{
		m_trackParams.Reset();
		return;
	}

	m_blockReadBuffer = (u8*)VOX_ALLOC(pWaveChunks->m_formatHeader.blockAlign);

	if(!m_blockReadBuffer)
	{
		VOX_FREE(m_readBuffer);
		m_readBuffer = 0;
		m_trackParams.Reset();
		return;
	}

	s32 preambleSize = sizeof(AdpcmState)*pWaveChunks->m_formatHeader.numChannels;

	if(((pWaveChunks->m_formatHeader.blockAlign - preambleSize) << 1) % pWaveChunks->m_formatHeader.numChannels != 0)
	{
		VOX_WARNING_LEVEL_3("Block size of adpcm is not compatible with %d channels, may cause seek issues", pWaveChunks->m_formatHeader.numChannels);
	}

	if(pWaveChunks->m_formatHeader.numChannels != 0)
	{
		m_samplesPerBlock = ((pWaveChunks->m_formatHeader.blockAlign - preambleSize) << 1) / pWaveChunks->m_formatHeader.numChannels  + 1;
	}
	else
	{
		m_trackParams.Reset();
		return;
	}

	m_trackParams.bitsPerSample = 16;						// Intended to be nb of decoded bits per sample
	m_trackParams.numChannels = pWaveChunks->m_formatHeader.numChannels;
	m_trackParams.samplingRate = pWaveChunks->m_formatHeader.sampleRate;
	m_trackParams.numSamples = pWaveChunks->m_factHeader.factData;

	if(m_trackParams.numChannels > 8)
		m_trackParams.Reset();

	m_usingNeonDecoder = false;
#if VOX_NEON_DECODER_IMA
	if(neonInstructionsPresent() && m_trackParams.numChannels == 2)
		m_usingNeonDecoder = true;
	if(neonInstructionsPresent() && m_trackParams.numChannels == 1)
		m_usingNeonDecoder = true;

	if(m_usingNeonDecoder && m_trackParams.numChannels == 2)
		m_readBufferSpecialAlignment = m_readBuffer + 4;
	else if(m_usingNeonDecoder && m_trackParams.numChannels == 1)
	{
		m_extraReadBuffer = (u8*)VOX_ALLOC(sizeof(u8) * (pWaveChunks->m_formatHeader.blockAlign * 4));
		m_extraBlockReadBuffer = (u8*)VOX_ALLOC(pWaveChunks->m_formatHeader.blockAlign);

		if(!m_extraReadBuffer || !m_extraBlockReadBuffer)
		{
			m_usingNeonDecoder = false;
			VOX_FREE(m_extraReadBuffer);
			VOX_FREE(m_extraBlockReadBuffer);
			m_extraReadBuffer = 0;
			m_extraBlockReadBuffer = 0;

		}
		else
		{
			m_readBufferSpecialAlignment = m_readBuffer + 2;
			m_extraReadBufferSpecialAlignment = m_extraReadBuffer + 2;
		}
	}
#endif

}

VoxMSWavSubDecoderIMAADPCM::~VoxMSWavSubDecoderIMAADPCM()
{
	VOX_FREE(m_readBuffer);
	VOX_FREE(m_blockReadBuffer);
#if VOX_NEON_DECODER_IMA
	VOX_FREE(m_extraReadBuffer);
	VOX_FREE(m_extraBlockReadBuffer);
#endif
}


s32 VoxMSWavSubDecoderIMAADPCM::Seek(u32 sample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::Seek", vox::VoxThread::GetCurThreadId());
	if(sample > m_trackParams.numSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}

	if(sample < m_trackParams.numSamples)
	{		
		u32 blockIndex = sample / m_samplesPerBlock;

		// Consider all blocks preceding the one containing the requested sample as read.
		m_totalDataBytesRead = blockIndex * m_pWaveChunks->m_formatHeader.blockAlign;

		// Seek to start of block containing requested sample.
		m_pStreamCursor->Seek(m_dataStartPosition + m_totalDataBytesRead);
	
		u32 nbSamplesInPrecedingBlocks = blockIndex * m_samplesPerBlock;

		// Consider all samples before the one requested as consumed.
		m_samplesInBufferConsumed = sample - nbSamplesInPrecedingBlocks;
		m_samplesInExtraBufferConsumed = 0;

		// Set all samples before the block containing the requested sample as decoded
		m_totalSampleDecoded = nbSamplesInPrecedingBlocks;
		
		// Decode the whole block containing the requested sample.
#if VOX_NEON_DECODER_IMA
		if(m_usingNeonDecoder && m_trackParams.numChannels == 2)
			m_samplesInBuffer = DecodeBlockNeonStereo((void*)m_readBufferSpecialAlignment);
		else if(m_usingNeonDecoder && m_trackParams.numChannels == 1)
			DecodeBlockNeonMono(
				(void*)m_readBufferSpecialAlignment,
				(void*)m_extraReadBufferSpecialAlignment,
				&m_samplesInBuffer,
				&m_samplesInExtraBuffer);
		else
			m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);
#else
		m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);
#endif

		// Set all consumed samples from current block as decoded.
		m_totalSampleDecoded += m_samplesInBufferConsumed;

		return 0;
	}
	return -1;
}


bool VoxMSWavSubDecoderIMAADPCM::HasData()
{
	if(m_pStreamCursor && !m_isDecoderInError)
	{

#if VOX_NEON_DECODER_IMA
		if(m_loop && ((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer && m_samplesInExtraBufferConsumed == m_samplesInExtraBuffer))))
		{
			Seek(0);
		}
		return !((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer && m_samplesInExtraBufferConsumed == m_samplesInExtraBuffer))) ;

#else // not using VOX_NEON_DECODER_IMA
		if(m_loop && ((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))))
		{
			Seek(0);
		}
		return !((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))) ;
#endif // VOX_NEON_DECODER_IMA

	}
	return false;
}

// outbuf must be of block align * 4 bytes
// return nbSample (interleaved)
s32 VoxMSWavSubDecoderIMAADPCM::DecodeBlock(void* outbuf)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::DecodeBlock", vox::VoxThread::GetCurThreadId());
	s32 readSize = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;

	u8* readBuffer = m_blockReadBuffer;

	readSize = m_pStreamCursor->Read(readBuffer, readSize);

	if(readSize <= 0)
		return 0;

	//Process Preamble

	// reinit our state
	AdpcmState * curState = (AdpcmState*)readBuffer;
	m_states[0] = *curState;
#if VOX_BIG_ENDIAN
	m_states[0].ConvertToBE();
#endif
	for(s32 i = 1; i < m_pWaveChunks->m_formatHeader.numChannels; i++)
	{
		++curState;
		m_states[i] = *curState;
#if VOX_BIG_ENDIAN
		m_states[i].ConvertToBE();
#endif
	}

	// prepare destination
	s16* dst[8];
	dst[0] = (s16*)outbuf;
	for(s32 i = 1; i < m_pWaveChunks->m_formatHeader.numChannels; i++)
	{
		dst[i] = dst[i-1] + 1;
	}

	u8* c = readBuffer;

	//Process data
	for(s32 i = 0; i < m_pWaveChunks->m_formatHeader.numChannels; i++)
	{
		*dst[i] = m_states[i].m_prevSample;
		dst[i] += m_pWaveChunks->m_formatHeader.numChannels;
	}

	// skip our read pointer over the block preambles
	s32 preambleSize = sizeof(AdpcmState) * m_pWaveChunks->m_formatHeader.numChannels;
	c += preambleSize;

	s32 nbSamples = 1;
	u32 data;
	for(s32 i = 0 ; i < (readSize - preambleSize);)
	{
		for(s32 j = 0; j < m_pWaveChunks->m_formatHeader.numChannels; j++)
		{
			data = (u8)c[0] + ((u8)c[1] << 8) + ((u8)c[2] << 16) + ((u8)c[3] << 24);
			AdpcmDecoder::DecodeAdpcm(data, &(m_states[j]), dst[j], m_pWaveChunks->m_formatHeader.numChannels, 8);
			dst[j] += 8*m_pWaveChunks->m_formatHeader.numChannels;
			i+=4;	
			c+=4;
		}
		nbSamples+=8;
	}

	m_totalDataBytesRead += readSize;

	if(m_totalSampleDecoded + nbSamples > m_trackParams.numSamples)
	{
		nbSamples = m_trackParams.numSamples - m_totalSampleDecoded;
	}

	return nbSamples;
}

#if VOX_NEON_DECODER_IMA


extern "C" int DecodeAdpcmNeonStereoAsm(s32 *params);
extern "C" int DecodeAdpcmNeonMonoAsm(s32 *params);


s32 VoxMSWavSubDecoderIMAADPCM::DecodeBlockNeonStereo(void* outbuf)
// Warning: output buffer must have a special memory alignment!
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::DecodeBlockNeonStereo", vox::VoxThread::GetCurThreadId());
	s32 readSize = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;

	u8* readBuffer = m_blockReadBuffer;

	readSize = m_pStreamCursor->Read(readBuffer, readSize);

	//Process Preamble

	// reinit our state
	AdpcmState * curState = (AdpcmState*)readBuffer;
	m_states[0] = curState[0];
	m_states[1] = curState[1];

	for(s32 i = 1; i < m_pWaveChunks->m_formatHeader.numChannels; i++)
	{
		++curState;
		m_states[i] = *curState;
	}


	// prepare destination
	s16* dst;
	dst = (s16*)outbuf;
	
	u8* c = readBuffer;

	//Process preamble extra sample
	dst[0]  = m_states[0].m_prevSample;
	dst[1]  = m_states[1].m_prevSample;
	dst += 2;

	// skip our read pointer over the block preambles
	s32 preambleSize = sizeof(AdpcmState) * 2;
	c += preambleSize;

	s32 nbSamples = 1;

	s32 neonLoopLength = (readSize - preambleSize);
	s32 neonParameters[8];

	neonParameters[0] = m_states[0].m_prevIndex;
	neonParameters[1] = m_states[1].m_prevIndex;
	neonParameters[2] = m_states[0].m_prevSample;
	neonParameters[3] = m_states[1].m_prevSample;
	neonParameters[4] = (s32)c;
	neonParameters[5] = (s32)dst;
	neonParameters[6] = (s32)(c + neonLoopLength);
	neonParameters[7] = (s32)AdpcmDecoder::cAdpcmNeonTable;

	DecodeAdpcmNeonStereoAsm(neonParameters);

	nbSamples += neonLoopLength;

	m_states[0].m_prevIndex  = neonParameters[0];
	m_states[1].m_prevIndex  = neonParameters[1];
	m_states[0].m_prevSample = neonParameters[2];
	m_states[1].m_prevSample = neonParameters[3];

	m_totalDataBytesRead += readSize;

	if(m_totalSampleDecoded + nbSamples > m_trackParams.numSamples)
	{
		nbSamples = m_trackParams.numSamples - m_totalSampleDecoded;
	}

	return nbSamples;

}



void VoxMSWavSubDecoderIMAADPCM::DecodeBlockNeonMono(void* outbuf1, void* outbuf2, s32 *samplesOut1, s32 *samplesOut2)
// Warning: output buffer must have a special memory alignment!
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::DecodeBlockNeonMono", vox::VoxThread::GetCurThreadId());

	s32 readSize = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;
	u8* readBuffer = m_blockReadBuffer;
	readSize = m_pStreamCursor->Read(readBuffer, readSize);
	m_totalDataBytesRead += readSize;

	s32 extraReadSize = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;
	u8* extraReadBuffer = m_extraBlockReadBuffer;
	extraReadSize = m_pStreamCursor->Read(extraReadBuffer, extraReadSize);
	m_totalDataBytesRead += extraReadSize;

	//Process Preambles

	// reinit our state
	AdpcmState * curState = (AdpcmState*)readBuffer;
	m_states[0] = *curState;
	curState = (AdpcmState*)extraReadBuffer;
	m_states[1] = *curState;
#if VOX_BIG_ENDIAN
#error Arm neon code cannot be big endian
#endif

	// prepare destination
	s16* dst[2];
	dst[0] = (s16*)outbuf1;
	dst[1] = (s16*)outbuf2;
	
	u8* c[2];
	c[0] = readBuffer;
	c[1] = extraReadBuffer;

	//Process preamble extra sample
	dst[0][0]  = m_states[0].m_prevSample;
	dst[1][0]  = m_states[1].m_prevSample;
	dst[0] += 1;
	dst[1] += 1;

	// skip our read pointer over the block preambles
	s32 preambleSize = sizeof(AdpcmState) * 1;
	c[0] += preambleSize;
	c[1] += preambleSize;

	s32 nbSamples[2];
	nbSamples[0] = 1;
	if(extraReadSize >= 4)
		nbSamples[1] = 1;
	else
		nbSamples[1] = 0;

	s32 neonLoopLength[2];
	neonLoopLength[0] = (readSize - preambleSize);
	neonLoopLength[1] = (extraReadSize - preambleSize);
	s32 neonParameters[10];

	if(neonLoopLength[1] >= 0) // Decode into two buffers
	{
		neonParameters[0] = m_states[0].m_prevIndex;
		neonParameters[1] = m_states[1].m_prevIndex;
		neonParameters[2] = m_states[0].m_prevSample;
		neonParameters[3] = m_states[1].m_prevSample;
		neonParameters[4] = (s32)c[0];
		neonParameters[5] = (s32)dst[0];
		neonParameters[6] = (s32)(c[0] + neonLoopLength[1]); // Always the shortest of the two
		neonParameters[7] = (s32)AdpcmDecoder::cAdpcmNeonTable;
		neonParameters[8] = (s32)c[1];
		neonParameters[9] = (s32)dst[1];

		DecodeAdpcmNeonMonoAsm(neonParameters);

		c[0] += neonLoopLength[1];
		dst[0] += neonLoopLength[1]*4;
		dst[1] += neonLoopLength[1]*4;

		neonLoopLength[0] -= neonLoopLength[1];
		nbSamples[0] += neonLoopLength[1]*2;
		nbSamples[1] += neonLoopLength[1]*2;

		m_states[0].m_prevIndex  = neonParameters[0];
		m_states[1].m_prevIndex  = neonParameters[1];
		m_states[0].m_prevSample = neonParameters[2];
		m_states[1].m_prevSample = neonParameters[3];
	}

	if(neonLoopLength[0] > 0)
	{
		neonParameters[0] = m_states[0].m_prevIndex;
		neonParameters[1] = m_states[0].m_prevIndex;
		neonParameters[2] = m_states[0].m_prevSample;
		neonParameters[3] = m_states[0].m_prevSample;
		neonParameters[4] = (s32)c[0];
		neonParameters[5] = (s32)dst[0];
		neonParameters[6] = (s32)(c[0] + neonLoopLength[0]);
		neonParameters[7] = (s32)AdpcmDecoder::cAdpcmNeonTable;
		neonParameters[8] = (s32)c[0];
		neonParameters[9] = (s32)dst[1];

		DecodeAdpcmNeonMonoAsm(neonParameters);

		nbSamples[0] += neonLoopLength[0]*2;

		m_states[0].m_prevIndex  = neonParameters[0];
		m_states[0].m_prevSample = neonParameters[2];

	}



	if(m_totalSampleDecoded + nbSamples[0] + nbSamples[1] > m_trackParams.numSamples)
	{
		if(m_totalSampleDecoded + nbSamples[0] > m_trackParams.numSamples)
		{
			nbSamples[0] = m_trackParams.numSamples - m_totalSampleDecoded;
			nbSamples[1] = 0;
		}
		else
		{
			nbSamples[1] = m_trackParams.numSamples - m_totalSampleDecoded - nbSamples[0];
		}
	}

	*samplesOut1 = nbSamples[0];
	*samplesOut2 = nbSamples[1];

	return;

}

#endif


s32 VoxMSWavSubDecoderIMAADPCM::Decode(void* outbuf, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::Decode", vox::VoxThread::GetCurThreadId());
	s32 nbSamplesDesired = nbBytes / (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 sampleAvailable;
	s32 nbSamplesToCopy;

#if VOX_NEON_DECODER_IMA
	if(m_usingNeonDecoder && 
		(m_trackParams.numChannels == 2 || m_trackParams.numChannels == 1))
	{
		return DecodeNeon(outbuf, nbBytes);
	}
#endif

	while(nbSamples > 0)
	{
		// Get a new decoded block if all samples have been consumed.
		if(m_samplesInBufferConsumed == m_samplesInBuffer)
		{
			m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);
			m_samplesInBufferConsumed = 0;
		}

		if(m_samplesInBuffer <= 0)
		{
			m_isDecoderInError = true;
			break;
		}

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * m_trackParams.numChannels;

		// Calculate the number of samples available in the current decoded block.
		sampleAvailable = m_samplesInBuffer - m_samplesInBufferConsumed;

		// Calculate the number of samples to copy from the decoded block to the output buffer.
		nbSamplesToCopy = (sampleAvailable > nbSamples) ? nbSamples : sampleAvailable;

		memcpy(&((s16*) outbuf)[bufferoffset], &(((short*)m_readBuffer)[m_samplesInBufferConsumed * m_trackParams.numChannels]), nbSamplesToCopy * m_trackParams.numChannels * sizeof(s16));

		nbSamples -= nbSamplesToCopy;
		m_samplesInBufferConsumed += nbSamplesToCopy;
		m_totalSampleDecoded += nbSamplesToCopy;

		if((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))) 
		{
			if(!(m_totalSampleDecoded >= m_trackParams.numSamples))
			{
				VOX_WARNING_LEVEL_4("Reached end of file but still waiting for samples, missing : %d", m_trackParams.numSamples - m_totalSampleDecoded);
			}
			if(!m_loop)
			{
				break;
			}
			else // If looping, seek to beginning of stream.
			{
				if(Seek(0) != 0)				
					break;		//could not go back to beginning
			}
		}
	}
	
	return (nbSamplesDesired - nbSamples)*( m_trackParams.numChannels * (m_trackParams.bitsPerSample>>3));
}

#if VOX_NEON_DECODER_IMA
s32 VoxMSWavSubDecoderIMAADPCM::DecodeNeon(void* outbuf, s32 nbBytes)
{

	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::DecodeNeon", vox::VoxThread::GetCurThreadId());
	s32 nbSamplesDesired = nbBytes / (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 sampleAvailable;
	s32 nbSamplesToCopy;

	while(nbSamples > 0)
	{
		if(m_samplesInBufferConsumed == m_samplesInBuffer
			&& m_samplesInExtraBufferConsumed == m_samplesInExtraBuffer)
		{
			if(m_trackParams.numChannels == 2)
				m_samplesInBuffer = DecodeBlockNeonStereo((void*)m_readBufferSpecialAlignment);
			else 
				DecodeBlockNeonMono((void*)m_readBufferSpecialAlignment,(void*)m_extraReadBufferSpecialAlignment,
					&m_samplesInBuffer,&m_samplesInExtraBuffer);
			
			m_samplesInBufferConsumed = 0;
			m_samplesInExtraBufferConsumed = 0;
		}			

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * m_trackParams.numChannels;

		// Calculate the number of samples available in the current decoded block.
		if(m_samplesInBufferConsumed != m_samplesInBuffer)
		{
			sampleAvailable = m_samplesInBuffer - m_samplesInBufferConsumed;

			nbSamplesToCopy = (sampleAvailable > nbSamples) ? nbSamples : sampleAvailable;

			memcpy(&((s16*) outbuf)[bufferoffset], 
				&(((short*)m_readBufferSpecialAlignment)[m_samplesInBufferConsumed * m_trackParams.numChannels]),
				nbSamplesToCopy * m_trackParams.numChannels * sizeof(s16));

			nbSamples -= nbSamplesToCopy;
			m_samplesInBufferConsumed += nbSamplesToCopy;
			m_totalSampleDecoded += nbSamplesToCopy;
		}
		else
		{
			sampleAvailable = m_samplesInExtraBuffer - m_samplesInExtraBufferConsumed;

			nbSamplesToCopy = (sampleAvailable > nbSamples) ? nbSamples : sampleAvailable;

			memcpy(&((s16*) outbuf)[bufferoffset],
				&(((short*)m_extraReadBufferSpecialAlignment)[m_samplesInExtraBufferConsumed * m_trackParams.numChannels]),
				nbSamplesToCopy * m_trackParams.numChannels * sizeof(s16));

			nbSamples -= nbSamplesToCopy;
			m_samplesInExtraBufferConsumed += nbSamplesToCopy;
			m_totalSampleDecoded += nbSamplesToCopy;
		}
		
		if((m_totalSampleDecoded >= m_trackParams.numSamples) 
			|| ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) 
			&& (m_samplesInBufferConsumed == m_samplesInBuffer 
			&& m_samplesInExtraBufferConsumed == m_samplesInExtraBuffer))) 
		{
			if(!(m_totalSampleDecoded >= m_trackParams.numSamples))
			{
				VOX_WARNING_LEVEL_4("Reached end of file but still waiting for samples, missing : %d", m_trackParams.numSamples - m_totalSampleDecoded);
			}
			if(!m_loop)
			{
				break;
			}
			else // If looping, seek to beginning of stream.
			{
				if(Seek(0) != 0)				
					break;		//could not go back to beginning
			}
		}
	}
	
	return (nbSamplesDesired - nbSamples)*( m_trackParams.numChannels * (m_trackParams.bitsPerSample>>3));

}
#endif // VOX_NEON_DECODER_IMA

}


