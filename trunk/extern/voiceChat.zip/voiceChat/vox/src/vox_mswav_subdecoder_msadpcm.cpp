
#include "StdAfx.h"
#include "vox_mswav_subdecoder_msadpcm.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include  <cstring>
#include "vox_profiler.h"

// For NEON availability detection
#if VOX_NEON_DECODER_MS
#include "vox_detect_neon.h"
#endif

namespace vox
{

VoxMSWavSubDecoderMSADPCM::VoxMSWavSubDecoderMSADPCM(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks)
: VoxMSWavSubDecoder(pStreamCursor,pWaveChunks)
, m_readBuffer(0)
, m_totalDataBytesRead(0)
, m_dataStartPosition(0)
, m_samplesInBuffer(0)
, m_samplesInBufferConsumed(0)
, m_totalSampleDecoded(0)
, m_blockReadBuffer(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::VoxMSWavSubDecoderMSADPCM", vox::VoxThread::GetCurThreadId());

	#if VOX_BIG_ENDIAN
		VOX_WARNING_LEVEL_3("%s", "MS-ADPCM files are not supported on big-endian platforms");
		m_trackParams.Reset();
		return;
	#endif
	VOX_ASSERT(pStreamCursor);
	
	// Get the extended bytes from fmt chunk
	m_pStreamCursor->Seek(k_nRiffChunkSize + k_nFmtChunkSize, ORIGIN_START);
	u32 nbFmtExtraBytes = pWaveChunks->m_formatHeader.chunkDataSize - (k_nFmtChunkSize - k_nChunkHeaderSize);
	m_pStreamCursor->Read((u8*)&m_fmtExtendedInfos, nbFmtExtraBytes);

	GoToNextDataChunk();
	m_dataStartPosition = m_pStreamCursor->Tell();

	m_trackParams.bitsPerSample = 16;						// Intended to be nb of decoded bits per sample
	m_trackParams.numChannels = pWaveChunks->m_formatHeader.numChannels;
	m_trackParams.samplingRate = pWaveChunks->m_formatHeader.sampleRate;
	m_trackParams.numSamples = pWaveChunks->m_factHeader.factData;

	m_usingNeonDecoder = false;
#if VOX_NEON_DECODER_MS
	if(neonInstructionsPresent() && m_trackParams.numChannels == 2)
		m_usingNeonDecoder = true;
	if(neonInstructionsPresent() && m_trackParams.numChannels == 1)
		m_usingNeonDecoder = true;
#endif

	if(m_trackParams.numChannels == 2 && m_usingNeonDecoder)
		m_readBuffer = (u8*)VOX_ALLOC(sizeof(u8) * (pWaveChunks->m_formatHeader.blockAlign * 4) * 2);
	else if(m_trackParams.numChannels == 1 && m_usingNeonDecoder)
		m_readBuffer = (u8*)VOX_ALLOC(sizeof(u8) * (pWaveChunks->m_formatHeader.blockAlign * 4) * 4);
	else
		m_readBuffer = (u8*)VOX_ALLOC(sizeof(u8) * (pWaveChunks->m_formatHeader.blockAlign * 4));

	if(!m_readBuffer)
	{
		m_trackParams.Reset();
		return;
	}

	if(m_trackParams.numChannels == 2 && m_usingNeonDecoder)
		m_blockReadBuffer = (u8*)VOX_ALLOC(pWaveChunks->m_formatHeader.blockAlign * 2);
	else if (m_trackParams.numChannels == 1 && m_usingNeonDecoder)
		m_blockReadBuffer = (u8*)VOX_ALLOC(pWaveChunks->m_formatHeader.blockAlign * 4);
	else
		m_blockReadBuffer = (u8*)VOX_ALLOC(pWaveChunks->m_formatHeader.blockAlign);

	if(!m_blockReadBuffer)
	{
		VOX_FREE(m_readBuffer);
		m_readBuffer = 0;
		m_trackParams.Reset();
		return;
	}


	if(m_trackParams.numChannels <= 0 || m_trackParams.numChannels > 2)
	{
		VOX_WARNING_LEVEL_3("%s", "Only mono and stereo files are presently supported for MS-ADPCM format");
		m_trackParams.Reset();
		return;
	}

	s32 preambleSize = MS_ADPCM_MONO_HEADER_SIZE * pWaveChunks->m_formatHeader.numChannels;

	if(((pWaveChunks->m_formatHeader.blockAlign - preambleSize) << 1) % pWaveChunks->m_formatHeader.numChannels != 0)
	{
		VOX_WARNING_LEVEL_3("Block size of adpcm is not compatible with %d channels, may cause seek issues", pWaveChunks->m_formatHeader.numChannels);
	}
}

VoxMSWavSubDecoderMSADPCM::~VoxMSWavSubDecoderMSADPCM()
{
	VOX_FREE(m_readBuffer);
	VOX_FREE(m_blockReadBuffer);
}


s32 VoxMSWavSubDecoderMSADPCM::Seek(u32 sample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::Seek", vox::VoxThread::GetCurThreadId());
	if(sample > m_trackParams.numSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}

	if(sample < m_trackParams.numSamples)
	{
		u32 blockIndex = sample / m_fmtExtendedInfos.m_samplesPerBlock;

		// Consider all blocks preceding the one containing the requested sample as read.
		m_totalDataBytesRead = blockIndex * m_pWaveChunks->m_formatHeader.blockAlign;

		// Seek to start of block containing requested sample.
		m_pStreamCursor->Seek(m_dataStartPosition + m_totalDataBytesRead);
	
		u32 nbSamplesInPrecedingBlocks = blockIndex * m_fmtExtendedInfos.m_samplesPerBlock;

		// Consider all samples before the one requested as consumed.
		m_samplesInBufferConsumed = sample - nbSamplesInPrecedingBlocks;

		// Set all samples before the block containing the requested sample as decoded
		m_totalSampleDecoded = nbSamplesInPrecedingBlocks;
		
		// Decode the whole block containing the requested sample.
#if VOX_NEON_DECODER_MS
		if(m_trackParams.numChannels == 2 && m_usingNeonDecoder)
			m_samplesInBuffer = DecodeBlockNeonStereo((void*)m_readBuffer);
		else if(m_trackParams.numChannels == 1 && m_usingNeonDecoder)
			m_samplesInBuffer = DecodeBlockNeonMono((void*)m_readBuffer);
		else
#endif
			m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);

		// Set all consumed samples from current block as decoded.
		m_totalSampleDecoded += m_samplesInBufferConsumed;

		return 0;
	}
	return -1;
}



bool VoxMSWavSubDecoderMSADPCM::HasData()
{
	if(m_pStreamCursor && !m_isDecoderInError)
	{
		if(m_loop && ((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))))
		{
			Seek(0);
		}
		return !((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))) ;
	}
	return false;
}


s32 VoxMSWavSubDecoderMSADPCM::DecodeBlock(void* outbuf)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::DecodeBlock", vox::VoxThread::GetCurThreadId());

	s32	i;
	s16	*coefficient[2];
	MsAdpcmState decoderState[2];
	MsAdpcmState *state[2];
	s16 *decoded = static_cast<s16*> (outbuf);

	s32 readSize = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;

	u8* readBuffer = m_blockReadBuffer;

	readSize = m_pStreamCursor->Read(readBuffer, readSize);

	if(readSize <= 0)
		return 0;

	state[0] = &decoderState[0];
	if (m_trackParams.numChannels == 2)
		state[1] = &decoderState[1];
	else
		state[1] = &decoderState[0];

	// Initialize predictor.
	for(i = 0; i < m_trackParams.numChannels; i++)
	{
		state[i]->predictor = *readBuffer++;
	}

	// Initialize delta.
	for(i = 0; i < m_trackParams.numChannels; i++)
	{
		state[i]->delta = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	// Initialize first two samples.
	for(i = 0; i < m_trackParams.numChannels; i++)
	{
		state[i]->sample1 = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	for (i = 0; i < m_trackParams.numChannels; i++)
	{
		state[i]->sample2 = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	coefficient[0] = m_fmtExtendedInfos.m_coefficients[state[0]->predictor];
	coefficient[1] = m_fmtExtendedInfos.m_coefficients[state[1]->predictor];

	for(i = 0; i < m_trackParams.numChannels; i++)
		*decoded++ = state[i]->sample2;

	for (i = 0; i < m_trackParams.numChannels; i++)
		*decoded++ = state[i]->sample1;

	s32 loopCount = readSize - 7 * m_pWaveChunks->m_formatHeader.numChannels;

	// The first two samples have already been 'decoded' in	the block header.
	s32 nbSamples = (loopCount << 1) / m_trackParams.numChannels + 2;

	while(loopCount > 0)
	{
		*decoded++ = DecodeSample(state[0], static_cast<u32> (*readBuffer >> 4), coefficient[0]);
		*decoded++ = DecodeSample(state[1], static_cast<u32> (*readBuffer & 0x0f), coefficient[1]);

		readBuffer++;
		loopCount--;
	}

	m_totalDataBytesRead += readSize;
	if(m_totalSampleDecoded + nbSamples > m_trackParams.numSamples)
	{
		nbSamples = m_trackParams.numSamples - m_totalSampleDecoded;
	}

	return nbSamples;
}

#if VOX_NEON_DECODER_MS





extern "C" int DecodeMsAdpcmNeonStereoAsm(s32 *params);
extern "C" int DecodeMsAdpcmNeonMonoAsm(s32 *params);

s32 VoxMSWavSubDecoderMSADPCM::DecodeBlockNeonStereo(void* outbuf)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::DecodeBlockNeonStereo", vox::VoxThread::GetCurThreadId());


	s16	*coefficient[4];
	MsAdpcmState decoderState[4];
	MsAdpcmState *state[4];

	s16 *decoded1 = static_cast<s16*> (outbuf);
	s16 *decoded2 = decoded1 + m_fmtExtendedInfos.m_samplesPerBlock*2;

	s32 readSize = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;
	u8* readBuffer = m_blockReadBuffer;
	readSize = m_pStreamCursor->Read(readBuffer, readSize);
	

	s32 readSize2 = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;
	u8* readBuffer2 = m_blockReadBuffer + m_pWaveChunks->m_formatHeader.blockAlign;
	readSize2 = m_pStreamCursor->Read(readBuffer2, readSize2);



	state[0] = &decoderState[0];
	state[1] = &decoderState[1];
	state[2] = &decoderState[2];
	state[3] = &decoderState[3];

	state[0]->predictor = *readBuffer++;
	state[1]->predictor = *readBuffer++;
	state[2]->predictor = *readBuffer2++;
	state[3]->predictor = *readBuffer2++;

	state[0]->delta = (readBuffer[1] << 8) | readBuffer[0];
	readBuffer += sizeof(u16);
	state[1]->delta = (readBuffer[1] << 8) | readBuffer[0];
	readBuffer += sizeof(u16);
	state[2]->delta = (readBuffer2[1] << 8) | readBuffer2[0];
	readBuffer2 += sizeof(u16);
	state[3]->delta = (readBuffer2[1] << 8) | readBuffer2[0];
	readBuffer2 += sizeof(u16);

	state[0]->sample1 = (readBuffer[1] << 8) | readBuffer[0];
	readBuffer += sizeof(u16);
	state[1]->sample1 = (readBuffer[1] << 8) | readBuffer[0];
	readBuffer += sizeof(u16);
	state[2]->sample1 = (readBuffer2[1] << 8) | readBuffer2[0];
	readBuffer2 += sizeof(u16);
	state[3]->sample1 = (readBuffer2[1] << 8) | readBuffer2[0];
	readBuffer2 += sizeof(u16);

	state[0]->sample2 = (readBuffer[1] << 8) | readBuffer[0];
	readBuffer += sizeof(u16);
	state[1]->sample2 = (readBuffer[1] << 8) | readBuffer[0];
	readBuffer += sizeof(u16);
	state[2]->sample2 = (readBuffer2[1] << 8) | readBuffer2[0];
	readBuffer2 += sizeof(u16);
	state[3]->sample2 = (readBuffer2[1] << 8) | readBuffer2[0];
	readBuffer2 += sizeof(u16);

	coefficient[0] = m_fmtExtendedInfos.m_coefficients[state[0]->predictor];
	coefficient[1] = m_fmtExtendedInfos.m_coefficients[state[1]->predictor];
	coefficient[2] = m_fmtExtendedInfos.m_coefficients[state[2]->predictor];
	coefficient[3] = m_fmtExtendedInfos.m_coefficients[state[3]->predictor];

	*decoded1++ = state[0]->sample2;
	*decoded1++ = state[1]->sample2;
	*decoded2++ = state[2]->sample2;
	*decoded2++ = state[3]->sample2;

	*decoded1++ = state[0]->sample1;
	*decoded1++ = state[1]->sample1;
	*decoded2++ = state[2]->sample1;
	*decoded2++ = state[3]->sample1;

	s32 loopCount[2];
	loopCount[0] = readSize - 14;
	if(readSize2 < 14)
		loopCount[1] = 0;
	else
		loopCount[1] = readSize2 - 14;

	// The first two samples have already been 'decoded' in	the block header.
	s32 nbSamples = (loopCount[0] << 1) / 2 + 2;
	if(readSize2 >= 14)
		nbSamples += (loopCount[1] << 1) / 2 + 2;

	while(loopCount[1] >= 1 && (((int)readBuffer2)&0x3) )
	{

		*decoded1++ = DecodeSample(state[0], static_cast<u32> (*readBuffer >> 4), coefficient[0]);
		*decoded1++ = DecodeSample(state[1], static_cast<u32> (*readBuffer & 0x0f), coefficient[1]);
		*decoded2++ = DecodeSample(state[2], static_cast<u32> (*readBuffer2 >> 4), coefficient[2]);
		*decoded2++ = DecodeSample(state[3], static_cast<u32> (*readBuffer2 & 0x0f), coefficient[3]);

		readBuffer++;
		readBuffer2++;
		loopCount[0]--;
		loopCount[1]--;
	}
	if(loopCount[1] >= 4)
	{
		int alignedBytes = (loopCount[1] >> 2) << 2;

		short neonState[20];

		neonState[0] = state[0]->sample1;
		neonState[1] = state[1]->sample1;
		neonState[2] = state[2]->sample1;
		neonState[3] = state[3]->sample1;
		neonState[4] = state[0]->sample2;
		neonState[5] = state[1]->sample2;
		neonState[6] = state[2]->sample2;
		neonState[7] = state[3]->sample2;
		neonState[8] = state[0]->delta;
		neonState[9] = state[1]->delta;
		neonState[10]= state[2]->delta;
		neonState[11]= state[3]->delta;
		neonState[12]= coefficient[0][0];
		neonState[13]= coefficient[1][0];
		neonState[14]= coefficient[2][0];
		neonState[15]= coefficient[3][0];
		neonState[16]= coefficient[0][1];
		neonState[17]= coefficient[1][1];
		neonState[18]= coefficient[2][1];
		neonState[19]= coefficient[3][1];

		int neonParams[7];

		neonParams[0] = (int)neonState;
		neonParams[1] = (int)adaptive16;
		neonParams[2] = (int)readBuffer;
		neonParams[3] = (int)decoded1;
		neonParams[4] = (int)(readBuffer + alignedBytes);
		neonParams[5] = (int)readBuffer2;
		neonParams[6] = (int)decoded2;

		DecodeMsAdpcmNeonStereoAsm(neonParams);

		state[0]->sample1 = neonState[0];
		state[1]->sample1 = neonState[1];
		state[2]->sample1 = neonState[2];
		state[3]->sample1 = neonState[3];
		state[0]->sample2 = neonState[4];
		state[1]->sample2 = neonState[5];
		state[2]->sample2 = neonState[6];
		state[3]->sample2 = neonState[7];
		state[0]->delta   = neonState[8];
		state[1]->delta   = neonState[9];
		state[2]->delta   = neonState[10];
		state[3]->delta   = neonState[11];

		readBuffer  += alignedBytes;
		readBuffer2 += alignedBytes;
		loopCount[0]-= alignedBytes;
		loopCount[1]-= alignedBytes;
		decoded1 += alignedBytes*2;
		decoded2 += alignedBytes*2;
	}
	while(loopCount[1] >= 1)
	{

		*decoded1++ = DecodeSample(state[0], static_cast<u32> (*readBuffer >> 4), coefficient[0]);
		*decoded1++ = DecodeSample(state[1], static_cast<u32> (*readBuffer & 0x0f), coefficient[1]);
		*decoded2++ = DecodeSample(state[2], static_cast<u32> (*readBuffer2 >> 4), coefficient[2]);
		*decoded2++ = DecodeSample(state[3], static_cast<u32> (*readBuffer2 & 0x0f), coefficient[3]);

		readBuffer++;
		readBuffer2++;
		loopCount[0]--;
		loopCount[1]--;
	}
	while(loopCount[0] >= 1 && (((int)readBuffer)&0x3)   )
	{
		*decoded1++ = DecodeSample(state[0], static_cast<u32> (*readBuffer >> 4), coefficient[0]);
		*decoded1++ = DecodeSample(state[1], static_cast<u32> (*readBuffer & 0x0f), coefficient[1]);

		readBuffer++;
		loopCount[0]--;
	}
	if(loopCount[0] >= 4)
	{
		int alignedBytes = (loopCount[0] >> 2) << 2;

		short neonState[20];

		neonState[0] = state[0]->sample1;
		neonState[1] = state[1]->sample1;
		neonState[2] = state[0]->sample1;
		neonState[3] = state[1]->sample1;
		neonState[4] = state[0]->sample2;
		neonState[5] = state[1]->sample2;
		neonState[6] = state[0]->sample2;
		neonState[7] = state[1]->sample2;
		neonState[8] = state[0]->delta;
		neonState[9] = state[1]->delta;
		neonState[10]= state[0]->delta;
		neonState[11]= state[1]->delta;
		neonState[12]= coefficient[0][0];
		neonState[13]= coefficient[1][0];
		neonState[14]= coefficient[0][0];
		neonState[15]= coefficient[1][0];
		neonState[16]= coefficient[0][1];
		neonState[17]= coefficient[1][1];
		neonState[18]= coefficient[0][1];
		neonState[19]= coefficient[1][1];

		int neonParams[7];

		neonParams[0] = (int)neonState;
		neonParams[1] = (int)adaptive16;
		neonParams[2] = (int)readBuffer;
		neonParams[3] = (int)decoded1;
		neonParams[4] = (int)(readBuffer + alignedBytes);
		neonParams[5] = (int)readBuffer;
		neonParams[6] = (int)decoded2;

		DecodeMsAdpcmNeonStereoAsm(neonParams);

		state[0]->sample1 = neonState[0];
		state[1]->sample1 = neonState[1];
		state[0]->sample2 = neonState[4];
		state[1]->sample2 = neonState[5];
		state[0]->delta   = neonState[8];
		state[1]->delta   = neonState[9];

		readBuffer  += alignedBytes;
		loopCount[0]-= alignedBytes;
		decoded1 += alignedBytes*2;
	}
	while(loopCount[0] >= 1)
	{
		*decoded1++ = DecodeSample(state[0], static_cast<u32> (*readBuffer >> 4), coefficient[0]);
		*decoded1++ = DecodeSample(state[1], static_cast<u32> (*readBuffer & 0x0f), coefficient[1]);

		readBuffer++;
		loopCount[0]--;
	}


	m_totalDataBytesRead += readSize;
	m_totalDataBytesRead += readSize2;
	
	if(m_totalSampleDecoded + nbSamples > m_trackParams.numSamples)
	{
		nbSamples = m_trackParams.numSamples - m_totalSampleDecoded;
	}

	return nbSamples;
}

s32 VoxMSWavSubDecoderMSADPCM::DecodeBlockNeonMono(void* outbuf)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::DecodeBlock", vox::VoxThread::GetCurThreadId());

	s32	i;
	s16	*coefficient[4];
	MsAdpcmState decoderState[4];
	MsAdpcmState *state[4];

	s16 *decoded[4];
	decoded[0] = static_cast<s16*> (outbuf);
	for(i=1; i<4; i++)
		decoded[i] = decoded[i-1] + m_fmtExtendedInfos.m_samplesPerBlock;

	s32 readSize[4];
	u8* readBuffer[4];
	
	readSize[0]   = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;
	readBuffer[0] = m_blockReadBuffer;
	readSize[0]   = m_pStreamCursor->Read(readBuffer[0], readSize[0]);
	m_totalDataBytesRead += readSize[0];

	for(i=1; i<4; i++)
	{
		readSize[i]   = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;
		readBuffer[i] = readBuffer[i-1] + m_pWaveChunks->m_formatHeader.blockAlign;
		readSize[i]   = m_pStreamCursor->Read(readBuffer[i], readSize[i]);
		m_totalDataBytesRead += readSize[i];
	}


	s32 loopCount[4];

	for(i=0; i<4; i++)
	{
		state[i] = &decoderState[i];

		state[i]->predictor = *readBuffer[i]++;
		coefficient[i] = m_fmtExtendedInfos.m_coefficients[state[i]->predictor];

		state[i]->delta = (readBuffer[i][1] << 8) | readBuffer[i][0];
		readBuffer[i] += sizeof(u16);

		state[i]->sample1 = (readBuffer[i][1] << 8) | readBuffer[i][0];
		readBuffer[i] += sizeof(u16);

		state[i]->sample2 = (readBuffer[i][1] << 8) | readBuffer[i][0];
		readBuffer[i] += sizeof(u16);

		*decoded[i]++ = state[i]->sample2;
		*decoded[i]++ = state[i]->sample1;

		if(readSize[i] < 7)
			loopCount[i] = 0;
		else
			loopCount[i] = readSize[i] - 7;

	}

	// The first two samples have already been 'decoded' in	the block header.
	s32 nbSamples = (loopCount[0] << 1) + 2;
	s32 topBlock = 0;

	for(i=1; i<4; i++)
	{
		if(readSize[i] >= 7)
		{
			nbSamples += (loopCount[i] << 1) + 2;
			topBlock = i;
		}
		else
		{
			readBuffer[i] = readBuffer[0];
			*state[i] = *state[0];
			coefficient[i] = coefficient[0];
		}
	}

	s32 j;
	for(j=0; j<2; j++)
	{
		while(loopCount[topBlock] >= 1 && (((int)readBuffer[topBlock])&0x1) )
		{
			for(i=0; i<4; i++)
			{
				*decoded[i]++ = DecodeSample(state[i], static_cast<u32> (*readBuffer[i] >> 4),   coefficient[i]);
				*decoded[i]++ = DecodeSample(state[i], static_cast<u32> (*readBuffer[i] & 0x0f), coefficient[i]);
				readBuffer[i]++;
				loopCount[i]--;
			}
		}

		if(loopCount[topBlock] >= 2)
		{
			int alignedBytes = (loopCount[topBlock] >> 1) << 1;

			short neonState[20];
			for(i=0; i<4; i++)
			{
				neonState[0 + i] = state[i]->sample1;
				neonState[4 + i] = state[i]->sample2;
				neonState[8 + i] = state[i]->delta;
				neonState[12+ i] = coefficient[i][0];
				neonState[16+ i] = coefficient[i][1];
			}

			int neonParams[11];
			neonParams[0] = (int)neonState;
			neonParams[1] = (int)adaptive16;
			neonParams[2] = (int)readBuffer[0];
			neonParams[3] = (int)decoded[0];
			neonParams[4] = (int)(readBuffer[0] + alignedBytes);
			neonParams[5] = (int)readBuffer[1];
			neonParams[6] = (int)decoded[1];
			neonParams[7] = (int)readBuffer[2];
			neonParams[8] = (int)decoded[2];
			neonParams[9] = (int)readBuffer[3];
			neonParams[10]= (int)decoded[3];

			DecodeMsAdpcmNeonMonoAsm(neonParams);

			for(i=0; i<4; i++)
			{
				state[i]->sample1 = neonState[0 + i];
				state[i]->sample2 = neonState[4 + i];
				state[i]->delta   = neonState[8 + i];
				readBuffer[i]    += alignedBytes;
				loopCount[i]     -= alignedBytes;
				decoded[i]       += alignedBytes*2;
			}
		}

		while(loopCount[topBlock] >= 1)
		{
			for(i=0; i<4; i++)
			{
				*decoded[i]++ = DecodeSample(state[i], static_cast<u32> (*readBuffer[i] >> 4),   coefficient[i]);
				*decoded[i]++ = DecodeSample(state[i], static_cast<u32> (*readBuffer[i] & 0x0f), coefficient[i]);
				readBuffer[i]++;
				loopCount[i]--;

			}

		}

		readBuffer[topBlock] = readBuffer[0];
		*state[topBlock] = *state[0];
		coefficient[topBlock] = coefficient[0];
		topBlock = 0;
	}


	
	if(m_totalSampleDecoded + nbSamples > m_trackParams.numSamples)
	{
		nbSamples = m_trackParams.numSamples - m_totalSampleDecoded;
	}

	return nbSamples;
}

#endif // VOX_NEON_DECODER_MS


// Compute a linear PCM value from the given differential coded	value.
s16 VoxMSWavSubDecoderMSADPCM::DecodeSample(MsAdpcmState *state, u32 code, const s16 *coefficient)
{
	s32	linearSample, delta;

	linearSample = ((state->sample1 * coefficient[0]) +	(state->sample2 * coefficient[1])) >> 8;

	// Variable 'code' is a 4-bit interpreted as signed complement-2 (reason for 28-shifts and s32-cast)
	linearSample += state->delta * ((static_cast<s32> (code << 28)) >> 28);

	// Clamp linearSample to a signed 16-bit value.
	if(linearSample < MIN_INT16)
		linearSample = MIN_INT16;
	else if (linearSample > MAX_INT16)
		linearSample = MAX_INT16;

	delta = ((s32) state->delta * adaptive[code]) >> 8;
	if(delta < 16)
	{
		delta = 16;
	}

	state->delta = (short)delta;
	state->sample2 = state->sample1;
	state->sample1 = (short)linearSample;

	// Because of earlier range checking, new_sample will be in the range of an s16.
	return static_cast<s16> (linearSample);
}


s32 VoxMSWavSubDecoderMSADPCM::Decode(void* outbuf, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::Decode", vox::VoxThread::GetCurThreadId());
	s32 nbSamplesDesired = nbBytes / (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 sampleAvailable;
	s32 nbSamplesToCopy;

	while(nbSamples > 0)
	{
		// Get a new decoded block if all samples have been consumed.
		if(m_samplesInBufferConsumed == m_samplesInBuffer)
		{
#if VOX_NEON_DECODER_MS
		if(m_trackParams.numChannels == 2 && m_usingNeonDecoder)
			m_samplesInBuffer = DecodeBlockNeonStereo((void*)m_readBuffer);
		else if(m_trackParams.numChannels == 1 && m_usingNeonDecoder)
			m_samplesInBuffer = DecodeBlockNeonMono((void*)m_readBuffer);
		else
#endif
			m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);
			m_samplesInBufferConsumed = 0;
		}

		// If no samples available, put decoder in error
		if(m_samplesInBuffer <= 0)
		{
			m_isDecoderInError = true;
			break;
		}

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * m_trackParams.numChannels;

		// Calculate the number of samples available in the current decoded block.
		sampleAvailable = m_samplesInBuffer - m_samplesInBufferConsumed;

		// Calculate the number of samples to copy from the decoded block to the output buffer.
		nbSamplesToCopy = (sampleAvailable > nbSamples) ? nbSamples : sampleAvailable;

		memcpy(&((s16*) outbuf)[bufferoffset], &(((short*)m_readBuffer)[m_samplesInBufferConsumed * m_trackParams.numChannels]), nbSamplesToCopy * m_trackParams.numChannels * sizeof(s16));

		nbSamples -= nbSamplesToCopy;
		m_samplesInBufferConsumed += nbSamplesToCopy;
		m_totalSampleDecoded += nbSamplesToCopy;

		if((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))) 
		{
			if(!(m_totalSampleDecoded >= m_trackParams.numSamples))
			{
				VOX_WARNING_LEVEL_4("Reached end of file but still waiting for samples, missing : %d", m_trackParams.numSamples - m_totalSampleDecoded);
			}
			if(!m_loop)
			{
				break;
			}
			else // If looping, seek to beginning of stream.
			{
				if(Seek(0) != 0)				
					break;		//could not go back to beginning
			}
		}
	}
	
	return (nbSamplesDesired - nbSamples)*( m_trackParams.numChannels * (m_trackParams.bitsPerSample>>3));
}

} // namespace vox


