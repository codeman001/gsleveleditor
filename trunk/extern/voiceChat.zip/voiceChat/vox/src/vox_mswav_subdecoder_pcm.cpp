
#include "StdAfx.h"
#include "vox_mswav_subdecoder_pcm.h"
#include "vox_macro.h"
#include "vox_profiler.h"


namespace vox
{
VoxMSWavSubDecoderPCM::VoxMSWavSubDecoderPCM(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks):
	VoxMSWavSubDecoder(pStreamCursor, pWaveChunks)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderPCM::VoxMSWavSubDecoderPCM", vox::VoxThread::GetCurThreadId());
	m_trackParams.bitsPerSample = m_pWaveChunks->m_formatHeader.significantBitsPerSample;
	m_trackParams.numChannels = m_pWaveChunks->m_formatHeader.numChannels;
	m_trackParams.samplingRate = m_pWaveChunks->m_formatHeader.sampleRate;
	m_trackParams.numSamples = GetDataSize() / (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3));

	GoToNextDataChunk();
}

s32 VoxMSWavSubDecoderPCM::Decode( void* outputBuffer, s32 nbBytes )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderPCM::Decode", vox::VoxThread::GetCurThreadId());
	if(m_currentChunkPosition >= m_pWaveChunks->m_dataHeader.chunkSize)
	{
		GoToNextDataChunk();
	}

	s32 size = 0;
	nbBytes -= (nbBytes%m_pWaveChunks->m_formatHeader.blockAlign);

	u32 chunkSize = m_pWaveChunks->m_dataHeader.chunkSize;
	
	while(size < nbBytes)
	{
		int readsize = 0;
		if(chunkSize >= m_currentChunkPosition + (nbBytes - size))
		{
			readsize = m_pStreamCursor->Read(((u8*) outputBuffer) + size, (nbBytes - size));
			m_currentChunkPosition += readsize;
		}
		else
		{
			readsize = m_pStreamCursor->Read(((u8*) outputBuffer) + size, chunkSize - m_currentChunkPosition);
			m_currentChunkPosition = m_pWaveChunks->m_dataHeader.chunkSize;
		}

		size += readsize;

		m_decodedSamples += readsize / (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3));
		if(m_currentChunkPosition >= chunkSize && m_decodedSamples < m_trackParams.numSamples) //end of chunk, but not data
		{
			GoToNextDataChunk();
			if(m_pWaveChunks->m_dataHeader.chunkSize == 0)
			{
				if(m_loop)
				{
					if(Seek(0))//Rewind (seek failed if return != 0)
						break;
				}
				else
				{
					m_decodedSamples = m_trackParams.numSamples;
					break;
				}
			}
		}
		else if(m_decodedSamples >= m_trackParams.numSamples) // end of data
		{
			if(m_loop)
			{
				if(Seek(0))//Rewind (seek failed if return != 0)
					break;
			}
			else
			{
				break;
			}
		}
		else if(readsize == 0)
		{
			//Not the end of data, but could not read anything
			m_isDecoderInError = true;
			break;
		}
	}
	
#if VOX_BIG_ENDIAN
	if(m_pWaveChunks->m_formatHeader.significantBitsPerSample == 16)
	{
		u16* tbuf = (u16*)outputBuffer;
		for(s32 i = 0; i < (size >> 1); i++)
			ConvertShortToBE(tbuf[i]);
	}
#endif

	return size;
}

int VoxMSWavSubDecoderPCM::GetDataSize()
{
	s32 size = 0;
	if(m_pWaveChunks->m_dataNodes)
	{
		DataNode* node = m_pWaveChunks->m_dataNodes;

		size += node->m_byteSize;
		while(node->m_next)
		{
			node = node->m_next;
			size += node->m_byteSize;
		}
	}

	return size;
}


int VoxMSWavSubDecoderPCM::Seek( u32 sampleNum )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderPCM::Seek", vox::VoxThread::GetCurThreadId());
	if(sampleNum > m_trackParams.numSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}

	m_currentDataNode = 0;
	m_decodedSamples = 0;
	GoToNextDataChunk();
	while(sampleNum > 0 && m_currentDataNode)
	{
		if((m_pWaveChunks->m_dataHeader.chunkSize / m_pWaveChunks->m_formatHeader.blockAlign) > sampleNum)
		{
			m_decodedSamples += sampleNum;
			m_pStreamCursor->Seek( sampleNum * m_pWaveChunks->m_formatHeader.blockAlign, ORIGIN_CURRENT);
			m_currentChunkPosition = sampleNum * m_pWaveChunks->m_formatHeader.blockAlign;
			sampleNum = 0;
		}
		else
		{
			m_decodedSamples += m_pWaveChunks->m_dataHeader.chunkSize / m_pWaveChunks->m_formatHeader.blockAlign;
			GoToNextDataChunk();
			sampleNum -= m_pWaveChunks->m_dataHeader.chunkSize / m_pWaveChunks->m_formatHeader.blockAlign;
		}
	}

	return 0;
}

bool VoxMSWavSubDecoderPCM::HasData()
{
	if(m_pStreamCursor && !m_isDecoderInError)
	{
		if(!(m_decodedSamples < m_trackParams.numSamples) && m_loop) //most likely reach end of data while in non-looping mode
			Seek(0);

		return m_decodedSamples < m_trackParams.numSamples;
	}
	return false;
}

}


