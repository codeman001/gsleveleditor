
#include "StdAfx.h"
#include "vox_mutex.h"
#include "vox_macro.h"

#include <cstring>

#if VOX_USE_GLF
#include <glf/core/mutex.h>
#include <glf/core/thread.h>
typedef glf::Mutex voxMutexType;

namespace vox {

struct VoxMutexData
{
	friend class Mutex;

	voxMutexType m_mutex;
};

//! Default constructor
/*!
	Mutex construction will create the mutex instance depending on the current platform
*/
Mutex::Mutex()
{
	m_data = VOX_NEW VoxMutexData;
	VOX_ASSERT_MSG(m_data, "Could not allocate Vox Mutex Data, operation will not be mutexed");
};

//! Default destructor
/*!
	Destroy platform dependent mutex
*/
Mutex::~Mutex()
{
	if(m_data)
		VOX_DELETE(m_data);
	m_data = 0;
}

Mutex::Mutex(const Mutex &mutex)
{
	memcpy(this, &mutex, sizeof(Mutex));
}

//! Lock the mutex
/*!
	Infinite timeout mutex method, will block until mutex is acquired
*/
void Mutex::Lock()
{
	if(!m_data)
		return;

	if(m_data)
		m_data->m_mutex.Lock();
}

//! Release the mutex
void Mutex::Unlock()
{
	if(!m_data)
		return;

	if(m_data)
		m_data->m_mutex.Unlock();
}

//! TryLock method
/*!
	Will try to acquire the lock on the mutex, however will not wait
	\return True if the mutex was aquired
*/
bool Mutex::TryLock()
{
	if(!m_data)
		return true;

	if(m_data)
		return m_data->m_mutex.TryLock();
	else
		return true;
}

} //namespace vox

#endif //VOX_USE_GLF


