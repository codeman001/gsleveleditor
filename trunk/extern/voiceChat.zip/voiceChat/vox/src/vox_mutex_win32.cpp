

#include "StdAfx.h"
#include "vox_mutex.h"
#include "vox_macro.h"
#include <cstring>

#if defined(_WIN32) && !VOX_USE_GLF
#if VOX_DEBUG_SERVER_ENABLE
#define _WINSOCKAPI_
#endif
#include <windows.h>
typedef HANDLE voxMutexType;

namespace vox {

struct VoxMutexData
{
	friend class Mutex;

	voxMutexType m_mutex;
};

//! Default constructor
/*!
	Mutex construction will create the mutex instance depending on the current platform
*/
Mutex::Mutex()
{
	m_data = VOX_NEW VoxMutexData;
	VOX_ASSERT_MSG(m_data, "Could not allocate Vox Mutex Data, operation will not be mutexed");
	if(m_data)
		m_data->m_mutex = CreateMutex(NULL,FALSE,NULL);
}

//! Default destructor
/*!
	Destroy platform dependent mutex
*/
Mutex::~Mutex()
{
	CloseHandle(m_data->m_mutex);
	if(m_data)
		VOX_DELETE(m_data);
	m_data = 0;
}

Mutex::Mutex(const Mutex &mutex)
{
	memcpy(this, &mutex, sizeof(Mutex));
}

//! Lock the mutex
/*!
	Infinite timeout mutex method, will block until mutex is acquired
*/
void Mutex::Lock()
{
	if(!m_data)
		return;

	int errorcode = WaitForSingleObject(m_data->m_mutex,INFINITE);
	VOX_ASSERT_MSG(errorcode==WAIT_OBJECT_0, "Error while locking mutex\n");
}

//! Release the mutex
void Mutex::Unlock()
{
	if(!m_data)
		return;

	ReleaseMutex(m_data->m_mutex);
}

//! TryLock method
/*!
	Will try to acquire the lock on the mutex, however will not wait
	\return True if the mutex was aquired
*/
bool Mutex::TryLock()
{
	if(!m_data)
		return true;
	DWORD result = WaitForSingleObject(m_data->m_mutex,0);
	return (result == WAIT_ABANDONED) || (result == WAIT_OBJECT_0);//while WAIT_ABANDONED grant ownership but means a problem with mutex logic ...
}

} //namespace vox

#endif //_WIN32


