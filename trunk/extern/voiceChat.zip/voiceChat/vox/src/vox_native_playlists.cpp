
#include "StdAfx.h"
#include "vox_native_playlists.h"
#include <stdio.h>
#include <stdlib.h>
#include "vox_profiler.h"

namespace vox {


PlaylistElement::PlaylistElement(): m_segmentIndex(-1), m_entryPointType(k_nEntryPreEntryCue), 
									m_playPreEntry(0), m_playPostExit(0), m_nbLoops(1)
{
}


PlaylistElement::PlaylistElement(PlaylistElement &playlistElement)
{
	m_segmentIndex = playlistElement.m_segmentIndex;
	m_entryPointType = playlistElement.m_entryPointType;
	m_playPreEntry = playlistElement.m_playPreEntry;
	m_playPostExit = playlistElement.m_playPostExit;
	m_nbLoops = playlistElement.m_nbLoops;
}


void PlaylistElement::Reset(void)
{
	m_segmentIndex = -1;
	m_entryPointType = k_nEntryPreEntryCue;
	m_playPreEntry = 0;
	m_playPostExit = 0;
	m_nbLoops = 1;
}


///

SegmentGroup::SegmentGroup(GroupInfos *pInfos, s32 switchMode):
m_isValid(true),
m_selectMode(pInfos->m_selectMode),
m_playcount(pInfos->m_playcount)
{
	m_nbLoops = pInfos->m_nbLoops;
	m_nbLoopsRemaining = m_nbLoops;
	m_nbPlaybacksRemaining = m_playcount;

	m_previousNbLoopsRemaining = m_nbLoopsRemaining;
	m_previousNbPlaybacksRemaining = m_nbPlaybacksRemaining;
}


SegmentGroup::SegmentGroup(SegmentGroup &group)
{
	m_isValid = true;
	m_nbLoops = group.m_nbLoops;
	m_playcount = group.m_playcount;

	m_nbLoopsRemaining = group.m_nbLoopsRemaining;
	m_nbPlaybacksRemaining = group.m_nbPlaybacksRemaining;

	m_previousNbLoopsRemaining = group.m_previousNbLoopsRemaining;
	m_previousNbPlaybacksRemaining = group.m_previousNbPlaybacksRemaining;

	m_selectMode = group.m_selectMode;
}

SegmentGroup::~SegmentGroup(void)
{
}


s32 SegmentGroup::GetSelectMode(void)
{
	return m_selectMode;
}


bool SegmentGroup::IsValid(void)
{
	return m_isValid;
}


void SegmentGroup::SetState(SegmentGroup &group)
{
	m_isValid = group.m_isValid;
	m_nbLoops = group.m_nbLoops;
	m_playcount = group.m_playcount;
	m_nbLoopsRemaining = group.m_nbLoopsRemaining;
	m_nbPlaybacksRemaining = group.m_nbPlaybacksRemaining;
	m_previousNbLoopsRemaining = group.m_previousNbLoopsRemaining;
	m_previousNbPlaybacksRemaining = group.m_previousNbPlaybacksRemaining;
	m_selectMode = group.m_selectMode;
}


///


RandomGroup::RandomGroup(GroupInfos *pInfos, s32 switchMode):SegmentGroup(pInfos, switchMode)
,m_nbElements(0)
{
	m_desiredNoRepeatLength = pInfos->m_selectParameter;
	
	// Case where, once selected, an element cannot be reselected before all elements are selected
	if(m_desiredNoRepeatLength == -1)
	{
		m_noRepeatLength = 0; // This value is increased by AddElement so it is equal to the number of elements.
	}
	else
	{
		m_noRepeatLength = m_desiredNoRepeatLength;
	}

	m_activeWeightsSum = 0;
	m_hasElementBeenReactivated = false;
}


// NOTE : This is not exactly a copy constructor since parameters such as m_loopPlaybackCount
//		  or m_nextRandomIndex are not initialized with values from received group but are
//		  calculated here.

RandomGroup::RandomGroup(RandomGroup &group):SegmentGroup(group)
,m_nbElements(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "RandomGroup::RandomGroup", vox::VoxThread::GetCurThreadId());

	RandomGroupElement *pNewElement;

	// Fill m_activeElements vector with values from group received in parameter.
	SIMPLE_VECTOR(RandomGroupElement*)::iterator iterator = group.m_activeElements.begin();
	SIMPLE_VECTOR(RandomGroupElement*)::iterator end = group.m_activeElements.end();
			
	for(; iterator != end; iterator++)
	{
		pNewElement = VOX_NEW RandomGroupElement();

		if(pNewElement)
		{
			*pNewElement = **iterator;
			m_activeElements.push_back(pNewElement);
			m_nbElements++;
		}
		else
		{
			m_isValid = false;
			return;
		}
	}

	m_desiredNoRepeatLength = group.m_desiredNoRepeatLength;
	m_noRepeatLength = group.m_noRepeatLength;
	m_activeWeightsSum = group.m_activeWeightsSum;
	m_loopPlaybackCount = m_nbElements;
	m_previousLoopPlaybackCount = m_loopPlaybackCount;

	m_nextRandomIndex = GetActiveElementIndex();
	m_previousRandomIndex = -1;

	m_hasElementBeenReactivated = group.m_hasElementBeenReactivated;
}


RandomGroup::~RandomGroup(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "RandomGroup::~RandomGroup", vox::VoxThread::GetCurThreadId());

	// Release active group elements
	s32 nbActiveElements = m_activeElements.size();
		
	for(s32 i = 0; i < nbActiveElements; i++)
	{
		VOX_DELETE(m_activeElements[i]);
	}

	// Release used group elements
	SIMPLE_LIST(RandomGroupElement*)::iterator usedIterator = m_usedElements.begin();
	SIMPLE_LIST(RandomGroupElement*)::iterator usedEnd = m_usedElements.end();
			
	for(; usedIterator != usedEnd; usedIterator++)
	{
		VOX_DELETE(*usedIterator);
	}
}



void RandomGroup::AddElement(RandomGroupElement *pElement)
{
	RandomGroupElement *pNewElement = VOX_NEW RandomGroupElement();

	if(pNewElement)
	{
		*pNewElement = *pElement;

		m_activeElements.push_back(pNewElement);
		m_activeWeightsSum += pNewElement->m_weight;
		m_nbElements++;

		// Case where no element can be selected before all elements are selected
		if(m_desiredNoRepeatLength == -1)
		{
			m_noRepeatLength++;
		}
	}
	else
	{
		m_isValid = false;
	}
}


// Method 'GetActiveElementIndex()' uses a weigthed random algorithm to provide the next
// group element from the 'm_activeElements' vector. The algorithm functions like the following:
//
// Suppose we have 4 elements with weights [ 10 20 80 40 ].
// 1) We sum all weights to get 10 + 20 + 80 + 40 = 150
// 2) We get a random value between 0 and 149 (= 150 - 1). Suppose we get 87.
// 3) We sum all the weights one by one and get pick the elements whose added weight gets
//	  the sum greater than the random value. So first sum is 10 (< 87), second sum is
//	  10 + 20 = 30 (<87), third sum is 30 + 80 (>87) and pick the third element (index = 2).

s32 RandomGroup::GetActiveElementIndex(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "RandomGroup::GetActiveElementIndex", vox::VoxThread::GetCurThreadId());

	s32 nbActiveElements = (s32) m_activeElements.size();
	
	if(nbActiveElements > 0)
	{
		s32 index;
		s32 currentWeightSum = 0;

		// Get a random number between 0 and the weight sum (minus one) of all active elements.
		s32 randomValue = /*std::*/rand() % m_activeWeightsSum;

		// Get index of element for which random value is smaller than the weight sum gotten when including this element.
		for(index = 0; index < nbActiveElements; index++)
		{
			currentWeightSum += m_activeElements[index]->m_weight;
			if(randomValue < currentWeightSum)
			{
				break;
			}
		}

		return index;
	}
	return -1;
}


// Random-no-repeat is interpreted such that 'm_noRepeatLength' is the number of
// draws that must occur before any elements can be chosen again. Thus, with
// m_noRepeatLength = 1, an element cannot be chosen two times in a row and the
// case m_noRepeatLength = 0 corresponds to normal random.

s32 RandomGroup::GetGroupElementPosition(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "RandomGroup::GetGroupElementPosition", vox::VoxThread::GetCurThreadId());

	if(m_nbPlaybacksRemaining != 0 && m_nbLoopsRemaining != 0 && m_nextRandomIndex >= 0)
	{
		s32 elementPosition = m_activeElements[m_nextRandomIndex]->m_elementPosition;

		if(m_noRepeatLength > 0)
		{
			// Send the element in "penalty"
			m_usedElements.push_back(m_activeElements[m_nextRandomIndex]);
			m_activeWeightsSum -= m_activeElements[m_nextRandomIndex]->m_weight;
			m_activeElements[m_nextRandomIndex] = m_activeElements[m_activeElements.size()-1];
			m_activeElements.pop_back();

			// If penalty box full, sent the oldest back to active elements
			if((s32)m_usedElements.size() > m_noRepeatLength)
			{
				m_activeElements.push_back(m_usedElements.front());
				m_activeWeightsSum += m_usedElements.front()->m_weight;
				m_usedElements.pop_front();
				m_hasElementBeenReactivated = true;
			}
			else
			{
				m_hasElementBeenReactivated = false;
			}
		}

		m_previousNbPlaybacksRemaining = m_nbPlaybacksRemaining;
		m_nbPlaybacksRemaining--;
		m_previousLoopPlaybackCount = m_loopPlaybackCount;
		m_loopPlaybackCount--;

		// If there a no more elements to play in current loop, decrease loop count.
		if(m_loopPlaybackCount == 0)
		{
			m_previousNbLoopsRemaining = m_nbLoopsRemaining;
			m_nbLoopsRemaining--;

			// If loop count is not 0, reset the number of elements in current loop.
			if(m_nbLoopsRemaining != 0)
			{
				m_loopPlaybackCount = m_nbElements;
			}
		}

		// Choose randomly the next active element index.
		m_previousRandomIndex = m_nextRandomIndex;
		m_nextRandomIndex = GetActiveElementIndex();

		return elementPosition;
	}

	return -1;
}



void RandomGroup::GetState(RandomGroupState *pState)
{
	// Current parameters
	pState->m_nbLoopsRemaining = m_nbLoopsRemaining;
	pState->m_nbPlaybacksRemaining = m_nbPlaybacksRemaining;
	pState->m_nextRandomIndex = m_nextRandomIndex;
	pState->m_activeWeightsSum = m_activeWeightsSum;
	pState->m_loopPlaybackCount = m_loopPlaybackCount;

	pState->m_pActiveElements = &m_activeElements;
	pState->m_pUsedElements = &m_usedElements;

	// Previous parameters
	pState->m_previousNbLoopsRemaining = m_previousNbLoopsRemaining;
	pState->m_previousNbPlaybacksRemaining = m_previousNbPlaybacksRemaining;
	pState->m_previousRandomIndex = m_previousRandomIndex;
	pState->m_previousLoopPlaybackCount = m_previousLoopPlaybackCount;
}



s32 RandomGroup::PeekAtNextGroupElement(GroupPeekMode mode)
{
	if(m_nextRandomIndex >= 0)
	{
		return m_activeElements[m_nextRandomIndex]->m_elementPosition;
	}

	return -1;
}


// Parameter resetType should be equal to k_nGroupFullReset when a playlist is forced
// (by a transition) to reset. When playlist is decrementing its loop count, resetType
// should be k_nGroupPartialReset.

void RandomGroup::Reset(s32 resetType)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "RandomGroup::Reset", vox::VoxThread::GetCurThreadId());

	RandomGroupElement *pElement;

	while(m_usedElements.size() > 0)
	{
		pElement = m_usedElements.front();
		m_activeWeightsSum += pElement->m_weight;
		m_activeElements.push_back(pElement);
		m_usedElements.pop_front();
	}
	m_previousNbLoopsRemaining = m_nbLoopsRemaining;
	m_nbLoopsRemaining = m_nbLoops;
	m_previousLoopPlaybackCount = m_loopPlaybackCount;
	m_loopPlaybackCount = m_nbElements;

	m_previousRandomIndex = m_nextRandomIndex;
	m_nextRandomIndex = GetActiveElementIndex();

	if(resetType == k_nGroupFullReset)
	{
		m_previousNbPlaybacksRemaining = m_nbPlaybacksRemaining;
		m_nbPlaybacksRemaining = m_playcount;
	}
}


void RandomGroup::SetState(RandomGroup &group)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "RandomGroup::SetState::RandomGroup", vox::VoxThread::GetCurThreadId());

	// Copy parent class parameters
	SegmentGroup::SetState(group);

	// Transfer target group elements from active <-> user lists to match the number in source.
	s32 nbSourceActiveElements = (s32) group.m_activeElements.size();
	s32 nbTargetActiveElements = (s32) m_activeElements.size();
	s32 transferSize = nbSourceActiveElements - nbTargetActiveElements;

	if(transferSize > 0) // Target needs more active group elements to have the same size as source.
	{
		// Transfer target group elements from used list to active list.
		for(s32 i = 0; i < transferSize; i++)
		{
			m_activeElements.push_back(m_usedElements.front());
		}
	}
	else if(transferSize < 0) // Target needs more used group elements to have the same size as source.
	{
		transferSize = - transferSize;
		
		// Transfer target group elements from active list to used list.
		for(s32 i = 0; i < transferSize; i++)
		{
			m_activeElements.push_back(m_usedElements.front());
		}
		m_usedElements.push_front(m_activeElements.back());
	}

	// Copy active group elements content from source to target.
	for(s32 i = 0; i < nbSourceActiveElements; i++)
	{
		m_activeElements[i] = group.m_activeElements[i];
	}

	// Copy used group elements content from source to target.
	SIMPLE_LIST(RandomGroupElement*)::iterator sourceIterator = group.m_usedElements.begin();
	SIMPLE_LIST(RandomGroupElement*)::iterator sourceEnd = group.m_usedElements.end();

	SIMPLE_LIST(RandomGroupElement*)::iterator targetIterator = group.m_usedElements.begin();
	SIMPLE_LIST(RandomGroupElement*)::iterator targetEnd = group.m_usedElements.end();

	s32 nbSourceUsedElements = (s32) group.m_usedElements.size();
	for(s32 i = 0; i < nbSourceUsedElements; i++)
	{
		**targetIterator = **sourceIterator;
		sourceIterator++;
		targetIterator++;
	}

	// Copy other parameters from source to target
	m_desiredNoRepeatLength = group.m_desiredNoRepeatLength;
	m_noRepeatLength = group.m_noRepeatLength;
	m_activeWeightsSum = group.m_activeWeightsSum;
	m_loopPlaybackCount = group.m_loopPlaybackCount;
	m_previousLoopPlaybackCount = group.m_previousLoopPlaybackCount;
	m_nextRandomIndex = group.m_nextRandomIndex;
	m_previousRandomIndex = group.m_previousRandomIndex;
	m_hasElementBeenReactivated = group.m_hasElementBeenReactivated;
}


void RandomGroup::SetState(RandomGroupState *pState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "RandomGroup::SetState::RandomGroupState", vox::VoxThread::GetCurThreadId());

	m_nbLoopsRemaining = pState->m_nbLoopsRemaining;
	m_nbPlaybacksRemaining = pState->m_nbPlaybacksRemaining;
	m_nextRandomIndex = pState->m_nextRandomIndex;
	m_activeWeightsSum = pState->m_activeWeightsSum;
	m_loopPlaybackCount = pState->m_loopPlaybackCount;

	m_previousNbLoopsRemaining = pState->m_previousNbLoopsRemaining;
	m_previousNbPlaybacksRemaining = pState->m_previousNbPlaybacksRemaining;
	m_previousRandomIndex = pState->m_previousRandomIndex;
	m_previousLoopPlaybackCount = pState->m_previousLoopPlaybackCount;
	
	// Clear m_activeElements vector and fill it with values from group received in parameter.
	m_activeElements.clear();

	SIMPLE_VECTOR(RandomGroupElement*)::iterator activeIterator = pState->m_pActiveElements->begin();
	SIMPLE_VECTOR(RandomGroupElement*)::iterator activeEnd = pState->m_pActiveElements->end();
			
	for(; activeIterator != activeEnd; activeIterator++)
	{
		m_activeElements.push_back(*activeIterator);
	}

	// Clear m_usedElements vector and fill it with values from group received in parameter.
	m_usedElements.clear();

	SIMPLE_LIST(RandomGroupElement*)::iterator usedIterator = pState->m_pUsedElements->begin();
	SIMPLE_LIST(RandomGroupElement*)::iterator usedEnd = pState->m_pUsedElements->end();
			
	for(; usedIterator != usedEnd; usedIterator++)
	{
		m_usedElements.push_back(*usedIterator);
	}
}


void RandomGroup::SetToPreviousState(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "RandomGroup::SetToPreviousState", vox::VoxThread::GetCurThreadId());

	m_nbLoopsRemaining = m_previousNbLoopsRemaining;
	m_nbPlaybacksRemaining = m_previousNbPlaybacksRemaining;
	m_nextRandomIndex = m_previousRandomIndex;					// TODO : Verify that it will not be overridden by a call to GetActiveElementIndex() before being used
	m_loopPlaybackCount = m_previousLoopPlaybackCount;

	if(m_noRepeatLength > 0)
	{
		RandomGroupElement *pReactivatedElement = 0;

		// If an element in penalty has been put as active during last element draw, get it out of active elements.
		if(m_hasElementBeenReactivated)
		{
			pReactivatedElement = m_activeElements.back();
			m_activeElements.pop_back();
			m_activeWeightsSum -= pReactivatedElement->m_weight;
		}

		// Set the last element that was put into penalty as active
		m_activeElements.push_back(m_usedElements.back());
		m_activeWeightsSum += m_usedElements.back()->m_weight;
		m_usedElements.pop_back();

		// Put the reactivated element (if any) into penalty.
		if(pReactivatedElement)
		{
			m_usedElements.push_back(pReactivatedElement);
		}
	}
}


///


SequentialGroup::SequentialGroup(GroupInfos *pInfos, s32 switchMode):
SegmentGroup(pInfos, switchMode),
m_currentPosition(0),
m_previousPosition(0)
{
}


SequentialGroup::SequentialGroup(SequentialGroup &group):SegmentGroup(group)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "SequentialGroup::SequentialGroup", vox::VoxThread::GetCurThreadId());

	m_currentPosition = group.m_currentPosition;
	m_previousPosition = group.m_previousPosition;

	// Fill m_elements vector with values from group received in parameter.
	SIMPLE_VECTOR(s32)::iterator iterator = group.m_elements.begin();
	SIMPLE_VECTOR(s32)::iterator end = group.m_elements.end();
			
	for(; iterator != end; iterator++)
	{
		m_elements.push_back(*iterator);
	}
}


SequentialGroup::~SequentialGroup(void)
{
}


void SequentialGroup::AddElement(s32 elementIndex)
{
	m_elements.push_back(elementIndex);
}


s32 SequentialGroup::GetGroupElementPosition(void)
{
	if(m_nbPlaybacksRemaining != 0 && m_nbLoopsRemaining != 0)
	{
		s32 currentPosition = m_currentPosition;

		m_previousPosition = m_currentPosition;
		m_currentPosition++;
			
		if(m_currentPosition >= (s32) m_elements.size())
		{
			m_currentPosition = 0;
			m_previousNbLoopsRemaining = m_nbLoopsRemaining;
			m_nbLoopsRemaining--;
		}

		m_previousNbPlaybacksRemaining = m_nbPlaybacksRemaining;
		m_nbPlaybacksRemaining--;

		return m_elements[currentPosition];
	}
	return -1;
}


void SequentialGroup::GetState(SequentialGroupState *pState)
{
	pState->m_nbLoopsRemaining = m_nbLoopsRemaining;
	pState->m_nbPlaybacksRemaining = m_nbPlaybacksRemaining;
	pState->m_currentPosition = m_currentPosition;

	pState->m_previousNbLoopsRemaining = m_previousNbLoopsRemaining;
	pState->m_previousNbPlaybacksRemaining = m_previousNbPlaybacksRemaining;
	pState->m_previousPosition = m_previousPosition;
}


s32 SequentialGroup::PeekAtNextGroupElement(GroupPeekMode mode)
{
	if(mode == k_nGroupPeekUnforced)
	{
		if(m_nbPlaybacksRemaining != 0 && m_nbLoopsRemaining != 0)
		{
			return m_elements[m_currentPosition];
		}
	}
	else
	{
		return m_elements[m_currentPosition];
	}
	return -1;
}



void SequentialGroup::Reset(s32 resetType)
{
	m_previousPosition = m_currentPosition;
	m_currentPosition = 0;
	m_previousNbLoopsRemaining = m_nbLoopsRemaining;
	m_nbLoopsRemaining = m_nbLoops;

	if(resetType == k_nGroupFullReset)
	{
		m_previousNbPlaybacksRemaining = m_nbPlaybacksRemaining;
		m_nbPlaybacksRemaining = m_playcount;
	}
}


void SequentialGroup::SetState(SequentialGroup &group)
{
	// Copy parent class parameters
	SegmentGroup::SetState(group);

	m_currentPosition = group.m_currentPosition;
	m_previousPosition = group.m_previousPosition;
}


void SequentialGroup::SetState(SequentialGroupState *pState)
{
	m_nbLoopsRemaining = pState->m_nbLoopsRemaining;
	m_nbPlaybacksRemaining = pState->m_nbPlaybacksRemaining;
	m_currentPosition = pState->m_currentPosition;

	m_previousNbLoopsRemaining = pState->m_previousNbLoopsRemaining;
	m_previousNbPlaybacksRemaining = pState->m_previousNbPlaybacksRemaining;
	m_previousPosition = pState->m_previousPosition;
}


void SequentialGroup::SetToPreviousState(void)
{
	m_nbLoopsRemaining = m_previousNbLoopsRemaining;
	m_nbPlaybacksRemaining = m_previousNbPlaybacksRemaining;
	m_currentPosition  = m_previousPosition;
}



///

NativePlaylist::NativePlaylist(PlaylistInfos *pInfos):
m_isValid(true),
m_groupSwitchMode(pInfos->m_switchMode),
m_nbLoops(pInfos->m_nbLoops),
m_currentGroup(0),
m_currentPosition(0),
m_previousGroup(0),
m_previousPosition(0)
{
	m_nbLoopsRemaining = m_nbLoops;
	m_previousNbLoopsRemaining = m_nbLoops;
}


NativePlaylist::NativePlaylist(NativePlaylist &playlist)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::NativePlaylist", vox::VoxThread::GetCurThreadId());

	m_isValid = true;
	PlaylistElement *pPlaylistElement;
	SegmentGroup *pGroup;

	m_groupSwitchMode = playlist.m_groupSwitchMode;
	m_nbLoops = playlist.m_nbLoops;

	m_currentGroup = playlist.m_currentGroup;
	m_currentPosition = playlist.m_currentPosition;
	m_nbLoopsRemaining = playlist.m_nbLoopsRemaining;

	m_previousGroup = playlist.m_previousGroup;
	m_previousPosition = playlist.m_previousPosition;
	m_previousNbLoopsRemaining = playlist.m_previousNbLoopsRemaining;

	// Create groups
	SIMPLE_VECTOR(SegmentGroup*)::iterator groupsIterator = playlist.m_groups.begin();
	SIMPLE_VECTOR(SegmentGroup*)::iterator groupsEnd = playlist.m_groups.end();
			
	for(; groupsIterator != groupsEnd; groupsIterator++)
	{
		if((*groupsIterator)->GetSelectMode() == k_nSelectSequential)
		{
			pGroup = (SegmentGroup *) VOX_NEW SequentialGroup(*((SequentialGroup *) (*groupsIterator)));
		}
		else // random or random no repeat
		{
			pGroup = (SegmentGroup *) VOX_NEW RandomGroup(*((RandomGroup *) (*groupsIterator)));
		}

		if(!pGroup)
		{
			m_isValid = false;
			return;
		}
		if(pGroup->IsValid())
		{
			m_groups.push_back(pGroup);
		}
		else
		{
			m_isValid = false;
			return;
		}
		
	}

	SIMPLE_VECTOR(PlaylistElement*)::iterator elementsIterator = playlist.m_playlistElements.begin();
	SIMPLE_VECTOR(PlaylistElement*)::iterator elementsEnd = playlist.m_playlistElements.end();

	for(; elementsIterator != elementsEnd; elementsIterator++)
	{
		pPlaylistElement = VOX_NEW PlaylistElement(**elementsIterator);
		if(pPlaylistElement)
		{
			m_playlistElements.push_back(pPlaylistElement);
		}
		else
		{
			m_isValid = false;
			return;
		}
	}
}


NativePlaylist::~NativePlaylist(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::~NativePlaylist", vox::VoxThread::GetCurThreadId());
		
	// Release groups
	s32 nbElements = m_groups.size();
	for(s32 i = 0; i < nbElements; i++)
	{
		if(m_groups[i]->GetSelectMode() == k_nSelectSequential)
		{
			VOX_DELETE((SequentialGroup *) m_groups[i]);
		}
		else
		{
			VOX_DELETE((RandomGroup *) m_groups[i]);
		}
	}

	// Release playlist elements
	nbElements = m_playlistElements.size();
	for(s32 i = 0; i < nbElements; i++)
	{
		VOX_DELETE(m_playlistElements[i]);
	}
}


void NativePlaylist::AddGroup(GroupInfos *groupInfos)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::AddGroup", vox::VoxThread::GetCurThreadId());

	SegmentGroup *pGroup;

	if(groupInfos->m_selectMode == k_nSelectSequential)
	{
		pGroup = (SegmentGroup *) VOX_NEW SequentialGroup(groupInfos, m_groupSwitchMode);
	}
	else // random or random no repeat
	{
		pGroup = (SegmentGroup *) VOX_NEW RandomGroup(groupInfos, m_groupSwitchMode);
	}

	if(pGroup) // Group has been added correctly
	{
		m_groups.push_back(pGroup);
	}
	else
	{
		m_isValid = false;
	}
}


void NativePlaylist::AddPlaylistElement(PlaylistElementInfos *pInfos)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::AddPlaylistElement", vox::VoxThread::GetCurThreadId());

	PlaylistElement *pPlaylistElement = VOX_NEW PlaylistElement();

	if(pPlaylistElement)
	{
		pPlaylistElement->m_segmentIndex = pInfos->m_segmentIndex;
		pPlaylistElement->m_playPreEntry = pInfos->m_playPreEntry;
		pPlaylistElement->m_playPostExit = pInfos->m_playPostExit;
		pPlaylistElement->m_nbLoops = pInfos->m_nbLoops;
		
		m_playlistElements.push_back(pPlaylistElement);

		if(m_groups[pInfos->m_groupIndex]->GetSelectMode() == k_nSelectSequential)
		{
			((SequentialGroup *) m_groups[pInfos->m_groupIndex])->AddElement(pInfos->m_index);
			if(!((SequentialGroup *) m_groups[pInfos->m_groupIndex])->IsValid())
			{
				m_isValid = false; // Element has not been added correctly
			}
		}
		else // Random group
		{
			RandomGroupElement groupElement;
			groupElement.m_elementPosition = pInfos->m_index;
			groupElement.m_weight = pInfos->m_weight;

			((RandomGroup *) m_groups[pInfos->m_groupIndex])->AddElement(&groupElement);
			if(!((RandomGroup *) m_groups[pInfos->m_groupIndex])->IsValid())
			{
				m_isValid = false; // Element has not been added correctly
			}
		}
	}
	else
	{
		m_isValid = false;
	}
}


PlaylistElement *NativePlaylist::GetCurrentElement(void)
{
	return m_playlistElements[m_currentPosition];
}


// Method 'GetCurrentPosition()' is used to in the case where a transition 'samePosition'
// is performed. The playlist has been set to the same settings as the playlist previously
// playing, therefore no parameter update needs to be done.

s32 NativePlaylist::GetCurrentPosition(void)
{
	return m_currentPosition;
}


void NativePlaylist::GetState(PlaylistState *pState)
{
	pState->m_currentGroup = m_currentGroup;
	pState->m_currentPosition = m_currentPosition;
	pState->m_nbLoopsRemaining = m_nbLoopsRemaining;
	pState->m_previousGroup = m_previousGroup;
	pState->m_previousPosition = m_previousPosition;
	pState->m_previousNbLoopsRemaining = m_previousNbLoopsRemaining;
	pState->m_pGroups = &m_groups;
}


// Method 'GetPlaylistElement()' is used to get a transition segment. This doesn't impact on
// the actual playlist behaviour (e.g. m_nbLoopsRemaining and m_currentPosition are not updated).

PlaylistElement *NativePlaylist::GetPlaylistElement(s32 position)
{	
	if(m_nbLoopsRemaining != 0)
	{
		if(position >= 0 && position < (s32) m_playlistElements.size())
		{
			return m_playlistElements[position];
		}
	}

	return 0;
}


PlaylistElement *NativePlaylist::GetPlaylistElement(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::GetPlaylistElement", vox::VoxThread::GetCurThreadId());

	s32 elementIndex = -1;
	PlaylistElement *pElement = 0;
	s32 nbGroupRequests = 0;
	s32 nbGroups = m_groups.size();

	if(m_nbLoopsRemaining != 0)
	{
		// k_nSwitchContinuous : Play all elements of group before switching to next group.
		if(m_groupSwitchMode == k_nSwitchContinuous)
		{
			elementIndex = m_groups[m_currentGroup]->GetGroupElementPosition();

			// If group cannot provide an element, switch to next group
			if(elementIndex == -1)
			{
				m_previousGroup = m_currentGroup;
				m_currentGroup++;
				if(m_currentGroup >= (s32) m_groups.size())
				{
					m_currentGroup = 0;
					m_previousNbLoopsRemaining = m_nbLoopsRemaining;
					m_nbLoopsRemaining--;

					// Reset all groups
					for(u32 i = 0; i < m_groups.size(); i++)
					{
						m_groups[i]->Reset(k_nGroupPartialReset);
					}
				}
				if(m_nbLoopsRemaining != 0)
				{
					elementIndex = m_groups[m_currentGroup]->GetGroupElementPosition();
				}
			}
		}
		else // k_nSwitchStep : Play one element per group and then switch group			
		{
			while(elementIndex == -1 && nbGroupRequests < nbGroups)
			{
				elementIndex = m_groups[m_currentGroup]->GetGroupElementPosition();
				nbGroupRequests++;

				// All groups have been requested and no element was provided.
				if(elementIndex == -1 && nbGroupRequests == nbGroups)
				{
					m_previousNbLoopsRemaining = m_nbLoopsRemaining;
					m_nbLoopsRemaining--;

					// Reset all groups
					for(u32 i = 0; i < m_groups.size(); i++)
					{
						m_groups[i]->Reset(k_nGroupPartialReset);
					}
					m_previousGroup = m_currentGroup;
					m_currentGroup = 0;

					if(m_nbLoopsRemaining != 0)
					{
						elementIndex = m_groups[m_currentGroup]->GetGroupElementPosition();
					}
				}

				m_previousGroup = m_currentGroup;
				m_currentGroup++;
				if(m_currentGroup >= nbGroups)
				{
					m_currentGroup = 0;
				}
			}
		}

		if(elementIndex >= 0)
		{
			m_previousPosition = m_currentPosition;
			m_currentPosition = elementIndex;
			pElement = m_playlistElements[m_currentPosition];
		}
	}

	return pElement;
}



bool NativePlaylist::IsValid(void)
{
	return m_isValid;
}


PlaylistElement *NativePlaylist::PeekAtNextElement(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::PeekAtNextElement", vox::VoxThread::GetCurThreadId());

	s32 elementIndex = -1;
	PlaylistElement *pElement = 0;
	s32 currentGroup = m_currentGroup;
	s32 nbLoopsRemaining = m_nbLoopsRemaining;
	s32 nbGroupRequests = 0;
	s32 nbGroups = m_groups.size();

	if(m_nbLoopsRemaining != 0)
	{
		if(m_groupSwitchMode == k_nSwitchContinuous) // Play all elements of group before switching to next group.
		{
			elementIndex = m_groups[currentGroup]->PeekAtNextGroupElement(k_nGroupPeekUnforced);
		
			// If group could not provide an element, switch to next group
			if(elementIndex == -1)
			{
				currentGroup++;
				if(currentGroup >= (s32) m_groups.size())
				{
					currentGroup = 0;
					nbLoopsRemaining--;
				}
				if(nbLoopsRemaining != 0)
				{
					elementIndex = m_groups[currentGroup]->PeekAtNextGroupElement(k_nGroupPeekForced);
				}
			}
		}
		else // k_nSwitchStep : Play one element per group and then switch group			
		{	
			while(elementIndex == -1 && nbGroupRequests < nbGroups)
			{
				elementIndex = m_groups[currentGroup]->PeekAtNextGroupElement(k_nGroupPeekUnforced);
				nbGroupRequests++;

				// All groups have been requested and no element was provided.
				if(elementIndex == -1 && nbGroupRequests == nbGroups)
				{
					nbLoopsRemaining--;
					currentGroup = 0;

					if(nbLoopsRemaining != 0)
					{
						elementIndex = m_groups[currentGroup]->PeekAtNextGroupElement(k_nGroupPeekUnforced);
					}
				}

				currentGroup++;
				if(currentGroup >= nbGroups)
				{
					currentGroup = 0;
				}
			}
		}
	
		if(elementIndex >= 0)
		{
			pElement = m_playlistElements[elementIndex];
		}
	}

	return pElement;
}


void NativePlaylist::Reset(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::Reset", vox::VoxThread::GetCurThreadId());

	m_previousGroup = m_currentGroup;
	m_currentGroup = 0;
	m_previousPosition = m_currentPosition;
	m_currentPosition = 0;
	m_nbLoopsRemaining = m_nbLoops;
	m_previousNbLoopsRemaining = m_nbLoops;
	s32 nbGroups = m_groups.size();

	for(s32 i = 0; i < nbGroups; i++)
	{
		m_groups[i]->Reset(k_nGroupFullReset);
	}
}


void NativePlaylist::SetState(NativePlaylist &playlist)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::SetState::NativePlaylist", vox::VoxThread::GetCurThreadId());

	m_isValid = playlist.m_isValid;
	m_groupSwitchMode = playlist.m_groupSwitchMode;
	m_nbLoops = playlist.m_nbLoops;

	m_currentGroup = playlist.m_currentGroup;
	m_currentPosition = playlist.m_currentPosition;
	m_nbLoopsRemaining = playlist.m_nbLoopsRemaining;

	m_previousGroup = playlist.m_previousGroup;
	m_previousPosition = playlist.m_previousPosition;
	m_previousNbLoopsRemaining = playlist.m_previousNbLoopsRemaining;

	// Copy groups
	u32 nbGroups = m_groups.size();
	for(u32 i = 0; i < nbGroups; i++)
	{
		if(m_groups[i]->GetSelectMode() == k_nSelectSequential)
		{
			m_groups[i]->SetState(*((SequentialGroup *) playlist.m_groups[i]));
		}
		else // random or random no repeat
		{
			m_groups[i]->SetState(*((RandomGroup *) playlist.m_groups[i]));
		}
	}
}


void NativePlaylist::SetState(PlaylistState *pState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::SetState::PlaylistState", vox::VoxThread::GetCurThreadId());

	m_currentGroup = pState->m_currentGroup;
	m_currentPosition = pState->m_currentPosition;
	m_nbLoopsRemaining = pState->m_nbLoopsRemaining;

	m_previousGroup = pState->m_previousGroup;
	m_previousPosition = pState->m_previousPosition;
	m_previousNbLoopsRemaining = pState->m_previousNbLoopsRemaining;

	// Loop over groups to set group parameters
	RandomGroupState randomGroupState;
	SequentialGroupState sequentialGroupState;

	s32 groupSize = m_groups.size();
	SegmentGroup *pCurrentGroup;

	for(s32 i = 0; i < groupSize; i++)
	{
		pCurrentGroup = pState->m_pGroups->at(i);

		if(pCurrentGroup->GetSelectMode() == k_nSelectSequential)
		{
			((SequentialGroup *) pCurrentGroup)->GetState(&sequentialGroupState);
			((SequentialGroup *) m_groups[i])->SetState(&sequentialGroupState);
		}
		else
		{
			((RandomGroup *) pCurrentGroup)->GetState(&randomGroupState);
			((RandomGroup *) m_groups[i])->SetState(&randomGroupState);
		}
	}
}


void NativePlaylist::SetToPreviousState(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylist::SetToPreviousState", vox::VoxThread::GetCurThreadId());

	SegmentGroup *pPreviousGroup = m_groups[m_previousGroup];
	pPreviousGroup->SetToPreviousState();

	m_currentGroup = m_previousGroup;
	m_currentPosition = m_previousPosition;
	m_nbLoopsRemaining = m_previousNbLoopsRemaining;
}


///

NativePlaylistsManager::NativePlaylistsManager(void):
m_isValid(true),
m_currentPlaylist(0),
m_nbPlaylists(0),
m_pPlaylists(0)
{
}


NativePlaylistsManager::NativePlaylistsManager(NativePlaylistsManager &playlistManager)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::NativePlaylistsManager", vox::VoxThread::GetCurThreadId());

	m_isValid = true;
	m_currentPlaylist = playlistManager.m_currentPlaylist;
	m_nbPlaylists = 0;

	m_pPlaylists = (NativePlaylist **) VOX_ALLOC(playlistManager.m_nbPlaylists * sizeof(NativePlaylist *));

	if(!m_pPlaylists)
	{
		m_isValid = false;
		return;
	}

	// Create and add playlists to array
	for(s32 i = 0; i < playlistManager.m_nbPlaylists; i++)
	{
		m_pPlaylists[i] = (NativePlaylist *) VOX_NEW NativePlaylist(*playlistManager.m_pPlaylists[i]);

		if(m_pPlaylists[i])
		{
			m_nbPlaylists++;				// Increment even if not valid to allow deletion.
			if(!m_pPlaylists[i]->IsValid())
			{
				m_isValid = false;
				return;
			}
		}
		else
		{
			m_isValid = false;
			return;
		}
	}
}


NativePlaylistsManager::~NativePlaylistsManager(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::~NativePlaylistsManager", vox::VoxThread::GetCurThreadId());

	if(m_pPlaylists)
	{
		for(s32 i = 0; i < m_nbPlaylists; i++)
		{
			if(m_pPlaylists[i])
			{
				VOX_DELETE(m_pPlaylists[i]);
			}
		}
	
		VOX_FREE(m_pPlaylists);
		m_pPlaylists = 0;
	}
}


void NativePlaylistsManager::AddGroup(GroupInfos *groupInfos)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::AddGroup", vox::VoxThread::GetCurThreadId());

	m_pPlaylists[groupInfos->m_playlist]->AddGroup(groupInfos);
	m_isValid = m_pPlaylists[groupInfos->m_playlist]->IsValid();
}


void NativePlaylistsManager::AddPlaylist(s32 index, PlaylistInfos *pInfos)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::AddPlaylist", vox::VoxThread::GetCurThreadId());

	m_pPlaylists[index] = (NativePlaylist *) VOX_NEW NativePlaylist(pInfos);

	if(m_pPlaylists[index])
	{
		m_nbPlaylists++;
	}
	else // Playlist insertion failed. Avoid creating a data source.
	{
		m_isValid = false;
	}
}


void NativePlaylistsManager::AddPlaylistElement(PlaylistElementInfos *pInfos)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::AddPlaylistElement", vox::VoxThread::GetCurThreadId());

	m_pPlaylists[pInfos->m_playlist]->AddPlaylistElement(pInfos);
	m_isValid = m_pPlaylists[pInfos->m_playlist]->IsValid();
}


s32 NativePlaylistsManager::GetNbPlaylists(void)
{
	return m_nbPlaylists;
}


PlaylistElement *NativePlaylistsManager::GetPlaylistElement(s32 playlistIndex, s32 playlistSelectMode, s32 position)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::GetPlaylistElement", vox::VoxThread::GetCurThreadId());

	NativePlaylist *pPlaylist = m_pPlaylists[playlistIndex];
	PlaylistElement *pElement = 0;

	if(playlistSelectMode == k_nSelectionUnforced)
	{
		pElement = pPlaylist->GetPlaylistElement();
	}
	else if(playlistSelectMode == k_nSelectionSamePosition)
	{
		pElement = pPlaylist->GetCurrentElement();
	}
	else if(playlistSelectMode == k_nSelectionTransitionSegment)
	{
		pElement = pPlaylist->GetPlaylistElement(position);
	}

	return pElement;
}


void NativePlaylistsManager::Init(s32 nbPlaylists)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::Init", vox::VoxThread::GetCurThreadId());

	// Create array of Playlist pointers
	m_pPlaylists = (NativePlaylist **) VOX_ALLOC(nbPlaylists * sizeof(NativePlaylist *));

	if(!m_pPlaylists)
		m_isValid = false;
}



bool NativePlaylistsManager::IsValid(void)
{
	return m_isValid;
}


PlaylistElement *NativePlaylistsManager::PeekAtNextPlaylistElement(s32 playlistIndex)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::PeekAtNextPlaylistElement", vox::VoxThread::GetCurThreadId());

	NativePlaylist *pPlaylist = m_pPlaylists[playlistIndex];

	return pPlaylist->PeekAtNextElement();
}


void NativePlaylistsManager::ResetPlaylist(s32 playlistIndex)
{
	if(playlistIndex >= 0)
	{
		m_pPlaylists[playlistIndex]->Reset();
	}
}


void NativePlaylistsManager::SetPlaylistToPreviousState(s32 playlistIndex)
{
	m_pPlaylists[playlistIndex]->SetToPreviousState();
}


void NativePlaylistsManager::SetState(NativePlaylistsManager &playlistManager)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::SetState", vox::VoxThread::GetCurThreadId());

	m_isValid = playlistManager.m_isValid;
	m_currentPlaylist = playlistManager.m_currentPlaylist;

	// Create and add playlists to array
	for(s32 i = 0; i < m_nbPlaylists; i++)
	{
		m_pPlaylists[i]->SetState(*playlistManager.m_pPlaylists[i]);
	}
}


void NativePlaylistsManager::TransposePlaylistParameters(s32 currentPlaylist, s32 newPlaylist)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "NativePlaylistsManager::TransposePlaylistParameters", vox::VoxThread::GetCurThreadId());

	if(currentPlaylist != newPlaylist)
	{
		NativePlaylist *pCurrentPlaylist = m_pPlaylists[currentPlaylist];
		NativePlaylist *pNewPlaylist = m_pPlaylists[newPlaylist];

		PlaylistState currentState;
		pCurrentPlaylist->GetState(&currentState);
		pNewPlaylist->SetState(&currentState);
	}
}



} // End namespace vox


