
#include "StdAfx.h"
#include "vox_priority_bank.h"
#include "vox_profiler.h"

#if defined(_WIN32)
	#define STRICMP _stricmp
#else
	#define STRICMP strcasecmp	
#endif

namespace vox 
{

/* PriorityBank */

PriorityBank::PriorityBank()
:m_name(0)
,m_threshold(-(s32)2147483647) 
,m_maxPlayback(0xFFFFFFFF) 
,m_behaviour(priority_bank::B_DO_NOTHING)
,m_parent(0)
,m_overrideChildPriority(false)
,m_bankPriority(0)
{
}


PriorityBank::PriorityBank(priority_bank::CreationSettings &cs, PriorityBank* parent)
:m_name(0)
,m_threshold(cs.m_threshold)
,m_maxPlayback(cs.m_maxPlayback)
,m_behaviour(cs.m_behaviour)
,m_parent(parent)
,m_overrideChildPriority(cs.m_overrideChildPriority)
,m_bankPriority(cs.m_bankPriority)
{
	if(cs.m_name)
	{
		u32 size = strlen(cs.m_name) + 1;
		m_name = static_cast<char*>(VOX_ALLOC(sizeof(char) * size));
		if(m_name)
		{
			strcpy(m_name, cs.m_name);
		}
	}

	if(m_maxPlayback > 32) //do not reserve more than 32 slots
		m_maxPlayback = 32;

	m_bankElements.reserve(m_maxPlayback);
}

bool PriorityBank::AddEmitter(EmitterObj* pEmitter, PriorityBank* childBank, s32 priority)
{
	if(!pEmitter)
		return false;

	if(m_threshold > priority)
		return false;

	if(m_parent != 0)
	{
		if(m_bankElements.size() < m_maxPlayback)
		{
			if(m_parent->AddEmitter(pEmitter, this, m_overrideChildPriority ? m_bankPriority : priority))
			{
				m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
				return true;
			}
			else
			{
				return false;
			}
		}

		if(m_behaviour == priority_bank::B_DO_NOTHING)
		{
			return false;
		}
		else if(m_behaviour == priority_bank::B_STEAL_OLDEST)
		{
			RemoveEmitter(m_bankElements[0].m_pEmitter);
			if(m_parent->AddEmitter(pEmitter, this, m_overrideChildPriority ? m_bankPriority : priority))
			{
				m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
				return true;
			}
			else
			{
				return false;
			}
		}
		else if(m_behaviour == priority_bank::B_STEAL_LOWEST_PRIORITY)
		{
			u32 index = 0xFFFFFFFF;
			s32 localPriority = priority;
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator it = m_bankElements.begin();
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator end = m_bankElements.end();

			u32 size = m_bankElements.size();
			for(u32 i = 0; i < size; i++)
			{
				if(m_bankElements[i].m_priority < localPriority)
				{
					localPriority = m_bankElements[i].m_priority;
					index = i;
				}
			}

			if(index != 0xFFFFFFFF)
			{
				RemoveEmitter(m_bankElements[index].m_pEmitter);
				if(m_parent->AddEmitter(pEmitter, this, m_overrideChildPriority ? m_bankPriority : priority))
				{
					m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
					return true;
				}
				else
				{
					return false;
				}
			}

			return false;
		}
		else if(m_behaviour == priority_bank::B_STEAL_LOWEST_PRIORITY_OLDEST)
		{
			u32 index = 0xFFFFFFFF;
			s32 localPriority = priority + 1;
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator it = m_bankElements.begin();
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator end = m_bankElements.end();

			u32 size = m_bankElements.size();
			for(u32 i = 0; i < size; i++)
			{
				if(m_bankElements[i].m_priority < localPriority)
				{
					localPriority = m_bankElements[i].m_priority;
					index = i;
				}
			}

			if(index != 0xFFFFFFFF)
			{
				RemoveEmitter(m_bankElements[index].m_pEmitter);
				if(m_parent->AddEmitter(pEmitter, this, m_overrideChildPriority ? m_bankPriority : priority))
				{
					m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
					return true;
				}
				else
				{
					return false;
				}
			}

			return false;
		}	
		else if(m_behaviour == priority_bank::B_STEAL_QUIETEST)
		{
			u32 index = 0xFFFFFFFF;
			f32 baseAttenuation = pEmitter->GetAttenuation();

			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator it = m_bankElements.begin();
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator end = m_bankElements.end();

			u32 size = m_bankElements.size();
			for(u32 i = 0; i < size; i++)
			{
				f32 elementAtt = m_bankElements[i].m_pEmitter->GetAttenuation();
				if(elementAtt <= baseAttenuation)
				{
					baseAttenuation = elementAtt;
					index = i;
				}
			}

			if(index != 0xFFFFFFFF)
			{
				RemoveEmitter(m_bankElements[index].m_pEmitter);
				if(m_parent->AddEmitter(pEmitter, this, m_overrideChildPriority ? m_bankPriority : priority))
				{
					m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
					return true;
				}
				else
				{
					return false;
				}
			}

			return false;
		}
	}
	else
	{
		if(m_bankElements.size() < m_maxPlayback)
		{
			m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
			return true;
		}

		if(m_behaviour == priority_bank::B_DO_NOTHING)
		{
			return false;
		}
		else if(m_behaviour == priority_bank::B_STEAL_OLDEST)
		{
			RemoveEmitter(m_bankElements[0].m_pEmitter);
			m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));

			return true;
		}
		else if(m_behaviour == priority_bank::B_STEAL_LOWEST_PRIORITY)
		{
			u32 index = 0xFFFFFFFF;
			s32 localPriority = priority;
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator it = m_bankElements.begin();
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator end = m_bankElements.end();

			u32 size = m_bankElements.size();
			for(u32 i = 0; i < size; i++)
			{
				if(m_bankElements[i].m_priority < localPriority)
				{
					localPriority = m_bankElements[i].m_priority;
					index = i;
				}
			}

			if(index != 0xFFFFFFFF)
			{
				RemoveEmitter(m_bankElements[index].m_pEmitter);
				m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
				return true;
			}

			return false;
		}
		else if(m_behaviour == priority_bank::B_STEAL_LOWEST_PRIORITY_OLDEST)
		{
			u32 index = 0xFFFFFFFF;
			s32 localPriority = priority + 1;
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator it = m_bankElements.begin();
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator end = m_bankElements.end();

			u32 size = m_bankElements.size();
			for(u32 i = 0; i < size; i++)
			{
				if(m_bankElements[i].m_priority < localPriority)
				{
					localPriority = m_bankElements[i].m_priority;
					index = i;
				}
			}

			if(index != 0xFFFFFFFF)
			{
				RemoveEmitter(m_bankElements[index].m_pEmitter);
				m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
				return true;
			}

			return false;
		}
		else if(m_behaviour == priority_bank::B_STEAL_QUIETEST)
		{
			u32 index = 0xFFFFFFFF;
			f32 baseAttenuation = pEmitter->GetAttenuation();

			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator it = m_bankElements.begin();
			VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator end = m_bankElements.end();

			u32 size = m_bankElements.size();
			for(u32 i = 0; i < size; i++)
			{
				f32 elementAtt = m_bankElements[i].m_pEmitter->GetAttenuation();
				if(elementAtt < baseAttenuation)
				{
					baseAttenuation = elementAtt;
					index = i;
				}
			}

			if(index != 0xFFFFFFFF)
			{
				RemoveEmitter(m_bankElements[index].m_pEmitter);
				m_bankElements.push_back(PriorityBankElement(pEmitter, childBank, priority));
				return true;
			}

			return false;
		}
	}

	return false;
}

bool PriorityBank::RemoveEmitter(EmitterObj* pEmitter, bool stop, bool up, bool down)
{
	if(!pEmitter)
		return false;

	VOX_WARNING_LEVEL_5("Removing Emitter %lld from priority bank %s. %s", pEmitter->GetId(), m_name, pEmitter->GetUserData().ToString());

	VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator it = m_bankElements.begin();
	VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator end = m_bankElements.end();

	for(; it != end; it++)
	{
		if((*it).m_pEmitter == pEmitter)
		{
			if(up)
			{
				if(m_parent != 0)
				{
					m_parent->RemoveEmitter(pEmitter, false, true, false);
				}
			}

			if(down)
			{
				if((*it).m_childBank != 0)
				{
					(*it).m_childBank->RemoveEmitter(pEmitter, stop, false, true);
				}
				else 
				{
					(*it).m_pEmitter->SetInPriorityBank(false);
					if(stop)
						(*it).m_pEmitter->Stop(VOX_DEFAULT_FADE_TIME_VOICE_STEAL);
				}
			}

			m_bankElements.erase(it);
			return true;
		}
	}

	return false;//emitter not in bank
}



void PriorityBank::Update()
{
	for(u32 i = 0;i < m_bankElements.size();)
	{
		if(m_bankElements[i].m_childBank == 0)
		{
			if(!m_bankElements[i].m_pEmitter->IsPlaying()
				&& m_bankElements[i].m_pEmitter->GetState() != DriverSource::STATE_PAUSED)
			{
				RemoveEmitter(m_bankElements[i].m_pEmitter, false);				
			}	
			else
			{
				++i;
			}
		}
		else
		{
			++i;
		}
	}
}


/* PriorityBankManager */
PriorityBankManager::PriorityBankManager()
{
	priority_bank::CreationSettings cs;
	cs.m_name = "default";
	PriorityBank* pBank = VOX_NEW PriorityBank(cs, 0);
	if(pBank)
		m_banks.push_back(pBank);

	m_bankQty = m_banks.size();
	
}

PriorityBankManager::~PriorityBankManager()
{
	for(u32 i = 0; i < m_banks.size(); i++)
	{
		if(m_banks[i])
			VOX_DELETE(m_banks[i]);
	}
	m_banks.clear();
}

PriorityBankManager::PriorityBankManager(u32 size)
:m_bankQty(size)
{
	m_banks.reserve(m_bankQty);
	for(u32 i = 0; i < m_bankQty; ++i)
	{
		PriorityBank* pBank = VOX_NEW PriorityBank();
		if(pBank)
			m_banks.push_back(pBank);
	}

	m_bankQty = m_banks.size();
}

u32  PriorityBankManager::AddPriorityBank(priority_bank::CreationSettings &cs)
{
	PriorityBank* pParentBank = 0;

	if(!cs.m_name)
	{
		VOX_WARNING_LEVEL_2("%s", "Cannot add priority bank: priority banks must be named!");
		return VOX_BANK_INVALID_ID;
	}

	if(cs.m_parentBankId > m_bankQty)
	{
		VOX_WARNING_LEVEL_2("Cannot add bank %d as parent to bank %s", cs.m_parentBankId, cs.m_name);
	}

	pParentBank = m_banks[cs.m_parentBankId];

	PriorityBank* pBank = VOX_NEW PriorityBank(cs, pParentBank);
	
	if(pBank)
	{
		m_banks.push_back(pBank);
		u32 bankId = m_banks.size() - 1;
		++m_bankQty;

		if(bankId + 1 != m_bankQty) //bank could not be added to the vector
		{
			m_bankQty = m_banks.size();
			return VOX_BANK_INVALID_ID;
		}

		return bankId;
	}
	
	return VOX_BANK_INVALID_ID;
}

bool PriorityBankManager::SetPriorityBank(u32 bankId, priority_bank::CreationSettings &cs)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	if(bankId < m_bankQty)
	{
		m_banks[bankId]->m_threshold = cs.m_threshold;
		m_banks[bankId]->m_maxPlayback = cs.m_maxPlayback;
		m_banks[bankId]->m_behaviour = cs.m_behaviour;
		m_banks[bankId]->m_bankPriority = cs.m_bankPriority;
		m_banks[bankId]->m_overrideChildPriority = cs.m_overrideChildPriority;
		
		u32 maxplayback = cs.m_maxPlayback;

		if(maxplayback > 32)
			maxplayback = 32;
		m_banks[bankId]->m_bankElements.reserve(maxplayback);

		return true;
	}
	else
	{
		VOX_WARNING_LEVEL_2("%s : Priority bank %d not defined", __FUNCTION__, bankId);
	}

	return false;
}

u32 PriorityBankManager::GetPriorityBankId(const char* name)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));

	if(!name) // must have a name to search
	{
		return VOX_BANK_INVALID_ID;
	}

	u32 size = m_banks.size();

	for(u32 i = 0; i < size; i++)
	{
		if(m_banks[i]->GetName())
		{
			if(STRICMP(name, m_banks[i]->GetName()) == 0)
			{
				return i;
			}
		}
	}

	return VOX_BANK_INVALID_ID;
}

bool PriorityBankManager::AddEmitter(u32 bankId, EmitterObj* pEmitter)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "PriorityBankManager::AddEmitter", 0/*vox::VoxThread::GetCurThreadId()*/);
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	if(!pEmitter)
		return false;

	if(bankId >= m_bankQty)
		return false;

	if(pEmitter->IsInPriorityBank())
	{
		VOX_WARNING_LEVEL_3("Failed to add emitter to bank %d, emitter already in a bank", bankId);
		return false; //should not happen
	}

	return m_banks[bankId]->AddEmitter(pEmitter, 0, pEmitter->GetPriority());

	//bool canAdd = _CanAddEmitter(bankId, m_pEmitter->GetPriority());
	//if(canAdd)
	//{
	//	if(m_banks[bankId].m_behaviour == priority_bank::B_DO_NOTHING || (m_banks[bankId].m_maxPlayback > m_banks[bankId].m_bankElements.size()))
	//	{
	//		m_banks[bankId].m_bankElements.push_back(PriorityBankElement(m_pEmitter, m_pEmitter->GetPriority()));
	//	}
	//	else if(m_banks[bankId].m_behaviour == priority_bank::B_STEAL_OLDEST)
	//	{
	//		VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator iter = m_banks[bankId].m_bankElements.begin();
	//		if((*iter).m_pEmitter)
	//		{
	//			(*iter).m_pEmitter->SetInPriorityBank(false);
	//			(*iter).m_pEmitter->Stop();
	//		}

	//		if(iter != m_banks[bankId].m_bankElements.end())
	//		{
	//			m_banks[bankId].m_bankElements.erase(iter);
	//		}

	//		m_banks[bankId].m_bankElements.push_back(PriorityBankElement(m_pEmitter, m_pEmitter->GetPriority()));
	//	}
	//	else if(m_banks[bankId].m_behaviour == priority_bank::B_STEAL_LOWEST_PRIORITY)
	//	{
	//		s32 prioTemp = m_pEmitter->GetPriority();
	//		VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator iter = m_banks[bankId].m_bankElements.begin();
	//		VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator last = m_banks[bankId].m_bankElements.end();
	//		VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator tempIter = last;
	//		for(;iter != last; ++iter)
	//		{
	//			s32 emitterPrio = (*iter).m_pEmitter->GetPriority();
	//			if(emitterPrio < prioTemp)
	//			{
	//				prioTemp = emitterPrio;
	//				tempIter = iter;
	//			}
	//		}

	//		if(tempIter != last)
	//		{
	//			if((*tempIter).m_pEmitter)
	//			{
	//				(*tempIter).m_pEmitter->SetInPriorityBank(false);
	//				(*tempIter).m_pEmitter->Stop();					
	//			}				
	//			m_banks[bankId].m_bankElements.erase(tempIter);

	//			m_banks[bankId].m_bankElements.push_back(PriorityBankElement(m_pEmitter, m_pEmitter->GetPriority()));
	//		}
	//		else
	//		{
	//			return false; //should not be possible
	//		}
	//	}
	//	else //priority_bank::B_STEAL_LOWEST_PRIORITY_OLDEST
	//	{
	//		s32 prioTemp = m_pEmitter->GetPriority();
	//		VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator iter = m_banks[bankId].m_bankElements.begin();
	//		VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator last = m_banks[bankId].m_bankElements.end();
	//		VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> >::iterator tempIter = last;
	//		for(;iter != last; ++iter)
	//		{
	//			s32 emitterPrio = (*iter).m_pEmitter->GetPriority();
	//			if(emitterPrio < prioTemp)
	//			{
	//				prioTemp = emitterPrio;
	//				tempIter = iter;
	//			}
	//			else if((emitterPrio == prioTemp) && (tempIter == last)) //oldest with same prio
	//			{
	//				prioTemp = emitterPrio;
	//				tempIter = iter;
	//			}
	//		}

	//		if(tempIter != last)
	//		{
	//			if((*tempIter).m_pEmitter)
	//			{
	//				(*tempIter).m_pEmitter->SetInPriorityBank(false);
	//				(*tempIter).m_pEmitter->Stop();					
	//			}				
	//			m_banks[bankId].m_bankElements.erase(tempIter);

	//			m_banks[bankId].m_bankElements.push_back(PriorityBankElement(m_pEmitter, m_pEmitter->GetPriority()));
	//		}
	//		else
	//		{
	//			return false; //should not be possible
	//		}
	//	}

	//	return true;
	//}

	//return false;
}

bool PriorityBankManager::RemoveEmitter(u32 bankId, EmitterObj* pEmitter)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "PriorityBankManager::RemoveEmitter", 0/*vox::VoxThread::GetCurThreadId()*/);
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	if(bankId >= m_bankQty || !pEmitter)
		return false;

	if(!pEmitter->IsInPriorityBank())
		return false;

	return m_banks[bankId]->RemoveEmitter(pEmitter, false);
}

//bool PriorityBankManager::CanAddEmitter(u32 bankId, s32 priority)  const
//{
//	VOX_THREADED_UPDATE_MODE_SCOPED_MUTEX(m_mutex, VOX_CONFIG.m_threadedUpdateOn);
//	return _CanAddEmitter(bankId, priority);
//}
//
//bool PriorityBankManager::_CanAddEmitter(u32 bankId, s32 priority)  const
//{
//	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "PriorityBankManager::_CanAddEmitter", 0/*vox::VoxThread::GetCurThreadId()*/);
//	if(bankId >= m_bankQty)
//	{
//		return false;
//	}
//
//	if(m_banks[bankId].m_threshold > priority)
//	{
//		return false;
//	}
//
//	if(m_banks[bankId].m_maxPlayback > m_banks[bankId].m_bankElements.size())
//	{
//		return true;
//	}
//	else
//	{
//		switch(m_banks[bankId].m_behaviour)
//		{
//			case priority_bank::B_DO_NOTHING:
//			{
//				return false;
//			}
//			case priority_bank::B_STEAL_OLDEST:
//			{
//				return true;
//			}
//			case priority_bank::B_STEAL_LOWEST_PRIORITY:
//			{
//				u32 size = m_banks[bankId].m_bankElements.size();
//				for(u32 i = 0; i < size; ++i)
//				{
//					if(m_banks[bankId].m_bankElements[i].m_priority < priority)
//					{
//						return true;
//					}
//				}
//				return false;
//			}
//			case priority_bank::B_STEAL_LOWEST_PRIORITY_OLDEST:
//			{
//				u32 size = m_banks[bankId].m_bankElements.size();
//				for(u32 i = 0; i < size; ++i)
//				{
//					if(m_banks[bankId].m_bankElements[i].m_priority <= priority)
//					{
//						return true;
//					}
//				}
//				return false;
//			}
//			default:
//			{
//				return false;
//			}
//		}
//	}
//
//	return false; // fail safe : should not get here in any case
//}

void PriorityBankManager::Update()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_EMITTER, "PriorityBankManager::Update", 0/*vox::VoxThread::GetCurThreadId()*/);
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	for(u32 i = 0; i < m_bankQty; ++i)
	{
		m_banks[i]->Update();
	}
}

//void PriorityBankManager::GetDebugInfo(DebugChunk_bank* info)
//{
//	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
//	for(int i = 0; i < m_bankQty; ++i)
//	{
//		info[i].id = i;
//		info[i].type = (s32)m_banks[i].m_behaviour;
//		info[i].threshold = m_banks[i].m_threshold;
//		info[i].max = m_banks[i].m_maxPlayback;
//		info[i].current = m_banks[i].m_bankElements.size();
//	}
//}

}//namespace vox


