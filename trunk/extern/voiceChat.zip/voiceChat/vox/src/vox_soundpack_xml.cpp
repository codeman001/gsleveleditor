
#include "StdAfx.h"
#include "vox_soundpack_xml_internal.h"
#include "vox_default_config.h"

#if VOX_USE_SOUNDPACK_XML

#include <cstring>
#include <stdlib.h>
#include <tinyxml.h>
#include "vox_filesystem.h"
#include "vox_memory.h"
#include "vox_macro.h"
 
extern double _GetTime();

namespace vox
{


SoundXMLDef::SoundXMLDef()
:m_priority(0), m_label(0), m_filename(0), m_loadingFlags(k_nNone), 
 m_format((s16)k_nDecoderTypeInvalid), m_bankId(0), m_groupId(0), m_isLoop(false), m_bus(0),
 m_is3D(k_n3DSoundTypeNone), m_referenceDistance(VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE),
 m_maxDistance(VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE),
 m_rolloffFactor(VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR), m_baseGain(1.0f), m_minGainMod(1.0f),
 m_maxGainMod(1.0f), m_isGainRandom(false), m_basePitch(1.0f), m_minPitchMod(1.0f),
 m_maxPitchMod(1.0f), m_isPitchRandom(false), m_killOnResume(true),
 m_fadeOnPlay(VOX_DEFAULT_FADE_TIME_PLAY), m_fadeOnStop(VOX_DEFAULT_FADE_TIME_STOP),
 m_numCustomSound(0), m_customSoundStr(0)
{}

GroupXMLDef::GroupXMLDef()
		:m_busName(""),
		m_name(""),
		m_is3D(k_n3DSoundTypeNone),
		m_parentId(0),
		m_volume(1),
		m_enable(true),
		m_refdistance(1),
		m_maxdistance((float)3.40282346638528860e+38), // max float
		m_rolloff(1),
		m_baseGain(1),
		m_basePitch(1),
		m_maxGainMod(1),
		m_maxPitchMod(1),
		m_minGainMod(1),
		m_minPitchMod(1),
		m_killOnResume(false),
		m_fadeOnPlay(VOX_DEFAULT_FADE_TIME_PLAY),
		m_fadeOnStop(VOX_DEFAULT_FADE_TIME_STOP)
{}


#if defined(_WIN32)
	#define VOX_STRCASECMP _stricmp
#else
	#define VOX_STRCASECMP strcasecmp	
#endif

bool c8stringcomp::operator() (const c8* lhs, const c8* rhs) const
{
	if(VOX_STRCASECMP(lhs, rhs) < 0)
		return true;
	return false;
}

bool stringcomp::operator() (const std::string& lhs, const std::string& rhs) const
{
	if(VOX_STRCASECMP(lhs.c_str(), rhs.c_str()) < 0)
		return true;
	return false;
}

VoxSoundPackXML::VoxSoundPackXML()
{
	data = VOX_NEW VoxSoundPackXMLInternalData;
}

VoxSoundPackXML::VoxSoundPackXML(const c8* xmlFileName)
{
	data = VOX_NEW VoxSoundPackXMLInternalData;

	LoadXML(xmlFileName);
}

VoxSoundPackXML::~VoxSoundPackXML()
{
	if(data)
		VOX_DELETE(data);
	data = 0;
}

bool VoxSoundPackXML::LoadXML(const c8* xmlFileName)
{
	if(!data)
		return false;

	data->m_soundVector.clear();
	data->m_groupVector.clear();
	data->m_bankVector.clear();
	data->m_eventVector.clear();
	data->m_soundLabel.clear();

	FileSystemInterface* pFS = FileSystemInterface::GetInstance();
	if(!pFS)
		return false;

	FileInterface* pFile = pFS->OpenFile((c8*)xmlFileName);

	if(!pFile)
		return false;

	pFile->Seek(0, k_nSeekEnd);
	s32 filesize = pFile->Tell();
	pFile->Seek(0, k_nSeekSet);

	c8* fileBuffer = (c8*)VOX_ALLOC(filesize + 1);

	if(!fileBuffer)
	{
		pFS->CloseFile(pFile);
		return false;
	}

	fileBuffer[filesize] = 0;

	s32 readSize = pFile->Read(fileBuffer, filesize, 1);
	pFS->CloseFile(pFile);

	if(readSize != 1)
	{
		VOX_FREE(fileBuffer);
		return false;
	}

	TiXmlDocument doc;
	doc.Parse(fileBuffer);

	if ( !doc.Error() )
	{
		TiXmlHandle docHandle( &doc );
		
		TiXmlElement* element;
		//s32 intVal;
		const c8 *strVal;
		//// Load Config
		 element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("config").Element();

		strVal = element->Attribute("apiversion");
		if(strVal)
		{
			c8* pch = strtok((c8 *)strVal, ".");
			if(pch)
			{
				data->m_config.m_majorVersion = atoi(pch);
				pch = strtok( NULL, ".");
				if(pch)
				{
					data->m_config.m_minorVersion = atoi(pch);
					pch = strtok( NULL, ".");
					if(pch)
					{
						data->m_config.m_fixVersion = atoi(pch);
					}
				}
			}
		}

		strVal = element->Attribute("console");
		if(strVal)
		{
			data->m_config.m_console = (c8 *)VOX_ALLOC(strlen(strVal) + 1);
			if(data->m_config.m_console)
				strcpy(data->m_config.m_console, strVal);
		}
		
		strVal = element->Attribute("nameofgame");
		if(strVal)
		{
			data->m_config.m_gameName = (c8 *)VOX_ALLOC(strlen(strVal) + 1);
			if(data->m_config.m_gameName)
				strcpy(data->m_config.m_gameName, strVal);
		}

		strVal = element->Attribute("descriptorversion");
		if(strVal)
		{
			data->m_config.m_packVersion = (c8 *)VOX_ALLOC(strlen(strVal) + 1);
			if(data->m_config.m_packVersion)
				strcpy(data->m_config.m_packVersion, strVal);
		}
		
		// Load Group
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("groups").Element();
		s32 groupsize;
		element->QueryIntAttribute("size", &groupsize);
		data->m_groupVector = VOX_VECTOR<GroupXMLDef, SAllocator<GroupXMLDef> >(groupsize);

		u32 groupUid = 0;
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("groups").FirstChild("group").Element();
		for ( ; element; element = element->NextSiblingElement() )
		{
			const c8* strValue;
			float floatValue;

			strValue = element->Attribute("mode3d");
			if(strValue)
			{
				if(strValue[0] == 'y')
				{
					data->m_groupVector[groupUid].m_is3D = k_n3DSoundTypeAbsolute;
				}
				else if(strValue[0] == 'r')
				{
					data->m_groupVector[groupUid].m_is3D = k_n3DSoundTypeRelative;
				}
				else
				{
					data->m_groupVector[groupUid].m_is3D = k_n3DSoundTypeNone;
				}
			}
			strValue = element->Attribute("bus");
			data->m_groupVector[groupUid].m_busName = strValue ? strValue : "";
			strValue = element->Attribute("name");
			data->m_groupVector[groupUid].m_name = strValue ? strValue : "";
			
			strValue = element->Attribute("parent");
			if(strValue)
			{
				u32 i;
				bool stop = false;
				for(i=0; i<groupUid && !stop; i++)
				{
					if(VOX_STRCASECMP(strValue, data->m_groupVector[i].m_name.c_str()) == 0)
					{
						data->m_groupVector[groupUid].m_parentId = i;
						stop = true;
					}
				}
				if(!stop) // parent group not found
				{
					VOX_WARNING_LEVEL_3("Cannot find parent group [%s] for bank [%s]", strValue, data->m_groupVector[groupUid].m_name.c_str());
					data->m_groupVector[groupUid].m_parentId = 0;
				}
			}
			else
			{
				data->m_groupVector[groupUid].m_parentId = 0;
			}
			
			if(TIXML_SUCCESS == element->QueryFloatAttribute("gain", &floatValue))
				data->m_groupVector[groupUid].m_volume = pow(10.0f, floatValue / 20.0f);

			strValue = element->Attribute("enable");
			if(strValue)
			{
				if(strValue[0] == 'n')
				{
					data->m_groupVector[groupUid].m_enable = false;
				}
				else
				{
					data->m_groupVector[groupUid].m_enable = true;
				}
			}
			
			
			// Get sound 3D parameters
			if(TIXML_SUCCESS == element->QueryFloatAttribute("refdistance", &floatValue))
				data->m_groupVector[groupUid].m_refdistance = floatValue;

			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxdistance", &floatValue))
				data->m_groupVector[groupUid].m_maxdistance = floatValue;

			if(TIXML_SUCCESS == element->QueryFloatAttribute("rolloff", &floatValue))
				data->m_groupVector[groupUid].m_rolloff = floatValue;

			// Get sound gain parameters
			if(TIXML_SUCCESS == element->QueryFloatAttribute("basegain", &floatValue))
				data->m_groupVector[groupUid].m_baseGain = pow(10.0f, floatValue / 20.0f);
			
			if(TIXML_SUCCESS == element->QueryFloatAttribute("mingainmod", &floatValue))
				data->m_groupVector[groupUid].m_minGainMod = pow(10.0f, floatValue / 20.0f);

			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxgainmod", &floatValue))
				data->m_groupVector[groupUid].m_maxGainMod = pow(10.0f, floatValue / 20.0f);
				

			// Get sound pitch parameters
			if(TIXML_SUCCESS == element->QueryFloatAttribute("basepitch", &floatValue))
				data->m_groupVector[groupUid].m_basePitch = pow(2.0f, floatValue / 1200.0f);
			
			if(TIXML_SUCCESS == element->QueryFloatAttribute("minpitchmod", &floatValue))
				data->m_groupVector[groupUid].m_minPitchMod = floatValue;

			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxpitchmod", &floatValue))
				data->m_groupVector[groupUid].m_maxPitchMod = floatValue;

			strValue = element->Attribute("killonresume");
			if(strValue)
			{
				if(strValue[0] == 'n')
					data->m_groupVector[groupUid].m_killOnResume = false;
				else
					data->m_groupVector[groupUid].m_killOnResume = true;
			}

			if(TIXML_SUCCESS == element->QueryFloatAttribute("fadeonplay", &floatValue))
				data->m_groupVector[groupUid].m_fadeOnPlay = floatValue;

			if(TIXML_SUCCESS == element->QueryFloatAttribute("fadeonstop", &floatValue))
				data->m_groupVector[groupUid].m_fadeOnStop = floatValue;

			groupUid++;


		}
		
		



		// Load Bank
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("banks").Element();
		s32 banksize;
		element->QueryIntAttribute("size", &banksize);
		data->m_bankVector = VOX_VECTOR<BankXMLDef, SAllocator<BankXMLDef> >(banksize);

		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("banks").FirstChild("bank").Element();

		
		// uid's are now attributed automatically on load, with 0 = default group.
		// they were previously part of the sdd.
		u32 bankUid = 0; 
		for ( ; element; element = element->NextSiblingElement() )
		{
			s32 intValue;
			const c8* strValue;
			

			strValue = element->Attribute("label");
			data->m_bankVector[bankUid].m_name = strValue ? strValue : "";

			if(TIXML_SUCCESS == element->QueryIntAttribute("maxplaybacks", &intValue))
				data->m_bankVector[bankUid].m_maxPlayback = intValue;
			if(TIXML_SUCCESS == element->QueryIntAttribute("threshold", &intValue))
				data->m_bankVector[bankUid].m_threshold = intValue;
			strValue = element->Attribute("behaviour");
			if(strValue)
			{
				if(strcmp(strValue, "steal oldest") == 0)
				{
					data->m_bankVector[bankUid].m_behaviour = priority_bank::B_STEAL_OLDEST;
				}
				else if(strcmp(strValue, "steal lowest priority") == 0)
				{
					data->m_bankVector[bankUid].m_behaviour = priority_bank::B_STEAL_LOWEST_PRIORITY;
				}
				else if(strcmp(strValue, "steal low. prio. or old. same prio") == 0)
				{
					data->m_bankVector[bankUid].m_behaviour = priority_bank::B_STEAL_LOWEST_PRIORITY_OLDEST;
				}
				else if(strcmp(strValue, "steal quietest") == 0)
				{
					data->m_bankVector[bankUid].m_behaviour = priority_bank::B_STEAL_QUIETEST;
				}
			}
			
			strValue = element->Attribute("parent");
			if(strValue)
			{
				// search all previous entries for parent with given name.
				u32 i;
				bool stop = false;
				for (i=0; i<bankUid && !stop; i++)
				{
					if ( VOX_STRCASECMP(strValue, data->m_bankVector[i].m_name.c_str()) == 0)
					{
						data->m_bankVector[bankUid].m_parentId = i;
						stop = true;
					}	
				}
				if (!stop) // parent bank not found
				{
					VOX_WARNING_LEVEL_3("Cannot find parent bank [%s] for bank [%s]", strValue, data->m_bankVector[bankUid].m_name.c_str());
					data->m_bankVector[bankUid].m_parentId = 0;
				}
			}
			else
			{
				data->m_bankVector[bankUid].m_parentId = 0;
			}
			
			if(TIXML_SUCCESS == element->QueryIntAttribute("priority", &intValue))
			{
				data->m_bankVector[bankUid].m_priority = intValue;
				data->m_bankVector[bankUid].m_overrideChildPriority = true;
			}
			else
			{
				data->m_bankVector[bankUid].m_overrideChildPriority = false;
			}

			bankUid++;
		}



		// Load Sound
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("sounds").Element();
		s32 soundsize;
		element->QueryIntAttribute("size", &soundsize);
		data->m_soundVector = VOX_VECTOR<SoundXMLDef, SAllocator<SoundXMLDef> >(soundsize);

		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("sounds").FirstChild("sound").Element();
		for (s32 uid=0 ; element; element = element->NextSiblingElement(), uid++ )
		{
			s32 intValue;
			f32 floatValue;
			const c8* strValue;
			u32 soundGroup = 0;

			strValue = element->Attribute("label");
			if(strValue)
			{
				data->m_soundVector[uid].m_label = (c8*)VOX_ALLOC(strlen(strValue) + 1);
				if(data->m_soundVector[uid].m_label)
					strcpy(data->m_soundVector[uid].m_label, strValue);
			}
			else
			{
				data->m_soundVector[uid].m_label = (c8*)VOX_ALLOC(1);
				if(data->m_soundVector[uid].m_label)
					data->m_soundVector[uid].m_label[0] = 0; //empty string
			}

			strValue = element->Attribute("bank");
			if(strValue)
			{
				bool stopping = false;
				u32 numBanks = data->m_bankVector.size();

				for(u32 i=0; i<numBanks && !stopping; i++)
				{
					if(VOX_STRCASECMP(strValue, data->m_bankVector[i].m_name.c_str()) == 0)
					{
						data->m_soundVector[uid].m_bankId = i;
						stopping = true;
					}
				}
				if(!stopping)
				{
					VOX_WARNING_LEVEL_3("Sound bank [%s] for sound [%s] can't be found!", strValue, data->m_soundVector[uid].m_label);
				}
			}
						
			strValue = element->Attribute("group");
			if(strValue)
			{
				bool stopping = false;
				u32 numGroups = data->m_groupVector.size();

				for(u32 i=0; i<numGroups && !stopping; i++)
				{
					if(VOX_STRCASECMP(strValue, data->m_groupVector[i].m_name.c_str()) == 0)
					{
						soundGroup = i;
						stopping = true;
					}
				}
				if(!stopping)
				{
					VOX_WARNING_LEVEL_3("Sound group [%s] for sound [%s] can't be found!", strValue, data->m_soundVector[uid].m_label);
				}
			}
			data->m_soundVector[uid].m_groupId = soundGroup;

			if(TIXML_SUCCESS == element->QueryIntAttribute("priority", &intValue))
				data->m_soundVector[uid].m_priority = intValue;
			strValue = element->Attribute("loop");
			if(strValue)
				data->m_soundVector[uid].m_isLoop = (strValue[0] == 'y' || strValue[0] == 'Y') ? true : false;
			

			strValue = element->Attribute("format");
			if(strValue)
			{
				if(strcmp(strValue, "pcm")==0 || strcmp(strValue, "adpcm")==0)
				{
					data->m_soundVector[uid].m_format = k_nDecoderTypeMSWav;
				}
				else if((strcmp(strValue, "mpc8")==0) || (strcmp(strValue, "mpc")==0))
				{
					data->m_soundVector[uid].m_format = k_nDecoderTypeMPC8;
				}
				else if(strcmp(strValue, "ogg")==0)
				{
					data->m_soundVector[uid].m_format = k_nDecoderTypeStbVorbis;
				}
				else if(strcmp(strValue, "vxn")==0)
				{
					data->m_soundVector[uid].m_format = k_nDecoderTypeInteractiveMusic;
				}
				else if(strcmp(strValue, "bcwav")==0)
				{
					data->m_soundVector[uid].m_format = k_nDecoderTypeBCWav;
				}
			}

			strValue = element->Attribute("loadingflags");
			if(strValue)
			{
				if(strcmp(strValue, "none")==0)
				{
					data->m_soundVector[uid].m_loadingFlags = k_nNone;
				}
				else if(strcmp(strValue, "load to ram")==0)
				{
					data->m_soundVector[uid].m_loadingFlags = k_nLoadToRam;
				}
				else if(strcmp(strValue, "load and decode")==0)
				{
					data->m_soundVector[uid].m_loadingFlags = k_nLoadToRamAndDecode;
				}
			}

			strValue = element->Attribute("filename");
			if(strValue)
			{
				data->m_soundVector[uid].m_filename = (c8*)VOX_ALLOC(strlen(strValue) + 1);
				if(data->m_soundVector[uid].m_filename)
					strcpy(data->m_soundVector[uid].m_filename, strValue);
			}
			else if(data->m_soundVector[uid].m_format != vox::k_nDecoderTypeInvalid)
			{
				data->m_soundVector[uid].m_filename = (c8*)VOX_ALLOC(strlen(data->m_soundVector[uid].m_label) + 7);
				if(data->m_soundVector[uid].m_filename)
				{
					strcpy(data->m_soundVector[uid].m_filename, data->m_soundVector[uid].m_label);
					if(data->m_soundVector[uid].m_format == k_nDecoderTypeMSWav)
					{
						strcat(data->m_soundVector[uid].m_filename, ".wav");
					}
					else if(data->m_soundVector[uid].m_format == k_nDecoderTypeMPC8)
					{
						strcat(data->m_soundVector[uid].m_filename, ".mpc");
					}
					else if(data->m_soundVector[uid].m_format == k_nDecoderTypeStbVorbis)
					{
						strcat(data->m_soundVector[uid].m_filename, ".ogg");
					}
					else if(data->m_soundVector[uid].m_format == k_nDecoderTypeInteractiveMusic)
					{
						strcat(data->m_soundVector[uid].m_filename, ".vxn");
					}
					else if(data->m_soundVector[uid].m_format == k_nDecoderTypeBCWav)
					{
						strcat(data->m_soundVector[uid].m_filename, ".bcwav");
					}
					//else
					//{
					//	data->m_soundVector[uid].m_filename = "";
					//}
				}
			}


			strValue = element->Attribute("bus");
			if(strValue)
			{
				data->m_soundVector[uid].m_bus = (c8 *)VOX_ALLOC(strlen(strValue)+1);
				if(data->m_soundVector[uid].m_bus)
					strcpy(data->m_soundVector[uid].m_bus, strValue);
			}
			else
			{
				data->m_soundVector[uid].m_bus = (c8 *)VOX_ALLOC(data->m_groupVector[soundGroup].m_busName.length()+1);
				if(data->m_soundVector[uid].m_bus)
					strcpy(data->m_soundVector[uid].m_bus, data->m_groupVector[soundGroup].m_busName.c_str());				
			}

			// Get sound 3D parameters
			data->m_soundVector[uid].m_is3D = data->m_groupVector[soundGroup].m_is3D;
			strValue = element->Attribute("mode3d");
			if(strValue)
			{
				if(strValue[0] == 'y')
					data->m_soundVector[uid].m_is3D = k_n3DSoundTypeAbsolute;
				else if(strValue[0] == 'r')
					data->m_soundVector[uid].m_is3D = k_n3DSoundTypeRelative;
				else if(strValue[0] == 'n')
					data->m_soundVector[uid].m_is3D = k_n3DSoundTypeNone;
				// otherwise using group value
			}

			data->m_soundVector[uid].m_referenceDistance = data->m_groupVector[soundGroup].m_refdistance;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("refdistance", &floatValue))
				data->m_soundVector[uid].m_referenceDistance = floatValue;

			data->m_soundVector[uid].m_maxDistance = data->m_groupVector[soundGroup].m_maxdistance;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxdistance", &floatValue))
				data->m_soundVector[uid].m_maxDistance = floatValue;

			data->m_soundVector[uid].m_rolloffFactor = data->m_groupVector[soundGroup].m_rolloff;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("rolloff", &floatValue))
				data->m_soundVector[uid].m_rolloffFactor = floatValue;

			// Get sound gain parameters
			data->m_soundVector[uid].m_baseGain = data->m_groupVector[soundGroup].m_baseGain;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("basegain", &floatValue))
				data->m_soundVector[uid].m_baseGain = pow(10.0f, floatValue / 20.0f);
			
			data->m_soundVector[uid].m_minGainMod = data->m_groupVector[soundGroup].m_minGainMod;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("mingainmod", &floatValue))
			{
				data->m_soundVector[uid].m_minGainMod = pow(10.0f, floatValue / 20.0f);
			}

			data->m_soundVector[uid].m_maxGainMod = data->m_groupVector[soundGroup].m_maxGainMod;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxgainmod", &floatValue))
			{
				data->m_soundVector[uid].m_maxGainMod = pow(10.0f, floatValue / 20.0f);
			}

			if(data->m_soundVector[uid].m_minGainMod != 1.f || data->m_soundVector[uid].m_maxGainMod != 1.f)
			{
				data->m_soundVector[uid].m_isGainRandom = true;
			}


			// Get sound pitch parameters
			data->m_soundVector[uid].m_basePitch = data->m_groupVector[soundGroup].m_basePitch;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("basepitch", &floatValue))
				data->m_soundVector[uid].m_basePitch = pow(2.0f, floatValue / 1200.0f);
			
			data->m_soundVector[uid].m_minPitchMod = data->m_groupVector[soundGroup].m_minPitchMod;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("minpitchmod", &floatValue))
			{
				data->m_soundVector[uid].m_minPitchMod = floatValue;
			}

			data->m_soundVector[uid].m_maxPitchMod = data->m_groupVector[soundGroup].m_maxPitchMod;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxpitchmod", &floatValue))
			{
				data->m_soundVector[uid].m_maxPitchMod = floatValue;
			}

			if(data->m_soundVector[uid].m_minPitchMod != 0.f || data->m_soundVector[uid].m_maxPitchMod != 0.f)
			{
				data->m_soundVector[uid].m_isPitchRandom = true;
			}

			data->m_soundVector[uid].m_killOnResume = data->m_groupVector[soundGroup].m_killOnResume;
			strValue = element->Attribute("killonresume");
			if(strValue)
			{
				if(strValue[0] == 'n')
					data->m_soundVector[uid].m_killOnResume = false;
				else
					data->m_soundVector[uid].m_killOnResume = true;
			}

			data->m_soundVector[uid].m_fadeOnPlay = data->m_groupVector[soundGroup].m_fadeOnPlay;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("fadeonplay", &floatValue))
				data->m_soundVector[uid].m_fadeOnPlay = floatValue;

			data->m_soundVector[uid].m_fadeOnStop = data->m_groupVector[soundGroup].m_fadeOnStop;
			if(TIXML_SUCCESS == element->QueryFloatAttribute("fadeonstop", &floatValue))
				data->m_soundVector[uid].m_fadeOnStop = floatValue;

			// Get sound custom parameters
			strValue = element->Attribute("customparam");
			if(strValue)
			{
				s32 numAttributes = 1;
				for(int i=0; strValue[i]; i++)
					if(strValue[i] == ',')
						numAttributes++;
				if(!strValue[0])
					numAttributes = 0;
				data->m_soundVector[uid].m_numCustomSound = numAttributes;

				if(data->m_soundVector[uid].m_numCustomSound > 0)
				{
					data->m_soundVector[uid].m_customSoundStr = (c8**)VOX_ALLOC(data->m_soundVector[uid].m_numCustomSound * sizeof(c8*));
					if(data->m_soundVector[uid].m_customSoundStr)
					{
						// Allocate memory for 1st string. The 'm_customSoundStr[i > 0]' point within this string.
						data->m_soundVector[uid].m_customSoundStr[0] = (c8*)VOX_ALLOC(strlen(strValue) + 1);
						if(data->m_soundVector[uid].m_customSoundStr[0])
						{
							strcpy(data->m_soundVector[uid].m_customSoundStr[0], strValue);
							for(s32 i = 1; i < data->m_soundVector[uid].m_numCustomSound; i++)
							{
								c8* sc = strchr(data->m_soundVector[uid].m_customSoundStr[i - 1], ',');
								data->m_soundVector[uid].m_customSoundStr[i] = sc + 1;
								*sc = 0;
							}
						}
						else
						{
							data->m_soundVector[uid].m_numCustomSound = 0;
						}
					}
					else
					{
						data->m_soundVector[uid].m_numCustomSound = 0;
					}
				}
			}

			if(data->m_soundVector[uid].m_label)
				data->m_soundLabel[data->m_soundVector[uid].m_label] = uid;
		}



		// Load Event
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("events").Element();
		s32 eventsize;
		element->QueryIntAttribute("size", &eventsize);
		data->m_eventVector = VOX_VECTOR<EventXMLDef, SAllocator<EventXMLDef> >(eventsize);

		// the event's uid is generated when loading
		s32 eventUid = 0;
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("events").FirstChild("event").Element();
		for ( ; element; element = element->NextSiblingElement() )
		{
			
			const c8* strValue;
			f32 floatValue;

			strValue = element->Attribute("label");
			//data->m_eventVector[eventUid].m_label = strValue ? strValue : "";
			
			if(strValue)
			{
				data->m_eventVector[eventUid].m_label = (c8*)VOX_ALLOC(strlen(strValue) + 1);
				if(data->m_eventVector[eventUid].m_label)
					strcpy(data->m_eventVector[eventUid].m_label, strValue);
			}
			else
			{
				data->m_eventVector[eventUid].m_label = (c8*)VOX_ALLOC(1);
				if(data->m_eventVector[eventUid].m_label)
					data->m_eventVector[eventUid].m_label[0] = 0; //empty string
			}
			
			strValue = element->Attribute("type");
			if(strValue)
			{
				if(strcmp(strValue, "random") == 0)
				{
					data->m_eventVector[eventUid].m_eventType = k_nEventTypeRandom;
				}
				else if(strcmp(strValue, "playlist") == 0)
				{
					data->m_eventVector[eventUid].m_eventType = k_nEventTypePlaylist;
				}
				else if(strcmp(strValue, "pl_random") == 0)
				{
					data->m_eventVector[eventUid].m_eventType = k_nEventTypePlRandom;
				}
			}
			strValue = element->Attribute("value");
			if(strValue)
			{
				std::map<c8*, s32, c8stringcomp, SAllocator<std::pair<const c8*,s32> > >::iterator target;
				c8* pch = strtok((c8 *)strValue, " ,");

				while(pch)
				{
					target = data->m_soundLabel.find(pch);
					if(target != data->m_soundLabel.end())
					{
						s32 targetSoundId = target->second;
						data->m_eventVector[eventUid].m_soundIds.push_back(targetSoundId);
					}
					else // not found
					{
						VOX_WARNING_LEVEL_3("Missing sound [%s] from event [%s].", pch, data->m_eventVector[eventUid].m_label);
					}
					pch = strtok( NULL, " ,");
				}
			}

			strValue = element->Attribute("params");
			if(strValue)
			{
				
				c8* pch = strtok((c8 *)strValue, " ;");
				if(pch)
				{
					s32 randomParam = atoi(pch);
					data->m_eventVector[eventUid].m_eventParam = randomParam < (s32)data->m_eventVector[eventUid].m_soundIds.size() ? randomParam : data->m_eventVector[eventUid].m_soundIds.size();
					pch = strtok( NULL, " ;");
					if(pch)
					{
						s32 playbackProb = atoi(pch);
						if(playbackProb == 0)
							VOX_WARNING_LEVEL_3("Playback probability of %s is 0", data->m_eventVector[eventUid].m_label);
						data->m_eventVector[eventUid].m_playbackProbability = playbackProb <= 100 ? playbackProb : 100;
					}
				}
			}

			if(TIXML_SUCCESS == element->QueryFloatAttribute("cooldownvalue", &floatValue))
			{
				data->m_eventVector[eventUid].m_cooldownValue = floatValue;
			}

			strValue = element->Attribute("cooldowntype");
			if(strValue)
			{
				if(strcmp(strValue, "time") == 0)
				{
					data->m_eventVector[eventUid].m_cooldownType = k_nCooldownTypeTime;
				}
				else if(strcmp(strValue, "plays") == 0)
				{
					data->m_eventVector[eventUid].m_cooldownType = k_nCooldownTypePlays;
				}
			}

			strValue = element->Attribute("customparam");
			if(strValue)
			{
				s32 numAttributes = 1;
				for(int i=0; strValue[i]; i++)
					if(strValue[i] == ',')
						numAttributes++;
				if(!strValue[0])
					numAttributes = 0;
				data->m_eventVector[eventUid].m_numCustomEvent = numAttributes;

				data->m_eventVector[eventUid].m_customEventStr = (c8**)VOX_ALLOC(data->m_eventVector[eventUid].m_numCustomEvent * sizeof(c8*));
				if(data->m_eventVector[eventUid].m_customEventStr)
				{
					// Allocate memory for 1st string. The 'm_customEventStr[i > 0]' point within this string.
					data->m_eventVector[eventUid].m_customEventStr[0] = (c8*)VOX_ALLOC(strlen(strValue) + 1);
					if(data->m_eventVector[eventUid].m_customEventStr[0])
					{
						strcpy(data->m_eventVector[eventUid].m_customEventStr[0], strValue);
						for(s32 i = 1; i < data->m_eventVector[eventUid].m_numCustomEvent; i++)
						{
							c8* sc = strchr(data->m_eventVector[eventUid].m_customEventStr[i - 1], ',');
							data->m_eventVector[eventUid].m_customEventStr[i] = sc + 1;
							*sc = 0;
						}
					}
					else
					{
						data->m_eventVector[eventUid].m_numCustomEvent = 0;
					}
				}
				else
				{
					data->m_eventVector[eventUid].m_numCustomEvent = 0;
				}
			}

			if(data->m_eventVector[eventUid].m_eventType != k_nEventTypePlRandom)
			{
				data->m_eventVector[eventUid].m_currentEvent = (s32)data->m_eventVector[eventUid].m_soundIds.size();
			}
			else
			{
				data->m_eventVector[eventUid].m_currentEvent = rand() % (s32)data->m_eventVector[eventUid].m_soundIds.size();
			}
			eventUid++;

		}
	}

	VOX_FREE(fileBuffer);

	return true;
}


bool VoxSoundPackXML::GetConfigInfo(ConfigInfoXML &configInfo) const
{
	if(!data)
		return false;

	configInfo.m_majorVersion = data->m_config.m_majorVersion;
	configInfo.m_minorVersion = data->m_config.m_minorVersion;
	configInfo.m_fixVersion = data->m_config.m_fixVersion;
	configInfo.m_gameName = data->m_config.m_gameName;
	configInfo.m_console = data->m_config.m_console;
	configInfo.m_packVersion = data->m_config.m_packVersion;

	return true;
}

u32	 VoxSoundPackXML::GetBankUid(const c8* name) const
{
	if(!data)
		return -1;

	for(u32 i = 0; i < data->m_bankVector.size(); i++)
	{
		if(data->m_bankVector[i].m_name == name)
		{
			return i;
		}
	}

	return -1;
}

bool VoxSoundPackXML::GetBankInfo(const c8* name, priority_bank::CreationSettings &bankInfo) const 
{
	if(!data)
		return false;

	u32 bankId = GetBankUid(name);
	return GetBankInfo(bankId, bankInfo);
}

bool VoxSoundPackXML::GetBankInfo(u32 bankId, priority_bank::CreationSettings &bankInfo) const
{
	if(!data)
		return false;

	if(bankId >= data->m_bankVector.size())
		return false;


	bankInfo.m_name = data->m_bankVector[bankId].m_name.c_str();

	bankInfo.m_threshold = data->m_bankVector[bankId].m_threshold;
	bankInfo.m_maxPlayback = data->m_bankVector[bankId].m_maxPlayback;
	bankInfo.m_behaviour = data->m_bankVector[bankId].m_behaviour;

	bankInfo.m_parentBankId = data->m_bankVector[bankId].m_parentId;
	bankInfo.m_overrideChildPriority = data->m_bankVector[bankId].m_overrideChildPriority;
	bankInfo.m_bankPriority = data->m_bankVector[bankId].m_priority;

	return true;
}

u32	 VoxSoundPackXML::GetGroupUid(const c8* name) const
{
	if(!data)
		return -1;

	for(u32 i = 0; i < data->m_groupVector.size(); i++)
	{
		if(data->m_groupVector[i].m_name == name)
		{
			return i;
		}
	}

	return -1;
}

bool VoxSoundPackXML::GetGroupInfo(const c8* name, group::CreationSettings &groupInfo) const 
{
	if(!data)
		return false;

	u32 groupId = GetGroupUid(name);
	return GetGroupInfo(groupId, groupInfo);
}

bool VoxSoundPackXML::GetGroupInfo(u32 groupId, group::CreationSettings &groupInfo) const 
{
	if(!data)
		return false;

	if(groupId >= data->m_groupVector.size())
		return false;


	groupInfo.m_name = data->m_groupVector[groupId].m_name.c_str();

	groupInfo.m_parentId = data->m_groupVector[groupId].m_parentId;
	groupInfo.m_volume = data->m_groupVector[groupId].m_volume;
	groupInfo.m_enable = data->m_groupVector[groupId].m_enable;

	return true;
}

s32	 VoxSoundPackXML::GetSoundUid(const c8* label) const
{
	if(!data)
		return -1;

#if defined(_NN_CTR)
	VOX_MAP<c8*, s32, c8stringcomp/*, SAllocator<std::pair<const c8*,s32> >*/ >::const_iterator it = data->m_soundLabel.find((c8*)label);
#else
	VOX_MAP<c8*, s32, c8stringcomp, SAllocator<std::pair<const c8*,s32> > >::const_iterator it = data->m_soundLabel.find((c8*)label);
#endif
	if(it != data->m_soundLabel.end())
		return  it->second;

	return -1;
}

bool VoxSoundPackXML::GetSoundLabel(s32 uid, const char *&result) const
{
	if(!data)
		return false;

	if(uid < 0 || uid >= (s32)data->m_soundVector.size())
		return false;

	result = data->m_soundVector[uid].m_label;
	return true;
};

bool VoxSoundPackXML::GetDataSourceInfo(const c8* label, data_source::CreationSettings &dataSourceSettings) const
{
	if(!data)
		return false;

	s32 soundUid = GetSoundUid(label);
	return GetDataSourceInfo(soundUid, dataSourceSettings);
}

bool VoxSoundPackXML::GetDataSourceInfo(s32 soundUid, data_source::CreationSettings &dataSourceSettings) const
{
	if(!data)
		return false;

	if(soundUid < 0 || soundUid >= (s32)data->m_soundVector.size())
		return false;

	dataSourceSettings.m_streamType = k_nStreamTypeCFile;
	dataSourceSettings.m_pStreamParams = (void *)(data->m_soundVector[soundUid].m_filename);
	dataSourceSettings.m_decoderType = data->m_soundVector[soundUid].m_format;
	dataSourceSettings.m_pDecoderParams = 0;
	dataSourceSettings.m_loadingFlags = data->m_soundVector[soundUid].m_loadingFlags;

	// dataSourceInfo.m_groupId = data->m_soundVector[soundUid].m_groupId; ????
	// dataSourceInfo.m_bankId = data->m_soundVector[soundUid].m_bankId; ????

	dataSourceSettings.m_uid = soundUid;
	dataSourceSettings.m_groupId = data->m_soundVector[soundUid].m_groupId;
	// Get custom parameters
	dataSourceSettings.m_numCustomSound = data->m_soundVector[soundUid].m_numCustomSound;
	dataSourceSettings.m_customSoundStr = data->m_soundVector[soundUid].m_customSoundStr;

	return true;
}




bool VoxSoundPackXML::GetEmitterInfo(const c8* label, emitter::CreationSettings &emitterSettings) const
{
	if(!data)
		return false;

	s32 soundUid = GetSoundUid(label);
	return GetEmitterInfo(soundUid, emitterSettings);
}

bool VoxSoundPackXML::GetEmitterInfo(s32 soundUid, emitter::CreationSettings &emitterSettings) const
{
	if(!data)
		return false;

	if(soundUid < 0 || soundUid >= (s32)data->m_soundVector.size())
		return false;

	// Get sound label?????

	const c8* busName;
	Vox3DSoundType is3d;

	busName = data->m_soundVector[soundUid].m_bus;
	is3d = data->m_soundVector[soundUid].m_is3D;

	emitterSettings.m_gain = data->m_soundVector[soundUid].m_baseGain;
	emitterSettings.m_maximumRandomGainRatio = data->m_soundVector[soundUid].m_maxGainMod;
	emitterSettings.m_minimumRandomGainRatio = data->m_soundVector[soundUid].m_minGainMod;
	emitterSettings.m_enableRandomGain = data->m_soundVector[soundUid].m_isGainRandom;

	emitterSettings.m_pitch = data->m_soundVector[soundUid].m_basePitch;
	emitterSettings.m_maximumRandomPitchCents = data->m_soundVector[soundUid].m_maxPitchMod;
	emitterSettings.m_minimumRandomPitchCents = data->m_soundVector[soundUid].m_minPitchMod;
	emitterSettings.m_enableRandomPitch = data->m_soundVector[soundUid].m_isPitchRandom;

	emitterSettings.m_isLoop = data->m_soundVector[soundUid].m_isLoop;

	VoxEngine &vox = VoxEngine::GetVoxEngine();
	const char *groupName = data->m_groupVector[data->m_soundVector[soundUid].m_groupId].m_name.c_str();
	emitterSettings.m_groupId = vox.GetGroupId(groupName);

	//Bank
	const char *bankName = data->m_bankVector[data->m_soundVector[soundUid].m_bankId].m_name.c_str();
	emitterSettings.m_priorityBankId = vox.GetPriorityBankIdFromName(bankName);
	emitterSettings.m_priority = data->m_soundVector[soundUid].m_priority;

	//3d parameters
	emitterSettings.m_is3d = (data->m_soundVector[soundUid].m_is3D != k_n3DSoundTypeNone);
	emitterSettings.m_pEmitter3DParameters.referenceDistance = data->m_soundVector[soundUid].m_referenceDistance;
	emitterSettings.m_pEmitter3DParameters.maxDistance = data->m_soundVector[soundUid].m_maxDistance;
	emitterSettings.m_pEmitter3DParameters.rolloffFactor = data->m_soundVector[soundUid].m_rolloffFactor;
	emitterSettings.m_pEmitter3DParameters.relativeToListener = (data->m_soundVector[soundUid].m_is3D != k_n3DSoundTypeAbsolute ? 1 : 0);

	// bus
	emitterSettings.m_busName = busName;

	// misc
	emitterSettings.m_killOnResume = data->m_soundVector[soundUid].m_killOnResume;
	emitterSettings.m_fadeOnPlay = data->m_soundVector[soundUid].m_fadeOnPlay;
	emitterSettings.m_fadeOnStop = data->m_soundVector[soundUid].m_fadeOnStop;

	emitterSettings.m_uid = soundUid;

	emitterSettings.m_pEmitterHandleUserData = 0;  // ????
	emitterSettings.m_stateChangedCallback = 0; // ????
	emitterSettings.m_pStateChangedCallbackUserData = 0; // ????

	emitterSettings.m_numCustomSound = data->m_soundVector[soundUid].m_numCustomSound;
	emitterSettings.m_customSoundStr = data->m_soundVector[soundUid].m_customSoundStr;

	return true;
}

bool VoxSoundPackXML::GetEmitterInfoFromSoundOrEvent(const c8* label, emitter::CreationSettings &emitterInfo)
{
	if(!data)
		return false;

	// If there is no sound with the specified label, search for an event.
	if(!GetEmitterInfo(label, emitterInfo))
	{
		s32 soundUid;

		if(GetEventSoundUid(label, soundUid))
		{
			return GetEmitterInfo(soundUid, emitterInfo);
		}
		
		return false;
	}
	return true;
}


bool VoxSoundPackXML::GetSoundCustomParam(const c8* soundLabel, s32 index, const c8* &param)
{
	if(!data)
		return false;

	s32 uid = GetSoundUid(soundLabel);
	return GetSoundCustomParam(uid, index, param);	
}

bool VoxSoundPackXML::GetSoundCustomParam(s32 soundUid, s32 index, const c8* &param)
{
	if(!data)
		return false;

	if(soundUid >= 0 && soundUid < (s32)data->m_soundVector.size())
	{
		if(index < data->m_soundVector[soundUid].m_numCustomSound)
		{
			param = data->m_soundVector[soundUid].m_customSoundStr[index];
			return true;
		}
		else
		{
			param = 0;
			return false;
		}		
	}
	return false;
}

s32 VoxSoundPackXML::GetEventUid(const c8* eventLabel) const
{
	if(!data)
		return -1;

	for(u32 i = 0; i < data->m_eventVector.size(); i++)
	{
#if defined(_WIN32)
		if(_stricmp(data->m_eventVector[i].m_label, eventLabel) == 0)
#else
		if(strcasecmp(data->m_eventVector[i].m_label, eventLabel) == 0)
#endif
		{
			return i;
		}
	}

	return -1;
}

bool VoxSoundPackXML::GetEventInfo(const c8* label, EventInfoXML &eventInfo) const
{
	if(!data)
		return false;

	s32 uid = GetEventUid(label);
	return GetEventInfo(uid, eventInfo);
}

bool VoxSoundPackXML::GetEventInfo(s32 eventUid, EventInfoXML &eventInfo) const 
{
	if(!data)
		return false;

	if(eventUid < 0 || eventUid >= (s32)data->m_eventVector.size())
		return false;

	eventInfo.m_id = eventUid;
	eventInfo.m_label = data->m_eventVector[eventUid].m_label;
	
	eventInfo.m_numSounds = (s32)data->m_eventVector[eventUid].m_soundIds.size();
	eventInfo.m_pSoundIds = 0;
	if(eventInfo.m_numSounds != 0)
	{
		eventInfo.m_pSoundIds = &data->m_eventVector[eventUid].m_soundIds[0];
	}

	eventInfo.m_eventType = static_cast<VoxSoundPackEventType>(data->m_eventVector[eventUid].m_eventType);
	eventInfo.m_eventParam = data->m_eventVector[eventUid].m_eventParam;
	eventInfo.m_playbackProbability = data->m_eventVector[eventUid].m_playbackProbability;		

	eventInfo.m_cooldownValue  = data->m_eventVector[eventUid].m_cooldownValue;
	eventInfo.m_cooldownType   = data->m_eventVector[eventUid].m_cooldownType;

	eventInfo.m_numCustomEvent = data->m_eventVector[eventUid].m_numCustomEvent;
	eventInfo.m_customEventStr = data->m_eventVector[eventUid].m_customEventStr;

	return true;
}

bool VoxSoundPackXML::GetEventSoundUid(const c8* eventLabel, s32 &soundUid) 
{
	if(!data)
		return false;

	s32 uid = GetEventUid(eventLabel);
	return GetEventSoundUid(uid, soundUid);
}

bool VoxSoundPackXML::GetEventSoundUid(s32 eventUid, s32 &soundUid) 
{
	if(!data)
		return false;

	if(eventUid >=0 && eventUid < (s32)data->m_eventVector.size())
	{
		s32 _size = data->m_eventVector[eventUid].m_soundIds.size();
		if( _size <= 0)
			return false;


		// First, check for cooldown
		switch(data->m_eventVector[eventUid].m_cooldownType)
		{
			case k_nCooldownTypeTime:
			default:
			{
				f64 timer = _GetTime();
				f32 timeLapse = (f32)(timer - data->m_eventVector[eventUid].m_cooldownCounter);
				if (timeLapse < 0)
				{
					timeLapse = 0;
					data->m_eventVector[eventUid].m_cooldownCounter = timer;
				}
				if( timeLapse < data->m_eventVector[eventUid].m_cooldownValue)
				{
					soundUid = -1;
					return true;
				}
				else
				{
					data->m_eventVector[eventUid].m_cooldownCounter = timer;
				}
				break;
			}
			case k_nCooldownTypePlays:
			{
				if(data->m_eventVector[eventUid].m_cooldownCounter < 0)
				{
					data->m_eventVector[eventUid].m_cooldownCounter = 0;
				}
				data->m_eventVector[eventUid].m_cooldownCounter -= 1;
				if(data->m_eventVector[eventUid].m_cooldownCounter > data->m_eventVector[eventUid].m_cooldownValue)
				{
					data->m_eventVector[eventUid].m_cooldownCounter = data->m_eventVector[eventUid].m_cooldownValue;
				}
				if(data->m_eventVector[eventUid].m_cooldownCounter >= 0)
				{
					soundUid = -1;
					return true;
				}
				data->m_eventVector[eventUid].m_cooldownCounter += data->m_eventVector[eventUid].m_cooldownValue;

				break;
			}
		}

		// Next, check for random probability
		if(rand() % 100 >= data->m_eventVector[eventUid].m_playbackProbability)
		{
			soundUid = -1;
			return true;
		}

		switch((VoxSoundPackEventType)data->m_eventVector[eventUid].m_eventType)
		{
			case k_nEventTypeRandom:
			{
				//choose randomly in current available sound
				_size = data->m_eventVector[eventUid].m_soundIds.size();
				s32 _id = rand() % _size;
				soundUid = data->m_eventVector[eventUid].m_soundIds[_id];

				//send the sound in "penalty" for m_eventParam event
				data->m_eventVector[eventUid].m_usedSoundIds.push_back(soundUid);
				data->m_eventVector[eventUid].m_soundIds[_id] = data->m_eventVector[eventUid].m_soundIds[_size - 1];
				data->m_eventVector[eventUid].m_soundIds.pop_back();

				//if penalty box full or active list empty, sent the oldest back to available soundids
				if((s32)data->m_eventVector[eventUid].m_usedSoundIds.size() > data->m_eventVector[eventUid].m_eventParam || data->m_eventVector[eventUid].m_soundIds.size() == 0)
				{
					data->m_eventVector[eventUid].m_soundIds.push_back(data->m_eventVector[eventUid].m_usedSoundIds.front());
					data->m_eventVector[eventUid].m_usedSoundIds.pop_front();
				}
				break;
			}
			case k_nEventTypePlaylist:
			case k_nEventTypePlRandom:
			{
				if(data->m_eventVector[eventUid].m_currentEvent >= _size)
				{
					data->m_eventVector[eventUid].m_currentEvent = 0;
				}

				soundUid = data->m_eventVector[eventUid].m_soundIds[data->m_eventVector[eventUid].m_currentEvent++];
				break;
			}
			default:
			{
				break;
			}
		}

		return true;
	}

	return false;
}

bool VoxSoundPackXML::ResetEvent(const c8* eventLabel)
{
	if(!data)
		return false;

	s32 uid = GetEventUid(eventLabel);
	return ResetEvent(uid);
}

bool VoxSoundPackXML::ResetEvent(s32 eventUid)
{
	if(!data)
		return false;

	if(eventUid <0 || eventUid >= (s32)data->m_eventVector.size())
		return false;
	
	if(data->m_eventVector[eventUid].m_eventType != k_nEventTypePlRandom)
	{
		data->m_eventVector[eventUid].m_currentEvent = (s32)data->m_eventVector[eventUid].m_soundIds.size();
	}
	else
	{
		data->m_eventVector[eventUid].m_currentEvent = rand() % (s32)data->m_eventVector[eventUid].m_soundIds.size();
	}

	while(data->m_eventVector[eventUid].m_usedSoundIds.size() > 0)
	{
		data->m_eventVector[eventUid].m_soundIds.push_back(data->m_eventVector[eventUid].m_usedSoundIds.front());
		data->m_eventVector[eventUid].m_usedSoundIds.pop_front();
	}

	data->m_eventVector[eventUid].m_cooldownCounter = -999999;

	return true;

	
}

s32 VoxSoundPackXML::GetEventSize(const c8* eventLabel)
{
	if(!data)
		return -1;

	s32 uid = GetEventUid(eventLabel);
	return GetEventSize(uid);
}

s32 VoxSoundPackXML::GetEventSize(s32 eventUid)
{
	if(!data)
		return -1;

	if(eventUid >= 0 && eventUid < (s32)data->m_eventVector.size())
	{
		return data->m_eventVector[eventUid].m_soundIds.size();
	}

	return -1;
}

bool VoxSoundPackXML::GetEventCustomParam(const c8* eventLabel, s32 index, const c8* &param)
{
	if(!data)
		return false;

	s32 uid = GetEventUid(eventLabel);
	return GetEventCustomParam(uid, index, param);	
}

bool VoxSoundPackXML::GetEventCustomParam(s32 eventUid, s32 index, const c8* &param)
{
	if(!data)
		return false;

	if(eventUid >= 0 && eventUid < (s32)data->m_eventVector.size())
	{
		if(index < data->m_eventVector[eventUid].m_numCustomEvent)
		{
			param = data->m_eventVector[eventUid].m_customEventStr[index];
			return true;
		}
		else
		{
			param = 0;
			return false;
		}		
	}
	return false;
}

bool VoxSoundPackXML::AutoSetupGroups()
{
	if(!data)
		return false;

	VoxEngine &vox = VoxEngine::GetVoxEngine();

	for(u32 i=0; i<data->m_groupVector.size(); i++) // don't have to register master group
	{
		u32 id = VOX_GROUP_INVALID_ID;


		group::CreationSettings cs;
		GetGroupInfo(i, cs);

		if(i!=0) // Do not register master group!
			id = vox.AddGroup(cs);
		else
		{
			id = 0;
			vox.ReconfigureGroup(i, cs);
		}

		if(id == VOX_GROUP_INVALID_ID)
		{
			VOX_WARNING_LEVEL_3("Cannot allocate group! (%d groups in SDD)", i);
			return false;
		}

	}
	return true;
}

bool VoxSoundPackXML::AutoSetupBanks()
{
	if(!data)
		return false;

	VoxEngine &vox = VoxEngine::GetVoxEngine();	

	for(u32 i=0; i<data->m_bankVector.size(); i++) // don't have to register default bank
	{
		u32 id = VOX_BANK_INVALID_ID;

		priority_bank::CreationSettings cs;
		GetBankInfo(i, cs);

		if(i!=0) // Do not allocate first bank!
			id = vox.AddPriorityBank(cs);
		else // setup first bank
		{
			id = 0;
			vox.ReconfigurePriorityBank(0, cs);
		}
			
		if(id == VOX_BANK_INVALID_ID)
		{
			VOX_WARNING_LEVEL_3("Cannot allocate bank! (%d banks in SDD)", i);
			return false;
		}

	}
	return true;
}
s32 VoxSoundPackXML::GetSoundCount() const
{
	if(!data)
		return 0;
	return (s32)data->m_soundVector.size();
}

s32 VoxSoundPackXML::GetBankCount() const
{
	if(!data)
		return 0;
	return (s32)data->m_bankVector.size();
}

s32 VoxSoundPackXML::GetGroupCount() const
{
	if(!data)
		return 0;
	return (s32)data->m_groupVector.size();
}

s32 VoxSoundPackXML::GetEventCount() const
{
	if(!data)
		return 0;
	return (s32)data->m_eventVector.size();
}



} // namespace vox

#endif //VOX_USE_SOUNDPACK_XML


