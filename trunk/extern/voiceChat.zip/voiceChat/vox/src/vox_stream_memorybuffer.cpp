
#include "StdAfx.h"
#include "vox_stream_memorybuffer.h"
#include "vox_default_config.h"
#include "vox.h"
#include "vox_memory.h"
#include "vox_profiler.h"

#include <string.h> // for memcpy

namespace vox {

StreamInterface* StreamMemoryBufferFactory(void* params)
{
	StreamMemoryBuffer* stream = VOX_NEW StreamMemoryBuffer( (StreamMemoryBufferParams*)params );
	VOX_ASSERT( stream );
	return stream;
}

///

StreamMemoryBuffer::StreamMemoryBuffer( StreamMemoryBufferParams* params ) 
: m_buffer(0), m_isBufferOwned(true) 
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamMemoryBuffer::StreamMemoryBuffer", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT(params);
	if ( params )
	{
		m_streamSize = params->size;
		m_isBufferOwned = params->doCopy || params->takeOwnership;
		//if ( m_isBufferOwned )
		if(params->doCopy && !params->takeOwnership) //if takeOwnership is true, buffer is not copied
		{
			if ( m_streamSize > 0 )
			{
#if defined(_NN_CTR)
				m_buffer = (u8*)VOX_ALLOC_ALIGN(m_streamSize, (vox::VoxMemHint)(vox::k_nVoxMemHint_Align32 | vox::k_nVoxMemHint_RamBuffer));
#else
				m_buffer = (u8*)VOX_ALLOC(m_streamSize);
#endif
				if(m_buffer)
					memcpy( m_buffer, params->buffer, m_streamSize );
				else
					m_streamSize = 0;
			}
		}
		else
		{
			m_buffer = params->buffer;
		}	
	}
}

StreamMemoryBuffer::~StreamMemoryBuffer()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamMemoryBuffer::~StreamMemoryBuffer", vox::VoxThread::GetCurThreadId());
	if ( m_buffer && m_isBufferOwned )
	{
		VOX_FREE(m_buffer);
	}
}

StreamCursorInterface* StreamMemoryBuffer::CreateNewCursor()
{
	if(m_buffer)
		return VOX_NEW StreamMemoryBufferCursor(this);
	else
		return 0;
}

void StreamMemoryBuffer::DestroyCursor(StreamCursorInterface* pStreamCursor)
{
	VOX_DELETE (pStreamCursor);
}
///

s32 StreamMemoryBufferCursor::Seek( s32 pos, s32 origin )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamMemoryBufferCursor::Seek", vox::VoxThread::GetCurThreadId());
	s32 currentPosition = m_cursorPosition;
	switch(origin)
	{
		case ORIGIN_START:
		{
			currentPosition = pos;
			break;
		}
		case ORIGIN_CURRENT:
		{
			currentPosition += pos;
			break;
		}
		case ORIGIN_END:
		{
			currentPosition = Size() - pos - 1;
			break;
		}
	}
	
	if(currentPosition < 0 || currentPosition > Size())
	{
		return -1;
	}
	else
	{
		m_cursorPosition = currentPosition;
		return 0;
	}
}

s32 StreamMemoryBufferCursor::ReadRef( u8* &buff, s32 len )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamMemoryBufferCursor::ReadRef", vox::VoxThread::GetCurThreadId());
	StreamMemoryBuffer* stream = (StreamMemoryBuffer*)m_pStream;
	if ( stream && stream->GetBuffer() && (len > 0))
	{
		s32 buffSize = Size();
		s32 remain = buffSize - m_cursorPosition;
		if ( len > remain )
		{
			len = remain;			
		}

		buff = stream->GetBuffer() + m_cursorPosition;

		m_cursorPosition += len;
		return len;
	}
	else
	{
		return 0;
	}
}

s32 StreamMemoryBufferCursor::Read( u8* buff, s32 len )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamMemoryBufferCursor::Read", vox::VoxThread::GetCurThreadId());
	StreamMemoryBuffer* stream = (StreamMemoryBuffer*)m_pStream;
	if ( buff && stream && stream->GetBuffer() && (len > 0))
	{
		s32 buffSize = Size();
		s32 remain = buffSize - m_cursorPosition;
		if ( len > remain )
		{
			len = remain;			
		}
		memcpy( buff, stream->GetBuffer() + m_cursorPosition, len );
		m_cursorPosition += len;
		return len;
	}
	else
	{
		return 0;
	}
}

bool StreamMemoryBufferCursor::EndOfStream()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamMemoryBufferCursor::EndOfStream", vox::VoxThread::GetCurThreadId());
	s32 buffSize = Size();
	return (buffSize - m_cursorPosition) == 0;
}

} //namespace vox


