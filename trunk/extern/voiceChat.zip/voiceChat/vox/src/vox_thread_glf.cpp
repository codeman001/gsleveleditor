
#include "StdAfx.h"
#include "vox_thread.h"
#include "vox_default_config.h"
#include "vox_macro.h"
#include "vox_profiler.h"

extern vox::f64 _GetTime();

#if VOX_USE_GLF
#include <glf/core/thread.h>
typedef glf::ThreadT<32 * 1024> voxThreadType;

namespace vox
{

class VoxRunnable : public glf::Runnable
{
public:
	VoxRunnable(c8* name):m_name(name), glf::Runnable(), m_alive(true){}
	virtual ~VoxRunnable(){}
	virtual void Run();

public:
	ThreadUpdateCallback m_callbackMethod;
	void* m_caller;
	void* m_param;

	c8* m_name;

	f64 m_lastUpdate;

	bool m_alive;

	voxThreadType m_internThread;
};

void VoxRunnable::Run()
{
	VOX_PROFILING_REGISTER_THREAD( m_name, vox::VoxThread::GetCurThreadId());

	while(m_alive)
	{
		f64 preUpdateTime = _GetTime();
		m_callbackMethod(m_caller, m_param);

		f64 curtime = _GetTime();

		s32 sleepTime = VOX_THREAD_UPDATE_DT + (VOX_THREAD_UPDATE_DT - (s32)((preUpdateTime - m_lastUpdate) * 1000));
		if(sleepTime > VOX_THREAD_UPDATE_DT)
		sleepTime = VOX_THREAD_UPDATE_DT;

		sleepTime -= (s32)((curtime - preUpdateTime) * 1000);

		m_lastUpdate = preUpdateTime;

		if(sleepTime < 1)
			sleepTime = 1;
			
		glf::Thread::Sleep(sleepTime);
	}
}

VoxThread::VoxThread(ThreadUpdateCallback callbackMethod, void* caller, void* param, const c8* name):
	m_updateCallback(callbackMethod),
	m_caller(caller),
	m_param(param),
	m_update(true),
	m_alive(true) ,
	m_lastUpdate(0.0)
{
	VOX_ASSERT_MSG(m_updateCallback, "No callback defined, no thread created");
	if(m_updateCallback == 0)
	{
		m_alive = false;
	}
	else
	{
		if(name != 0)
		{
			strncpy(m_name, name, 63);
			m_name[63] = 0;
		}
		else
		{
			strcpy(m_name, "VoxThread");
		}

		m_voxRunnable = VOX_NEW VoxRunnable(m_name);
		if(m_voxRunnable)
		{
			m_voxRunnable->m_callbackMethod = m_updateCallback;
			m_voxRunnable->m_caller = caller;
			m_voxRunnable->m_param = param;
			m_voxRunnable->m_internThread.Start(*m_voxRunnable);
		}
		else
		{
			VOX_ASSERT_MSG(m_voxRunnable, "Could not create runnable for thread");
		}
	}
}

VoxThread::~VoxThread()
{
	Stop();
}

void VoxThread::Stop()
{
	m_mutex.Lock();
	m_update = false;
	m_alive = false;
	m_mutex.Unlock();
	
	m_voxRunnable->m_alive = false;
	m_voxRunnable->m_internThread.Join();
}

void VoxThread::_Update()
{
}


void VoxThread::Sleep(u32 sleepTimeMs)
{
	glf::Thread::Sleep(sleepTimeMs);
}

u32 VoxThread::GetCurThreadId()
{
	glf::Thread& t = glf::Thread::GetCurrent();
	return (u32)&t;
}

}

#endif //VOX_USE_GLF


