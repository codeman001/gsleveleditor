
#include "StdAfx.h"
#include "vox_thread.h"
#include "vox_default_config.h"
#include "vox_macro.h"
#include "vox_profiler.h"

extern vox::f64 _GetTime();

#if VOX_USE_PTHREAD && !VOX_USE_GLF
#include <pthread.h>
#include <unistd.h>
typedef pthread_t voxThreadType;

namespace vox
{

class VoxRunnable
{
public:
	VoxRunnable(){};
	~VoxRunnable(){};

	friend class VoxThread;

public:
	voxThreadType m_internThread;

	static void* Run(void* iValue);
};

void* VoxRunnable::Run(void* iValue)
{
	((VoxThread*)iValue)->_Update();

	return 0;
};

VoxThread::VoxThread(ThreadUpdateCallback callbackMethod, void* caller, void* param, const c8* name):
	m_updateCallback(callbackMethod),
	m_caller(caller),
	m_param(param),
	m_update(true),
	m_alive(true) ,
	m_lastUpdate(0.0)
{
	VOX_ASSERT_MSG(m_updateCallback, "No callback defined, no thread created");
	if(m_updateCallback == 0)
	{
		m_alive = false;
	}
	else
	{
		m_voxRunnable = VOX_NEW VoxRunnable();
		if(m_voxRunnable == 0)
		{
			m_alive = false;
			VOX_ASSERT_MSG(m_voxRunnable, "Unable to create new VoxUpdatable, no thread created");
		}
		else
		{
			if(name != 0)
			{
				strncpy(m_name, name, 63);
				m_name[63] = 0;
			}
			else
			{
				strcpy(m_name, "VoxThread");
			}

			s32 result = pthread_create(&m_voxRunnable->m_internThread, 0, vox::VoxRunnable::Run, this);
			if(result != 0)
			{
				VOX_WARNING_LEVEL_1("%s","Error in Creating thread\n");
			}
#	if VOX_OVERRIDE_PTHREAD_DEFAULT_PRIORITY
			else
			{
				sched_param param;
				int sched_mode;
				pthread_getschedparam(m_voxRunnable->m_internThread, &sched_mode, &param);
				VOX_WARNING_LEVEL_5("Thread %d created with priority %d scheduler policy %d", (s32)m_voxRunnable->m_internThread, param.sched_priority, sched_mode);	
				
				s32 minprio = sched_get_priority_min(sched_mode);
				s32 maxprio = sched_get_priority_max(sched_mode);
				
				s32 threadprio = (VOX_PTHREAD_PRIORITY <= maxprio) ? ( VOX_PTHREAD_PRIORITY >= minprio ? VOX_PTHREAD_PRIORITY : minprio ) : maxprio ;
				
				sched_param param_thread;
				param_thread.sched_priority = threadprio;
				pthread_setschedparam(m_voxRunnable->m_internThread, sched_mode, &param_thread);

				pthread_getschedparam(m_voxRunnable->m_internThread, &sched_mode, &param);
				VOX_WARNING_LEVEL_5("Thread %d scheduler modified to priority %d scheduler policy %d", (s32)m_voxRunnable->m_internThread, param.sched_priority, sched_mode);	
			}
#	endif
		}
	}
}

VoxThread::~VoxThread()
{
	Stop();
}

void VoxThread::Stop()
{
	m_mutex.Lock();
	m_update = false;
	m_alive = false;
	m_mutex.Unlock();
	
	pthread_join(m_voxRunnable->m_internThread, 0);

	VOX_DELETE(m_voxRunnable);
}

void VoxThread::_Update()
{
	bool update, alive;

	m_mutex.Lock();
	update = m_update;
	alive = m_alive;
	m_mutex.Unlock();

	VOX_PROFILING_REGISTER_THREAD( m_name, vox::VoxThread::GetCurThreadId());

	while(alive)
	{
		f64 preUpdateTime = _GetTime();

		if(update)
		{
			m_updateCallback(m_caller, m_param);
		}

		f64 curtime = _GetTime();

		s32 sleepTime = VOX_THREAD_UPDATE_DT + (VOX_THREAD_UPDATE_DT - (s32)((preUpdateTime - m_lastUpdate) * 1000));
		//if(sleepTime > VOX_THREAD_UPDATE_DT)
		//	sleepTime = VOX_THREAD_UPDATE_DT;

		sleepTime -= (s32)((curtime - preUpdateTime) * 1000);

		m_lastUpdate = preUpdateTime;

		if(sleepTime < 1)
			sleepTime = 1;
		else if(sleepTime > VOX_THREAD_UPDATE_DT)
			sleepTime = VOX_THREAD_UPDATE_DT;

		VoxThread::Sleep(sleepTime);

		m_mutex.Lock();
		update = m_update;
		alive = m_alive;
		m_mutex.Unlock();
	}
}

void VoxThread::Sleep(u32 sleepTimeMs)
{
	usleep(sleepTimeMs*1000);
}

u32 VoxThread::GetCurThreadId()
{
	return (u32)pthread_self();
}

}

#endif //VOX_USE_PTHREAD


