
#include "StdAfx.h"
#include "vox_thread.h"
#include "vox_default_config.h"
#include "vox_macro.h"
#include "vox_profiler.h"

extern vox::f64 _GetTime();

#if defined(_WIN32) && !VOX_USE_GLF
#if VOX_DEBUG_SERVER_ENABLE
#define _WINSOCKAPI_
#endif
#include <windows.h>
typedef HANDLE voxThreadType;

namespace vox
{

class VoxRunnable
{
public:
	VoxRunnable(){};
	~VoxRunnable(){};

	friend class VoxThread;

public:
	voxThreadType m_internThread;

	static DWORD WINAPI Run(LPVOID iValue);
};

DWORD WINAPI VoxRunnable::Run(LPVOID iValue)
{
	((VoxThread*)iValue)->_Update();

	return 0;
};

VoxThread::VoxThread(ThreadUpdateCallback callbackMethod, void* caller, void* param, const c8* name):
	m_updateCallback(callbackMethod),
	m_caller(caller),
	m_param(param),
	m_update(true),
	m_alive(true) ,
	m_lastUpdate(0.0)
{
	VOX_ASSERT_MSG(m_updateCallback, "No callback defined, no thread created");
	if(m_updateCallback == 0)
	{
		m_alive = false;
	}
	else
	{
		m_voxRunnable = VOX_NEW VoxRunnable();
		if(m_voxRunnable == 0)
		{
			m_alive = false;
			VOX_ASSERT_MSG(m_voxRunnable, "Unable to create new VoxUpdatable, no thread created");
		}
		else
		{
			if(name != 0)
			{
				strncpy(m_name, name, 63);
				m_name[63] = 0;
			}
			else
			{
				strcpy(m_name, "VoxThread");
			}

			DWORD dwGenericThread;
			m_voxRunnable->m_internThread = CreateThread(NULL,0, &vox::VoxRunnable::Run, this, 0, &dwGenericThread);
			if(m_voxRunnable->m_internThread == NULL)
			{
				DWORD dwError = GetLastError();
				VOX_WARNING_LEVEL_1("Error in Creating thread %d\n", dwError);
			}
		}
	}
}

VoxThread::~VoxThread()
{
	Stop();
}

void VoxThread::Stop()
{
	m_mutex.Lock();
	m_update = false;
	m_alive = false;
	m_mutex.Unlock();
	
    WaitForSingleObject(m_voxRunnable->m_internThread,INFINITE);

	VOX_DELETE(m_voxRunnable);
}

void VoxThread::_Update()
{
	bool update, alive;

	m_mutex.Lock();
	update = m_update;
	alive = m_alive;
	m_mutex.Unlock();

	VOX_PROFILING_REGISTER_THREAD( m_name, vox::VoxThread::GetCurThreadId());

	while(alive)
	{
		f64 preUpdateTime = _GetTime();

		if(update)
		{
			m_updateCallback(m_caller, m_param);
		}

		f64 curtime = _GetTime();

		s32 sleepTime = VOX_THREAD_UPDATE_DT + (VOX_THREAD_UPDATE_DT - (s32)((preUpdateTime - m_lastUpdate) * 1000));
		//if(sleepTime > VOX_THREAD_UPDATE_DT)
		//	sleepTime = VOX_THREAD_UPDATE_DT;

		sleepTime -= (s32)((curtime - preUpdateTime) * 1000);

		m_lastUpdate = preUpdateTime;

		if(sleepTime < 1)
			sleepTime = 1;
		else if(sleepTime > VOX_THREAD_UPDATE_DT)
			sleepTime = VOX_THREAD_UPDATE_DT;

		VoxThread::Sleep(sleepTime);

		m_mutex.Lock();
		update = m_update;
		alive = m_alive;
		m_mutex.Unlock();
	}
}

void VoxThread::Sleep(u32 sleepTimeMs)
{
	SleepEx(sleepTimeMs, true);
}

u32 VoxThread::GetCurThreadId()
{
	return (u32)GetCurrentThreadId();
}

}

#endif //_WIN32


