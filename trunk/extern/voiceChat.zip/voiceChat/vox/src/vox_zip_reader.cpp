
#include "StdAfx.h"
#include "vox_zip_reader.h"
#include "vox_filesystem.h"
#include "MSHeaders.h"
#include "vox_macro.h"
#include <string.h>

namespace vox
{

CZipReader::CZipReader(const c8* filename, bool ignoreCase, bool ignorePaths)
:File(0)
,IgnoreCase(ignoreCase)
,IgnorePaths(ignorePaths)
,m_isValid(false)
,m_hasExtensionTable(false)
{
	ZipTableSerializer zipSerializer(filename, k_nZipExtensionRead);

	// Determine whether the zip file has an extension or not
	VoxZipStreamStatus zipStatus = zipSerializer.GetStatus();

	// If zip file has an extension table, get sound files infos from table instead of scanning full file.
	if(zipStatus == k_nZipWithExtension)
	{
		m_hasExtensionTable = true;
		if(ImportHeader(zipSerializer))
		{
			m_archiveName = zipSerializer.GetFilePath();
			m_isValid = true;
		}
	}
	else if(zipStatus == k_nZipWithoutExtension) // File doesn't have an extension table.
	{
		// Close the zip serializer and use the FileSystemInterface to scan the whole zip file.
		zipSerializer.Close();

		FileSystemInterface* fs = vox::FileSystemInterface::GetInstance();

		if(fs)
			File = fs->_OpenFile((c8*)filename);

		if(File)
		{
			m_isValid = true;
			m_archiveName = File->GetFilePath();

			// Scan local headers
			while(scanLocalHeader());
		}
	}
}

CZipReader::~CZipReader()
{
	if(File)
	{
		FileSystemInterface* fs = vox::FileSystemInterface::GetInstance();
		fs->_CloseFile(File);
	}
}

//! splits filename from zip file into useful filenames and paths
void
CZipReader::extractFilename(SZipFileEntry* entry)
{
	s32 lorfn = entry->header.FilenameLength; // length of real file name

	if (!lorfn)
		return;

	if (IgnoreCase)
	{
		for (u32 i=0; i<entry->zipFileName.length(); ++i)
		{
			char x = entry->zipFileName[i];
			entry->zipFileName[i] = x >= 'A' && x <= 'Z' ? (char) x + 0x20 : (char) x;
		}
	}
	const c8* p = entry->zipFileName.c_str() + lorfn;
	
	// suche ein slash oder den anfang.

	while (*p!='/' && p!=entry->zipFileName.c_str())
	{
		--p;
		--lorfn;
	}

	bool thereIsAPath = p != entry->zipFileName.c_str();

	if (thereIsAPath)
	{
		// there is a path
		++p;
		++lorfn;
	}

	entry->simpleFileName = p;
	entry->path = "";

	// pfad auch kopieren
	if (thereIsAPath)
	{
		lorfn = (s32)(p - entry->zipFileName.c_str());
		
		entry->path = entry->zipFileName.substr( 0, lorfn );

		//entry->path.append(entry->zipFileName, lorfn);
		//entry->path.append ( "" );
	}

	if (!IgnorePaths)
		entry->simpleFileName = entry->zipFileName; // thanks to Pr3t3nd3r for this fix
}

//! scans for a local header, returns false if there is no more local file header.
bool CZipReader::scanLocalHeader()
{
	c8 tmp[1024];
	
	unsigned char headerBuffer[30];

	SZipFileEntry entry;
	entry.fileDataPosition = 0;
	
	memset(headerBuffer, 0, 30);
	File->Read(headerBuffer, 30, 1);
	entry.header.parseData(headerBuffer);

	if (entry.header.Sig != 0x04034b50 && entry.header.Sig != VOX_ZIP_MAGIC_NUMBER)
		return false; // local file headers end here.

	// read filename
	entry.zipFileName.reserve(entry.header.FilenameLength+2);
	File->Read(tmp, entry.header.FilenameLength, 1);
	tmp[entry.header.FilenameLength] = 0x0;
	entry.zipFileName = tmp;

	extractFilename(&entry);

	// move forward length of extra field.

	if (entry.header.ExtraFieldLength)
		File->Seek(entry.header.ExtraFieldLength, k_nSeekCur);

	// if bit 3 was set, read DataDescriptor, following after the compressed data
	if (entry.header.GeneralBitFlag & ZIP_INFO_IN_DATA_DESCRITOR)
	{
		// read data descriptor
		File->Read(headerBuffer+14, 12, 1);
		entry.header.parseDataDescriptor(headerBuffer+14);
	}

	// store position in file
	entry.fileDataPosition = File->Tell();//File->getPos();

	// move forward length of data
	File->Seek(entry.header.DataDescriptor.CompressedSize, k_nSeekCur);

	//#ifdef _DEBUG
	////os::Debuginfo::print("added file from archive", entry.simpleFileName.c_str());
	//#endif

	FileList[entry.simpleFileName] = entry;
	//FileList.push_back(entry);

	return true;
}

bool CZipReader::getFileInfo(const c8* filename, s32 &baseOffset, s32 &fileSize)
{
	VOX_STRING fname(filename);

	if(IgnorePaths)
		deletePathFromFilename(fname);

	if (IgnoreCase)
	{
		for (u32 i = 0; i < fname.length(); ++i)
		{
			char x = fname[i];
			fname[i] = x >= 'A' && x <= 'Z' ? (char) x + 0x20 : (char) x;
		}
	}

	VOX_MAP<VOX_STRING, SZipFileEntry, StringComp, SAllocator<std::pair<const VOX_STRING,SZipFileEntry> > >::const_iterator it = FileList.find(fname);
	if(it == FileList.end())
		return false;
	
	switch(it->second.header.CompressionMethod)
	{
		case 0: // no compression
		{
			baseOffset = it->second.fileDataPosition;
			fileSize = it->second.header.DataDescriptor.UncompressedSize;
			VOX_WARNING_LEVEL_5("Found file %s", filename);
			return true;
		}
		default:
		{
			VOX_WARNING_LEVEL_2("Archive file %s has unsupported compression method.", it->second.simpleFileName.c_str());
			return false;
		}
	};
}

// returns count of files in archive
s32 CZipReader::getFileCount()
{
	return FileList.size();
}

// deletes the path from a filename
void CZipReader::deletePathFromFilename(VOX_STRING& filename)
{
	// delete path from filename
	const c8* p = filename.c_str() + filename.size();

	// search for path separator or beginning

	while (*p!='/' && *p!='\\' && p!=filename.c_str())
		--p;

	if (p != filename.c_str())
	{
		++p;
		filename = p;
	}
}

bool CZipReader::ExportHeader(ZipTableSerializer& outStream)
{
	FileListMap::iterator cur = FileList.begin();
	FileListMap::iterator end = FileList.end();
	
	// Get nb of entries in extension table
	s32 nbEntries = FileList.size();

	if(nbEntries > 0)
	{
		// Write nb of entries in extension table
		outStream.WriteInt(nbEntries);

		// Write pertinent information for each entry
		for( ; cur != end ; ++cur)
		{
			//const VOX_STRING& key = (*cur).first;
			SZipFileEntry& value = (*cur).second;
			outStream.WriteInt(value.header.FilenameLength);
			outStream.Write((void*)value.zipFileName.c_str(), value.header.FilenameLength * sizeof(char));
			outStream.WriteInt(value.fileDataPosition);

			// Write used fields in current entry's header
			outStream.WriteShort(value.header.GeneralBitFlag);
			outStream.WriteShort(value.header.CompressionMethod);
			outStream.WriteInt(value.header.DataDescriptor.CompressedSize);
			outStream.WriteInt(value.header.DataDescriptor.UncompressedSize);
			outStream.WriteShort(value.header.ExtraFieldLength);
		}
		return true;
	}

	return false;
}

bool CZipReader::ImportHeader(ZipTableSerializer& inStream)
{
	static char buffer[MAX_ZIP_FILENAME];	//max filename size...

	s32 numEntries;
	s32 strSize;
	SZipFileEntry entry;
	s16 shortValue;
	s32 intValue;

	// If stream comes from a zip file without extension table, don't try reading into it.
	if(inStream.GetStatus() != k_nZipWithExtension)
		return false;

	inStream.ReadInt(numEntries);
	for(int i = 0; i < numEntries; i++)
	{
		inStream.ReadInt(strSize);	
		if(strSize < MAX_ZIP_FILENAME)
		{
			inStream.Read(buffer, strSize);
			buffer[strSize] = '\0';
			entry.zipFileName = buffer;
			inStream.ReadInt(entry.fileDataPosition);

			// Read current entry's header
			entry.header.Sig = VOX_ZIP_MAGIC_NUMBER;
			entry.header.VersionToExtract = -1;				// Not used
			inStream.ReadShort(shortValue);					// Use intermediate value because of compilation ...
			entry.header.GeneralBitFlag = shortValue;		// ... issue related to PS3 structure packing.
			inStream.ReadShort(shortValue);
			entry.header.CompressionMethod = shortValue;
			entry.header.LastModFileTime = -1;				// Not used
			entry.header.LastModFileDate = -1;				// Not used
			entry.header.DataDescriptor.CRC32 = -1;			// Not used
			inStream.ReadInt(intValue);
			entry.header.DataDescriptor.CompressedSize = intValue;
			inStream.ReadInt(intValue);
			entry.header.DataDescriptor.UncompressedSize = intValue;
			entry.header.FilenameLength = strSize;
			inStream.ReadShort(shortValue);
			entry.header.ExtraFieldLength = shortValue;
			
			extractFilename(&entry);
			FileList[entry.simpleFileName] = entry;
		}
		else
		{
			//a file with path of more then 1024 was in the header file, this is not supported...
			break;
		}
	}
	return true;
}

}


