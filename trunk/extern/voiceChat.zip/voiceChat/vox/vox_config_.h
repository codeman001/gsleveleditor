#ifndef _VOX_CONFIG_H_
#define _VOX_CONFIG_H_

// Your game should provide this file in the same folder where vox is external.

// You can override the default settings from "./vox/include/vox_default_config.h"

#endif //_VOX_CONFIG_H_