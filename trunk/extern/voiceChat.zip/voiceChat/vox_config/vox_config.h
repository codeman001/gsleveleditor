#ifndef _VOX_CONFIG_H_
#define _VOX_CONFIG_H_

#define VOX_MICROPHONE_INPUT		( 1 )

#endif //_VOX_CONFIG_H_