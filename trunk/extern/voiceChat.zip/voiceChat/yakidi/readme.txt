There is no setup.bat yet.
To install, create a directory "../yakidi_config" and copy "yak_extern_config_template.h" in that directory and rename it "yak_extern_config.h".