/*
 * Copyright (C) 2007 iptego GmbH
 * 
 * based on the SUN codec wrapper from twinklephone
 *  Copyright (C) 2005-2007  Michel de Boer <michel@twinklephone.com>
 *
 * This file is part of SEMS, a free SIP media server.
 *
 * SEMS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. This program is released under
 * the GPL with the additional exemption that compiling, linking,
 * and/or using OpenSSL is allowed.
 *
 * For a license to use the SEMS software under conditions
 * other than those described here, or to purchase support for this
 * software, please contact iptel.org by e-mail at the following addresses:
 *    info@iptel.org
 *
 * SEMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software 
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _ADPCM_H
#define _ADPCM_H

#include "g72x.h"
#include <stdlib.h>

#define PCM16_B2S(b) ((b) >> 1)
#define PCM16_S2B(s) ((s) << 1)

static long G726_create(void);
static void G726_destroy(long h_inst);

static inline int Pcm16_2_G726_16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );
static inline int G726_16_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );

static inline int Pcm16_2_G726_24( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );
static inline int G726_24_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );

static inline int Pcm16_2_G726_32( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );
static inline int G726_32_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );

static inline int Pcm16_2_G726_40( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );
static inline int G726_40_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );


static inline unsigned int g726_16_bytes2samples(long, unsigned int);
static inline unsigned int g726_16_samples2bytes(long, unsigned int);

static inline unsigned int g726_24_bytes2samples(long, unsigned int);
static inline unsigned int g726_24_samples2bytes(long, unsigned int);

static inline unsigned int g726_32_bytes2samples(long, unsigned int);
static inline unsigned int g726_32_samples2bytes(long, unsigned int);

static inline unsigned int g726_40_bytes2samples(long, unsigned int);
static inline unsigned int g726_40_samples2bytes(long, unsigned int);


struct G726_twoway {
  struct g72x_state to_g726;  
  struct g72x_state from_g726;  
};


static inline long G726_create() {
  struct G726_twoway* cinst = (G726_twoway*)calloc(1, sizeof(struct G726_twoway));
  if (!cinst)
    return 0;

  g72x_init_state(&cinst->to_g726);
  g72x_init_state(&cinst->from_g726);

  return (long) cinst;
}

static inline void G726_destroy(long h_inst) {
  if (h_inst)
    free((struct G726_twoway*) h_inst);
}

// 2 bits/sample
static inline unsigned int g726_16_bytes2samples(long h_codec, unsigned int num_bytes)
{  return num_bytes << 2; } 
static inline unsigned int g726_16_samples2bytes(long h_codec, unsigned int num_samples)
{  return num_samples >> 2; }

// 3 bits/sample
static inline unsigned int g726_24_bytes2samples(long h_codec, unsigned int num_bytes)
{   return (num_bytes * 8) / 3; }
static inline unsigned int g726_24_samples2bytes(long h_codec, unsigned int num_samples)
{  return (num_samples * 3) / 8; }

// 4 bits/sample
static inline unsigned int g726_32_bytes2samples(long h_codec, unsigned int num_bytes)
{  return num_bytes << 1; }
static inline unsigned int g726_32_samples2bytes(long h_codec, unsigned int num_samples)
{  return num_samples >> 1; }

// 5 bits/sample
static inline unsigned int g726_40_bytes2samples(long h_codec, unsigned int num_bytes)
{  return (num_bytes * 8) / 5; }
static unsigned int g726_40_samples2bytes(long h_codec, unsigned int num_samples)
{  return (num_samples * 5) / 8; }

static inline int Pcm16_2_G726_16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec ) {
  unsigned int i, j;  
  if (!h_codec)
    return -1;

  short* sample_buf = (short*)in_buf;
  struct G726_twoway* cs = (struct G726_twoway*)h_codec;

  for (i = 0; i < PCM16_B2S(size); i += 4) {
    out_buf[i >> 2] = 0;
    for (j = 0; j < 4; j++) {
      char v = g723_16_encoder(sample_buf[i+j],
			       AUDIO_ENCODING_LINEAR, 
			       &cs->to_g726);
      out_buf[i >> 2] |= v << ((3-j) * 2);
    }
  }
  
  return PCM16_B2S(size) >> 2;
}

static inline int G726_16_2_Pcm16(unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			   unsigned int channels, unsigned int rate, long h_codec ) {
  unsigned int i, j;
  if (!h_codec)
    return -1;

  short* pcm_buf = (short*)out_buf;
  struct G726_twoway* cs = (struct G726_twoway*)h_codec;

  for (i = 0; i < size; i++) {
    for (j = 0; j < 4; j++) {
      char w;
      w = (in_buf[i] >> ((3-j)*2)) & 0x3;
      pcm_buf[4*i+j] = g723_16_decoder(w, AUDIO_ENCODING_LINEAR, 
				       &cs->from_g726);
    }
  }

  return PCM16_S2B(size * 4);
}

static inline int Pcm16_2_G726_24( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec ) {
  unsigned int i, j;  
  if (!h_codec)
    return -1;
  short* sample_buf = (short*)in_buf;
  struct G726_twoway* cs = (struct G726_twoway*)h_codec;

  for (i = 0; i < PCM16_B2S(size); i += 8) {
    unsigned int v = 0;
    for (j = 0; j < 8; j++) {
	v |= (g723_24_encoder(sample_buf[i+j],
				    AUDIO_ENCODING_LINEAR, &cs->to_g726)) << ((7-j) * 3);
    }
    out_buf[(i >> 3) * 3] = (v & 0xff);
    out_buf[(i >> 3) * 3 + 1] = ((v >> 8) & 0xff);
    out_buf[(i >> 3) * 3 + 2] = ((v >> 16) & 0xff);
  }
  
  return (PCM16_B2S(size) >> 3) * 3;
}

static inline int G726_24_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec ) {
  unsigned int i, j;
  if (!h_codec)
    return -1;

  short* pcm_buf = (short*)out_buf;
  struct G726_twoway* cs = (struct G726_twoway*)h_codec;

  for (i = 0; i < size; i += 3) {
    unsigned int v = ((in_buf[i+2]) << 16) |
      ((in_buf[i+1]) << 8) |
      (in_buf[i]);
    
    for (j = 0; j < 8; j++) {
      char w;
	w = (v >> ((7-j)*3)) & 0x7;
	pcm_buf[8*(i/3)+j] = 
	  g723_24_decoder(w, AUDIO_ENCODING_LINEAR, &cs->from_g726);
    }
  }
  
  return PCM16_S2B(size * 8 / 3);
}

static inline int Pcm16_2_G726_32( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec ) {
  unsigned int i, j;  
  if (!h_codec)
    return -1;
  short* sample_buf = (short*)in_buf;
  struct G726_twoway* cs = (struct G726_twoway*)h_codec;
  
  for (i = 0; i < PCM16_B2S(size); i += 2) {
    out_buf[i >> 1] = 0;
    for (j = 0; j < 2; j++) {
      char v = g721_encoder(sample_buf[i+j],
			    AUDIO_ENCODING_LINEAR, &cs->to_g726);
      
	out_buf[i >> 1] |= v << ((1-j) * 4);
    }
  }
  
  return PCM16_B2S(size) >> 1;
}

static inline int G726_32_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec ) {

  unsigned int i, j;
  if (!h_codec)
    return -1;

  short* pcm_buf = (short*)out_buf;
  struct G726_twoway* cs = (struct G726_twoway*)h_codec;
  
  for (i = 0; i < size; i++) {
    for (j = 0; j < 2; j++) {
      char w;
      w = (in_buf[i] >> ((1-j)*4)) & 0xf;
      pcm_buf[2*i+j] = 
	g721_decoder(w, AUDIO_ENCODING_LINEAR,  &cs->from_g726);
    }
  }
	
  return PCM16_S2B(size * 2);
}

static inline int Pcm16_2_G726_40( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec ) {

  unsigned int i, j;  
  if (!h_codec)
    return -1;
  short* sample_buf = (short*)in_buf;
  struct G726_twoway* cs = (struct G726_twoway*)h_codec;

  for (i = 0; i < PCM16_B2S(size); i += 8) {
    unsigned long long v = 0;
    for (j = 0; j < 8; j++) {
#ifdef G726_PACK_RFC3551
	v |= ((unsigned long long)g723_40_encoder(sample_buf[i+j],
				       AUDIO_ENCODING_LINEAR, &cs->to_g726)) << (j * 5);
#else
	v |= ((unsigned long long)g723_40_encoder(sample_buf[i+j],
						 AUDIO_ENCODING_LINEAR, &cs->to_g726)) << ((7-j) * 5);
#endif
		}
    out_buf[(i >> 3) * 5] = (v & 0xff);
    out_buf[(i >> 3) * 5 + 1] = ((v >> 8) & 0xff);
    out_buf[(i >> 3) * 5 + 2] = ((v >> 16) & 0xff);
    out_buf[(i >> 3) * 5 + 3] = ((v >> 24) & 0xff);
    out_buf[(i >> 3) * 5 + 4] = ((v >> 32) & 0xff);
  }
	
  return (PCM16_B2S(size) >> 3) * 5;
}

static inline int G726_40_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec ) {

  unsigned int i, j;
  unsigned long long v;
  if (!h_codec)
    return -1;
  
  short* pcm_buf = (short*)out_buf;
  struct G726_twoway* cs = (struct G726_twoway*)h_codec;
  
  for (i = 0; i < size; i += 5) {
    v = ((unsigned long long)in_buf[i+4]) << 32  | 
      (unsigned long long)(in_buf[i+3]) << 24 | 
      (unsigned long long)(in_buf[i+2]) << 16 | 
      (unsigned long long)(in_buf[i+1]) << 8 | 
      (unsigned long long)(in_buf[i]); 
    
    for (j = 0; j < 8; j++) {
      char w;
	w = (v >> ((7-j)*5)) & 0x1f;
      pcm_buf[8*(i/5)+j] = 
	g723_40_decoder(w, AUDIO_ENCODING_LINEAR, &cs->from_g726);
    }
  }

  return PCM16_S2B(size * 8 / 5);
}


#endif // _ADPCM_H