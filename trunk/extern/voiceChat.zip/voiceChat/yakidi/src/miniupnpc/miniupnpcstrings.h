#ifndef __MINIUPNPCSTRINGS_H__
#define __MINIUPNPCSTRINGS_H__

#if defined (_WIN32)
#define OS_STRING "Windows"
#elif defined (__APPLE__)
#	ifdef OS_IPHONE
#		define OS_STRING "iOS"
#	else
#		define OS_STRING "MAC"
#	endif
#else
#define OS_STRING "Unknown"
#endif

#define MINIUPNPC_VERSION_STRING "1.6"

#endif
