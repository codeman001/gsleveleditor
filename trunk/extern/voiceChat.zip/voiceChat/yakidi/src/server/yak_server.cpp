#include "yak_server.h"
#include "../yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

static void* HttpEventHandler(enum mg_event event, struct mg_connection* conn, const struct mg_request_info* request_info);

Server::Server(unsigned short port, bool list)
	: m_running(true)
	, m_list(list)
	, m_session( NULL )
	, m_pServerCtx(0)
{
	m_bwOutCount		= 0;
	m_bwInCount			= 0;
	m_bwOut				= 0.0f;
	m_bwIn				= 0.0f;
	m_bwlastTime		= 0;

	m_enterTime = 0;
	m_exitTime	= 0;

	m_socket.Create( AF_INET, SOCK_DGRAM, 0 );
	m_socket.Bind( port );

	if (m_list)
	{
		CreateHttpInterface();
	}
}

Server::~Server()
{
	if( m_list )
	{
		DestroyHttpInterface();
	}
	
	m_socket.Close();
	yakdel( m_session );
}

void Server::Wait()
{
	static const int sleepTime = D_YAK_SLEEP_TIME_MICRO;

	int processTime = m_exitTime - m_enterTime;
	int safeSleep = MIN( sleepTime, MAX( 0, sleepTime  - processTime ) );

	SleepMicro( safeSleep );

    //printf("\n\n================   %.2f , %.2f    =============", processTime / 1000.0f, safeSleep / 1000.0f );
}

void Server::Update()
{
	m_enterTime	= S_GetTimeMicro();

    //printf("\n================================================");

	static char recvBlock[ D_YAK_PACKET_MAX_SIZE ];
	static int  recvSize = D_YAK_PACKET_MAX_SIZE;

	while( m_socket.CanRead() )
	{
		int ip				= 0;
		unsigned short port	= 0;

		int nRecv = m_socket.Receive( recvBlock, recvSize, &ip, &port );

		if( nRecv > 0 )
		{
			Buffer	buf( recvBlock, nRecv );
			Process( &buf, ip, port );

			m_bwInCount += nRecv;
		}
	}

    if( m_session != NULL ) {
        m_session->Update();
    }

    unsigned int now = S_GetTime();

	if( now - m_bwlastTime >= 1000 )
	{
		m_bwOut = m_bwOutCount * 8.0f / 1000.0f;
		m_bwIn	= m_bwInCount * 8.0f / 1000.0f;

		m_bwOutCount = 0;
		m_bwInCount  = 0;

		m_bwlastTime = now;
	}

	m_exitTime	= S_GetTimeMicro();

	//HeapCheck();
}

void Server::Send( int ip, unsigned short port, const char *buf, int len )
{
	int nBytes = m_socket.Send( ip, port, buf, len );
	m_bwOutCount += MAX( 0, nBytes );
}

void Server::Process( Buffer *buf, int ip, unsigned short port )
{
	char remote_request					= 0;
	char memberId						= 0;
	Conference::EServerRequest request	= static_cast<Conference::EServerRequest>( 0 );

	Peer::Address remoteAddress;
	Peer::Address localAddress;

	remoteAddress.m_ip					= ip;
	remoteAddress.m_port				= port;

	buf->ReadChar( &remote_request );

	request = static_cast<Conference::EServerRequest>( remote_request );
	switch(  request )
	{
	case Conference::eServerRequestServerInfo:
		{
			buf->ReadInt( &localAddress.m_ip );
			buf->ReadShort( (short*) &localAddress.m_port );

			OnRequestServerInfo( localAddress, remoteAddress );
		}
		break;

	case Conference::eServerRequestRemoteInfo:
		{
			buf->ReadInt( &localAddress.m_ip );
			buf->ReadShort( (short*) &localAddress.m_port );

			OnRequestRemoteInfo( localAddress, remoteAddress );
		}
		break;

	case Conference::eServerRequestJoin:
		{
			char remote_arch = 0;
			char remote_out_context = 0;
			char remote_in_context = 0;

			buf->ReadChar( &remote_arch );
			buf->ReadChar( &remote_out_context );
			buf->ReadChar( &remote_in_context );
			buf->ReadChar( &memberId );
			buf->ReadInt( &localAddress.m_ip );
			buf->ReadShort( (short*) &localAddress.m_port );

			EArchitecture arch		= static_cast<EArchitecture>( remote_arch );
			Codec::EContext outCtx	= static_cast<Codec::EContext>( remote_in_context );
			Codec::EContext inCtx	= static_cast<Codec::EContext>( remote_out_context );

			if( m_session == NULL )
			{
				m_session = yaknew Session( this, arch, outCtx, inCtx );
				yakout( "\nServer: Start new session by [%u]", memberId );
			}

			OnClientNewConnection( localAddress, remoteAddress, arch, outCtx, inCtx, memberId );
		}
		break;

	case Conference::eServerRequestLeave:
		{
			buf->ReadChar( &memberId );
			OnClientLeave( memberId );
		}
		break;

	case Conference::eServerRequestSignal:
		{
			buf->ReadChar( &memberId );
			OnClientSignal( memberId );
		}
		break;

	case Conference::eServerRequestForwardVoice:
		{
			char sourceMemberId		= -1;

			buf->ReadChar( &sourceMemberId );

			if( m_session != NULL && m_session->IsPartyConnected( sourceMemberId ) )
			{
                Party *party = Session::PP( m_session->m_allPeers[ sourceMemberId ] );

				unsigned int timestamp	= 0;
				unsigned short len		= 0;

				buf->ReadInt( &party->m_forwardMask );
				buf->ReadInt( ( int* ) &timestamp );
				buf->ReadShort( ( short* ) &len );

				if( m_session->GetArchitecture() != eArchitectureServer )
				{
					char	b[ D_YAK_PACKET_MAX_SIZE ];
					Buffer	bb( b, D_YAK_PACKET_MAX_SIZE );

					bb.WriteChar( Conference::eServerResponseForwardVoice );
					bb.WriteInt( timestamp );
					bb.WriteChar( sourceMemberId );
					bb.WriteShort( len );
					bb.WriteBlock( buf->GetPtrR(), len );

					for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
					{
						if( ( ( party->m_forwardMask >> k ) & 0x1 ) && m_session->IsPartyConnected( k ) )
						{
                            Party *sendparty = Session::PP( m_session->m_allPeers[ k ] );

							Send( sendparty->GetRemoteIP(), sendparty->GetRemotePort(),
											( const char* ) bb.GetData(), bb.GetSizeW() );
						}
					};
				}
				else {
					party->AddSoundFrame( S_GetTime(), buf->GetPtrR(), len );
				}
			}
		}
		break;

	case Conference::eServerRequestForwardPeerState:
		{
			char sourceMemberId		= -1;

			buf->ReadChar( &sourceMemberId );

			if( m_session != NULL && m_session->IsPartyConnected( sourceMemberId ) )
			{
				char  toPeer			= 0;
				char peerState			= 0;
				char peerAvailability	= 0;

				buf->ReadChar( &toPeer );
				buf->ReadChar( &peerState );
				buf->ReadChar( &peerAvailability );

				if( m_session->IsPartyConnected( toPeer ) )
				{
					char	b[ D_YAK_PACKET_MAX_SIZE ];
					Buffer	bb( b, D_YAK_PACKET_MAX_SIZE );

					bb.WriteChar( Conference::eServerResponseForwardPeerState );
					bb.WriteChar( sourceMemberId );
					bb.WriteChar( peerState );
					bb.WriteChar( peerAvailability );


                    Party *sendparty = Session::PP( m_session->m_allPeers[ toPeer ] );

					Send( sendparty->GetRemoteIP(), sendparty->GetRemotePort(),
									( const char* ) bb.GetData(), bb.GetSizeW() );
				}
			}
		}
		break;

	default:
		yakout( "\n Received Invalid Command", 0 );
	}
}

void Server::OnRequestServerInfo( Peer::Address &localAddress, Peer::Address &remoteAddress )
{
	// Send reply back
	char b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );
	bb.WriteChar( Conference::eServerResponseServerInfo );

	// client is already talking with the right server
	bb.WriteInt( 0 );
	bb.WriteShort( 0 );

	Send( remoteAddress.m_ip, remoteAddress.m_port,
					( const char* ) bb.GetData(), bb.GetSizeW() );
}

void Server::OnRequestRemoteInfo( Peer::Address &localAddress, Peer::Address &remoteAddress )
{
	// Send reply back
	char b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );
	bb.WriteChar( Conference::eServerResponseRemoteInfo );

	bb.WriteInt( remoteAddress.m_ip );
	bb.WriteShort( remoteAddress.m_port );

	Send( remoteAddress.m_ip, remoteAddress.m_port,
					( const char* ) bb.GetData(), bb.GetSizeW() );
}

void Server::OnClientNewConnection(
								   Peer::Address &localAddress,
								   Peer::Address &remoteAddress,
								   EArchitecture arch,
								   Codec::EContext outCtx,
								   Codec::EContext inCtx,
								   int memberId )
{
	yakass( m_session != NULL );

    Party *party = NULL;

	if( !m_session->IsPartyConnected( memberId ) )
	{
        party = yaknew Party( m_session );

		party->SetMemberId( memberId );

		party->SetLocalIP( localAddress.m_ip );
		party->SetLocalPort( localAddress.m_port );

		party->SetRemoteIP( remoteAddress.m_ip );
        party->SetRemotePort( remoteAddress.m_port );
	}
	else {
		yakout( "\nServer: Party allready connected: %d", memberId );
		return;
	}

	if( arch != m_session->GetArchitecture() )
	{
		char b[ D_YAK_PACKET_MAX_SIZE ];
		Buffer bb( b, D_YAK_PACKET_MAX_SIZE );
		bb.WriteChar( Conference::eServerResponseError );
		bb.WriteChar( Conference::eServerErrorArch );

		Send( party->GetRemoteIP(), party->GetRemotePort(),
			( const char* ) bb.GetData(), bb.GetSizeW() );

		return;
	}

	if( outCtx != m_session->GetOutContext() ||
		inCtx  != m_session->GetInContext() )
	{
		char b[ D_YAK_PACKET_MAX_SIZE ];
		Buffer bb( b, D_YAK_PACKET_MAX_SIZE );
		bb.WriteChar( Conference::eServerResponseError );
		bb.WriteChar( Conference::eServerErrorContext );

		Send( party->GetRemoteIP(), party->GetRemotePort(),
			( const char* ) bb.GetData(), bb.GetSizeW() );

		return;
	}


	// Send reply back
	char nConnected = 0;

	char b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

	bb.WriteChar( Conference::eServerResponseJoin );

	bb.WriteInt( party->GetRemoteIP() );
	bb.WriteShort( party->GetRemotePort() );

	bb.WriteChar( 0 ); // nConnected

	for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
	{
        Party *sendparty = Session::PP( m_session->m_allPeers[ k ] );

		if( sendparty != NULL )
		{
			bb.WriteChar( sendparty->GetMemberId() );
			bb.WriteInt( sendparty->GetLocalIP() );
			bb.WriteShort( sendparty->GetLocalPort() );
			bb.WriteInt( sendparty->GetRemoteIP() );
			bb.WriteShort( sendparty->GetRemotePort() );

			++nConnected;
		}
	}

	// buffer hack
	int nWrite = bb.GetSizeW();
	int nOff = sizeof( char ) + sizeof( int ) + sizeof( short );
	bb.WriteRewind();
	bb.WriteSkip( nOff );
	bb.WriteChar( nConnected );
	bb.WriteSkip( nWrite - nOff - sizeof( char ) );
	//

	Send( party->GetRemoteIP(), party->GetRemotePort(),
					( const char* ) bb.GetData(), bb.GetSizeW() );


	//Broadcast data to other parties
	bb.WriteRewind();
	bb.WriteChar( Conference::eServerResponseAddPeer );
	bb.WriteChar( party->GetMemberId() );
	bb.WriteInt( party->GetLocalIP() );
	bb.WriteShort( party->GetLocalPort() );
	bb.WriteInt( party->GetRemoteIP() );
	bb.WriteShort( party->GetRemotePort() );

	for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
	{
        Party *sendparty = Session::PP( m_session->m_allPeers[ k ] );

		if( sendparty != NULL )
		{
			Send( sendparty->GetRemoteIP(), sendparty->GetRemotePort(),
						( const char* ) bb.GetData(), bb.GetSizeW() );
		}
	}

	yakout("\nServer: Add client: %d", memberId );
	m_session->AddParty( memberId, party );
}

void Server::OnClientLeave( int memberId )
{
	if( m_session != NULL && m_session->IsPartyConnected( memberId ) )
	{
		m_session->RemoveParty( memberId );
		yakout("\nServer: Party left: [%d]", memberId );
		//TODO: Inform others?
	}
}


void Server::OnClientSignal( int memberId )
{
	if( m_session != NULL && m_session->IsPartyConnected( memberId ) ) {
		m_session->UpdatePartyTimestamp( memberId );
	}
}

void Server::CreateHttpInterface()
{
	char portstr[6] = {0};
	sprintf(portstr, "%u", m_socket.GetPort());

	const char *options[] = {"listening_ports", portstr, NULL};
	m_pServerCtx = mg_start(HttpEventHandler, (void*) this, options);
}

void Server::DestroyHttpInterface()
{
	if (m_pServerCtx) {
		mg_stop(m_pServerCtx);
	}
}

void* Server::HttpCallback(enum mg_event event, struct mg_connection *conn, const struct mg_request_info *request_info)
{
	if (event != MG_NEW_REQUEST) {
		return NULL;
	}

	std::string response;

	char trafficstats[1024] = {0};
	sprintf(trafficstats, "Traffic: OUT(%.2f kB); IN(%.2f kB)\n\n", m_bwOut, m_bwIn);
	response.append(trafficstats);

	char line[1024] = {0};

	for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
	{
        Party *party = Session::PP( m_session->m_allPeers[ k ] );

		if( m_session->IsPartyConnected( k ) )
		{
			struct in_addr remote;
			remote.s_addr = party->GetRemoteIP();
			char r_ip[16] = {0};
			strcpy(r_ip, inet_ntoa( remote ));

			struct in_addr local;
			local.s_addr = party->GetLocalIP();
			char l_ip[16] = {0};
			strcpy(l_ip, inet_ntoa( local ));


			sprintf(line, "\tid %d\tlocalIP %s:%u\tremoteIP %s:%u\n", party->GetMemberId(),
				l_ip, party->GetLocalPort(), r_ip,  party->GetRemotePort());

			response.append(line);
		}
	}

	response.append("\n");

	mg_printf(conn, "HTTP/1.1 200 OK\r\n"
			  "Content-Type: text/plain\r\n\r\n"
			  "%s", response.c_str());

	return (void*) "";  // Mark as processed
}

static void* HttpEventHandler(enum mg_event event, struct mg_connection* conn, const struct mg_request_info* request_info)
{
	Server* server = (Server*)( request_info->user_data );
	return server->HttpCallback( event, conn, request_info );
}

// ----------------------------------------------------------------------//
} // namespace yak;
