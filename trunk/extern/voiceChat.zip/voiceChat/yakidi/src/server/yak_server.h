#ifndef __YAK_CSERVER_H
#define __YAK_CSERVER_H

#include <map>

#include "mongoose/mongoose.h"

#include "../yak_conference.h"
#include "yak_session.h"

namespace yak
{
// ----------------------------------------------------------------------//

class Server
{
protected:
	bool						m_running;
	bool						m_list;

	Socket						m_socket;
	Session*					m_session;

	struct mg_context*			m_pServerCtx;
	void						CreateHttpInterface();
	void						DestroyHttpInterface();

	unsigned int				m_enterTime;
	unsigned int				m_exitTime;

	int							m_bwOutCount;
	int							m_bwInCount;
	float						m_bwOut;
	float						m_bwIn;
	unsigned int				m_bwlastTime;

public:
	Server(unsigned short port = D_YAK_P2P_SERVER_PORT, bool list = false);
	 ~Server();

	unsigned short				GetPort() { return m_socket.GetPort(); }

	void						Update();
	void						Stop() { m_running = false; }
	bool						IsRunning() { return m_running; }
	void						Process( Buffer *buf, int ip, unsigned short port );
	void						Send( int ip, unsigned short port, const char *buf, int len );

	void						OnClientNewConnection(
									Peer::Address &localAddress,
									Peer::Address &remoteAddress,
									EArchitecture arch,
									Codec::EContext outCtx,
									Codec::EContext inCtx,
									int memberId
									);

	void						OnClientLeave( int memberId );
	void						OnClientSignal( int memberId );

	void						OnRequestRemoteInfo( Peer::Address &localAddress, Peer::Address &remoteAddress );
	void						OnRequestServerInfo( Peer::Address &localAddress, Peer::Address &remoteAddress );

	void*						HttpCallback(enum mg_event event, struct mg_connection *conn, const struct mg_request_info *request_info);

	void						Wait();
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CSERVER_H
