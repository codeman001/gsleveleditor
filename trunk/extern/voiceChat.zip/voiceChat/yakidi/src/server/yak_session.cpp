#include "yak_server.h"
#include "yak_session.h"

namespace yak
{
// ----------------------------------------------------------------------//

Party::Party( Conference *conf )
    : Peer( conf, false )
    , m_forwardMask( 0 )
    , m_timestamp( conf->GetCurrentTime() )
{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
    m_serverRecCache = yaknew char[ D_YAK_CONFIG_RAW_DUMP_MAX_SIZE ];
    m_serverRecBuffer = yaknew Buffer( m_serverRecCache, D_YAK_CONFIG_RAW_DUMP_MAX_SIZE );
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE

#if D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
    m_serverMixCache = yaknew char[ D_YAK_CONFIG_RAW_DUMP_MAX_SIZE ];
    m_serverMixBuffer = yaknew Buffer( m_serverMixCache, D_YAK_CONFIG_RAW_DUMP_MAX_SIZE );
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
//-----------------------------------------------------------------------//
}

Party::~Party()
{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
    yakdel( m_serverRecBuffer );
    yakdelarray( m_serverRecCache);
#endif //D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
    yakdel( m_serverMixBuffer );
    yakdelarray( m_serverMixCache);
#endif //D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
//-----------------------------------------------------------------------//
}

Session::Session( Server *pServer, EArchitecture arch, Codec::EContext outCtx, Codec::EContext inCtx  )
: Conference( outCtx, inCtx )
{
	yakass( pServer != NULL );

	m_server		= pServer;
	m_architecture	= arch;

	m_cleanupTimer		= 0;

	Codec::Context *ctx = &Codec::m_contexts[ inCtx ];

	m_mixingBuffer	= yaknew int[ ctx->m_frameSize ];
	m_scaledBuffer	= yaknew short[ ctx->m_frameSize ];
}

Session::~Session()
{
	yakdel( m_scaledBuffer );
	yakdel( m_mixingBuffer );
}

void Session::Cleanup( const int dt )
{
	int nConnected = 0;
	m_cleanupTimer += dt;

	if( m_cleanupTimer >= kCleanupInterval )
	{
		for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
		{
			Party *party = PP( m_allPeers[ k ] );

			if( party != NULL )
			{
				if( m_currentTime - party->m_timestamp > kCleanupTimeout )
				{
					int memberId = party->GetMemberId();
					RemoveParty( memberId );

					yakout("\nSession: Remove party: %d", memberId );
				}

				++nConnected;
			}
		}

		m_cleanupTimer = 0;
	}
}

void Session::Update()
{
	Conference::Update();
	Cleanup( m_currentTime - m_lastTime );

	if( m_architecture == eArchitectureServer )
	{
		Codec::Context *outCtx = &Codec::m_contexts[ m_outContext ];
		Codec::Context *inCtx = &Codec::m_contexts[ m_inContext ];

		TChannelMixInfo mixInfo[ D_YAK_PEER_UID_MAX ];

        memset( mixInfo, 0, sizeof( mixInfo ) );

		// dejitter from all clients
		for( int i = 0; i < D_YAK_PEER_UID_MAX; i++ )
		{
			Party *party = PP( m_allPeers[ i ] );

			if( party != NULL )
			{
				int memberId		= party->GetMemberId();
				char *clientData	= NULL;

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
				if( !party->m_serverRecBuffer->CanWrite( inCtx->m_bufferSize ) )
				{
					char dbgName[ 64 ];

					sprintf( dbgName, "rec_srv_%d_1_8KHz_%d_%d.pcm16", getpid(), party->GetMemberId(), S_GetTime() );
					BufToFile( party->m_serverRecBuffer, dbgName );

					party->m_serverRecBuffer->WriteRewind();
				}
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
//-----------------------------------------------------------------------//

				if( eResultOk == party->m_playout->Get( S_GetTime(), &clientData ) )
				{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
					if( clientData != NULL ) {
						party->m_serverRecBuffer->WriteBlock( clientData, inCtx->m_bufferSize );
					}
					else {
						party->m_serverRecBuffer->WriteZeroes( inCtx->m_bufferSize );
					}
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
//-----------------------------------------------------------------------//

					mixInfo[ memberId ].m_decData = (short*) clientData;

					if( clientData == NULL )
					{
						Codec *codec = party->GetCodec();
						codec->AGCCtrlSilent();
					}
				}
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
				else {
					party->m_serverRecBuffer->WriteZeroes( inCtx->m_bufferSize );
				}
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
//-----------------------------------------------------------------------//

				for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
				{
					if( ( party->m_forwardMask >> k ) & 0x1 ) {
						mixInfo[ k ].m_fromMask |= ( 1 << memberId );
					}
				}
			}
		}

		// mix for each client
		for( int i = 0; i < D_YAK_PEER_UID_MAX; i++ )
		{
			Party *party = PP( m_allPeers[ i ] );

			if( party != NULL )
			{
				memset( m_mixingBuffer, 0, inCtx->m_frameSize * sizeof(int) );

				int speakMask		= 0;
                int maxSample       = 0;
                int mixScale        = 0;

				int memberId        = party->GetMemberId();
				TChannelMixInfo*	myInfo = &mixInfo[ memberId ];

				for( int j = 0; j < D_YAK_PEER_UID_MAX; j++ )
				{
					if( ( ( myInfo->m_fromMask >> j ) & 0x1 ) )
					{
						int   *pOutput		= m_mixingBuffer;
						short *pData = mixInfo[ j ].m_decData;

						if( pData != NULL )
						{
							for( unsigned int k = 0; k < inCtx->m_frameSize; k++ )
							{
								*pOutput += pData[ k ];

                                int mix = abs( *pOutput );
                                if( mix > maxSample ) {
                                    maxSample = mix;
                                }

								++pOutput;
							}

                            speakMask |= ( 1 << j );
						}
					}
				}

				char	b[ D_YAK_PACKET_MAX_SIZE ];
				Buffer	bb( b, D_YAK_PACKET_MAX_SIZE );

				bb.WriteChar( Conference::eServerResponseMixedVoice );
				bb.WriteInt( m_timeStamp );
				bb.WriteInt( speakMask );

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
				if( !party->m_serverMixBuffer->CanWrite( inCtx->m_bufferSize ) )
				{
					char dbgName[ 64 ];

					sprintf( dbgName, "mix_srv_%d_1_8KHz_%d_%d.pcm16", getpid(), party->GetMemberId(), S_GetTime() );
					BufToFile( party->m_serverMixBuffer, dbgName );

					party->m_serverMixBuffer->WriteRewind();
				}
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
//-----------------------------------------------------------------------//

				if( speakMask != 0 )
				{
                    if( maxSample > SHORT_MAX ) {
                        mixScale = ( SHORT_MAX * 100 ) / maxSample;
                    }

                    if( mixScale != 0 )
                    {
                        for( unsigned int k = 0; k < inCtx->m_frameSize; k++ )
                        {
                            int mix = ( m_mixingBuffer[ k ] * mixScale ) / 100;
                            m_scaledBuffer[ k ] = mix;
                        }
                    }
                    else
                    {
                        for( unsigned int k = 0; k < inCtx->m_frameSize; k++ )
						{
                            int mix = m_mixingBuffer[ k ];
                            m_scaledBuffer[ k ] = mix;
                        }
                    }

					Codec *codec		= party->GetCodec();
					int len				= 0;
					char *src			= (char*)( m_scaledBuffer );
					int bufSize			= inCtx->m_bufferSize;

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
					party->m_serverMixBuffer->WriteBlock( m_scaledBuffer, bufSize );
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
//-----------------------------------------------------------------------//

					Codec::LockEncode();
                    src = codec->Preprocess( inCtx->m_samplingRate, src, bufSize, false, D_YAK_CONFIG_USE_AGC_ON_SERVER );
					if( src != NULL )
					{
						len = codec->Encode( src, outCtx->m_bufferSize );
						bb.WriteShort( len );
						bb.WriteBlock( Codec::GetEncodeBuffer(), len );
					}
					else
					{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
						party->m_serverMixBuffer->WriteZeroes( bufSize );
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
//-----------------------------------------------------------------------//

						bb.WriteShort( 0 );
					}
					Codec::UnlockEncode();

                    //printf( "\n[TS: %d]\tfrom: 0x%x\tto: %d", m_timeStamp, speakMask, i );
				}
				else
				{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
					party->m_serverMixBuffer->WriteZeroes( inCtx->m_bufferSize );
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
//-----------------------------------------------------------------------//

					bb.WriteShort( 0 );
				}

				m_server->Send( party->GetRemoteIP(), party->GetRemotePort(), bb.GetData(), bb.GetSizeW() );
			}
		}

		m_timeStamp		+= D_YAK_SOUND_FRAME_TIME;
    }
}

// ----------------------------------------------------------------------//
} // namespace yak;
