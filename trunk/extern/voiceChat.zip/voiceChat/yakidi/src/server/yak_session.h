#ifndef __YAK_CSESSION_H
#define __YAK_CSESSION_H

#include <map>
#include "../yak_conference.h"

namespace yak
{
// ----------------------------------------------------------------------//
class Server;
class Buffer;

class Party : public Peer
{
public:
    int						m_forwardMask;
    int						m_timestamp;

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
    char					*m_serverRecCache;
    Buffer					*m_serverRecBuffer;
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
#if D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
    char					*m_serverMixCache;
    Buffer					*m_serverMixBuffer;
#endif // D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
//-----------------------------------------------------------------------//

    Party( Conference *conf );
    virtual ~Party();
};

class Session : public Conference
{
	friend class Server;

public:

	typedef struct 
	{					
        short*				m_decData;
        int					m_fromMask;
	} TChannelMixInfo;

protected:
	static const int		kCleanupInterval =     15 * 1000;
	static const int		kCleanupTimeout  =     10 * 1000;

	Server					*m_server;
	EArchitecture			m_architecture;

	int						*m_mixingBuffer;
	short					*m_scaledBuffer;

	int						m_cleanupTimer;

protected:
	static inline Party*	PP( Peer *peer ) { return reinterpret_cast<Party*> ( peer ); }

	virtual void			Record( char *frame,  unsigned short size ){}
	void					Cleanup( const int dt );

public:
	Session( Server *pServer, EArchitecture arch, Codec::EContext outCtx, Codec::EContext inCtx );
	 ~Session();

	EArchitecture		GetArchitecture()
						{ return m_architecture; }

	bool				IsPartyConnected( int memberId )
						{ return IsValidMemberId( memberId ) && m_allPeers[ memberId ] != NULL; }

	void				AddParty( int memberId, Party *party ) 
						{ 
							if( IsValidMemberId( memberId ) ) {
								m_allPeers[ memberId ] = party; 
							}
						}

	void				RemoveParty( int memberId ) 
						{
							if( IsValidMemberId( memberId ) )
							{
								yakdel( m_allPeers[ memberId ] );
								m_allPeers[ memberId ] = NULL;
							}
						}

	void				UpdatePartyTimestamp( int memberId )
						{
							if( IsValidMemberId( memberId) && m_allPeers[ memberId ] != NULL ) {
								PP( m_allPeers[ memberId ] )->m_timestamp = m_currentTime;
							}
						}

	void				Update();
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CSESSION_H
