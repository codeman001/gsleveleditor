
#ifndef _SPEEX_CONFIG_H
#define _SPEEX_CONFIG_H

#ifndef _USE_SSE
#  define USE_ALLOCA
#endif
/* Default to floating point */

#define SPEEX_FLOATING_POINT
#define USE_SMALLFT

#if defined ( WIN32 )
#	define inline __inline
#	define SPEEX_EXPORT
#endif // WIN32

#if defined ( OS_IPHONE )
#	define SPEEX_EXPORT __attribute__((visibility("default")))
#	define restrict __restrict
#   define _USE_NEON
#endif // OS_IPHONE

#if defined ( OS_ANDROID )
#	define restrict __restrict
#endif // OS_ANDROID

#if defined ( OS_LINUX )
#  define SPEEX_EXPORT
#endif // OS_LINUX

#include "arch.h"

#endif  /* _SPEEX_CONFIG_H */
