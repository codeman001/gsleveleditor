#pragma once

#ifdef D_YAK_CONFIG_USE_VOX_1_0

#ifndef _VOX_MINIBUS_DATA_GENERATOR_PLUGIN_H_
#define _VOX_MINIBUS_DATA_GENERATOR_PLUGIN_H_

#include "vox_default_config.h"
#include "vox_internal.h"					// To get access to VoxVector3f
#include "vox_minibus_system.h"
#include "vox_driver_callback_template.h"	// For enhanced 3D declarations

#define MDGP_MAX_DOPPLER_PITCH		2.9f	// Limit so user*data*doppler max pitch = (2 * (44100 / 32000) * 2.9) * 2^28 doesn't overflow s32.
#define MDGP_MIN_DOPPLER_PITCH		0.001f
#define MDGP_ANGLE_180_DEGREES		180
#define MDGP_NOMINAL_RAMP_INTERVAL	0.003f	// Volume ramping time span when volume changes or starving

#ifndef MDGP_PI
	#define MDGP_PI	3.14159265358979323846264f
#endif

#define MDGP_ENHANCED_3D_DELAY_LENGTH 128

namespace vox
{

class MinibusDataGeneratorPlugin : public MinibusDataGeneratorInterface
{
 public:
	MinibusDataGeneratorPlugin();
	virtual ~MinibusDataGeneratorPlugin();

	virtual void GetData(s32* buffer, s32 nbSample, s32 sampleRate)=0;
};

struct Mdgp3DEnvironmentParams
{
	u32 m_distanceModel;
	f32	m_dopplerFactor;			
	f32	m_speedOfSound;
	u32 m_enhanced3D;		// Used to set (or unset) enhanced3D at runtime.

	Mdgp3DEnvironmentParams():m_distanceModel(VOX_DEFAULT_3D_MODEL), m_dopplerFactor(VOX_DEFAULT_3D_DOPPLER_FACTOR),
							  m_speedOfSound(VOX_DEFAULT_3D_SPEED_OF_SOUND), m_enhanced3D(VOX_DEFAULT_3D_ENHANCED_3D) {}
};

struct Mdgp3DListenerPositioning
{
	VoxVector3f m_position;
	VoxVector3f m_velocity;
	VoxVector3f m_atOrientation;
	VoxVector3f m_upOrientation;

	Mdgp3DListenerPositioning()
	{
		m_position.x = 0.0f;
		m_position.y = 0.0f;
		m_position.z = 0.0f;

		m_velocity.x = 0.0f;
		m_velocity.y = 0.0f;
		m_velocity.z = 0.0f;

		m_atOrientation.x = 0.0f;
		m_atOrientation.y = 0.0f;
		m_atOrientation.z = -1.0f;

		m_upOrientation.x = 0.0f;
		m_upOrientation.y = 1.0f;
		m_upOrientation.z = 0.0f;
	}
};

struct Mdgp3DSourcePositioning
{
	VoxVector3f	m_position;
	VoxVector3f	m_velocity;
	VoxVector3f	m_direction;

	Mdgp3DSourcePositioning()
	{
		m_position.x = 0.0f;
		m_position.y = 0.0f;
		m_position.z = 0.0f;

		m_velocity.x = 0.0f;
		m_velocity.y = 0.0f;
		m_velocity.z = 0.0f;

		m_direction.x = 0.0f;
		m_direction.y = 0.0f;
		m_direction.z = 0.0f;
	}
};

struct Mdg3DParameters
{
	Vox3DEmitterParameters		m_sourceParams;
	Mdgp3DListenerPositioning	m_listenerPositioning;
	Mdgp3DSourcePositioning		m_sourcePositioning;
};

class MinibusDataGenerator3DPlugin : public MinibusDataGeneratorPlugin
{
 public:
	MinibusDataGenerator3DPlugin();
	virtual ~MinibusDataGenerator3DPlugin();

	static void Get3DGeneralParameters(Vox3DGeneralParameters &parameters);
	static void Set3DGeneralParameters(const Vox3DGeneralParameters &parameters);
	static void SetEnhanced3D(bool isActivated);

	virtual void GetData(s32* buffer, s32 nbSample, s32 sampleRate)=0;

	virtual void Get3DSourceParameters(Vox3DEmitterParameters &sourceParams);
	virtual void Get3DListenerPositioning(Mdgp3DListenerPositioning &positioning);
	virtual void Get3DSourcePositioning(Mdgp3DSourcePositioning &positioning);
	virtual void Set3DSourceParameters(const Vox3DEmitterParameters &sourceParams);
	virtual void Set3DListenerPositioning(const Mdgp3DListenerPositioning &positioning);
	virtual void Set3DSourcePositioning(const Mdgp3DSourcePositioning &positioning);
 protected:
	static Mdgp3DEnvironmentParams s_environmentParams;			// General 3D environment parameters
	static Enhanced3dTweakParameters s_enhanced3DParameters;	// Enhanced 3D parameters

	Vox3DEmitterParameters m_sourceParams;				// Source 3D general parameters
	Mdgp3DListenerPositioning m_listenerPositioning;	// Listener positioning parameters
	Mdgp3DSourcePositioning m_sourcePositioning;		// Source positioning parameters

#if VOX_ENHANCED_3D
	VoxFilter m_filter[4]; 
	s32 m_leftSideDelay;
	s32 m_delayBuffer[MDGP_ENHANCED_3D_DELAY_LENGTH];
	s32 m_delayWriteCounter;
	s32 m_delayReadCounter;
#endif

public:
	fx1814 GetDirectionalGain(void);
	fx1814 GetDistanceGain(void);
	fx1814 GetDopplerPitch(void);
	void GetStereoPanning(fx1814 *leftPan, fx1814 *rightPan);
	void GetNormalizedPosition(f32 *resultX, f32 *resultY, f32 *resultZ);
};

} // namespace vox

#endif // _VOX_MINIBUS_DATA_GENERATOR_PLUGIN_H_

#endif // D_YAK_CONFIG_USE_VOX_1_0