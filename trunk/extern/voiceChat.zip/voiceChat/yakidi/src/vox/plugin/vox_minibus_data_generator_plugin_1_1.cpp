#ifndef D_YAK_CONFIG_USE_VOX_1_0

#include "vox_minibus_data_generator_plugin_1_1.h"

#define VOX_INTERNAL_CODE
#include "vox_default_config.h"
#include "vox_internal.h"					// To get access to VoxVector3f
#include "vox_minibus_system.h"
#include "vox_driver_callback_template.h"	// For enhanced 3D declarations


#include "vox_profiler.h"
#include <math.h>

namespace vox
{

MinibusDataGeneratorPlugin::MinibusDataGeneratorPlugin()
{
}

MinibusDataGeneratorPlugin::~MinibusDataGeneratorPlugin()
{
}

//*** MinibusDataGenerator3DPlugin ***//

Mdgp3DEnvironmentParams MinibusDataGenerator3DPlugin::s_environmentParams;

Mdgp3DEnvironmentParams::Mdgp3DEnvironmentParams()
:m_distanceModel(VOX_DEFAULT_3D_MODEL), m_dopplerFactor(VOX_DEFAULT_3D_DOPPLER_FACTOR),
m_speedOfSound(VOX_DEFAULT_3D_SPEED_OF_SOUND), m_enhanced3D(VOX_DEFAULT_3D_ENHANCED_3D)
{}


Enhanced3dTweakParametersMBDG MinibusDataGenerator3DPlugin::s_enhanced3DParameters =
{
	VOX_DEFAULT_ENHANCED_3D_STEREO_PANNING_POWER,
	VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_FRONT,
	VOX_DEFAULT_ENHANCED_3D_STEREO_MAX_DELAY_BACK,
	
	VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_SIDE,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_BACK,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_DEPTH_DISTANCE,

	VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_SIDE,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_BACK,
	VOX_DEFAULT_ENHANCED_3D_NOTCH_WIDTH_DISTANCE,

	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MINIMUM,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_MAXIMUM,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_CURVE,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_SIDE,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_WIDTH_BACK,
	VOX_DEFAULT_ENHANCED_3D_DISTANCE_FREQUENCY,

	VOX_DEFAULT_ENHANCED_3D_ROLLOFF_FACTOR
};

MinibusDataGenerator3DPlugin::MinibusDataGenerator3DPlugin()
{
}

MinibusDataGenerator3DPlugin::~MinibusDataGenerator3DPlugin()
{
}

// Method 'GetDirectionalGain()' calculates the source gain related to direction of propagation. The gain is related to
// the angle between the source-to-listener and source direction vectors as follow:
//
// 1) If the angle is smaller than the cone inner angle, gain = 1.0f
// 2) If the angle is larger than the cone outer angle, gain = m_outerConeGain.
// 3) If the angle is between the cone inner and outer angles, gain is interpolated between 1.0f and m_outerConeGain.
//
// The angle between source-to-listener and sourceDirection vectors is calculted according to:
//
// angle = arccos(sqrt((slVector.sourceDirection)^2 / (slVector^2 * sourceDirection^2)),
//
// when scalar product slVector.sourceDirection is positive. When scalar product is negative, the calculated angle is
// transformed according to "angle = 180 - angle;".
	
fx1814 MinibusDataGenerator3DPlugin::GetDirectionalGain(void)
{		
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MinibusDataGenerator3DPlugin::GetDirectionalGain", vox::VoxThread::GetCurThreadId());

	// Calculate gain only if source is directional (but not omni-directional).
	if(m_sourceParams.innerConeAngle < 360.0f && (m_sourcePositioning.m_direction.x != 0.0f ||
	   m_sourcePositioning.m_direction.y != 0.0f || m_sourcePositioning.m_direction.z != 0.0f))
	{
		f32 angle;				// Angle between sourceDirection and sourceToListener vectors.
		f32 scalarProduct;
		f32 numerator;
		f32 denominator;
		f32 slVectorX;			// x component of source to listener vector.
		f32 slVectorY;			// y component of source to listener vector.
		f32 slVectorZ;			// z component of source to listener vector.
		f32 slVectorSquare;
		f32 sourceDirectionSquare;
			
		if(m_sourceParams.relativeToListener) // Source position is relative to listener.
		{
			slVectorX = -m_sourcePositioning.m_position.x;
			slVectorY = -m_sourcePositioning.m_position.y;
			slVectorZ = -m_sourcePositioning.m_position.z;
		}
		else // Source position is not relative to listener.
		{
			slVectorX = m_listenerPositioning.m_position.x - m_sourcePositioning.m_position.x;
			slVectorY = m_listenerPositioning.m_position.y - m_sourcePositioning.m_position.y;
			slVectorZ = m_listenerPositioning.m_position.z - m_sourcePositioning.m_position.z;
		}
			
		// Calculate square of scalar product between sourceToListener and sourceDirection vectors.
		scalarProduct = slVectorX * m_sourcePositioning.m_direction.x +
						slVectorY * m_sourcePositioning.m_direction.y +
						slVectorZ * m_sourcePositioning.m_direction.z;
			
		f32 scalarProductSquare = scalarProduct * scalarProduct;	
			
		// Calculate square of length of source-to-listener vector.
		slVectorSquare = slVectorX * slVectorX + slVectorY * slVectorY + slVectorZ * slVectorZ;			
			
		// Calculate square of length of source direction vector.
		sourceDirectionSquare = m_sourcePositioning.m_direction.x * m_sourcePositioning.m_direction.x +
								m_sourcePositioning.m_direction.y * m_sourcePositioning.m_direction.y +
								m_sourcePositioning.m_direction.z * m_sourcePositioning.m_direction.z;	
			
		// Calculate the angle between source-to-listener and direction vectors (in degrees).
		angle = acos(sqrt(scalarProductSquare / (slVectorSquare * sourceDirectionSquare)));
		angle = angle * MDGP_ANGLE_180_DEGREES / MDGP_PI; 	// Conversion from radians to degrees.
			
		// Convert angle when scalar product is negative (because argument of acos is positive).
		if(scalarProduct < 0.0f)
		{
			angle = MDGP_ANGLE_180_DEGREES - angle;
		}
			
		// Get the angle between direction vector and inner cone (half the cone inner angle).
		f32 halfInConeAngle = m_sourceParams.innerConeAngle / 2.0f;
			
		if(angle > halfInConeAngle)
		{
			// Get the angle between direction vector and outer cone (half the cone outer angle).
			f32 halfOutConeAngle = m_sourceParams.outerConeAngle / 2.0f;
				
			// If the source-to-listener vector is located between the inner and outer cones,
			// interpolate the gain between 1.0f and coneOuterGain.
			if(angle < halfOutConeAngle)
			{
				numerator = (halfOutConeAngle - angle) + m_sourceParams.outerConeGain * (angle - halfInConeAngle);
				denominator = halfOutConeAngle - halfInConeAngle;
				if(denominator > 0.0f)
				{
					return((fx1814) (numerator / denominator * VOX_FX1814_ONE));
				}
			}
			else // Angle is larger than halfOutConeAngle, gain = m_outerConeGain.
			{
				return((fx1814) (m_sourceParams.outerConeGain * VOX_FX1814_ONE));
			}
		}
	}
		
	// If source is non-directional or if angle <= halfInConeAngle, gain = 1.0f.
	return(VOX_FX1814_ONE);
}

// Method 'GetDistanceGain()' calculates volume attenuation induced by source to listener distance. The calculation is
// dependent upon the current distance model.
	
fx1814 MinibusDataGenerator3DPlugin::GetDistanceGain(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MinibusDataGenerator3DPlugin::GetDistanceGain", vox::VoxThread::GetCurThreadId());
	f32 distanceX;
	f32 distanceY;
	f32 distanceZ;
	f32 distance;
	f32 numerator = 1.0f;
	f32 denominator = 1.0f;
	f32 attenuation;

	if(m_sourceParams.relativeToListener) // Source position is relative to listener.
	{
		distanceX = m_sourcePositioning.m_position.x;
		distanceY = m_sourcePositioning.m_position.y;
		distanceZ = m_sourcePositioning.m_position.z;
	}
	else // Source position is not relative to listener.
	{
		distanceX = m_sourcePositioning.m_position.x - m_listenerPositioning.m_position.x;
		distanceY = m_sourcePositioning.m_position.y - m_listenerPositioning.m_position.y;
		distanceZ = m_sourcePositioning.m_position.z - m_listenerPositioning.m_position.z;
	}
	
	distance = sqrt(distanceX * distanceX + distanceY * distanceY + distanceZ * distanceZ);
	
	// Evaluate volume attenuation according to distance model.
	if(s_environmentParams.m_distanceModel == Vox3DDistanceModel::k_nInverseDistanceClamped)
	{
		if(distance < m_sourceParams.referenceDistance)
		{
			distance = m_sourceParams.referenceDistance;
		}
		else if(distance > m_sourceParams.maxDistance)
		{
			distance = m_sourceParams.maxDistance;
		}
		
		denominator = m_sourceParams.referenceDistance + m_sourceParams.rolloffFactor * (distance - m_sourceParams.referenceDistance);
		
		if(denominator > 0.0f)
		{			
			return((fx1814) (m_sourceParams.referenceDistance / denominator * VOX_FX1814_ONE));
		}
	}
	else if(s_environmentParams.m_distanceModel == Vox3DDistanceModel::k_nLinearDistanceClamped)
	{
		if(distance < m_sourceParams.referenceDistance)
		{
			distance = m_sourceParams.referenceDistance;
		}
		else if(distance > m_sourceParams.maxDistance)
		{
			distance = m_sourceParams.maxDistance;
		}
		
		numerator = (distance - m_sourceParams.referenceDistance) * m_sourceParams.rolloffFactor;
		denominator = m_sourceParams.maxDistance - m_sourceParams.referenceDistance;
		
		if(denominator > 0.0f)
		{
			attenuation = 1.0f - (numerator / denominator);
			if(attenuation < 0.0f)
			{
				attenuation = 0.0f;
			}
			return((fx1814) (attenuation * VOX_FX1814_ONE));
		}		
	}
	else if(s_environmentParams.m_distanceModel == Vox3DDistanceModel::k_nExponentDistanceClamped)
	{	
		if(m_sourceParams.rolloffFactor > 0.0f && m_sourceParams.referenceDistance > 0.0f)
		{		
			if(distance < m_sourceParams.referenceDistance)
			{
				distance = m_sourceParams.referenceDistance;
			}
			else if(distance > m_sourceParams.maxDistance)
			{
				distance = m_sourceParams.maxDistance;
			}
			
			attenuation = pow(distance / m_sourceParams.referenceDistance, -m_sourceParams.rolloffFactor);
			return((fx1814) (attenuation * VOX_FX1814_ONE));
		}					
	}
	
	return VOX_FX1814_ONE;
}

// Method 'GetDopplerPitch()' calculates doppler shift based on a formula taken from the OpenAL 1.1 Specification.
// However, calculations differ slightly from the specification in order to minimize multiplications and divisions
// (while keeping the same result). The implemented formula is :
//	
// dopplerShitf = (psv - plv) / ((speedOfSound / dopplerFactor) * slVectorLength - psv)
// and
// psv = projected source velocity (projected on source to listener vector).
// plv = projected listener velocity (projected on source to listener vector).
// m_speedOfSound = speed of sound
// DopplerFactor = doppler factor.
// slVectorLength = magnitude of source to listener vector.
	
fx1814 MinibusDataGenerator3DPlugin::GetDopplerPitch(void)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MinibusDataGenerator3DPlugin::GetDopplerPitch", vox::VoxThread::GetCurThreadId());

	if(s_environmentParams.m_dopplerFactor > 0.0f)
	{
		f32 slVectorX;
		f32 slVectorY;
		f32 slVectorZ;
		f32 plv = 0.0f;
		f32	psv;
		
		// Calculate source to listener vector.
		if(m_sourceParams.relativeToListener)				// Source position is relative to listener.
		{
			slVectorX = -m_sourcePositioning.m_position.x;
			slVectorY = -m_sourcePositioning.m_position.y;
			slVectorZ = -m_sourcePositioning.m_position.z;
		}
		else // Source position is not relative to listener.
		{
			slVectorX = m_listenerPositioning.m_position.x - m_sourcePositioning.m_position.x;
			slVectorY = m_listenerPositioning.m_position.y - m_sourcePositioning.m_position.y;
			slVectorZ = m_listenerPositioning.m_position.z - m_sourcePositioning.m_position.z;
			
			// Calculate projection of listener velocity on sourceToListener vector.
			plv = (m_listenerPositioning.m_velocity.x * slVectorX +
				   m_listenerPositioning.m_velocity.y * slVectorY +
				   m_listenerPositioning.m_velocity.z * slVectorZ);
		}
			
		// Calculate the length of source to listener vector.
		f32 slVectorLength = sqrt(slVectorX * slVectorX + slVectorY * slVectorY + slVectorZ * slVectorZ);

		// Calculate projection of source velocity on sourceToListener vector.
		psv = (m_sourcePositioning.m_velocity.x * slVectorX + 
			   m_sourcePositioning.m_velocity.y * slVectorY +
			   m_sourcePositioning.m_velocity.z * slVectorZ);
			
		// Limit source and listener absolute velocities with the speedOfSound/dopplerFactor ratio.
		f32 speedOfSoundFactor = s_environmentParams.m_speedOfSound / s_environmentParams.m_dopplerFactor * slVectorLength;
		
		// Limit projected listener velocity to speedOfSoundFactor
		if(plv > speedOfSoundFactor)
		{
			plv = speedOfSoundFactor;
		}

		f32 denominator = speedOfSoundFactor - psv;
			
		// Return calculated pitch only is denominator is larger than 0.
		if(denominator > 0.0f)
		{
			float dopplerPitch = (1.0f + (psv - plv) / denominator);
			if(dopplerPitch > MDGP_MAX_DOPPLER_PITCH)
			{
				dopplerPitch = MDGP_MAX_DOPPLER_PITCH;
			}
			else if(dopplerPitch < MDGP_MIN_DOPPLER_PITCH)
			{
				dopplerPitch = MDGP_MIN_DOPPLER_PITCH;
			}
			
			return((fx1814) (dopplerPitch * VOX_FX1814_ONE));
		}
	}
	
	return(VOX_FX1814_ONE);
}

// Method 'GetStereoPanning()' returns gains for the left and right channels according to the source position relative
// to listener orientation. Calculations are performed using the following steps:
//
// 1) The relative position between source and listener is calculated and the 'listener to source' vector is normalized.
// 2) Vector product between the listener's 'at' and 'up' orientation vectors is performed and the calculated vector is
//	  normalized. This vector is orthogonal to both the 'at' and 'up' vector and points to the right of the listener.
// 3) The normalized 'listener to source' vector is projected upon the vector calculated in item (2) by taking the scalar
//	  of both vectors, providing a value between -1.0 and 1.0.
// 4) Right gain is calculated from the projection generated in item (3) through rightGain = sqrt(0.5f * (1.0f + projection));
// 5) Left gain is calculated from the right gain through leftGain = sqrt(1.0f - rightGain^2);
//
// NOTE : When source is relative to listener, the 'at x up' vector equals (1, 0, 0) thus the projected vector calculated in
//        item (3) simply corresponds to the 'x' coordinate of the source position.
	
void MinibusDataGenerator3DPlugin::GetStereoPanning(fx1814 *leftPan, fx1814 *rightPan)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MinibusDataGenerator3DPlugin::GetStereoPanning", vox::VoxThread::GetCurThreadId());
	f32 positionX;
	f32 positionY;
	f32 positionZ;
	f32 leftPanFloat;
	f32 rightPanFloat;
		
	if(m_sourceParams.relativeToListener)
	{
		// Calculate the norm of the source (relative) position vector.
		f32 positionNorm = sqrt(m_sourcePositioning.m_position.x * m_sourcePositioning.m_position.x +
								m_sourcePositioning.m_position.y * m_sourcePositioning.m_position.y +
								m_sourcePositioning.m_position.z * m_sourcePositioning.m_position.z);
			
		if(positionNorm > 0.0f)
		{
			positionX = m_sourcePositioning.m_position.x / positionNorm;
		}
		else
		{
			positionX = 0.0f;
		}	
	}
	else // Source position is not relative to listener.
	{
		// Get source position relative to listener.
		// TODO : Do a vector assignment
		positionX = m_sourcePositioning.m_position.x - m_listenerPositioning.m_position.x;
		positionY = m_sourcePositioning.m_position.y - m_listenerPositioning.m_position.y;
		positionZ = m_sourcePositioning.m_position.z - m_listenerPositioning.m_position.z;
		
		// Calculate the norm of the source (relative) position vector.
		f32 positionNorm = sqrt(positionX * positionX + positionY * positionY +	positionZ * positionZ);
		
		// Calculate vector product between 'at' and 'up' vectors
		f32 atUpVectorProductX = m_listenerPositioning.m_atOrientation.y * m_listenerPositioning.m_upOrientation.z -
								 m_listenerPositioning.m_atOrientation.z * m_listenerPositioning.m_upOrientation.y;
		f32 atUpVectorProductY = m_listenerPositioning.m_atOrientation.z * m_listenerPositioning.m_upOrientation.x -
								 m_listenerPositioning.m_atOrientation.x * m_listenerPositioning.m_upOrientation.z;
		f32 atUpVectorProductZ = m_listenerPositioning.m_atOrientation.x * m_listenerPositioning.m_upOrientation.y - 
								 m_listenerPositioning.m_atOrientation.y * m_listenerPositioning.m_upOrientation.x;

		// Calculate the norm of the ('at' x 'up') vector product.
		f32 atUpNorm = sqrt(atUpVectorProductX * atUpVectorProductX + atUpVectorProductY * atUpVectorProductY +
							atUpVectorProductZ * atUpVectorProductZ);
			
		if(positionNorm > 0.0f && atUpNorm > 0.0f)
		{
			// Normalize source (relative) position
			positionX /= positionNorm;
			positionY /= positionNorm;
			positionZ /= positionNorm;
				
			// Normalize ('at' x 'up') vector product.
			atUpVectorProductX /= atUpNorm;
			atUpVectorProductY /= atUpNorm;
			atUpVectorProductZ /= atUpNorm;
				
			// Project the 'listener to source' vector upon the 'at' x 'up' vector product.
			positionX = positionX * atUpVectorProductX + positionY * atUpVectorProductY + positionZ * atUpVectorProductZ;
		}
		else
		{
			positionX = 0.0f;
		}
	}

	// Transform the projected vector 'positionX' to left and right panning values.
	rightPanFloat = sqrt(((VOX_MAX_STEREO_PANNING_POWER - 0.5f) * positionX) + 0.5f);
	leftPanFloat = sqrt(1.0f - rightPanFloat * rightPanFloat);
	*leftPan = (fx1814) (leftPanFloat * VOX_FX1814_ONE);
	*rightPan = (fx1814) (rightPanFloat * VOX_FX1814_ONE);
}

void MinibusDataGenerator3DPlugin::GetNormalizedPosition(f32 *resultX, f32 *resultY, f32 *resultZ)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "MinibusDataGenerator3DPlugin::GetNormalizedPosition", vox::VoxThread::GetCurThreadId());
	f32 positionX;
	f32 positionY;
	f32 positionZ;

	if(m_sourceParams.relativeToListener)
	{
		// Calculate the norm of the source (relative) position vector.
		f32 positionNorm = sqrt(m_sourcePositioning.m_position.x * m_sourcePositioning.m_position.x +
								m_sourcePositioning.m_position.y * m_sourcePositioning.m_position.y +
								m_sourcePositioning.m_position.z * m_sourcePositioning.m_position.z);
			
		if(positionNorm > 0.0f)
		{
			*resultX = m_sourcePositioning.m_position.x / positionNorm;
			*resultY = m_sourcePositioning.m_position.y / positionNorm;
			*resultZ = m_sourcePositioning.m_position.z / positionNorm;
			return;
		}
		else
		{
			*resultX = 0.0f;
			*resultY = 0.0f;
			*resultZ = 0.0f;
			return;
		}
			
	}
	else // Source position is not relative to listener.
	{
		// Get source position relative to listener.
		positionX = m_sourcePositioning.m_position.x - m_listenerPositioning.m_position.x;
		positionY = m_sourcePositioning.m_position.y - m_listenerPositioning.m_position.y;
		positionZ = m_sourcePositioning.m_position.z - m_listenerPositioning.m_position.z;
		
		// Calculate the norm of the source (relative) position vector.
		f32 positionNorm = sqrt(positionX * positionX + positionY * positionY +	positionZ * positionZ);
		
		// Calculate vector product between 'at' and 'up' vectors
		f32 atUpVectorProductX = m_listenerPositioning.m_atOrientation.y * m_listenerPositioning.m_upOrientation.z -
								 m_listenerPositioning.m_atOrientation.z * m_listenerPositioning.m_upOrientation.y;
		f32 atUpVectorProductY = m_listenerPositioning.m_atOrientation.z * m_listenerPositioning.m_upOrientation.x -
								 m_listenerPositioning.m_atOrientation.x * m_listenerPositioning.m_upOrientation.z;
		f32 atUpVectorProductZ = m_listenerPositioning.m_atOrientation.x * m_listenerPositioning.m_upOrientation.y - 
								 m_listenerPositioning.m_atOrientation.y * m_listenerPositioning.m_upOrientation.x;

		// Recalculate up vector to make sure it is at 90 degrees from the "look at" vector
		f32 upCrossX = m_listenerPositioning.m_atOrientation.z * atUpVectorProductY -
					   m_listenerPositioning.m_atOrientation.y * atUpVectorProductZ;
		f32 upCrossY = m_listenerPositioning.m_atOrientation.x * atUpVectorProductZ -
					   m_listenerPositioning.m_atOrientation.z * atUpVectorProductX;
		f32 upCrossZ = m_listenerPositioning.m_atOrientation.y * atUpVectorProductX -
					   m_listenerPositioning.m_atOrientation.x * atUpVectorProductY;

		// Calculate the norm of the ('up') vector.
		f32 upNorm = sqrt(upCrossX * upCrossX + upCrossY * upCrossY + upCrossZ * upCrossZ);

		// Calculate the norm of the ('at') vector.
		f32 atNorm = sqrt(m_listenerPositioning.m_atOrientation.x * m_listenerPositioning.m_atOrientation.x
		                 + m_listenerPositioning.m_atOrientation.y * m_listenerPositioning.m_atOrientation.y
		                 + m_listenerPositioning.m_atOrientation.z * m_listenerPositioning.m_atOrientation.z);

		// Calculate the norm of the ('at' x 'up') vector product.
		f32 atUpNorm = sqrt(atUpVectorProductX * atUpVectorProductX + atUpVectorProductY * atUpVectorProductY +
							atUpVectorProductZ * atUpVectorProductZ);
			
		if(positionNorm>0.0f && atNorm>0.0f && upNorm>0.0f && atUpNorm>0.0f)
		{
			// Normalize source (relative) position
			positionX /= positionNorm;
			positionY /= positionNorm;
			positionZ /= positionNorm;
			
			*resultX = positionX * atUpVectorProductX
			         + positionY * atUpVectorProductY
			         + positionZ * atUpVectorProductZ;

			*resultY = positionX * upCrossX
			         + positionY * upCrossY
			         + positionZ * upCrossZ;

			*resultZ = positionX * m_listenerPositioning.m_atOrientation.x
			         + positionY * m_listenerPositioning.m_atOrientation.y
			         + positionZ * m_listenerPositioning.m_atOrientation.z;

			// Multiply by norm for correct result;
			*resultX /= atUpNorm;
			*resultY /= upNorm;
			*resultZ /= atNorm;
			return;
		}
		else
		{
			*resultX = 0.0f;
			*resultY = 0.0f;
			*resultZ = 0.0f;
			return;
		}
	}

	// This code should be unreachable
	*resultX = 0.0f;
	*resultY = 0.0f;
	*resultZ = 0.0f;
	return;
}

void MinibusDataGenerator3DPlugin::Get3DGeneralParameters(Vox3DGeneralParameters &parameters)
{
	// General environment parameters
	parameters.distanceModel = s_environmentParams.m_distanceModel;
	parameters.dopplerFactor = s_environmentParams.m_dopplerFactor;
	parameters.speedOfSound = s_environmentParams.m_speedOfSound;
	parameters.enhanced3d = s_environmentParams.m_enhanced3D;

	// Enhanced 3D tweaking parameters
	parameters.enhanced3dStereoPanningPower = s_enhanced3DParameters.enhanced3dStereoPanningPower;
	parameters.enhanced3dStereoMaxDelayFront = s_enhanced3DParameters.enhanced3dStereoMaxDelayFront;
	parameters.enhanced3dStereoMaxDelayBack = s_enhanced3DParameters.enhanced3dStereoMaxDelayBack;
	parameters.enhanced3dNotchDepth = s_enhanced3DParameters.enhanced3dNotchDepth;
	parameters.enhanced3dNotchDepthSide = s_enhanced3DParameters.enhanced3dNotchDepthSide;
	parameters.enhanced3dNotchDepthBack = s_enhanced3DParameters.enhanced3dNotchDepthBack;
	parameters.enhanced3dNotchDepthDistance = s_enhanced3DParameters.enhanced3dNotchDepthDistance;
	parameters.enhanced3dNotchWidth = s_enhanced3DParameters.enhanced3dNotchWidth;
	parameters.enhanced3dNotchWidthSide = s_enhanced3DParameters.enhanced3dNotchWidthSide;
	parameters.enhanced3dNotchWidthBack = s_enhanced3DParameters.enhanced3dNotchWidthBack;
	parameters.enhanced3dNotchWidthDistance = s_enhanced3DParameters.enhanced3dNotchWidthDistance;
	parameters.enhanced3dDistanceWidthMinimum = s_enhanced3DParameters.enhanced3dDistanceWidthMinimum;
	parameters.enhanced3dDistanceWidthMaximum = s_enhanced3DParameters.enhanced3dDistanceWidthMaximum;
	parameters.enhanced3dDistanceWidthCurve = s_enhanced3DParameters.enhanced3dDistanceWidthCurve;
	parameters.enhanced3dDistanceWidthSide = s_enhanced3DParameters.enhanced3dDistanceWidthSide;
	parameters.enhanced3dDistanceWidthBack = s_enhanced3DParameters.enhanced3dDistanceWidthBack;
	parameters.enhanced3dDistanceFrequency = s_enhanced3DParameters.enhanced3dDistanceFrequency;
	parameters.enhanced3dRolloffFactor = s_enhanced3DParameters.enhanced3dRolloffFactor;
}

void MinibusDataGenerator3DPlugin::Set3DGeneralParameters(const Vox3DGeneralParameters &parameters)
{
	// General environment parameters
	s_environmentParams.m_distanceModel = parameters.distanceModel;
	s_environmentParams.m_dopplerFactor = parameters.dopplerFactor;
	s_environmentParams.m_speedOfSound = parameters.speedOfSound;
	s_environmentParams.m_enhanced3D = parameters.enhanced3d;

	// Enhanced 3D tweaking parameters
	s_enhanced3DParameters.enhanced3dStereoPanningPower = parameters.enhanced3dStereoPanningPower;
	s_enhanced3DParameters.enhanced3dStereoMaxDelayFront = parameters.enhanced3dStereoMaxDelayFront;
	s_enhanced3DParameters.enhanced3dStereoMaxDelayBack = parameters.enhanced3dStereoMaxDelayBack;
	s_enhanced3DParameters.enhanced3dNotchDepth = parameters.enhanced3dNotchDepth;
	s_enhanced3DParameters.enhanced3dNotchDepthSide = parameters.enhanced3dNotchDepthSide;
	s_enhanced3DParameters.enhanced3dNotchDepthBack = parameters.enhanced3dNotchDepthBack;
	s_enhanced3DParameters.enhanced3dNotchDepthDistance = parameters.enhanced3dNotchDepthDistance;
	s_enhanced3DParameters.enhanced3dNotchWidth = parameters.enhanced3dNotchWidth;
	s_enhanced3DParameters.enhanced3dNotchWidthSide = parameters.enhanced3dNotchWidthSide;
	s_enhanced3DParameters.enhanced3dNotchWidthBack = parameters.enhanced3dNotchWidthBack;
	s_enhanced3DParameters.enhanced3dNotchWidthDistance = parameters.enhanced3dNotchWidthDistance;
	s_enhanced3DParameters.enhanced3dDistanceWidthMinimum = parameters.enhanced3dDistanceWidthMinimum;
	s_enhanced3DParameters.enhanced3dDistanceWidthMaximum = parameters.enhanced3dDistanceWidthMaximum;
	s_enhanced3DParameters.enhanced3dDistanceWidthCurve = parameters.enhanced3dDistanceWidthCurve;
	s_enhanced3DParameters.enhanced3dDistanceWidthSide = parameters.enhanced3dDistanceWidthSide;
	s_enhanced3DParameters.enhanced3dDistanceWidthBack = parameters.enhanced3dDistanceWidthBack;
	s_enhanced3DParameters.enhanced3dDistanceFrequency = parameters.enhanced3dDistanceFrequency;
	s_enhanced3DParameters.enhanced3dRolloffFactor = parameters.enhanced3dRolloffFactor;
}

void MinibusDataGenerator3DPlugin::Get3DSourceParameters(Vox3DEmitterParameters &sourceParams)
{
	sourceParams = m_sourceParams;
}

void MinibusDataGenerator3DPlugin::Set3DSourceParameters(const Vox3DEmitterParameters &sourceParams)
{
	m_sourceParams = sourceParams;
}

void MinibusDataGenerator3DPlugin::Get3DListenerPositioning(Mdgp3DListenerPositioning &positioning)
{
	positioning = m_listenerPositioning;
}

void MinibusDataGenerator3DPlugin::Set3DListenerPositioning(const Mdgp3DListenerPositioning &positioning)
{
	m_listenerPositioning = positioning;
}

void MinibusDataGenerator3DPlugin::Get3DSourcePositioning(Mdgp3DSourcePositioning &positioning)
{
	positioning = m_sourcePositioning;
}

void MinibusDataGenerator3DPlugin::Set3DSourcePositioning(const Mdgp3DSourcePositioning &positioning)
{
	m_sourcePositioning = positioning;
}

void MinibusDataGenerator3DPlugin::SetEnhanced3D(bool isActivated)
{
	s_environmentParams.m_enhanced3D = static_cast<u32> (isActivated);
}

} // namespace vox

#endif // D_YAK_CONFIG_USE_VOX_1_0