#include "yak_vox_alloc.h"

#ifndef OS_ANDROID
void* VoxAlloc(size_t size, const char* filename, const char* function, int line)
{
	return ( void*) yaknew char[ size ];
}

void* VoxAlloc( size_t size )
{
	return ( void*) yaknew char[ size ];
}

void* VoxAlloc( size_t size, vox::VoxMemHint memhint ) 
{ 
	return ( void*) yaknew char[ size ];
}

void* VoxAlloc( size_t size, vox::VoxMemHint memhint, const char* filename, const char* function, int line ) 
{ 
	return ( void*) yaknew char[ size ];
}

void VoxFree( void* ptr )
{
	yakdel( ptr );
}
#endif // OS_ANDROID