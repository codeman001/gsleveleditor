#ifndef __YAK_VOX_ALLOC_H
#define __YAK_VOX_ALLOC_H

#include <vox_memory.h>
#include "../yak_config.h"

#ifdef OS_ANDROID
#define EXTERN extern
#else
#define EXTERN
#endif

EXTERN void* VoxAlloc(size_t size, const char* filename, const char* function, int line);
EXTERN void* VoxAlloc( size_t size );
EXTERN void* VoxAlloc( size_t size, vox::VoxMemHint memhint );
EXTERN void* VoxAlloc( size_t size, vox::VoxMemHint memhint, const char* filename, const char* function, int line );
EXTERN void VoxFree( void* ptr );

#endif // __YAK_VOX_ALLOC_H