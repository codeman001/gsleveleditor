#include <math.h>
#include "../yak_peer.h"
#include "yak_vox_data_manager.h"

namespace yak
{
// ----------------------------------------------------------------------//

VoxDataManager::VoxDataManager()
{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
	m_clientVoxCache  = yaknew char[ D_YAK_CONFIG_RAW_DUMP_MAX_SIZE ];
	m_clientVoxBuffer = yaknew Buffer( m_clientVoxCache, D_YAK_CONFIG_RAW_DUMP_MAX_SIZE );
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
//-----------------------------------------------------------------------//

	m_mixingBuffer		= NULL;
	m_mixingBufferSize	= 0;

	int bufferSamples	= D_YAK_SOUND_RECORDER_FRAME_SIZE;
	int bufferSize		= D_YAK_SOUND_FRAME_NUM * bufferSamples * sizeof(vox::s32) * 2;

	m_inputBuffer		= yaknew vox::u8[ bufferSize ];
	m_readInput			= yaknew Buffer( (char*)m_inputBuffer, bufferSize );
	m_writeInput		= yaknew Buffer( (char*)m_inputBuffer, bufferSize );

	memset( m_inputBuffer, 0, bufferSize );
	m_inputBufferValidDataSize	= 0;
	m_inputBufferDelayDataSize	= D_YAK_CONFIG_VOX_DELAY_NUM_FRAMES * bufferSamples * sizeof(vox::s32) * 2;
}

VoxDataManager::~VoxDataManager()
{
	yakdel( m_mixingBuffer );

	yakdel( m_writeInput );
	yakdel( m_readInput );

	yakdel( m_inputBuffer );

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
	yakdel( m_clientVoxBuffer );
	yakdelarray( m_clientVoxCache);
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
//-----------------------------------------------------------------------//
}

void VoxDataManager::GetData(vox::s32* buffer, vox::s32 nbSample, vox::s32 sampleRate)
{
	vox::s32 neededSize = nbSample * sizeof(vox::s32) * 2;

	
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
	if( !m_clientVoxBuffer->CanWrite( neededSize ) )
	{
		char dbgName[ 64 ];

		sprintf( dbgName, "vox_cli_2_44KHz_0x%x_%d.pcm32", this, S_GetTime() );
		BufToFile( m_clientVoxBuffer, dbgName );

		m_clientVoxBuffer->WriteRewind();
	}
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
//-----------------------------------------------------------------------//

	if( m_inputBufferValidDataSize < neededSize || 
		m_inputBufferValidDataSize < m_inputBufferDelayDataSize )
	{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
		m_clientVoxBuffer->WriteZeroes( neededSize );
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
//-----------------------------------------------------------------------//

		//printf( "VR" );
		return;
	}

	// Reallocate mixing buffer if its size is too small
	if( m_mixingBufferSize < neededSize )
	{
		yakdel( m_mixingBuffer );

		m_mixingBuffer		= yaknew vox::u8[ neededSize ];
		m_mixingBufferSize	= m_mixingBuffer ? neededSize : 0;
	}

	// Fill the mixing buffer if in sending mode
	if( m_mixingBuffer )
	{
		// Reset buffer since it is an accumulator
		memset( m_mixingBuffer, 0, neededSize );

		// mutex scope block
		{
			vox::ScopeMutex sm( &m_mutex );

			if( m_readInput->CanRead( neededSize ) )
			{
				//yakout( "\n ---- READ %d samples at pos %d", neededSize/8, m_readInput->GetSizeR()/8 );
				m_readInput->ReadBlock( m_mixingBuffer, neededSize );

				if( m_readInput->GetFreeR() == 0 ) {
					m_readInput->ReadRewind();
					//printf( "R" );
				}
			}
			else
			{
				unsigned int nFree		= m_readInput->GetFreeR();
				unsigned int nRemain	= neededSize - nFree;

				//yakout( "\n ---- READ %d samples at pos %d", nFree/8, m_readInput->GetSizeR()/8 );
				m_readInput->ReadBlock( m_mixingBuffer, nFree );

				m_readInput->ReadRewind();
				//printf( "r" );

				//yakout( "\n ---- READ %d samples at pos %d", nRemain/8, m_readInput->GetSizeR()/8 );
				m_readInput->ReadBlock( m_mixingBuffer + nFree, nRemain );
			}

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
			m_clientVoxBuffer->WriteBlock( m_mixingBuffer, neededSize );
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
//-----------------------------------------------------------------------//
			m_inputBufferValidDataSize -= neededSize;
		}

		// Add the content of the mixing buffer to the (accumulator) buffer provided by vox minibus
		vox::fx1814 *pData = reinterpret_cast<vox::fx1814*> ( m_mixingBuffer );
		for(int i = 0; i < nbSample; i++)
		{
			// Fill left channel
			*buffer += (*pData);
			buffer++;
			pData++;

			// Fill right channel
			*buffer += (*pData);
			buffer++;
			pData++;
		}
	}

	//yakout( "\n valid size: %d", m_inputBufferValidDataSize );
}

void VoxDataManager::SetData(vox::u8* buffer, vox::s32 size)
{
	vox::ScopeMutex sm(&m_mutex);

	if( !m_writeInput->CanWrite( size ) )
	{
		unsigned int nFree		= m_writeInput->GetFreeW();
		unsigned int nRemain	= size - nFree;

		//yakout( "\n ++++WRITE %d samples at pos %d", nFree/8, m_writeInput->GetSizeW()/8 );
		m_writeInput->WriteBlock( buffer, nFree );

		m_writeInput->WriteRewind();
		//printf( "w" );

		//yakout( "\n ++++WRITE %d samples at pos %d", nRemain/8, m_writeInput->GetSizeW()/8 );
		m_writeInput->WriteBlock( buffer + nFree, nRemain );
	}
	else {
		//yakout( "\n ++++WRITE %d samples at pos %d", size/8, m_writeInput->GetSizeW()/8 );
		m_writeInput->WriteBlock( buffer, size );

		if( m_writeInput->GetFreeW() == 0 ) {
			m_writeInput->WriteRewind();
			//printf( "W" );
		}
	}

	m_inputBufferValidDataSize += size;
}

// ----------------------------------------------------------------------//
} // namespace yak;