#ifndef __YAK_VOX_DATA_MANAGER_H
#define __YAK_VOX_DATA_MANAGER_H

// **************************************************************************************** //
// *********************************** VoxDataManager class ********************************** //
// **************************************************************************************** //

// VoxDataManager receives data from DataProvider through its SetData() method. It cumulates the received
// data in its input buffer and when the input buffer data size gets greater than a threshold (fixed
// arbitrarily at 3 seconds), it starts providing it to the vox minibus system (which calls the
// GetData() callback at the driver callback period (by default VOX_MMSYSTEM_DRIVER_BUFFER_LENGTH
// when using Windows mmsystem driver).

#include <vox.h>
#include <vox_mutex.h>
#ifdef D_YAK_CONFIG_USE_VOX_1_0
#	include "plugin/vox_minibus_data_generator_plugin_1_0.h"
#else
#	include "plugin/vox_minibus_data_generator_plugin_1_1.h"
#endif

#include "../yak_config.h"
#include "../yak_buffer.h"

namespace yak
{
// ----------------------------------------------------------------------//
class Peer;

class VoxDataManager : public vox::MinibusDataGenerator3DPlugin
{
public:
	VoxDataManager();
	~VoxDataManager();

	static vox::s32	GetDriverSampleRate(){return s_driverSampleRate;}
	
	// Method the data provider calls to send data
	void			SetData(vox::u8* buffer, vox::s32 size);

	// Method called by vox minibus system to provide data at driver rate
	virtual void	GetData(vox::s32* buffer, vox::s32 nbSample, vox::s32 sampleRate);
 private:

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
	char				*m_clientVoxCache;
	Buffer				*m_clientVoxBuffer;
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
//-----------------------------------------------------------------------//

	 vox::u8			*m_mixingBuffer;
	 vox::s32			m_mixingBufferSize;
	 
	 vox::u8			*m_inputBuffer;	 
	 vox::s32			m_inputBufferValidDataSize;
	 vox::s32			m_inputBufferDelayDataSize;
	 
	 Buffer				*m_readInput;
	 Buffer				*m_writeInput;
	 vox::Mutex			 m_mutex;					// To prevent concurrent read/write in input buffer.
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_VOX_DATA_MANAGER_H