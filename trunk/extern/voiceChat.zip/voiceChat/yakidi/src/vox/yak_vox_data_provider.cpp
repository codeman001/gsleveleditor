#include <math.h>

#include "yak_vox_data_provider.h"

namespace yak
{
// ----------------------------------------------------------------------//
#if D_YAK_CONFIG_USE_WHITE_NOISE_FOR_SILENCE
static vox::s32 s_whiteNoise[ 48000 * sizeof( vox::s32 ) * 2];
#endif

vox::fx1814	 VoxDataProvider::m_masterVolume	= ( VOX_FX1814_ONE * 3 ) >> 2; // max volume

VoxDataProvider::VoxDataProvider( VoxDataManager *pDataManager, vox::s32 inRate )
:m_pDataManager( pDataManager )
{
	m_driverSampleRate		= VoxDataManager::GetDriverSampleRate();
	m_inSamplingRate		= inRate;
	
	m_inputBufferSamples	= ( D_YAK_SOUND_FRAME_TIME * m_driverSampleRate ) / 1000;
	m_inputBufferSize		= m_inputBufferSamples * sizeof( vox::s32 ) * 2;
	
	m_inputBuffer			= yaknew vox::u8[ m_inputBufferSize ];
	memset( m_inputBuffer, 0, m_inputBufferSize );

	m_upsampleBuffer		= yaknew vox::s16[ m_inputBufferSamples ];

#if D_YAK_CONFIG_USE_SPEEX_RESAMPLER
	int ret = 0;
	m_upSampler = speex_resampler_init ( 1, m_inSamplingRate, m_driverSampleRate, 0, &ret );
#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER
}

VoxDataProvider::~VoxDataProvider()
{
#if D_YAK_CONFIG_USE_SPEEX_RESAMPLER
	speex_resampler_destroy( ( SpeexResamplerState* ) m_upSampler );
#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER

	yakdel( m_upsampleBuffer );
	yakdel( m_inputBuffer );
}


void VoxDataProvider::Update( vox::s16 *samples, vox::s32 nbSamples )
{
	vox::s32 *pOutput = reinterpret_cast<vox::s32*> ( m_inputBuffer );

	// ----------    silence packets    -----------------
	if( nbSamples == 0 )
	{
#if D_YAK_CONFIG_USE_WHITE_NOISE_FOR_SILENCE
		for( int k = 0; k < m_inputBufferSamples; k++ )
		{
			vox::s32 noise = ( ( rand() % 8 ) << 1 ) - 8;
			s_whiteNoise[ k * 2 + 0 ] = noise;
			s_whiteNoise[ k * 2 + 1 ] = noise;
		}
		m_pDataManager->SetData( reinterpret_cast<vox::u8*>(&s_whiteNoise[ 0 ]), m_inputBufferSize );
#else
		memset( m_inputBuffer, 0, m_inputBufferSize );
		m_pDataManager->SetData( m_inputBuffer, m_inputBufferSize );
#endif
		return;
	}

	// ----------    voice packets    -----------------
	vox::fx1814 leftGain  = m_masterVolume;
	vox::fx1814 rightGain = m_masterVolume;

#if D_YAK_CONFIG_USE_3DFX_VOICES
	if( ArchSupports3DVoice() )
	{
		vox::fx1814 leftPan, rightPan;
		vox::fx1814 gain3D;

		// Get volume attenuation caused by source to listener distance
		gain3D = m_pDataManager->GetDistanceGain();
		leftGain = (leftGain * gain3D) >> VOX_FX1814_FRACT_SHIFT;

		// Get volume attenuation caused by source directional sound propagation
		gain3D = m_pDataManager->GetDirectionalGain();
		leftGain = (leftGain * gain3D) >> VOX_FX1814_FRACT_SHIFT;

#if VOX_NEON_MIXER
		if(neonInstructionsPresent())
		{
			if(leftGain > 16383)
				leftGain = 16383;
		}
#endif

		// Get stereo panning due to source position relative to listener. Important to update rightGain before leftGain.
		m_pDataManager->GetStereoPanning(&leftPan, &rightPan);
		rightGain = (leftGain * rightPan) >> VOX_FX1814_FRACT_SHIFT;
		leftGain = (leftGain * leftPan) >> VOX_FX1814_FRACT_SHIFT;
	}
#endif // D_YAK_CONFIG_USE_3DFX_VOICES

#if D_YAK_CONFIG_USE_SPEEX_RESAMPLER
	speex_resampler_process_int ( 
		( SpeexResamplerState * ) m_upSampler,
		0,
		( short* ) samples,
		( spx_uint32_t * ) &nbSamples,
		m_upsampleBuffer,
		( spx_uint32_t * ) &m_inputBufferSamples
	);

#else
	vox::s32 sampleValue, sampleBefore, diff;
	vox::fx1814 currentSample = 0;
	vox::fx1814 fract;
	vox::s32 leftValue = 0;
	vox::s32 rightValue = 0;

	vox::fx1814 effectivePitch = ( m_inSamplingRate << VOX_FX1814_FRACT_SHIFT ) / m_driverSampleRate;
#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER

	for( vox::s32 i = 0; i < m_inputBufferSamples; i++ )
	{
#if	D_YAK_CONFIG_USE_SPEEX_RESAMPLER
		vox::s32 leftValue  = m_upsampleBuffer[ i ];
		vox::s32 rightValue = m_upsampleBuffer[ i ];
#else
		// Interpolate sample value
		sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
		fract = currentSample & VOX_FX1814_FRACT_MASK;

		if( sampleBefore + 1 >= nbSamples )
		{
			for( int k = i; k < m_inputBufferSamples; k++ )
			{
				// Fill left channel
				*pOutput = leftValue;
				pOutput++;

				// Fill right channel
				*pOutput = rightValue;
				pOutput++;			
			}
			break;
		}

		//do not merge the following 2 lines, it breaks interpolation on Vita Release
		diff = ( samples[sampleBefore + 1] - samples[sampleBefore] );
		sampleValue = samples[ sampleBefore ] + ( ( fract * diff ) >> VOX_FX1814_FRACT_SHIFT );

		leftValue = ((sampleValue * leftGain) >> VOX_FX1814_FRACT_SHIFT);
		rightValue = ((sampleValue * rightGain) >> VOX_FX1814_FRACT_SHIFT);

		currentSample += effectivePitch;
#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER

		// Fill left channel
		*pOutput = leftValue;
		pOutput++;

		// Fill right channel
		*pOutput = rightValue;
		pOutput++;
	}

	// Send data to the DataManager
	m_pDataManager->SetData( m_inputBuffer, m_inputBufferSize );
}

// ----------------------------------------------------------------------//
} // namespace yak;