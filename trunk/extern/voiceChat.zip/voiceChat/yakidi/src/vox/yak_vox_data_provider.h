#ifndef __YAK_VOX_DATA_PROVIDER_H
#define __YAK_VOX_DATA_PROVIDER_H

#include <vox.h>
#include <vox_mutex.h>
// **************************************************************************************** //
// *********************************** VoxDataProvider class ********************************* //
// **************************************************************************************** //

// VoxDataProvider plays the role of the network and provides data (on a regular basis for simplicity)
// to the data manager. We have set the rate at which the provider sends data as 80% of the rate
// at which the driver expects data in order to make the DataManager starve from time to time and
// thus avoid DataManager buffer overflows.

#include "../yak_config.h"

extern "C"
{
	#include "../speex/include/speex_resampler.h"
}

#include "yak_vox_data_manager.h"

namespace yak
{
// ----------------------------------------------------------------------//

class VoxDataProvider
{
protected:
	 static vox::fx1814		 m_masterVolume;

	 VoxDataManager			*m_pDataManager;

	 vox::u8				*m_inputBuffer;
	 vox::s32				 m_inputBufferSize;
	 vox::s32				 m_inputBufferSamples;

	 vox::s32				 m_driverSampleRate;		// Sample rate at which vox driver expects data
	 vox::s32				 m_inSamplingRate;

	 vox::s16				*m_upsampleBuffer;

#if D_YAK_CONFIG_USE_SPEEX_RESAMPLER
	 void					*m_upSampler;
#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER

public:
	 VoxDataProvider( VoxDataManager *pDataManager, vox::s32 inRate );
	 ~VoxDataProvider();

	 void					Update( vox::s16 *samples, vox::s32 nbSamples );// Method clocked by update thread to provide data to DataManager.

	 static void			SetMasterVolume( vox::fx1814 volume )	{ m_masterVolume = volume; }
	 static vox::fx1814		GetMasterVolume()						{ return m_masterVolume; }
	 static vox::fx1814		GetMaxVolume()							{ return ( ( VOX_FX1814_ONE * 75 ) / 100 );  }

};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_VOX_DATA_PROVIDER_H
