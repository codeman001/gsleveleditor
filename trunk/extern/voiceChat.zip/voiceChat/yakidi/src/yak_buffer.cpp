#include "yak_buffer.h"

namespace yak
{
// ----------------------------------------------------------------------//

Buffer::Buffer( char *buf, int length )
{
	m_data			= buf;

	m_write_pos		= 0;
	m_read_pos		= 0;

	m_length		= length;
}

Buffer::~Buffer()
{
}

void Buffer::ReadChar( char *c )
{
	yakass( c != NULL && CanRead( sizeof( char ) ) );

	*c = (m_data[m_read_pos++] & 0xFF);
}

void Buffer::ReadShort( short *h )
{
	yakass( h != NULL && CanRead( sizeof( short ) ) );

	*h  = (m_data[m_read_pos++] & 0xFF) << 8;
    *h |= (m_data[m_read_pos++] & 0xFF);
}

void Buffer::ReadInt( int *i )
{
	yakass( i != NULL && CanRead( sizeof( int ) ) );

	*i  = (m_data[m_read_pos++] & 0xFF) << 24;
    *i |= (m_data[m_read_pos++] & 0xFF) << 16;
    *i |= (m_data[m_read_pos++] & 0xFF) << 8;
    *i |= (m_data[m_read_pos++] & 0xFF);
}

void Buffer::ReadFloat( float *f )
{
	yakass( f != NULL && CanRead( sizeof( float ) ) );

	char *p = (char *)f;

	*(p)	= m_data[m_read_pos++];
	*(p+1)	= m_data[m_read_pos++];
	*(p+2)	= m_data[m_read_pos++];
	*(p+3)	= m_data[m_read_pos++];
}

void Buffer::ReadBlock( void *buf, unsigned int size )
{
	yakass( buf != NULL && CanRead( size * sizeof( char ) ) );

	if( size > 0 )
	{
		char *b = ( char* ) &m_data[ m_read_pos ];	
		memcpy( buf, b, size * sizeof( char ) );

		m_read_pos += size * sizeof( char );
	}
}

void Buffer::WriteChar( char c )
{
	yakass( CanWrite( sizeof( char ) ) );

	char data = c;

	m_data[m_write_pos++] = (char)((data & 0x000000FF));
}

void Buffer::WriteShort( short h )
{
	yakass( CanWrite( sizeof( short ) ) );

	short data = h;

	m_data[m_write_pos++] = (char)((data & 0x0000FF00)>>8);
    m_data[m_write_pos++] = (char)((data & 0x000000FF));
}


void Buffer::WriteInt( int i )
{
	yakass( CanWrite( sizeof( int ) ) );

	int data = i;

	m_data[m_write_pos++] = (char)((data & 0xFF000000)>>24);
    m_data[m_write_pos++] = (char)((data & 0x00FF0000)>>16);
    m_data[m_write_pos++] = (char)((data & 0x0000FF00)>>8);
    m_data[m_write_pos++] = (char)((data & 0x000000FF));
}

void Buffer::WriteFloat( float f )
{
	yakass( CanWrite( sizeof( float ) ) );

	float data = f;
	char* p = (char*)&data;

	m_data[m_write_pos++] = *(p);
	m_data[m_write_pos++] = *(p+1);
	m_data[m_write_pos++] = *(p+2);
	m_data[m_write_pos++] = *(p+3);
}

void Buffer::WriteBlock( void *b, unsigned int size )
{
	yakass( CanWrite( size * sizeof( char ) ) );

	if( size > 0 )
	{
		memcpy( &m_data[ m_write_pos ], b, size * sizeof( char ) );
		m_write_pos += size * sizeof( char );
	}
}

void Buffer::WriteZeroes( unsigned int nZeroes )
{
	int nFree = GetFreeW();
	if( nZeroes > GetFreeW() ) {
		nZeroes = nFree;
	}

	if( nZeroes > 0 )
	{
		memset( &m_data[ m_write_pos ], 0, nZeroes * sizeof( char ) );
		m_write_pos += nZeroes * sizeof( char );
	}
}

void Buffer::Encrypt( char *key, int keySize )
{
    static unsigned char s[256];
    static unsigned char k[256];
    unsigned char temp;
    int i, j;

    for (i = 0; i < 256; i++)
    {
        s[i] = ( unsigned char ) i;
        k[i] = key[ i % keySize ];
    }

    j = 0;
    for (i = 0; i < 256; i++)
    {
        j = ( j + s[ i ] + k[ i ] ) % 256;
        temp = s[ i ];
        s[ i ] = s[ j ];
        s[ j ] = temp;
    }

    i = j = 0;
    for( int x = 0; x < keySize; x++ )
    {
        i = ( i + 1 ) % 256;
        j = ( j + s[ i ] ) % 256;
        temp = s[ i ];
        s[ i ] = s[ j ];
        s[ j ] = temp;
        int t = ( s[ i ] + s[ j ] ) % 256;
        m_data[ x ] ^= s[ t ];
    }
}

void Buffer::Decrypt( char *key, int keySize )
{
	Encrypt( key, keySize );
}

bool Buffer::CanWrite( unsigned int size )
{
	return ( m_write_pos + size <= m_length );
}

bool Buffer::CanRead( unsigned int size )
{
	return ( m_read_pos + size <= m_length );
}

// ----------------------------------------------------------------------//
} // namespace yak;