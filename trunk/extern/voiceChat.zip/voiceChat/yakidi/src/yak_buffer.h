#ifndef __YAK_CBUFFER_H
#define __YAK_CBUFFER_H

#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

class Buffer
{
protected:
	unsigned int	m_write_pos;
	unsigned int	m_read_pos;
	unsigned int	m_length;

	char			*m_data;

public:
	Buffer( char *buf, int length );
	 ~Buffer();

	void			ReadChar( char *c );
	void			ReadShort( short *h );
	void			ReadInt( int *i );
	void			ReadFloat( float *f );
	void			ReadBlock( void *buf, unsigned int size );
	void			ReadRewind() { m_read_pos = 0; }
	void			ReadForward( unsigned int fw ) { m_read_pos = fw; }
	void			ReadSkip( unsigned int fw ) { m_read_pos += fw; }

	void			WriteChar( char c );
	void			WriteShort( short h );
	void			WriteInt( int i );
	void			WriteFloat( float f );
	void			WriteBlock( void *b, unsigned int size );
	void			WriteZeroes( unsigned int nZeroes );
	void			WriteRewind() { m_write_pos = 0; }
	void			WriteForward( unsigned int fw ) { m_write_pos = fw; }
	void			WriteSkip( unsigned int fw ) { m_write_pos += fw; }


	// RC4 encryption/decryption algorithm
	void			Encrypt( char *key, int keySize );
	void			Decrypt( char *key, int keySize );

	unsigned int	GetSizeW() { return m_write_pos; }
	unsigned int	GetSizeR() { return m_read_pos; }

	unsigned int	GetFreeW() { return m_length - m_write_pos; }
	unsigned int	GetFreeR() { return m_length - m_read_pos; }

	char*			GetData() { return m_data; }
	char*			GetPtrR() { return m_data + m_read_pos; }
	char*			GetPtrW() { return m_data + m_write_pos; }

	bool			CanWrite( unsigned int size );
	bool			CanRead( unsigned int size );
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CBUFFER_H
