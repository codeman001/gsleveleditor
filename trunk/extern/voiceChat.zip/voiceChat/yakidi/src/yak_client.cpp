#include <math.h>
#include "yak_client.h"

namespace yak
{
// ----------------------------------------------------------------------//

void* ClientThreadProc(void * pParam);

Client::Client( Codec::EContext outCtx, Codec::EContext inCtx, Listener *dg ) 
: Conference( outCtx, inCtx )
{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE
	m_sineWaveBuffer = new short[ D_YAK_SOUND_RECORDER_SAMPLING_RATE ];

	float angle;
	float frequency = 500.0f;
	float inverseSampleRate = 2.0f * 3.1415926535897932f / D_YAK_SOUND_RECORDER_SAMPLING_RATE;	

	for(int i = 0; i < D_YAK_SOUND_RECORDER_SAMPLING_RATE; i++)
	{	
		angle = inverseSampleRate * frequency;
		m_sineWaveBuffer[i] = static_cast<vox::s16> (5000 * sin(i * angle));
	}

	m_sineWaveCursor = 0;
#endif // D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE

#if D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE
	m_clientRecCache = yaknew char[ D_YAK_CONFIG_RAW_DUMP_MAX_SIZE ];
	m_clientRecBuffer = yaknew Buffer( m_clientRecCache, D_YAK_CONFIG_RAW_DUMP_MAX_SIZE );
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE
//-----------------------------------------------------------------------//

	m_bwOutCount		= 0;
	m_bwInCount			= 0;
	m_bwOut				= 0.0f;
	m_bwIn				= 0.0f;
	m_bwlastTime		= 0;

	m_enterTime			= 0;
	m_exitTime			= 0;

#if D_YAK_DEBUG_STRING
	m_dbgString[0]		= '\0';
	m_lastTimestamp		= 0;
#endif //D_YAK_DEBUG_STRING

	m_listener			= dg;

	m_isDiscoverable	= false;
	m_isConnected		= false;
	m_isMuted			= false;
	m_isSuspended		= false;
	m_isAcceptingConnections	= true;

	m_isUpnpDone		= false;
	m_upnpPort			= 0;

	m_socket.Create( AF_INET, SOCK_DGRAM, 0 );
	m_socket.Bind( 0 );

	m_iAmSpeaking	= false;
	m_speakingMask	= 0;
	int localIP		= 0;

	Socket::GetLocalIP( &localIP );

	m_peerMe->SetLocalIP( localIP );
	m_peerMe->SetLocalPort( m_socket.GetPort() );

	m_peerMe->SetRemoteIP( localIP );
	m_peerMe->SetRemotePort( m_socket.GetPort() );

	memset( &m_3DParameters, 0, sizeof( m_3DParameters ));
	memset( &m_3DListenerPositioning, 0, sizeof( m_3DListenerPositioning ));

	m_recordCache			= yaknew char[ D_YAK_SOUND_RECORDER_BLOCK_BUFFER_SIZE ];
	memset( m_recordCache, 0, D_YAK_SOUND_RECORDER_BLOCK_BUFFER_SIZE );

	m_recordWrite			= yaknew Buffer( m_recordCache, D_YAK_SOUND_RECORDER_BLOCK_BUFFER_SIZE );
	m_recordRead			= yaknew Buffer( m_recordCache, D_YAK_SOUND_RECORDER_BLOCK_BUFFER_SIZE );

	m_signalTime			= -1;

	AddState( Client::eStateIdle,			this, &Client::StateIdleCallback );
	AddState( Client::eStateDiscovery,		this, &Client::StateDiscoveryCallback );
	AddState( Client::eStateConnecting,		this, &Client::StateConnectingCallback );
	AddState( Client::eStateConnected,		this, &Client::StateConnectedCallback );
	AddState( Client::eStateError,			this, &Client::StateErrorCallback );

	StateMachine::Init( Client::eStateIdle );

	m_error					= Client::eErrorNone;

	m_isInitialized			= false;
	m_quit					= false;
	m_thread.Init( ClientThreadProc, this, 0 );
	m_thread.Start();
}

Client::~Client()
{
	Leave();
	Close();

	m_quit = true;
	m_thread.Stop();

	Sleep( 50 );

	Condition c( &m_mutex );

	yakdel( m_recordWrite );
	yakdel( m_recordRead );
	yakdel( m_recordCache );

	m_socket.Close();

	StateMachine::Destroy();

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE
	yakdel( m_clientRecBuffer );
	yakdelarray( m_clientRecCache);
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE

#if D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE
	yakdelarray( m_sineWaveBuffer );
#endif // D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE
//-----------------------------------------------------------------------//
}

void Client::Init( int serverIp, unsigned short serverPort )
{
	if( !m_isInitialized )
	{
		Condition c( &m_mutex );

		m_peerSv->SetRemoteIP( serverIp );
		m_peerSv->SetRemotePort( serverPort );
		
		m_isInitialized = true;
	}
}


void Client::Send( int ip, unsigned short port, const char *buf, int len )
{
	int nBytes = m_socket.Send( ip, port, buf, len );
	m_bwOutCount += MAX( 0, nBytes );
}

void Client::SendGetServerAddress()
{
	char	b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

	bb.WriteChar( Conference::eServerRequestServerInfo );
	bb.WriteShort( m_peerMe->GetLocalPort() );

	Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
}

void Client::SendGetRemoteInfo()
{
	char	b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

	bb.WriteChar( Conference::eServerRequestRemoteInfo );
	bb.WriteInt( m_peerMe->GetLocalIP() );
	bb.WriteShort( m_peerMe->GetLocalPort() );

	Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
}

void Client::SendJoin()
{
	yakass( m_isDiscoverable );

	char	b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

	bb.WriteChar( Conference::eServerRequestJoin );
	bb.WriteChar( static_cast<char>( kArchitecture ) );
	bb.WriteChar( static_cast<char>( m_peerMe->GetCodec()->GetOutContextId() ) );
	bb.WriteChar( static_cast<char>( m_peerMe->GetCodec()->GetInContextId() ) );
	bb.WriteChar( m_peerMe->GetMemberId() );
	bb.WriteInt( m_peerMe->GetLocalIP() );
	bb.WriteShort( m_peerMe->GetLocalPort() );

	Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
}

void Client::SendLeave()
{
	char	b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

	bb.WriteChar( Conference::eServerRequestLeave );
	bb.WriteChar( m_peerMe->GetMemberId() );

	// burst 3 messages
	Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
	Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
	Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
}

void Client::SendPresence()
{
	if( m_isConnected && m_signalTime != -1 )
	{
		if( m_currentTime - m_signalTime > D_YAK_CONFERENCE_SIGNALLING_TIME )
		{
			char	b[ D_YAK_PACKET_MAX_SIZE ];
			Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

			bb.WriteChar( Conference::eServerRequestSignal );
			bb.WriteChar( m_peerMe->GetMemberId() );

			Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );

			m_signalTime = m_currentTime;
		}
	}
}

void Client::SendPing( Peer *peer )
{
	yakass( peer != NULL );
	
	char b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

	bb.WriteInt( Conference::kClientRequestTS );
	bb.WriteChar( m_peerMe->GetMemberId() );
	bb.WriteChar( Conference::eClientRequestPing );
	bb.WriteInt( m_currentTime );

	Send( peer->GetRemoteIP(), peer->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
}

void Client::SendPeerState( Peer *peer, Peer::EState state )
{
	yakass( peer != NULL );

	char b[ D_YAK_PACKET_MAX_SIZE ];
	Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

#if !D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
	if( peer == m_peerMe ) {
		return;
	}
#endif // !D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT

	if( peer->IsReachable() && kArchitecture != eArchitectureServer )
	{
		bb.WriteInt( Conference::kClientRequestTS );
		bb.WriteChar( m_peerMe->GetMemberId() );
		bb.WriteChar( Conference::eClientRequestPeerState );
		bb.WriteChar( static_cast<char>(state) );
		bb.WriteChar( IsAcceptingConnections() ? '1' : '0' );

		Send( peer->GetRemoteIP(), peer->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
	}
	else
	{
		bb.WriteChar( Conference::eServerRequestForwardPeerState );
		bb.WriteChar( m_peerMe->GetMemberId() );
		bb.WriteChar( peer->GetMemberId() );
		bb.WriteChar( static_cast<char>(state) );
		bb.WriteChar( IsAcceptingConnections() ? '1' : '0' );

		Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
	}
}


bool Client::IsServer( int ip, unsigned short port )
{
	return ( ip		== m_peerSv->GetRemoteIP() &&
			 port	== m_peerSv->GetRemotePort() );
}

void Client::Record( char *frame,  unsigned short size )
{
	if( m_isSuspended || !m_isConnected ) {
		return;
	}

	Condition c( &m_mutex );

#if D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE
	if( !m_clientRecBuffer->CanWrite( size ) )
	{
		char dbgName[ 64 ];

		sprintf( dbgName, "rec_cli_1_44KHz_%d_%d.pcm16", m_peerMe->GetMemberId(), S_GetTime() );
		BufToFile( m_clientRecBuffer, dbgName );

		m_clientRecBuffer->WriteRewind();
	}
	
	m_clientRecBuffer->WriteBlock( frame, size );
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE

	if( !m_recordWrite->CanWrite( size ) )
	{
		unsigned int nFree		= m_recordWrite->GetFreeW();
		unsigned int nRemain	= size - nFree;

		m_recordWrite->WriteBlock( frame, nFree );
		
		int i = m_recordWrite->GetSizeW();
		int j = m_recordRead->GetSizeR();
		int w = ( i - j ) / D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE;

		for( int k = 0; k < w; k++ ) {
			Flush();
		}

		m_recordWrite->WriteRewind();
		m_recordWrite->WriteBlock( frame + nFree, nRemain );
	}
	else
	{
		m_recordWrite->WriteBlock( frame, size );
		
		int i = m_recordWrite->GetSizeW();
		int j = m_recordRead->GetSizeR();
		int w = ( i - j ) / D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE;

		for( int k = 0; k < w; k++ ) {
			Flush();
		}

		if( m_recordWrite->GetFreeW() == 0 ) {
			m_recordWrite->WriteRewind();
		}
	}
}

void Client::Flush()
{
	int len				= 0;
	char *src			= NULL;
	Codec *codec		= m_peerMe->GetCodec();
	Codec::Context *ctx	= codec->GetOutContext();

#if D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE
	src					= (char*)(m_sineWaveBuffer + m_sineWaveCursor);
	int bufSize			= D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE;

	Codec::LockEncode();
	src = codec->Preprocess( D_YAK_SOUND_RECORDER_SAMPLING_RATE, src, bufSize, true, !D_YAK_CONFIG_USE_AGC_ON_SERVER );
	if( src != NULL )
	{
		len = codec->Encode( src, ctx->m_bufferSize );
		Speak( Codec::GetEncodeBuffer(), len );
	}
	else { // SILENCE
		Speak( NULL, 0 );
	}
	Codec::UnlockEncode();

	m_sineWaveCursor += D_YAK_SOUND_RECORDER_FRAME_SIZE;
	m_sineWaveCursor %= D_YAK_SOUND_RECORDER_SAMPLING_RATE;

	// sync with the real buffer
	m_recordRead->ReadSkip( D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE );
	if( m_recordRead->GetFreeR() == 0 ) {
		m_recordRead->ReadRewind();
	}

//	unsigned int now = S_GetTime();
//	static unsigned int lt = 0;
//	printf( "\nLT: %d", now-lt );
//	lt = now;

	return;
#endif // D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE

	src					= m_recordRead->GetPtrR();
	int srcSize			= D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE;

	Codec::LockEncode();
	src = codec->Preprocess( D_YAK_SOUND_RECORDER_SAMPLING_RATE, src, srcSize, true, true );
	if( src != NULL )
	{
		len = codec->Encode( src, ctx->m_bufferSize );
		Speak( Codec::GetEncodeBuffer(), len );
	}
	else { // SILENCE
		Speak( NULL, 0 );
	}
	Codec::UnlockEncode();

	m_recordRead->ReadSkip( D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE );
	if( m_recordRead->GetFreeR() == 0 ) {
		m_recordRead->ReadRewind();
	}
}

void Client::Speak( char *frame, unsigned short len )
{
	int forwardToMask = 0;

	Group *group = m_activeGroup;

	if( group != NULL )
	{
		char	b[ D_YAK_PACKET_MAX_SIZE ];
		Buffer	bb( b, D_YAK_PACKET_MAX_SIZE );

		if( kArchitecture != eArchitectureServer )
		{
			bb.WriteInt( m_timeStamp );
			bb.WriteChar( m_peerMe->GetMemberId() );
			bb.WriteShort( m_isMuted ? 0 : len );
			bb.WriteBlock( frame, len );
		}

		// send directly to reachable peers
		for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
		{
			Peer *peer = group->GetPeer( k );

			if( peer != NULL && peer->IsPaired() )
			{
#if !D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
				if( peer != m_peerMe )
#endif // !D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
				{
					if( peer->IsReachable() && kArchitecture != eArchitectureServer ) {
						Send( peer->GetRemoteIP(), peer->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );
					}
					else {
						forwardToMask |= ( 1 << peer->GetMemberId() );
					}
				}
			}
		}

		if( kArchitecture != eArchitectureP2P )
		{
			if( forwardToMask != 0 )
			{
				bb.WriteRewind();

				bb.WriteChar( Conference::eServerRequestForwardVoice );
				bb.WriteChar( m_peerMe->GetMemberId() );
				bb.WriteInt( forwardToMask );

				bb.WriteInt( m_timeStamp );
				bb.WriteShort( m_isMuted ? 0 : len );
				bb.WriteBlock( frame, len );

				Send( m_peerSv->GetRemoteIP(), m_peerSv->GetRemotePort(), ( const char* ) bb.GetData(), bb.GetSizeW() );

                
                //unsigned int now = S_GetTime();
                //static unsigned int lt = 0;
                //printf( "\nSPK.LT: %d", now-lt );
                //lt = now;
                
				//printf( "\n[TS: %d]\tfrom: %d\tto: 0x%x", m_timeStamp, m_peerMe->GetMemberId(), forwardToMask );
			}
		}
	}

	m_iAmSpeaking = ( len > 0 );
	m_timeStamp += D_YAK_SOUND_FRAME_TIME;
}

void Client::SyncPeerState( Peer *peer )
{
	yakass( peer != NULL );

	unsigned int now = m_currentTime;
	unsigned int lt = peer->GetLastStateSyncTime();

	if( now - lt > D_YAK_PEER_STATE_SYNC_INTERVAL ) {
		SendPeerState( peer, peer->GetLocalState() );
		peer->SetLastStateSyncTime( now );
	}
}

void Client::UpdatePeerState( Peer *peer, Peer::EState remoteState, bool isAccepting )
{
	yakass( peer != NULL );

	peer->SetAcceptingConnections( isAccepting );
	peer->SetRemoteState( remoteState );

	if( m_isAcceptingConnections && 
		Peer::eStatePaired == remoteState  && 
		Peer::eStateMuted  != peer->GetLocalState() ) 
	{
		peer->SetLocalState( Peer::eStatePaired );	
	}
	else if( Peer::eStateMuted == remoteState )
	{
		peer->SetLocalState( Peer::eStateIdle );
	}
}

void Client::UpdateConnections()
{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
	// m_peerMe uid = 0... ping it to test loopback chat
	m_peerMe->SetLocalState( Peer::eStatePaired );
	m_peerMe->SetRemoteState( Peer::eStatePaired );
	m_peerMe->SetConnectionTime( m_currentTime );
	m_peerMe->SetRemoteIP( m_peerMe->GetLocalIP() );
	m_peerMe->SetRemotePort( m_peerMe->GetLocalPort() );
#endif
//-----------------------------------------------------------------------//

	for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
	{
		Peer *peer = m_allPeers[ k ];

		if( peer != NULL )
		{
#if !D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
			if( peer != m_peerMe)
#endif // !D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
			{
				SyncPeerState( peer );

				if( kArchitecture != eArchitectureServer )
				{
					if( !peer->IsPinged() )
					{
						if( peer->HolePunchTimedOut() )
						{
							// default to client-server
							if( m_listener != NULL ) {
								m_listener->OnPeerHolePunchFail( peer );
							}

							peer->SetReachable( false );
							peer->SetPinged( true );

							yakout( "\nPeer %d is not reachable; fallback to client-server", peer->GetMemberId() );
						}
						else
						{
							if( peer->CanComputeRtt() )
							{
								peer->ComputeRtt();
								peer->SetReachable( true );
								peer->SetPinged( true );
							}
							else
							{
								unsigned int lt = peer->GetLastPingTime();

								if( m_currentTime - lt > 50 )
								{
									SendPing( peer );
									peer->SetLastPingTime( m_currentTime );
								}
							}
						}
					}
				}
			}
		}
	}	
}

void Client::Process( Buffer *buf, int ip, unsigned short port )
{
	if( IsServer( ip, port ) )
	{ // message received from discovery/udp hole punching server

		char remote_response = 0;
		buf->ReadChar( &remote_response );
		
		Conference::EServerResponse response = static_cast<Conference::EServerResponse>( remote_response );

		switch( response )
		{
		case Conference::eServerResponseServerInfo:
			{
				int					ip;
				unsigned short		port;

				buf->ReadInt( &ip );
				buf->ReadShort( ( short* ) &port );

				if( ip != 0 ) {
					m_peerSv->SetRemoteIP( ip );
				}

				if( port != 0 ) {
					m_peerSv->SetRemotePort( port );
				}
			}
			break;

		case Conference::eServerResponseRemoteInfo:
			{
				Peer::Address remote;

				buf->ReadInt( &remote.m_ip );
				buf->ReadShort( ( short* ) &remote.m_port );

				// get my endpoint address
				m_peerMe->SetRemoteIP( remote.m_ip );
				m_peerMe->SetRemotePort( remote.m_port );

				m_isDiscoverable = true;
			}
			break;

		case Conference::eServerResponseJoin:
			{
				char nPeers = 0;

				Peer::Address local;
				Peer::Address remote;

				buf->ReadInt( &remote.m_ip );
				buf->ReadShort( ( short* ) &remote.m_port );

				// get my endpoint address
				m_peerMe->SetRemoteIP( remote.m_ip );
				m_peerMe->SetRemotePort( remote.m_port );

				buf->ReadChar( &nPeers );

				yakout( "\nReceived Conference::ResponseJoin, %d peers", nPeers );
				yakout( "\nMY ENDPOINT ADDRESS: %s ", inet_ntoa( *((in_addr*)&remote.m_ip) ) );

				for( int k = 0; k < nPeers; k++ )
				{
					Peer *peer		= NULL;
					char  memberId	= 0;

					buf->ReadChar( &memberId );
					buf->ReadInt( &local.m_ip );
					buf->ReadShort( ( short* ) &local.m_port );
					buf->ReadInt( &remote.m_ip );
					buf->ReadShort( ( short* ) &remote.m_port );

					yakass( memberId != m_peerMe->GetMemberId() );

					peer = AddPeer( memberId, &local, &remote );

					if( peer != NULL )
					{
						peer->Set3DParameters( m_3DParameters );
						peer->Set3DListenerPositioning( m_3DListenerPositioning );

						if( IsAcceptingConnections() ) {
							peer->SetLocalState( Peer::eStatePaired );
						}

						if( m_listener != NULL ) {
							m_listener->OnPeerConnect( peer );
						}
					}
				}

				m_isConnected = true;
			}
			break;

		case Conference::eServerResponseAddPeer:
			{
				Peer *peer		= NULL;
				char  memberId	= 0;

				Peer::Address local;
				Peer::Address remote;

				buf->ReadChar( &memberId );

				yakass( memberId != m_peerMe->GetMemberId() );

				buf->ReadInt( &local.m_ip );
				buf->ReadShort( ( short* ) &local.m_port );
				buf->ReadInt( &remote.m_ip );
				buf->ReadShort( ( short* ) &remote.m_port );

				yakout( "\n Received Conference::ResponseAddPeer, memberId = %d", memberId );

				peer = AddPeer( memberId, &local, &remote );

				if( peer != NULL )
				{
					peer->Set3DParameters( m_3DParameters );
					peer->Set3DListenerPositioning( m_3DListenerPositioning );

					if( IsAcceptingConnections() ) {
						peer->SetLocalState( Peer::eStatePaired );
					}

					if( m_listener != NULL ) {
						m_listener->OnPeerConnect( peer );
					}
				}
			}
			break;

		case Conference::eServerResponseForwardVoice:
			{
				unsigned int timestamp = 0;
				char owner = 0;

				buf->ReadInt( ( int* ) &timestamp );
				buf->ReadChar( &owner );

				if( timestamp != Conference::kClientRequestTS )
				{
					Peer *peer = GetPeer( owner );

					if( peer != NULL )
					{
						Group *group = m_activeGroup;

						if( group != NULL && group->IsJoined( peer ) )
						{
							short dataSize = 0;

							buf->ReadShort( &dataSize );
							peer->AddSoundFrame( timestamp, buf->GetPtrR(), m_isMuted ? 0 : dataSize );
						}
					}

					//yakout( "\nRECV.eServerResponseForwardVoice %d from %d", timestamp, owner );
				}
			}
			break;

		case Conference::eServerResponseForwardPeerState:
			{
				char owner = 0;

				buf->ReadChar( &owner );

				Peer *peer = GetPeer( owner );

				if( peer != NULL )
				{
					char remote_state = 0, remove_available = 0;
					buf->ReadChar( &remote_state );
					buf->ReadChar( &remove_available );

					UpdatePeerState( peer, static_cast<Peer::EState>(remote_state), remove_available == '1' ); 

					//yakout( "\nRECV.eServerRequestForwardPeerState from %d", owner );
				}
			}
			break;

		case Conference::eServerResponseMixedVoice:
			{
				short dataSize			= 0;
				unsigned int timestamp	= 0;

				buf->ReadInt( ( int* ) &timestamp );
				buf->ReadInt( ( int* ) &m_speakingMask );
				buf->ReadShort( &dataSize );

				m_peerSv->AddSoundFrame( timestamp, buf->GetPtrR(), m_isMuted ? 0 : dataSize );
				m_peerSv->SetConnectionTime( m_currentTime );

#if D_YAK_DEBUG_STRING
				int ts_dt = timestamp - m_lastTimestamp;
				sprintf( m_dbgString, "[TS: %d][DT: %d] - %c", timestamp, m_currentTime - m_lastTime, ts_dt == D_YAK_SOUND_FRAME_TIME ? ' ':'L' );
				m_lastTimestamp = timestamp;
#endif // D_YAK_DEBUG_STRING
                
                //printf( "\nRECV.eServerResponseMixedVoice %d", timestamp );
			}
			break;

		case Conference::eServerResponseError:
			{
				char remote_error = 0;

				buf->ReadChar( &remote_error );

				m_error = static_cast<EClientError>( remote_error );
				m_currentStateCode = Client::eStateError;
			}
			break;
		}
	}
	else
	{ // message received from other peer
		unsigned int timestamp = 0;
		char owner = 0;

		buf->ReadInt( ( int* ) &timestamp );
		buf->ReadChar( &owner );

		if( timestamp == Conference::kClientRequestTS )
		{ // special packets changed between peers

			char	remote_request	= 0;
			buf->ReadChar( &remote_request );

			Conference::EClientRequest request = static_cast<Conference::EClientRequest>( remote_request );

			switch( request )
			{
			case Conference::eClientRequestPing:
				{
					Peer *peer = GetPeer( owner );
					
					if( peer != NULL )
					{
						unsigned int time	= 0;

						buf->ReadInt( ( int* ) &time );

						char b[ D_YAK_PACKET_MAX_SIZE ];
						Buffer bb( b, D_YAK_PACKET_MAX_SIZE );

						bb.WriteInt( Conference::kClientRequestTS );
						bb.WriteChar( m_peerMe->GetMemberId() );
						bb.WriteChar( Conference::eClientRequestPong );
						bb.WriteInt( time );

						Send( ip, port, ( const char* ) bb.GetData(), bb.GetSizeW() );
					}
					yakout( "\n Peer memberId: %d is trying to reach me ", owner );
				}
				break;

			case Conference::eClientRequestPong:
				{
					unsigned int time	= 0;

					buf->ReadInt( ( int* ) &time );

					Peer *peer = GetPeer( owner );
					if( peer != NULL ) {

						Peer::PingPacket pP;
						pP.m_time0 = time;
						pP.m_time1 = m_currentTime;

						peer->AddPingPacket( &pP );
						peer->SetConnectionTime( m_currentTime );
						yakout( "\n ===> Peer memberId:%d is reachable PING = %d", owner, pP.m_time1 - time );
					}
				}
				break;

			case Conference::eClientRequestPeerState:
				{
					Peer *peer = GetPeer( owner );

					if( peer != NULL )
					{
						char remote_state = 0, remove_available = 0;
						buf->ReadChar( &remote_state );
						buf->ReadChar( &remove_available );

						UpdatePeerState( peer, static_cast<Peer::EState>(remote_state), remove_available == '1' );
						peer->SetConnectionTime( m_currentTime );
					}
				}
				break;
			}
		}
		else // sound frame packets received from peers
		{
			Peer *peer = GetPeer( owner );

			if( peer != NULL )
			{
				Group *group = m_activeGroup;

				if( group != NULL && group->IsJoined( peer ) )
				{
					short dataSize = 0;

					buf->ReadShort( &dataSize );
					peer->AddSoundFrame( timestamp, buf->GetPtrR(), m_isMuted ? 0 : dataSize );
					peer->SetConnectionTime( m_currentTime );
				}
			}
		}
	}
}

void Client::Update()
{
	m_enterTime = S_GetTimeMicro();

	Condition c( &m_mutex );
	Conference::Update();

	while( m_socket.CanRead() )
	{
		static char recvBlock[ D_YAK_PACKET_MAX_SIZE ];
		static int  recvSize = D_YAK_PACKET_MAX_SIZE;

		int ip				= 0;
		unsigned short port = 0;
		int nRecv			= m_socket.Receive( recvBlock, recvSize, &ip, &port );

		if( nRecv > 0 )
		{
			Buffer buf( recvBlock, nRecv );
			Process( &buf, ip, port );

			m_bwInCount		+= MAX( 0, nRecv );
		}
		
		else if( nRecv == SOCKET_ERROR )
		{
			m_error = Client::eErrorSocketReceive;
			m_currentStateCode = Client::eStateError;
			break;
		}
	}

	StateMachine::Run();

	if( m_currentTime - m_bwlastTime >= 1000 )
	{
		m_bwOut = m_bwOutCount * 8.0f / 1000.0f;
		m_bwIn	= m_bwInCount * 8.0f / 1000.0f;

		m_bwOutCount = 0;
		m_bwInCount  = 0;

		m_bwlastTime = m_currentTime;
	}

	m_exitTime = S_GetTimeMicro();
}

void Client::Wait()
{
    static const int sleepTime = ( 85 * D_YAK_SLEEP_TIME_MICRO ) / 100;
	
	int processTime = m_exitTime - m_enterTime;
	int safeSleep = MIN( sleepTime, MAX( 0, sleepTime  - processTime ) );

	m_thread.WaitMicro( safeSleep );
    
    //printf( "\n sleepTime: %d", safeSleep );
}

void Client::Join( int memberId )
{
	if( !m_isConnected )
	{
		yakass( memberId >= 0 && memberId < D_YAK_PEER_UID_MAX );

		Condition c( &m_mutex );

		m_signalTime		= m_currentTime;

		m_peerMe->SetMemberId( memberId );
		m_allPeers[ memberId ] = m_peerMe;
		m_groupAll->AddPeer( m_peerMe );

		Open();

		if( kArchitecture == eArchitectureServer )
		{
			m_isDiscoverable	= true;
			m_currentStateCode	= Client::eStateConnecting;

			m_peerSv->SetLocalState( Peer::eStatePaired );
			m_peerSv->SetRemoteState( Peer::eStatePaired );
		}
		else
		{
			m_isUpnpDone		= false;
			m_currentStateCode = Client::eStateDiscovery;
		}
	}
}

void Client::Leave()
{
	if( m_isConnected )
	{
		Close();

        {
            Condition c( &m_mutex );

            SendLeave();

            RemoveAllPeers();
            RemoveAllGroups();

            int memberId = m_peerMe->GetMemberId();
            m_allPeers[ memberId ] = NULL;
            m_groupAll->RemovePeer( m_peerMe );
            m_peerMe->SetMemberId( -1 );

            m_isConnected	= false;
            m_signalTime	= -1;

            m_isUpnpDone	= false;
            m_upnpPort		= 0;

            m_peerSv->SetLocalState( Peer::eStateIdle );
            m_peerSv->SetRemoteState( Peer::eStateIdle );

            m_currentStateCode = Client::eStateIdle;
        }
	}
}

Group* Client::AddGroup( void )
{
	Condition c( &m_mutex );
	return Conference::AddGroup();
}

void Client::RemoveGroup( Group *group )
{
	if( group != NULL )
	{
		Condition c( &m_mutex );
		Conference::RemoveGroup( group );
	}
}

void Client::SetActiveGroup( Group *group )
{
	Condition c( &m_mutex );
	Conference::SetActiveGroup( group );
}

 Group *Client::GetActiveGroup()
{
	Condition c( &m_mutex );
	return Conference::GetActiveGroup();
}

void Client::AddPeerToGroup( int memberId, Group *group )
{
	if( group != NULL )
	{
		Condition c( &m_mutex );
		group->AddPeer( GetPeer( memberId ) );
	}
}

void Client::RemovePeerFromGroup( int memberId, Group *group )
{
	if( group != NULL )
	{
		Condition c( &m_mutex );
		group->RemovePeer( GetPeer( memberId ) );
	}
}

void Client::DisconnectPeer( int memberId )
{
	if( m_isConnected )
	{
		Condition c( &m_mutex );
		Peer *peer = GetPeer( memberId );

		if( peer != NULL && peer != m_peerMe ) {

			if( m_listener != NULL ) {
				m_listener->OnPeerDisconnect( peer );
			}

			RemovePeer( peer );
		}
	}
}

void Client::SetPeerState( int memberId, Peer::EState state )
{
	if( m_isConnected )
	{
		Condition c( &m_mutex );
		Peer *peer = GetPeer( memberId );

		if( peer != NULL ) {
			peer->SetLocalState( state );
		}
	}
}

Peer::EState Client::GetPeerState( int memberId )
{
	Peer::EState localState = Peer::eStateIdle;

	if( m_isConnected )
	{
		Condition c( &m_mutex );
		Peer *peer = GetPeer( memberId );

		if( peer != NULL ) {
			localState = peer->GetLocalState();		
		}
	}

	return localState;
}

bool Client::CanConnectToPeer( int memberId )
{
	if( m_isConnected )
	{
		Condition c( &m_mutex );
		Peer *peer = GetPeer( memberId );

		return ( peer != NULL &&
				 peer->IsAcceptingConnections() && 
				 peer->GetRemoteState() != Peer::eStateMuted );
	}
	else {
		return false;
	}
}

bool Client::IsPeerPaired( int memberId )
{
	if( m_isConnected )
	{
		Condition c( &m_mutex );
		Peer *peer = GetPeer( memberId );

		return ( peer != NULL && peer->IsPaired() );
	}
	else {
		return false;
	}
}

bool Client::IsPeerSpeaking( int memberId )
{
	if( IsValidMemberId( memberId ) )
	{
		int speakMask = m_speakingMask;
		return ( ( speakMask >> memberId ) & 0x01 );
	}
	else {
		return false;
	}
}

void Client::SetMasterVolume( float volume )
{
	float vol					= MAX( 0.0f, MIN( 1.0f, volume ) );
	vox::fx1814 masterVolume	= (vox::fx1814) ( vol * VoxDataProvider::GetMaxVolume() );

	VoxDataProvider::SetMasterVolume( masterVolume );
}

float Client::GetMasterVolume()
{
	float mVol	= ( float ) VoxDataProvider::GetMasterVolume();
	float vol	= ( mVol / VoxDataProvider::GetMaxVolume() );

	return MAX( 0.0f, MIN( 1.0f, vol ) );
}

void Client::Set3DParameters( vox::Vox3DEmitterParameters &params3D )
{
#if D_YAK_CONFIG_USE_3DFX_VOICES
	if( ArchSupports3DVoice() )
	{
		Condition c( &m_mutex );

		memcpy( &m_3DParameters, &params3D, sizeof( &m_3DParameters ) );	

		for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
		{
			Peer *peer = m_allPeers[ k ];

			if( peer != NULL ) {
				peer->Set3DParameters( m_3DParameters );
			}
		}
	}
#endif // D_YAK_CONFIG_USE_3DFX_VOICES
}

void Client::Set3DListenerPositioning( vox::Mdgp3DListenerPositioning &listenerPositioning )
{
#if D_YAK_CONFIG_USE_3DFX_VOICES
	if( ArchSupports3DVoice() )
	{
		Condition c( &m_mutex );

		memcpy( &m_3DListenerPositioning,&listenerPositioning, sizeof( &m_3DListenerPositioning ) );	

		for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
		{
			Peer *peer = m_allPeers[ k ];

			if( peer != NULL ) {
				peer->Set3DListenerPositioning( listenerPositioning );
			}
		}
	}
#endif // D_YAK_CONFIG_USE_3DFX_VOICES
}

void Client::SetPeer3DPositioning( int memberId, vox::Mdgp3DListenerPositioning &positioning3D )
{
#if D_YAK_CONFIG_USE_3DFX_VOICES
	if( ArchSupports3DVoice() )
	{
		Condition c( &m_mutex );

		Peer *peer = GetPeerByRoomID( memberId );

		if( peer != NULL ) {
			peer->Set3DPositioning( positioning3D );
		}
	}
#endif // D_YAK_CONFIG_USE_3DFX_VOICES
}

bool Client::UpnpSetup(unsigned short remotePort)
{
	struct UPNPDev* devlist = 0;
	devlist = upnpDiscover(2000, 0, 0, 0, 0, 0);
	
	if (devlist)
	{
		yakout("\n\nList of UPNP devices found on the network :\n", 0);
		
		struct UPNPDev* device;
		for(device = devlist; device; device = device->pNext)
		{
			yakout(" desc: %s\n st: %s\n\n", device->descURL, device->st);
		}

		char lanaddr[64];	/* my ip address on the LAN */
		struct UPNPUrls urls;
		struct IGDdatas data;
		if (UPNP_GetValidIGD(devlist, &urls, &data, lanaddr, sizeof(lanaddr)) == 1)
		{
			char iport[32] = {0};
			sprintf(iport, "%u", m_peerMe->GetLocalPort() );
			char eport[32] = {0};
			sprintf(eport, "%u", remotePort);

			int r = UPNP_AddPortMapping(urls.controlURL, data.first.servicetype,
					eport, iport, lanaddr, 0, "UDP", 0, 0);

			if(r != UPNPCOMMAND_SUCCESS)
			{
				yakout("\nAddPortMapping(%s, %s, %s) failed with code %d (%s)",
					eport, iport, lanaddr, r, strupnperror(r));
			}

			char intPort[6];
			char intClient[16];
			r = UPNP_GetSpecificPortMappingEntry(urls.controlURL,
				data.first.servicetype,
				eport, "UDP",
				intClient, intPort, 0, 0, 0);

			FreeUPNPUrls(&urls);
			freeUPNPDevlist(devlist);

			if(r != UPNPCOMMAND_SUCCESS)
			{
				yakout("\nGetSpecificPortMappingEntry() failed with code %d (%s)",
					r, strupnperror(r));
				return false;
			}

			return true;
		}
	}

	return false;
}

void* ClientThreadProc( void *pParam )
{
	Client	*client = (Client*)pParam;

	while( !client->m_quit )
	{
        client->Update();
		client->Wait();

        //unsigned int now = S_GetTime();
        //static unsigned int lt = 0;
        //printf( "\nUPD.LT: %d", now-lt );
        //lt = now;
        
		//HeapCheck();
	}

	return NULL;
}

// ----------------------------------------------------------------------//
} // namespace yak;
