#ifndef __YAK_CCLIENT_H
#define __YAK_CCLIENT_H

#include "yak_conference.h"
#include "yak_file.h"
#include "yak_singleton.h"
#include "yak_state_machine.h"
#include "yak_thread.h"
#include "yak_mutex.h"

#define D_YAK_DEBUG_STRING		( 0 )

namespace yak
{
// ----------------------------------------------------------------------//

class Client : public Singleton< Client >, public StateMachine, public Conference 
{
public:
	class Listener
	{
	public:
		virtual void OnClientConnect( const int memberId ) = 0;
		virtual void OnClientError( const int error ) = 0;

		virtual void OnPeerConnect( Peer *peer )	= 0;
		virtual void OnPeerDisconnect( Peer *peer ) = 0;

		virtual void OnPeerHolePunchFail( Peer *peer )	= 0;
	};

	typedef enum
	{
		eErrorNone,
		eErrorSocketReceive,
		
		eErrorArch		= Conference::eServerErrorArch,
		eErrorContext	= Conference::eServerErrorContext,

	} EClientError;

protected:
	typedef enum
	{
		eStateIdle,
		eStateDiscovery,
		eStateConnecting,
		eStateConnected,
		eStateError,

		eStateCount
	} EClientState;

	friend void* ClientThreadProc( void *pParam );
	friend void* UpnpThreadProc( void *pParam );

protected:
	Socket						m_socket;
	Thread						m_thread;
	
	Thread						m_upnpThread;
	bool						m_isUpnpDone;
	unsigned short				m_upnpPort;

	bool						m_isDiscoverable;
	bool						m_isConnected;
	bool						m_isMuted;
	bool						m_isSuspended;
	bool						m_isAcceptingConnections;

	unsigned int				m_signalTime;

	bool						m_iAmSpeaking;
	unsigned int				m_speakingMask;

	// used to cache sound frames 
	char						*m_recordCache;
	Buffer						*m_recordWrite;
	Buffer						*m_recordRead;

	EClientError				 m_error;
	bool						 m_quit;
	bool						 m_isInitialized;

	Listener					*m_listener;
	Mutex						 m_mutex;

	vox::Vox3DEmitterParameters		m_3DParameters;
	vox::Mdgp3DListenerPositioning	m_3DListenerPositioning;

	int							m_bwOutCount;
	int							m_bwInCount;
	float						m_bwOut;
	float						m_bwIn;
	unsigned int				m_bwlastTime;

	int							m_enterTime;
	int							m_exitTime;

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE
	short						*m_sineWaveBuffer;
	unsigned int				m_sineWaveCursor;
#endif // D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE

#if D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE
	char						*m_clientRecCache;
	Buffer						*m_clientRecBuffer;
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE
//-----------------------------------------------------------------------//

protected:
	// states callbacks
	static int					StateIdleCallback( void *arg );
	static int					StateDiscoveryCallback( void *arg );
	static int					StateConnectingCallback( void *arg );
	static int					StateConnectedCallback( void *arg );
	static int					StateErrorCallback( void *arg );

	// messages to discovery/udp hole punching server
	void						SendGetServerAddress();
	void						SendGetRemoteInfo();
	void						SendJoin();
	void						SendLeave();
	void						SendPresence();

	// P2P messages to other peers
	void						SendPing( Peer *peer );
	void						SendPeerState( Peer *peer, Peer::EState state );

	bool						UpnpSetup(unsigned short remotePort);
	void						Record( char *buf,  unsigned short size );
	void						Flush();
	void						Speak( char *frame, unsigned short len );

	bool						IsServer( int ip, unsigned short port );
	void						Process( Buffer *buf, int ip, unsigned short port );
	void						UpdateConnections();
	void						Update();
	void						Wait();

	void						SyncPeerState( Peer *peer );
	void						UpdatePeerState( Peer *peer, Peer::EState newState, bool isAccepting );

	EClientError				GetError() { return m_error; }
	void						SetError( EClientError err ) { m_error = err; }

	void						Send( int ip, unsigned short port, const char *buf, int len );		

public:
	Client( Codec::EContext outCtx, Codec::EContext inCtx, Listener *dg = NULL );
	 ~Client();

	void						Init( int serverIp, unsigned short serverPort );

	void						Join( int memberId );
	void						Leave();

	void						Mute( bool mute )		{ m_isMuted = mute; }

	void						Suspend()	{ m_isSuspended = true; }
	void						Resume()	{ m_isSuspended = false; }

	Group*						AddGroup( void );
	void						RemoveGroup( Group *group );

	void						SetActiveGroup( Group *group );
	Group*						GetActiveGroup( void );

	void						AddPeerToGroup( int memberId, Group *group );
	void						RemovePeerFromGroup( int memberId, Group *group );
	void						DisconnectPeer( int memberId );

	void						SetPeerState( int memberId, Peer::EState state );
	Peer::EState				GetPeerState( int memberId );

	bool						CanConnectToPeer( int memberId );
	bool						IsPeerPaired( int memberId );
	bool						IsPeerSpeaking( int memberId );
	bool						IAmSpeaking() { return m_iAmSpeaking; }

	bool						IsAcceptingConnections() { return m_isAcceptingConnections; }
	void						SetAcceptingConnections( bool isAccept ) { m_isAcceptingConnections = isAccept; }

	static void					SetMasterVolume( float volume );
	static float				GetMasterVolume();

	void						Set3DParameters( vox::Vox3DEmitterParameters &params3D );
	void						Set3DListenerPositioning( vox::Mdgp3DListenerPositioning &listenerPositioning );
	void						SetPeer3DPositioning( int memberId, vox::Mdgp3DListenerPositioning &positioning3D );

	float						GetBwIn() { return m_bwIn; }
	float						GetBwOut(){ return m_bwOut; }

	bool						IsConnected() { return m_isConnected; }
	bool						IsMuted(){ return m_isMuted; }

#if D_YAK_DEBUG_STRING
	char						m_dbgString[64];
	unsigned int				m_lastTimestamp;
#endif // D_YAK_DEBUG_STRING
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CSERVER_H
