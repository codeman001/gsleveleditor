#include "yak_client.h"
#include "yak_file.h"

namespace yak
{
// ----------------------------------------------------------------------//

void* UpnpThreadProc( void *pParam );

int Client::StateIdleCallback( void *arg )
{
	Client *client = (Client*) arg;

	return Client::eStateIdle;
}

int Client::StateDiscoveryCallback( void *arg )
{
	yakass( kArchitecture != eArchitectureServer );

	Client *client = (Client*) arg;

	// @TODO: timeout
	static unsigned int past = 0;
	unsigned int now = client->GetCurrentTime();

	if( !client->m_isDiscoverable ) {
		
		if( now - past > 100 ) {
			client->SendGetRemoteInfo();
			past = now;
		}
		
		return Client::eStateDiscovery;
	}
	
	if( !client->m_upnpThread.IsActive() )
	{
		client->m_upnpPort = client->m_peerMe->GetRemotePort();

		client->m_upnpThread.Init( UpnpThreadProc, client, 0 );
		client->m_upnpThread.Start();
	}

	if( !client->m_isUpnpDone ) {
		return Client::eStateDiscovery;
	}

	client->m_upnpThread.Stop();

	return Client::eStateConnecting;
}

int Client::StateConnectingCallback( void *arg )
{
	Client *client = (Client*) arg;

	// @TODO: timeout
	static unsigned int past	= 0;
	unsigned int		now		= client->GetCurrentTime();

	if( !client->m_isConnected )
	{
		if( now - past > 100 ) {
			client->SendJoin();
			past = now;
		}
		return Client::eStateConnecting;
	}

	client->InitConnectionsTime( now );

	if( client->m_listener != NULL ) {
		client->m_listener->OnClientConnect( client->m_peerMe->GetMemberId() );
	}

	return Client::eStateConnected;
}

int Client::StateConnectedCallback( void *arg )
{
	Client *client		= (Client*) arg;
	Group *group		= client->m_activeGroup;
	
	if( kArchitecture == eArchitectureServer )
	{
		client->m_peerSv->Update();
	}
	else
	{
		if( group != NULL )
		{
			// active group only
			for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
			{
				Peer *peer = group->GetPeer( k );

#if !D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
				if( peer != client->m_peerMe )
#endif // D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
				{
					if( peer != NULL && peer->IsPaired() ) {
						peer->Update();
					}
				}
			}
		}
	}

	client->UpdateConnections();
	client->SendPresence();

	return Client::eStateConnected;
}

int Client::StateErrorCallback( void *arg )
{
	Client *client = (Client*) arg;
	Client::EClientError err = client->GetError();

	switch( err )
	{
	case eErrorNone:
		{
			yakass( false && "No error code but in error state!!!" );
		}
		break;

	default:
		{
			if( client->m_listener != NULL ) {
				client->m_listener->OnClientError( err );
			}
		}
		break;
	}

	return Client::eStateError;
}

void* UpnpThreadProc( void *pParam )
{
	Client	*client = (Client*)pParam;

	if ( client->UpnpSetup( client->m_upnpPort ) ) {
		yakout( "\nUPnP opened port: %u", client->m_upnpPort );
	}
	else {
		yakout( "\nUPnP could not open port: %u", client->m_upnpPort );
	}

	client->m_isUpnpDone = true;

	return NULL;
}

// ----------------------------------------------------------------------//
} // namespace yak;