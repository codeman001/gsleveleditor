#if !D_YAK_IS_LINUX_SERVER
#	include <vox.h>
#endif

#include "yak_codec.h"

#ifndef VOX_FX1814_FRACT_SHIFT
#	define VOX_FX1814_FRACT_SHIFT		14
#endif //VOX_FX1814_FRACT_SHIFT

#ifndef VOX_FX1814_ONE
#define VOX_FX1814_ONE			( 1 << VOX_FX1814_FRACT_SHIFT )
#endif // VOX_FX1814_ONE

#ifndef VOX_FX1814_FRACT_MASK
#	define VOX_FX1814_FRACT_MASK		0x3FFF
#endif // VOX_FX1814_ONE

namespace yak
{
// ----------------------------------------------------------------------//

Codec::Context Codec::m_contexts[ 6 ] =
{
	// EContext::eContextNone
	{
		0,
		0,
		0,
		NULL,
		NULL,
	},
	// EContext::eContextPcm16
	{
		8000,
		D_YAK_SOUND_FRAME_TIME * 8000 / 1000,
		( D_YAK_SOUND_BITS_PER_SAMPLE / 8 ) * (D_YAK_SOUND_FRAME_TIME * 8000 / 1000 ),
		Pcm16_2_Pcm16,
		Pcm16_2_Pcm16,
	},
	// EContext::eContextAdpcm2Bit
	{
		8000,
		D_YAK_SOUND_FRAME_TIME * 8000 / 1000,
		( D_YAK_SOUND_BITS_PER_SAMPLE / 8 ) * (D_YAK_SOUND_FRAME_TIME * 8000 / 1000 ),
		Pcm16_2_G726_16,
		G726_16_2_Pcm16,
	},
	// EContext::eContextAdpcm3Bit
	{
		8000,
		D_YAK_SOUND_FRAME_TIME * 8000 / 1000,
		( D_YAK_SOUND_BITS_PER_SAMPLE / 8 ) * (D_YAK_SOUND_FRAME_TIME * 8000 / 1000 ),
		Pcm16_2_G726_24,
		G726_24_2_Pcm16,
	},
	// EContext::eContextAdpcm4Bit
	{
		8000,
		D_YAK_SOUND_FRAME_TIME * 8000 / 1000,
		( D_YAK_SOUND_BITS_PER_SAMPLE / 8 ) * (D_YAK_SOUND_FRAME_TIME * 8000 / 1000 ),
		Pcm16_2_G726_32,
		G726_32_2_Pcm16,
	},
	// EContext::eContextAdpcm5Bit
	{
		8000,
		D_YAK_SOUND_FRAME_TIME * 8000 / 1000,
		( D_YAK_SOUND_BITS_PER_SAMPLE / 8 ) * (D_YAK_SOUND_FRAME_TIME * 8000 / 1000 ),
		Pcm16_2_G726_40,
		G726_40_2_Pcm16,
	},
};

unsigned char Codec::m_encodeBuffer[ D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE ] = {0};
unsigned char Codec::m_decodeBuffer[ D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE ] = {0};
unsigned char Codec::m_resampleBuffer[ D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE ] = {0};

Mutex Codec::m_encMutex;
Mutex Codec::m_decMutex;

Codec::Codec( EContext outCtx, EContext inCtx )
{
    m_agc.sample_max		= 1;
    m_agc.igain				= 65536;
    m_agc.ipeak				= (int)(SHORT_MAX * 0.80f * 65536.0f);
	m_agc.silence_counter	= 0;
	m_agc.silence_threshold = 1000 / D_YAK_SOUND_FRAME_TIME;

	m_outCtxId = outCtx;
	m_outCtxState = G726_create();

	m_inCtxId = inCtx;
	m_inCtxState = G726_create();

#if D_YAK_CONFIG_USE_SPEEX_RESAMPLER
	Context *ctx  = &m_contexts[ outCtx ];

	int ret = 0;
	m_reSampler = speex_resampler_init ( 1, D_YAK_SOUND_RECORDER_SAMPLING_RATE, ctx->m_samplingRate, 0, &ret );
#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER
}

Codec::~Codec()
{
#if D_YAK_CONFIG_USE_SPEEX_RESAMPLER
	speex_resampler_destroy( ( SpeexResamplerState* ) m_reSampler );
#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER

	G726_destroy( m_outCtxState );
	G726_destroy( m_inCtxState );
}

void Codec::AGCCtrlSilent()
{
	m_agc.silence_counter++;

	if ((m_agc.igain > 65536) && (m_agc.silence_counter >= m_agc.silence_threshold)) {
		m_agc.igain = (m_agc.igain * 62259) >> 16;
	}
}

void Codec::AGCCtrlVoice()
{
	long gain_new = ((m_agc.ipeak / m_agc.sample_max) * 62259) >> 16;

	if (m_agc.silence_counter > m_agc.silence_threshold) {
		m_agc.igain += (gain_new - m_agc.igain) >> 2;
	}
	else {
		m_agc.igain += (gain_new - m_agc.igain) / 20;
	}

	m_agc.sample_max = 1;
	m_agc.silence_counter = 0;
}

void Codec::ApplyAGC( short *h, int n )
{
	for( int k = 0; k < n; k++ )
	{
		int sample;

		/* get the abs of buffer[i] */
		sample = h[ k ];
		sample = (sample < 0 ? -(sample):sample);

		if(sample > (int)m_agc.sample_max)
		{
			/* update the max */
			m_agc.sample_max = (unsigned int)sample;
		}

		/* Will we get an overflow with the current gain factor? */
		if (((sample * m_agc.igain) >> 16) > m_agc.ipeak)
		{
			/* Yes: Calculate new gain. */
			m_agc.igain = ((m_agc.ipeak / m_agc.sample_max) * 62259) >> 16;
			h[k] = (short) ((h[k] * m_agc.igain) >> 16);
		}
		else {
			h[k] = (short) ((h[k] * m_agc.igain) >> 16);
		}
	}
}

char* Codec::Preprocess( int inRate, char *srcData, unsigned int bufSize, bool useVAD, bool useAGC )
{
	char *out		= NULL;
	Context *ctx	= &m_contexts[ m_outCtxId ];
	int n			= ctx->m_frameSize;


	if( inRate != ctx->m_samplingRate )
	{
		unsigned int srcSize	= bufSize >> 1;
		unsigned int dstSize	= D_YAK_SOUND_RECORDER_FRAME_SIZE;
		short *dst				= ( short* ) m_resampleBuffer;
		short *src				= ( short* ) srcData;

#if D_YAK_CONFIG_USE_SPEEX_RESAMPLER
		speex_resampler_process_int (
			( SpeexResamplerState * ) m_reSampler,
			0,
			( short* ) srcData,
			( spx_uint32_t * ) &srcSize,
			dst,
			( spx_uint32_t * ) &dstSize
		);
#else
		int sampleBefore, diff;
		int fract;
		int currentSample = 0;
		int sampleValue = 0;
		int effectivePitch = ( inRate << VOX_FX1814_FRACT_SHIFT ) / ctx->m_samplingRate;

		for( n = 0; n < ctx->m_frameSize; n++ )
		{
			// Interpolate sample value
			sampleBefore = currentSample >> VOX_FX1814_FRACT_SHIFT;
			fract = currentSample & VOX_FX1814_FRACT_MASK;

			if( sampleBefore + 1 >= srcSize )
				break;

			//do not merge the following 2 lines, it breaks interpolation on Vita Release
			diff = ( src[sampleBefore + 1] - src[sampleBefore] );
			sampleValue = src[ sampleBefore ] + ( ( fract * diff ) >> VOX_FX1814_FRACT_SHIFT );

			dst[ n ]	= sampleValue;
			currentSample += effectivePitch;
		}

#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER

		out = ( char* ) dst;
	}
	else {
		out = srcData;
	}

	// VAD
	if( useVAD )
	{
		bool isSilent = IsSilent( (short*)out, n );

		if( isSilent )
		{
			AGCCtrlSilent();
			return NULL;
		}
	}

	// AGC
	if( useAGC )
	{
		ApplyAGC( (short*)out, n );
		AGCCtrlVoice();
	}

	//HeapCheck();

	return out;
}

int Codec::Encode( char *srcData, unsigned int bufSize )
{
	// ENCODE
	Context *ctx = &m_contexts[ m_outCtxId ];
	YakCodecEncodeFn encodeFn = ctx->m_encodeFn;

	int len = encodeFn(
		m_encodeBuffer,
		(unsigned char*)srcData,
		ctx->m_bufferSize,
		1,
		ctx->m_samplingRate,
		m_outCtxState
	);

	//yakout( "PACKET: initial size= %d bytes, compressed size= %d bytes\n", D_YAK_SOUND_NETWORK_FRAME_BUFFER_SIZE, len );
	//yakout( "PACKET: %.2f%% compression ratio\n", 100.0f-(((float)len*100.0f)/((float)D_YAK_SOUND_NETWORK_FRAME_BUFFER_SIZE)) );

	return len;
}

int Codec::Decode( char *srcData, unsigned int srcSize )
{
	Context *ctx				= &m_contexts[ m_inCtxId ];
	YakCodecDecodeFn decodeFn	= ctx->m_decodeFn;

	int len	= decodeFn(
		m_decodeBuffer,
		(unsigned char*) srcData,
		srcSize,
		1,
		ctx->m_samplingRate,
		m_inCtxState
	);

	return len;
}

bool Codec::IsSilent( short *h, int n )
{
	const int  w = n/10;
	const int ww = w*10;

	long   i = 0;
	float  a = 0.1f;
	float  b = 1.0f - a;
	float  x = 0.0f, y  = 0.0f, m  = 0.0f, mm = 0.0f, t = 1.5f;
	float f0 = 0.0f, f1 = 0.0f, f2 = 0.0f, f3 = 0.0f;

	for( int k = 0; k < ww; k += w )
	{
		f0 = h[ k ]; f0 *= f0;
		f3 = 0.0f;

		// f1[j] = a*(h[j]^2) + b*(f1[j-1]^2)
		for( int j = 1; j < w; j++ )
		{
			f2 = h[ k + j ]; f2 *= f2;
			f1 = a * f2 + b * f0;
			f3 += f1;
			f0 = f1;
		}

		m  = f3 / w;

		// mm = fast_sqrt( m )
		x  = m * 0.5f;
		y  = m;
		i  = * ( long * ) &y;
		i  = 0x5F3759DF - ( i >> 1 );
		y  = * ( float * ) &i;
		y  = y * ( t - ( x * y * y ) );
		y  = y * ( t - ( x * y * y ) );
		mm = m * y;
		//

		//yakout( "\nNRG:%.2f", mm );
		if( mm > D_YAK_SOUND_VOICE_ENERGY_THRESHOLD ) {
			return false;
		}
	}

	return true;
}

// ----------------------------------------------------------------------//
} // namespace yak;

static inline int Pcm16_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec )
{
	memcpy( out_buf, in_buf, size );
	return size;
}
