#ifndef __YAK_CCODEC_H
#define __YAK_CCODEC_H

extern "C"
{
	#include "speex/include/speex_resampler.h"
}

#include "yak_config.h"
#include "yak_mutex.h"

namespace yak
{
// ----------------------------------------------------------------------//
typedef int (*YakCodecEncodeFn)
			( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			  unsigned int channels, unsigned int rate, long h_codec );

typedef int (*YakCodecDecodeFn)
			( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			  unsigned int channels, unsigned int rate, long h_codec );

class Codec
{
	friend class Playout;

public:

	typedef struct {
		unsigned int    sample_max;
		long            igain;
		int             ipeak;
		int             silence_counter;
		int				silence_threshold;
	} AGCState;

	typedef enum
	{
		eContextNone		= 0,
		eContextPcm16		= 1,
		eContextAdpcm2Bit	= 2,
		eContextAdpcm3Bit	= 3,
		eContextAdpcm4Bit	= 4,
		eContextAdpcm5Bit	= 5,
	} EContext;

	typedef struct
	{
		unsigned int			m_samplingRate;
		unsigned int			m_frameSize;
		unsigned int			m_bufferSize;

		YakCodecEncodeFn		m_encodeFn;
		YakCodecDecodeFn		m_decodeFn;
	} Context;

	static Context				m_contexts[ 6 ];

protected:
	static unsigned char		m_encodeBuffer[ D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE ];
	static unsigned char		m_decodeBuffer[ D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE ];
	static unsigned char		m_resampleBuffer[ D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE ];

	static Mutex				m_encMutex;
	static Mutex				m_decMutex;

	AGCState					m_agc;
	EContext					m_outCtxId;
	long						m_outCtxState;
	EContext					m_inCtxId;
	long						m_inCtxState;

#if D_YAK_CONFIG_USE_SPEEX_RESAMPLER
	void						*m_reSampler;
#endif // D_YAK_CONFIG_USE_SPEEX_RESAMPLER

protected:
	bool						IsSilent( short *h, int n );
	void						ApplyAGC( short *h, int n );

public:
	Codec( EContext outCtx, EContext inCtx );
	virtual ~Codec();

	void						AGCCtrlSilent();
	void						AGCCtrlVoice();
	char*						Preprocess( int inRate, char *srcData, unsigned int bufSize, bool useVAD, bool useAGC );

	static void					LockEncode()		{ m_encMutex.Lock(); }
	int							Encode( char *srcData, unsigned int srcSize );
	static char*				GetEncodeBuffer()	{ return (char*)m_encodeBuffer; }
	static void					UnlockEncode()		{ m_encMutex.Unlock(); }

	static void 				LockDecode()		{ m_decMutex.Lock(); }
	int							Decode( char *srcData, unsigned int srcSize );
	static char*				GetDecodeBuffer()	{ return (char*)m_decodeBuffer; }
	static void					UnlockDecode()		{ m_decMutex.Unlock(); }

	inline EContext				GetOutContextId()	{ return m_outCtxId; }
	inline Context*				GetOutContext()		{ return &m_contexts[ m_outCtxId ]; }
	inline EContext				GetInContextId()	{ return m_inCtxId; }
	inline Context*				GetInContext()		{ return &m_contexts[ m_inCtxId ]; }
};

// ----------------------------------------------------------------------//
} // namespace yak;

static int  Pcm16_2_Pcm16( unsigned char* out_buf, unsigned char* in_buf, unsigned int size,
			    unsigned int channels, unsigned int rate, long h_codec );

#endif // __YAK_CCODEC_H
