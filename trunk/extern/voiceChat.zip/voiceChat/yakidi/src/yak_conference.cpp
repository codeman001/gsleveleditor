#include "yak_conference.h"

namespace yak
{
// ----------------------------------------------------------------------//

#if !D_YAK_IS_LINUX_SERVER
#   include "vox.h"
#endif


Conference::Conference( Codec::EContext outCtx, Codec::EContext inCtx )
{
	// "inCtx != outCtx" only for "eArchitectureServer", with server mixing channels.
	yakass( 
		  ( kArchitecture != eArchitectureServer && inCtx == outCtx ) ||
		  ( kArchitecture == eArchitectureServer )
	);
	//

	m_outContext = outCtx;
	m_inContext	 = inCtx;

	memset( m_allPeers, 0, sizeof( m_allPeers ) );
	memset( m_allGroups, 0, sizeof( m_allGroups ) );

	// default group with all peers ( for "shout" op. )
	m_groupAll		= AddGroup();
	m_activeGroup	= m_groupAll;

	// default peer object assigned to local user.
	m_peerMe		= yaknew Peer( this, D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT != 0 );

	// server peer object assigned to the server when "eArchitectureServer" is used.
	m_peerSv		= yaknew Peer( this, kArchitecture == eArchitectureServer );

	m_isOpen		= false;
    m_currentTime	= S_GetTime();
    m_lastTime		= m_currentTime;
	m_timeStamp		= 0;
}

Conference::~Conference()
{
	RemoveAllGroups();
	RemoveAllPeers();

	yakdel( m_groupAll );
	yakdel( m_peerMe );
	yakdel( m_peerSv );
}

int Conference::AssignGroupId()
{
	for( int k = 0; k < D_YAK_GROUP_GID_MAX; k++ )
	{
		Group *group = m_allGroups[ k ];

		if( group == NULL ) {
			return k;
		}
	}

	return D_YAK_GROUP_GID_INVALID;
}

bool Conference::IsJoined( int memberId )
{
	Peer *peer = GetPeer( memberId );

	return peer != NULL;
}

Peer* Conference::AddPeer( int memberId, Peer::Address *local, Peer::Address *remote )
{
	Peer *peer = NULL;

	if( !IsJoined( memberId ) )
	{
		yakass( memberId >= 0 && memberId < D_YAK_PEER_UID_MAX );

		if( IsValidMemberId( memberId ) )
		{
			peer = yaknew Peer( this, kArchitecture != eArchitectureServer );

			peer->SetLocalIP( local->m_ip );
			peer->SetLocalPort( local->m_port );
			peer->SetRemoteIP( remote->m_ip );
			peer->SetRemotePort( remote->m_port );

			// behind the same NAT as myself, I can communicate directly
			if( m_peerMe != NULL && remote->m_ip == m_peerMe->GetRemoteIP())
			{
				peer->SetRemoteIP( local->m_ip );
				peer->SetRemotePort( local->m_port );
			}

			peer->SetMemberId( memberId );

			peer->SetLocalState( Peer::eStateIdle );
			peer->SetRemoteState( Peer::eStateIdle );
			peer->SetConnectionTime( m_currentTime );

			m_allPeers[ memberId ] = peer;
			m_groupAll->AddPeer( peer );

			yakout( "\nClient: Add peer(%d)\t[ %s:%u ]", memberId,
				inet_ntoa( *((in_addr*)remote) ), remote->m_port );
		}
	}

	return peer;
}

void Conference::InitConnectionsTime( unsigned int tm )
{
	for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
	{
		Peer *peer = m_allPeers[ k ];

		if( peer != NULL ) {
			peer->SetConnectionTime( tm );
		}
	}
}

Peer* Conference::GetPeer( int memberId )
{
	if( IsValidMemberId( memberId ) ) {
		return m_allPeers[ memberId ];
	}

	return NULL;
}


void Conference::RemovePeer( Peer *peer )
{
	if( peer != NULL )
	{
		int memberId = peer->GetMemberId();

		if( IsValidMemberId( memberId ) && m_allPeers[ memberId ] == peer )
		{
			for( int k = 0; k < D_YAK_GROUP_GID_MAX; k++ )
			{
				Group *group = m_allGroups[ k ];

				if( group != NULL ) {
					group->RemovePeer( peer );
				}
			}

			m_allPeers[ memberId ] = NULL;
		}

		yakdel( peer );
	}
}

void Conference::RemoveAllPeers()
{
	for( int k = 0; k < D_YAK_PEER_UID_MAX; k++ )
	{
		Peer *peer = m_allPeers[ k ];

		if( peer != m_peerMe ) {

			RemovePeer( peer );
		}
	}
}

Group* Conference::AddGroup( void )
{
	Group *group = NULL;

	int groupId = AssignGroupId();

	if( IsValidGroupId( groupId ) )
	{
		group = yaknew Group( groupId );
		m_allGroups[ groupId ] = group;
	}

	return group;
}

void Conference::RemoveGroup( Group *group )
{
	if( group != NULL )
	{
		int groupId = group->GetGroupId();

		if( IsValidGroupId( groupId ) && m_allGroups[ groupId ] == group )
		{
			group->RemoveAllPeers();
			yakdel( group );

			m_allGroups[ groupId ] = NULL;
		}

		yakdel( group );
	}
}

void Conference::RemoveAllGroups()
{
	for( int k = 0; k < D_YAK_GROUP_GID_MAX; k++ )
	{
		Group *group = m_allGroups[ k ];

		if( group != m_groupAll ) {

			// do not remove Conference::  , you're asking for trouble :)
			Conference::RemoveGroup( group );
		}
	}
}

#if !D_YAK_IS_LINUX_SERVER
void Conference::GetData(vox::s16* buffer, vox::s32 nbSample, vox::s32 sampleRate, vox::s32 numChannels)
{
	yakass( numChannels == 1 );
	yakass( sampleRate == D_YAK_SOUND_RECORDER_SAMPLING_RATE );

	Record( (char*) buffer, nbSample * sizeof( vox::s16 ) );
}
#endif // !D_YAK_IS_LINUX_SERVER

void Conference::Open()
{
	if( !m_isOpen )
	{
#if !D_YAK_IS_LINUX_SERVER
		vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
		vox.SetMicrophoneCallback( this );
#endif // !D_YAK_IS_LINUX_SERVER
		m_isOpen = true;
	}
}

void Conference::Close()
{
	if( m_isOpen )
	{
		m_isOpen		= false;

#if !D_YAK_IS_LINUX_SERVER
		vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
		vox.RemoveMicrophoneCallback();
#endif //D_YAK_IS_LINUX_SERVER
	}
}

void Conference::Update()
{
	m_lastTime	  = m_currentTime;
	m_currentTime = S_GetTime();
}

// ----------------------------------------------------------------------//
} // namespace yak;
