#ifndef __YAK_CCONFERENCE_H
#define __YAK_CCONFERENCE_H

#include "yak_config.h"
#include "yak_socket.h"
#include "yak_peer.h"
#include "yak_buffer.h"
#include "yak_group.h"
#include "yak_playout.h"
#include "yak_codec.h"

#if !D_YAK_IS_LINUX_SERVER
#	include <vox.h>
#endif // !D_YAK_IS_LINUX_SERVER

namespace yak
{
// ----------------------------------------------------------------------//

class Conference
#if !D_YAK_IS_LINUX_SERVER
	: public vox::RecordedAudioReceptor
#endif // !D_YAK_IS_LINUX_SERVER
{
public:

	typedef enum
	{
		eServerRequestJoin = 1,
		eServerRequestLeave,
		eServerRequestSignal,
		eServerRequestRemoteInfo,
		eServerRequestServerInfo,

		eServerRequestForwardVoice,
		eServerRequestForwardPeerState,

	} EServerRequest;

	typedef enum
	{
		eServerResponseJoin = 1,
		eServerResponseAddPeer,
		eServerResponseRemoteInfo,
		eServerResponseServerInfo,

		eServerResponseForwardVoice,
		eServerResponseForwardPeerState,
		eServerResponseMixedVoice,

		eServerResponseError,

	} EServerResponse;

	typedef enum
	{
		eServerErrorArch	=	64,
		eServerErrorContext,
	} EServerError;

	typedef enum
	{
		eClientRequestPing =  1,
		eClientRequestPong,
		eClientRequestPeerState,

	} EClientRequest;

	static const unsigned int	kClientRequestTS = 0xFFFFFFFF; // timestamp that marks a special packet

protected:
	Codec::EContext m_outContext;
	Codec::EContext m_inContext;

	Peer		   *m_allPeers[ D_YAK_PEER_UID_MAX ];
	Group		   *m_allGroups[ D_YAK_GROUP_GID_MAX ];

	Peer		   *m_peerMe;
	Peer		   *m_peerSv;
	Group		   *m_groupAll;
	Group		   *m_activeGroup;

	bool			m_isOpen;
	unsigned int	m_currentTime;
	unsigned int	m_lastTime;
	unsigned int	m_timeStamp;

protected:
	int				AssignGroupId();

	bool			IsJoined( int memberId );
	void			InitConnectionsTime( unsigned int tm );

#if !D_YAK_IS_LINUX_SERVER
	void			GetData( vox::s16* buffer, vox::s32 nbSample, vox::s32 sampleRate, vox::s32 numChannels );
#endif // !D_YAK_IS_LINUX_SERVER

	Peer*			AddPeer( int memberId, Peer::Address *local, Peer::Address *remote );
	void			RemovePeer( Peer *peer );
	void			RemoveAllPeers();

	Peer*			GetPeer( int memberId );

	virtual Group*	AddGroup( void );
	virtual void	RemoveGroup( Group *group );
	void			RemoveAllGroups();

	virtual void	SetActiveGroup( Group *group ) { m_activeGroup = group; }
	virtual Group*	GetActiveGroup( void ) { return m_activeGroup; }

	void			Open();
	void			Close();
	bool			IsOpened() { return m_isOpen; }

	virtual void	Record( char *frame,  unsigned short size ) = 0;
	virtual void	Update();

public:
	Conference( Codec::EContext outCtx, Codec::EContext inCtx );
	virtual ~Conference();

	const Peer*		GetMyPeer( void ) { return m_peerMe; }

	Codec::EContext	GetOutContext() { return m_outContext; }
	Codec::EContext	GetInContext() { return m_inContext; }

	unsigned int	GetTimeStamp() { return m_timeStamp; }
	unsigned int	GetCurrentTime() { return m_currentTime; }
	unsigned int	GetLastTime() { return m_lastTime; }
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CCONFERENCE_H
