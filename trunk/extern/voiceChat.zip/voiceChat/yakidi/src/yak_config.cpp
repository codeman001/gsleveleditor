#ifdef OS_IPHONE
#   import <UIKit/UIKit.h>
#   import <Foundation/NSPathUtilities.h>
#endif

#include "yak_config.h"
#include "yak_buffer.h"

namespace yak
{
// ----------------------------------------------------------------------//

EArchitecture		kArchitecture = eArchitectureServer;

void BufToFile( Buffer *buf, const char *dbgName )
{
	char saveName[ 256 ];
	
#ifdef OS_IPHONE
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    strcpy( saveName, [ documentsDirectory UTF8String ] );
    strcat( saveName, "/" );
    strcat( saveName, dbgName );
    
    [pool release];
#elif defined( OS_LINUX )
    strcpy( saveName, "/tmp/" );
	strcat( saveName, dbgName );
#else
	strcpy( saveName, dbgName );
#endif //OS_LINUX
	
	FILE *f = fopen( saveName, "wb" );

	if( f )
	{
		fwrite( buf->GetData(), buf->GetSizeW(), 1, f );
		fclose( f );
	}
}

void HeapCheck()
{
#if defined( WIN32 )
	static const char *HP[] = 
	{
		"\nOK - _HEAPEMPTY",
		"\nOK - _HEAPOK",
		"\nER - _HEAPBADBEGIN",
		"\nER - _HEAPBADNODE",
		"\nER - _HEAPEND",
		"\nER - _HEAPBADPTR",
		"\nER - _FREEENTRY",
		"\nER - _USEDENTRY",
	};
	
	const char *resultText = NULL;
	int resultInt = _heapchk();

	switch( resultInt )
	{
	case _HEAPEMPTY:
		resultText = HP[ 0 ];
		break;
	case _HEAPOK:
		resultText = HP[ 1 ];
		break;
	case _HEAPBADBEGIN:
		resultText = HP[ 2 ];
		break;
	case _HEAPBADNODE:
		resultText = HP[ 3 ];
		break;
	case _HEAPEND:
		resultText = HP[ 4 ];
		break;
	case _HEAPBADPTR:
		resultText = HP[ 5 ];
		break;
	case _FREEENTRY:
		resultText = HP[ 6 ];
		break;
	case _USEDENTRY:
		resultText = HP[ 7 ];
		break;
	}

	yakass( resultInt == _HEAPEMPTY || resultInt == _HEAPOK );

#endif // WIN32
}

#if defined ( OS_IPHONE ) || defined ( OS_LINUX ) || defined ( OS_ANDROID )

#include <sys/time.h>

int S_GetTime (void)
{
    struct timeval	tp;
    gettimeofday(&tp, 0);

	static long old_tv_sec_1 = tp.tv_sec;
    return ((tp.tv_sec - old_tv_sec_1) * 1000 + tp.tv_usec / 1000);
}

int S_GetTimeMicro (void)
{
    struct timeval	tp;
    gettimeofday(&tp, 0);

	static long old_tv_sec_2 = tp.tv_sec;
    return ((tp.tv_sec - old_tv_sec_2) * 1000000 + tp.tv_usec);
}
#elif defined( WIN32 )
int S_GetTime (void)
{
	static long old_time = timeGetTime();
	return timeGetTime() - old_time;
}

int S_GetTimeMicro(void)
{
	int theTime = S_GetTime();
	return theTime * 1000;
}

#endif

// ----------------------------------------------------------------------//
} // namespace yak;
