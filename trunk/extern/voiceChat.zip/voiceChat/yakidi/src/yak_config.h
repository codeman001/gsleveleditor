#ifndef __YAK_CCONFIG_H
#define __YAK_CCONFIG_H

#include "../../yakidi_config/yak_extern_config.h"

#ifndef D_YAK_SOUND_RECORDER_SAMPLING_RATE
#pragma error "Please specify VOX recorder's working sampling rate in yak_extern_config.h"
#endif

#if defined( WIN32 )
#	include <windows.h>
#	include <winsock.h>
#	include <crtdbg.h>
#	include <mmsystem.h>
#
#	define CLOSESOCKET(sk)	closesocket(sk)
#
	typedef int socklen_t;
#	pragma warning (disable:4996)
#	pragma comment (lib , "pthreadVC2.lib" )
#endif // WIN32

#if defined ( OS_IPHONE ) || defined ( OS_LINUX ) || defined (OS_ANDROID)
#
#	include <stdio.h>
#
#	include <unistd.h>
#	include <netinet/in.h>
#	include <net/if.h>
#	include <arpa/inet.h>
#	include <memory.h>
#	include <fcntl.h>
#	include <errno.h>
#	include <sys/ioctl.h>
#	include <sys/types.h>
#	include <sys/select.h>
#	include <sys/socket.h>
#	include <netdb.h>

	typedef int 				SOCKET;
	typedef struct sockaddr 	SOCKADDR;
	typedef struct sockaddr_in	SOCKADDR_IN;

#	define INVALID_SOCKET		((SOCKET)-1)
#	define SOCKET_ERROR			((SOCKET)-1)
#
#	define CLOSESOCKET(sk)		close(sk)
#	define Sleep(x)				usleep((x)*1000)
#	define SleepMicro(x)		usleep((x))
#else
#	define SleepMicro(x)		Sleep((x)/1000)
#endif

#include <assert.h>
#include <iostream>

#include "adpcm/adpcm.h"

#if !D_YAK_IS_LINUX_SERVER
#	if !defined( STATICLIB )
#		define STATICLIB
#	endif
#	include "miniupnpc/miniupnpc.h"
#	include "miniupnpc/upnpcommands.h"
#	include "miniupnpc/upnperrors.h"
#endif // !D_YAK_IS_LINUX_SERVER

#if defined(DEBUG) || defined(_DEBUG)
#	define yakout						printf
#	define yakass						assert
#
#	if defined( OS_ANDROID )
#		include <android/log.h>
#		undef  yakout
#		define yakout(msg, ...) __android_log_print(ANDROID_LOG_FATAL-0, "YAK", msg, __VA_ARGS__);
#	endif
#else
#	define yakout(...)
#	define yakass(...)
#endif

#define yaknew		new
#define yakdel( x )			{ if( x ) { delete x; x = NULL; } }
#define yakdelarray( x )	{ if( x ) { delete[] x; x = NULL; } }

#ifndef D_YAK_CONFIG_USE_WHITE_NOISE_FOR_SILENCE
#define D_YAK_CONFIG_USE_WHITE_NOISE_FOR_SILENCE		( 0 )
#endif

#ifndef D_YAK_CONFIG_USE_3DFX_VOICES
#define D_YAK_CONFIG_USE_3DFX_VOICES					( 0 )
#endif

#ifndef D_YAK_CONFIG_USE_AGC_ON_SERVER
#define D_YAK_CONFIG_USE_AGC_ON_SERVER					( 0 )
#endif

// -----------------   DEBUGGING DEFINES    ---------------------------//
#ifndef D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT
#define D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT				( 0 )
#endif

#ifndef D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
#define D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE			( 0 )
#endif

#ifndef D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE
#define D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE			( 0 )
#endif

#ifndef D_YAK_CONFIG_DEBUG_SAVE_VOX_REC_TO_FILE
#define D_YAK_CONFIG_DEBUG_SAVE_VOX_REC_TO_FILE			( 0 )
#endif

#ifndef D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
#define D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE			( 0 )
#endif

#ifndef D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
#define D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE			( 0 )
#endif

#define D_YAK_CONFIG_RAW_DUMP_MAX_SIZE					( 128 * 1024 )

// ---------------------------------------------------------------------//

#if D_YAK_IS_LINUX_SERVER
#	undef D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
#	undef D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE
#	undef D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE
#else
#	undef D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE
#	undef D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE
#endif // D_YAK_IS_LINUX_SERVER

#ifndef D_YAK_CONFIG_USE_SPEEX_RESAMPLER
#define D_YAK_CONFIG_USE_SPEEX_RESAMPLER			( 1 )
#endif

#define D_YAK_P2P_CLIENT_PORT						( 27820 )
#define D_YAK_P2P_SERVER_PORT						( 27821 )

#define D_YAK_CONFERENCE_SIGNALLING_TIME			( 2 * 1000 ) // 2 seconds

#ifndef D_YAK_SOUND_VOICE_ENERGY_THRESHOLD
#define D_YAK_SOUND_VOICE_ENERGY_THRESHOLD			( 1000.0f )
#endif

#define D_YAK_SOUND_FRAME_TIME						( 50 ) // 50 ms
#define D_YAK_SOUND_FRAME_TIME_MICRO				( D_YAK_SOUND_FRAME_TIME * 1000 )
#define D_YAK_SOUND_BITS_PER_SAMPLE					( 16 )
#define D_YAK_SOUND_FRAME_NUM						( 16 )
#define D_YAK_SOUND_BUFFER_TIME						( D_YAK_SOUND_FRAME_NUM * D_YAK_SOUND_FRAME_TIME )

#ifndef D_YAK_CONFIG_VOX_DELAY_NUM_FRAMES
#define D_YAK_CONFIG_VOX_DELAY_NUM_FRAMES			( 150 / D_YAK_SOUND_FRAME_TIME )
#endif

#define D_YAK_CODEC_DELAY_TIME_MICRO				( 0 )
#define D_YAK_SLEEP_TIME_MICRO				        ( D_YAK_SOUND_FRAME_TIME_MICRO - D_YAK_CODEC_DELAY_TIME_MICRO )

#define D_YAK_SOUND_RECORDER_FRAME_SIZE				( ( D_YAK_SOUND_FRAME_TIME * D_YAK_SOUND_RECORDER_SAMPLING_RATE ) / 1000 )
#define D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE		( D_YAK_SOUND_RECORDER_FRAME_SIZE * ( D_YAK_SOUND_BITS_PER_SAMPLE / 8 ) )
#define D_YAK_SOUND_RECORDER_BLOCK_BUFFER_SIZE		( D_YAK_SOUND_RECORDER_FRAME_BUFFER_SIZE * D_YAK_SOUND_FRAME_NUM )

#define D_YAK_JIT_HISTORY_SZ						( 512 )
#define D_YAK_JIT_HISTORY_DROPPCT					( 3 )
#define D_YAK_JIT_HISTORY_DROPPCT_MAX				( 4 )
#define D_YAK_JIT_HISTORY_MAXBUF_SZ					( D_YAK_JIT_HISTORY_SZ * D_YAK_JIT_HISTORY_DROPPCT_MAX / 100 )
#define D_YAK_JIT_TARGET_EXTRA						( 40 )
#define D_YAK_JIT_ADJUST_DELAY						( 40 )
#define D_YAK_JIT_RESYNC_TIME						( D_YAK_SOUND_BUFFER_TIME - D_YAK_SOUND_FRAME_TIME )

#define D_YAK_PACKET_MAX_SIZE						( 1024 )
#define D_YAK_PACKET_MULTIPLE_SEND					( 5 )
#define D_YAK_PACKET_PING_COUNT						( 2 )

#define D_YAK_PEER_STATE_SYNC_INTERVAL				( 250 )
#define D_YAK_PEER_TIMEOUT_INTERVAL					( 20 * 1000 )

#define D_YAK_PEER_UID_INVALID						( -1 )
#define D_YAK_PEER_UID_MAX							( 32 )

#define D_YAK_GROUP_GID_INVALID						( -1 )
#define D_YAK_GROUP_GID_MAX							( 16 )

#if !defined(MIN)
	#define MIN(x,y)		((x)<(y)?(x):(y))
#endif
#if !defined(MAX)
	#define MAX(x,y)		((x)>(y)?(x):(y))
#endif

#ifndef USHORT_MAX
#	define USHORT_MAX      ( ( unsigned short )( ~0U ) )
#endif

#ifndef SHORT_MAX
#	define SHORT_MAX       ( ( short )( USHORT_MAX >> 1 ) )
#endif

#ifndef SHORT_MIN
#	define SHORT_MIN       ( -SHORT_MAX - 1 )
#endif

namespace yak
{
// ----------------------------------------------------------------------//

	class Buffer;

	typedef enum
	{
		eArchitectureP2P		= 1,
		eArchitectureHybrid,
		eArchitectureServer
	} EArchitecture;

	extern EArchitecture		kArchitecture;

	void						BufToFile( Buffer *buf, const char *dbgName );
	void						HeapCheck();
	int							S_GetTime();
	int							S_GetTimeMicro();

	static inline void			SetArchitecture( EArchitecture arch )	{ kArchitecture = arch ; }
	static inline EArchitecture	GetArchitecture()						{ return kArchitecture; }
	static bool					ArchSupports3DVoice()					{ return kArchitecture != eArchitectureServer; }

    static inline bool          IsValidMemberId( int memberId )         { return ( memberId >= 0 && memberId < D_YAK_PEER_UID_MAX ); }
    static inline bool          IsValidGroupId( int groupId )           { return ( groupId >= 0 && groupId < D_YAK_GROUP_GID_MAX ); }
// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CCONFIG_H
