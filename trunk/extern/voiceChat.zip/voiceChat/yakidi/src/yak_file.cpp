#include "yak_file.h"

namespace yak
{
// ----------------------------------------------------------------------//

File::File( const std::string &filename )
{
	m_position	= 0;
	m_size		= 0;
	
	m_buffer	= NULL;
	m_current	= NULL;
	
	m_filename	= filename;
}

File::~File()
{
	Close();
}

bool File::Open( void )
{
	FILE *f;	
	f = fopen( m_filename.c_str(), "rb" );

	if( !f )
	{ return false; }

	fseek( f, 0, SEEK_END );
	m_size = ftell( f );
	fseek( f, 0, SEEK_SET );
	
	m_buffer = yaknew unsigned char[ m_size + 1 ];
	m_buffer[ m_size ] = '\0';
	
	fread( &m_buffer[ 0 ], m_size, 1, f );
	
	m_current = m_buffer;
	
	fclose( f );

	return true;
}

void File::Close( void )
{
	yakdel( m_buffer );
	
	m_position	= 0;
	m_size		= 0;
}


unsigned int File::Read( void *ptr, unsigned int size )
{
	if( ( m_position + size ) > m_size )
	{ size = m_size - m_position; }

	memcpy( ptr, &m_buffer[ m_position ], size );
	m_position += size;

	return size;
}

void *File::ReadPtr( unsigned int size )
{
	void *ptr;
	
	if( ( m_position + size ) > m_size )
	{ size = m_size - m_position; }

	ptr = &m_buffer[ m_position ];
	
	m_position += size;

	return ptr;
}


unsigned char* File::Eof( void )
{ return m_buffer + m_size; }

unsigned int File::Seek( eFileSeekMode seekMode, int offset)
{
	switch(seekMode)
	{
		case e_FileSeekFromStart:
		{
			m_position = offset;
			break;
		}
		case e_FileSeekFromCurrent:
		{
			m_position += offset;
			break;
		}
		case e_FileSeekFromEnd:
		{
			m_position -= offset;
			break;
		}
	}
	return m_position;
}

// ----------------------------------------------------------------------//
} // namespace yak;
