#ifndef __YAK_CFILE_H
#define __YAK_CFILE_H

#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

class File
{
public:
	typedef enum
	{
		e_FileSeekFromStart,
		e_FileSeekFromCurrent,
		e_FileSeekFromEnd

	} eFileSeekMode;

protected:
	std::string			m_filename;
	unsigned int		m_position;
	unsigned int		m_size;

	unsigned char		*m_buffer;
	unsigned char		*m_current;

public:
	File( const std::string &filename );
	 ~File();

	bool			Open( void );

	void			Close( void );
	unsigned int	Read( void *buffer, unsigned int size );
	void*			ReadPtr( unsigned int size );
	
	unsigned char*	Eof( void );

	unsigned int	Seek( eFileSeekMode seekMode, int offset );

	inline unsigned char *GetBuffer() { return m_buffer; }
	inline unsigned char *GetCurrent() { return m_current; }
	inline unsigned int   GetSize() { return m_size; }
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CFILE_H
