#include "yak_conference.h"
#include "yak_group.h"

namespace yak
{
// ----------------------------------------------------------------------//

Group::Group( int groupId )
{
	m_groupId = groupId;
	memset( m_peers, 0, sizeof( m_peers ) );
}

Group::~Group()
{

}

Peer* Group::GetPeer( int memberId )
{
	if( IsValidMemberId( memberId ) ) {
		return m_peers[ memberId ];
	}

	return NULL;
}


void Group::AddPeer( Peer *peer )
{
	if( peer != NULL && !IsJoined( peer ) )
	{
		int memberId = peer->GetMemberId();

		if( IsValidMemberId( memberId ) && m_peers[ memberId ] == NULL ) {
			m_peers[ memberId ] = peer;
		}
	}
}

void Group::RemovePeer( Peer *peer )
{
	if( peer != NULL )
	{
		int memberId = peer->GetMemberId();

		if( IsValidMemberId( memberId ) &&
			peer == m_peers[ memberId ] )
		{
			m_peers[ memberId ] = NULL;
		}
	}
}

void Group::RemoveAllPeers()
{
	memset( m_peers, 0, sizeof( m_peers ) );
}

bool Group::IsJoined( Peer *peer )
{
	if( peer != NULL )
	{
		int memberId = peer->GetMemberId();

		if( IsValidMemberId( memberId ) )
		{
			if( peer == m_peers[ memberId ] ) {
				return true;
			}
		}
	}

	return false;
}

unsigned int Group::GetPeerCount()
{
	unsigned int count = 0;

	for( int k = 0; k < D_YAK_GROUP_GID_MAX; k++ )
	{
		Peer *peer = m_peers[ k ];
		if( peer != NULL )
		{
			count++;
		}
	}

	return count;
}

// ----------------------------------------------------------------------//
} // namespace yak;
