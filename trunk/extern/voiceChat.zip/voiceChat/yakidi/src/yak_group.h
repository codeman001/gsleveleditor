#ifndef __YAK_CGROUP_H
#define __YAK_CGROUP_H

#include "yak_config.h"
#include "yak_peer.h"

namespace yak
{
// ----------------------------------------------------------------------//

class Group
{
	friend class Conference;

protected:

	int					m_groupId;
	Peer			   *m_peers[ D_YAK_PEER_UID_MAX ];

protected:
	Group( int groupId );

	int					AssignUgid();

public:

	virtual ~Group();

	int					GetGroupId()			{ return m_groupId; }

	void				AddPeer( Peer *peer );
	void				RemovePeer( Peer *peer );
	void				RemoveAllPeers();
	unsigned int		GetPeerCount();

	Peer*				GetPeer( int memberId );

	bool				IsJoined( Peer *peer );
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CGROUP_H
