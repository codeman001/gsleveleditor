#include <limits.h>
#include "yak_jitter_buffer.h"

namespace yak
{
// ----------------------------------------------------------------------//

JitterBuffer::JitterBuffer()
{
	m_frames = NULL;
	m_free = NULL;

	Reset();
}

JitterBuffer::~JitterBuffer()
{
	JitFrame *frame;

	/* free all the frames on the "free list" */
	frame = m_free;
	while (frame != NULL)
	{
		JitFrame *next = frame->next;
		yakdel(frame);
		frame = next;
	}
}

void JitterBuffer::Reset()
{
	/* only save settings */
	JitConf s = m_info.conf;
	memset(this, 0, sizeof(JitterBuffer));
	m_info.conf = s;

	/* initialize length, using the default value */
	m_info.current = m_info.target = m_info.conf.target_extra = D_YAK_JIT_TARGET_EXTRA;
	m_info.silence_begin_ts = -1;
}

int JitterBuffer::CheckResync( long ts, long now, long ms, const JitFrameType type, long *delay )
{
	long numts = 0;
	long threshold = 2 * m_info.jitter + m_info.conf.resync_threshold;

	/* Check for overfill of the buffer */
	if (m_frames) {
		numts = m_frames->prev->ts - m_frames->ts;
	}

	if (numts >= (m_info.conf.max_jitterbuf)) {
		if (!m_dropem) {
			JIT_DBG("Attempting to exceed Jitterbuf max %ld timeslots\n",
				m_info.conf.max_jitterbuf);
			m_dropem = true;
		}
		m_info.frames_dropped++;
		return -1;
	} else {
		m_dropem = false;
	}

	/* check for drastic change in delay */
	if (m_info.conf.resync_threshold != -1) {
		if (abs(*delay - m_info.last_delay) > threshold) {
			m_info.cnt_delay_discont++;
			/* resync the jitterbuffer on 3 consecutive discontinuities,
			 * or immediately if a control frame */
			if ((m_info.cnt_delay_discont > 3) || (type == eFrameTypeControl)) {
				m_info.cnt_delay_discont = 0;
				m_hist_ptr = 0;
				m_hist_maxbuf_valid = 0;
				JIT_WRN("Resyncing the jb. last_delay %ld, this delay %ld, threshold %ld, new offset %ld\n", m_info.last_delay, *delay, threshold, ts - now);
				m_info.resync_offset = ts - now;
				m_info.last_delay = *delay = 0; /* after resync, frame is right on time */
			} else {
				m_info.frames_dropped++;
				return -1;
			}
		} else {
			m_info.last_delay = *delay;
			m_info.cnt_delay_discont = 0;
		}
	}
	return 0;
}

int JitterBuffer::HistoryPut( long ts, long now, long ms, long delay )
{
	long kicked;

	/* don't add special/negative times to history */
	if (ts <= 0)
		return 0;

	kicked = m_history[m_hist_ptr % D_YAK_JIT_HISTORY_SZ];

	m_history[(m_hist_ptr++) % D_YAK_JIT_HISTORY_SZ] = delay;

	/* optimization; the max/min buffers don't need to be recalculated, if this packet's
	 * entry doesn't change them.  This happens if this packet is not involved, _and_ any packet
	 * that got kicked out of the history is also not involved
	 * We do a number of comparisons, but it's probably still worthwhile, because it will usually
	 * succeed, and should be a lot faster than going through all 500 packets in history */
	if (!m_hist_maxbuf_valid)
		return 0;

	/* don't do this until we've filled history
	 * (reduces some edge cases below) */
	if (m_hist_ptr < D_YAK_JIT_HISTORY_SZ) {
		m_hist_maxbuf_valid = 0;
		return 0;
	}

	/* if the new delay would go into min */
	if (delay < m_hist_minbuf[D_YAK_JIT_HISTORY_MAXBUF_SZ-1]) {
		m_hist_maxbuf_valid = 0;
		return 0;
	}

	/* or max.. */
	if (delay > m_hist_maxbuf[D_YAK_JIT_HISTORY_MAXBUF_SZ-1]) {
		m_hist_maxbuf_valid = 0;
		return 0;
	}

	/* or the kicked delay would be in min */
	if (kicked <= m_hist_minbuf[D_YAK_JIT_HISTORY_MAXBUF_SZ-1]) {
		m_hist_maxbuf_valid = 0;
		return 0;
	}

	if (kicked >= m_hist_maxbuf[D_YAK_JIT_HISTORY_MAXBUF_SZ-1]) {
		m_hist_maxbuf_valid = 0;
		return 0;
	}
	/* if we got here, we don't need to invalidate, 'cause this delay didn't
	 * affect things */
	return 0;
	/* end optimization */
}

void JitterBuffer::HistoryCalcMaxBuf()
{
	int i,j;
	if (m_hist_ptr == 0)
		return;


	/* initialize maxbuf/minbuf to the latest value */
	for (i=0;i<D_YAK_JIT_HISTORY_MAXBUF_SZ;i++) {
/*
 * m_hist_maxbuf[i] = m_history[(m_hist_ptr-1) % D_YAK_JIT_HISTORY_SZ];
 * m_hist_minbuf[i] = m_history[(m_hist_ptr-1) % D_YAK_JIT_HISTORY_SZ];
 */
		m_hist_maxbuf[i] = LONG_MIN;
		m_hist_minbuf[i] = LONG_MAX;
	}

	/* use insertion sort to populate maxbuf */
	/* we want it to be the top "n" values, in order */

	/* start at the beginning, or D_YAK_JIT_HISTORY_SZ frames ago */
	i = (m_hist_ptr > D_YAK_JIT_HISTORY_SZ) ? (m_hist_ptr - D_YAK_JIT_HISTORY_SZ) : 0;

	for (;i<m_hist_ptr;i++) {
		long toins = m_history[i % D_YAK_JIT_HISTORY_SZ];

		/* if the maxbuf should get this */
		if (toins > m_hist_maxbuf[D_YAK_JIT_HISTORY_MAXBUF_SZ-1])  {

			/* insertion-sort it into the maxbuf */
			for (j=0;j<D_YAK_JIT_HISTORY_MAXBUF_SZ;j++) {
				/* found where it fits */
				if (toins > m_hist_maxbuf[j]) {
					/* move over */
					if (j != D_YAK_JIT_HISTORY_MAXBUF_SZ - 1) {
						memmove(m_hist_maxbuf + j + 1, m_hist_maxbuf + j, (D_YAK_JIT_HISTORY_MAXBUF_SZ - (j + 1)) * sizeof(m_hist_maxbuf[0]));
					}
					/* insert */
					m_hist_maxbuf[j] = toins;

					break;
				}
			}
		}

		/* if the minbuf should get this */
		if (toins < m_hist_minbuf[D_YAK_JIT_HISTORY_MAXBUF_SZ-1])  {

			/* insertion-sort it into the maxbuf */
			for (j=0;j<D_YAK_JIT_HISTORY_MAXBUF_SZ;j++) {
				/* found where it fits */
				if (toins < m_hist_minbuf[j]) {
					/* move over */
					if (j != D_YAK_JIT_HISTORY_MAXBUF_SZ - 1) {
						memmove(m_hist_minbuf + j + 1, m_hist_minbuf + j, (D_YAK_JIT_HISTORY_MAXBUF_SZ - (j + 1)) * sizeof(m_hist_minbuf[0]));
					}
					/* insert */
					m_hist_minbuf[j] = toins;

					break;
				}
			}
		}
	}

	m_hist_maxbuf_valid = 1;
}

void JitterBuffer::HistoryGet()
{
	long max, min, jitter;
	int idx;
	int count;

	if (!m_hist_maxbuf_valid)
		HistoryCalcMaxBuf();

	/* count is how many items in history we're examining */
	count = (m_hist_ptr < D_YAK_JIT_HISTORY_SZ) ? m_hist_ptr : D_YAK_JIT_HISTORY_SZ;

	/* idx is the "n"ths highest/lowest that we'll look for */
	idx = count * D_YAK_JIT_HISTORY_DROPPCT / 100;

	/* sanity checks for idx */
	if (idx > (D_YAK_JIT_HISTORY_MAXBUF_SZ - 1))
		idx = D_YAK_JIT_HISTORY_MAXBUF_SZ - 1;

	if (idx < 0) {
		m_info.min = 0;
		m_info.jitter = 0;
		return;
	}

	max = m_hist_maxbuf[idx];
	min = m_hist_minbuf[idx];

	jitter = max - min;

	/* these debug stmts compare the difference between looking at the absolute jitter, and the
	 * values we get by throwing away the outliers */
	/*
	fprintf(stderr, "[%d] min=%d, max=%d, jitter=%d\n", index, min, max, jitter);
	fprintf(stderr, "[%d] min=%d, max=%d, jitter=%d\n", 0, m_hist_minbuf[0], m_hist_maxbuf[0], m_hist_maxbuf[0]-m_hist_minbuf[0]);
	*/

	m_info.min = min;
	m_info.jitter = jitter;
}

/* returns 1 if frame was inserted into head of queue, 0 otherwise */
int JitterBuffer::QueuePut( void *data, const JitFrameType type, long ms, long ts )
{
	JitFrame *frame = NULL;
	JitFrame *p = NULL;
	int head = 0;
	long resync_ts = ts - m_info.resync_offset;

	if ((frame = m_free)) {
		m_free = frame->next;
	}
	else if (!(frame = yaknew JitFrame)) {
		JIT_ERR("cannot allocate frame\n");
		return 0;
	}

	m_info.frames_cur++;

	frame->data = data;
	frame->ts = resync_ts;
	frame->ms = ms;
	frame->type = type;

	/*
	 * frames are a circular list, jb-frames points to to the lowest ts,
	 * m_frames->prev points to the highest ts
	 */

	if (!m_frames) {  /* queue is empty */
		m_frames = frame;
		frame->next = frame;
		frame->prev = frame;
		head = 1;
	} else if (resync_ts < m_frames->ts) {
		frame->next = m_frames;
		frame->prev = m_frames->prev;

		frame->next->prev = frame;
		frame->prev->next = frame;

		/* frame is out of order */
		m_info.frames_ooo++;

		m_frames = frame;
		head = 1;
	} else {
		p = m_frames;

		/* frame is out of order */
		if (resync_ts < p->prev->ts) m_info.frames_ooo++;

		while (resync_ts < p->prev->ts && p->prev != m_frames)
			p = p->prev;

		frame->next = p;
		frame->prev = p->prev;

		frame->next->prev = frame;
		frame->prev->next = frame;
	}
	return head;
}

long JitterBuffer::QueueNext()
{
	if (m_frames)
		return m_frames->ts;
	else
		return -1;
}

long JitterBuffer::QueueLast()
{
	if (m_frames)
		return m_frames->prev->ts;
	else
		return -1;
}

JitFrame* JitterBuffer::_QueueGet( long ts, int all )
{
	JitFrame *frame = m_frames;

	if (!frame)
		return NULL;

	/*JB_WRN("QueueGet: ASK %ld FIRST %ld\n", ts, frame->ts); */

	if (all || ts >= frame->ts) {
		/* remove this frame */
		frame->prev->next = frame->next;
		frame->next->prev = frame->prev;

		if (frame->next == frame)
			m_frames = NULL;
		else
			m_frames = frame->next;


		/* insert onto "free" single-linked list */
		frame->next = m_free;
		m_free = frame;

		m_info.frames_cur--;

		/* we return the frame pointer, even though it's on free list,
		 * but caller must copy data */
		return frame;
	}

	return NULL;
}

JitFrame* JitterBuffer::QueueGet( long ts )
{
	return _QueueGet( ts,0 ) ;
}

JitFrame* JitterBuffer::QueueGetAll()
{
	return _QueueGet( 0, 1 );
}

#ifdef DEEP_DEBUG
/* some diagnostics */
void JitterBuffer::DbgInfo()
{
	JIT_DBG("\njb info: fin=%ld fout=%ld flate=%ld flost=%ld fdrop=%ld fcur=%ld\n",
		m_info.frames_in, m_info.frames_out, m_info.frames_late, m_info.frames_lost, m_info.frames_dropped, m_info.frames_cur);

	JIT_DBG("jitter=%ld current=%ld target=%ld min=%ld sil=%d len=%d len/fcur=%ld\n",
		m_info.jitter, m_info.current, m_info.target, m_info.min, m_info.silence_begin_ts, m_info.current - m_info.min,
		m_info.frames_cur ? (m_info.current - m_info.min)/m_info.frames_cur : -8);
	if (m_info.frames_in > 0)
		JIT_DBG("jb info: Loss PCT = %ld%%, Late PCT = %ld%%\n",
			m_info.frames_lost * 100/(m_info.frames_in + m_info.frames_lost),
			m_info.frames_late * 100/m_info.frames_in);
	JIT_DBG("jb info: queue %d -> %d.  last_ts %d (queue len: %d) last_ms %d\n",
		QueueNext(),
		QueueLast(),
		m_info.next_voice_ts,
		QueueLast() - QueueNext(),
		m_info.last_voice_ms);
}
#endif

#ifdef DEEP_DEBUG
void JitterBuffer::ChkQueue()
{
	int i=0;
	JitFrame *p = m_frames;

	if (!p) {
		return;
	}

	do {
		if (p->next == NULL)  {
			JIT_ERR("Queue is BROKEN at item [%d]", i);
		}
		i++;
		p=p->next;
	} while (p->next != m_frames);
}

void JitterBuffer::DbgQueue()
{
	int i=0;
	JitFrame *p = m_frames;

	JIT_DBG("queue: ");

	if (!p) {
		JIT_DBG("EMPTY\n");
		return;
	}

	do {
		JIT_DBG("[%d]=%ld ", i++, p->ts);
		p=p->next;
	} while (p->next != m_frames);

	JIT_DBG("\n");
}
#endif

JitResult JitterBuffer::Put( void *data, const JitFrameType type, long ms, long ts, long now )
{
	long delay = now - (ts - m_info.resync_offset);

	if (CheckResync(ts, now, ms, type, &delay)) {
		JIT_DBG( "jb_put(%p) DROPPED ts: %u\n", this, ts );
		return eResultDrop;
	}

	if (type == eFrameTypeVoice) {
		/* presently, I'm only adding VOICE frames to history and drift calculations; mostly because with the
		 * IAX integrations, I'm sending retransmitted control frames with their awkward timestamps through */
		HistoryPut(ts, now, ms, delay);
	}

	m_info.frames_in++;

	/* if put into head of queue, caller needs to reschedule */
	if (QueuePut(data,type,ms,ts)) {
		return eResultSched;
	}
	return eResultOk;
}


JitResult JitterBuffer::_Get( JitFrame *frameout, long now, long interpl )
{
	JitFrame *frame;
	long diff;

	HistoryGet();

	/* target */
	m_info.target = m_info.jitter + m_info.min + m_info.conf.target_extra;

	/* if a hard clamp was requested, use it */
	if ((m_info.conf.max_jitterbuf) && ((m_info.target - m_info.min) > m_info.conf.max_jitterbuf)) {
		JIT_DBG("clamping target from %ld to %ld\n", (m_info.target - m_info.min), m_info.conf.max_jitterbuf);
		m_info.target = m_info.min + m_info.conf.max_jitterbuf;
	}

	diff = m_info.target - m_info.current;

	/* JB_WRN("diff = %d lms=%d last = %d now = %d\n", diff,  */
	/*	m_info.last_voice_ms, m_info.last_adjustment, now); */

	/* let's work on non-silent case first */
	if (!m_info.silence_begin_ts) {
		/* we want to grow */
		if ((diff > 0) &&
			/* we haven't grown in the delay length */
			(((m_info.last_adjustment + D_YAK_JIT_ADJUST_DELAY) < now) ||
			/* we need to grow more than the "length" we have left */
			(diff > QueueLast()  - QueueNext()) ) ) {
			/* grow by interp frame length */
			m_info.current += interpl;
			m_info.next_voice_ts += interpl;
			m_info.last_voice_ms = interpl;
			m_info.last_adjustment = now;
			m_info.cnt_contig_interp++;
			if (m_info.conf.max_contig_interp && m_info.cnt_contig_interp >= m_info.conf.max_contig_interp) {
				m_info.silence_begin_ts = m_info.next_voice_ts - m_info.current;
			}
			JIT_DBG("G");
			return eResultInterp;
		}

		frame = QueueGet(m_info.next_voice_ts - m_info.current);

		/* not a voice frame; just return it. */
		if (frame && frame->type != eFrameTypeVoice) {
			if (frame->type == eFrameTypeSilence) {
				m_info.silence_begin_ts = frame->ts;
				m_info.cnt_contig_interp = 0;
			}

			*frameout = *frame;
			m_info.frames_out++;
			JIT_DBG("o");
			return eResultOk;
		}


		/* voice frame is later than expected */
		if (frame && frame->ts + m_info.current < m_info.next_voice_ts) {
			if (frame->ts + m_info.current > m_info.next_voice_ts - m_info.last_voice_ms) {
				/* either we interpolated past this frame in the last jb_get */
				/* or the frame is still in order, but came a little too quick */
				*frameout = *frame;
				/* reset expectation for next frame */
				m_info.next_voice_ts = frame->ts + m_info.current + frame->ms;
				m_info.frames_out++;
				DecLossPct();
				m_info.cnt_contig_interp = 0;
				JIT_DBG("v");
				return eResultOk;
			} else {
				/* voice frame is late */
				*frameout = *frame;
				m_info.frames_out++;
				DecLossPct();
				m_info.frames_late++;
				m_info.frames_lost--;
				JIT_DBG("l");
				return eResultDrop;
			}
		}

		/* keep track of frame sizes, to allow for variable sized-frames */
		if (frame && frame->ms > 0) {
			m_info.last_voice_ms = frame->ms;
		}

		/* we want to shrink; shrink at 1 frame / 500ms */
		/* unless we don't have a frame, then shrink 1 frame */
		/* every 80ms (though perhaps we can shrink even faster */
		/* in this case) */
		if (diff < -m_info.conf.target_extra &&
			((!frame && m_info.last_adjustment + 80 < now) ||
			(m_info.last_adjustment + 500 < now))) {

			m_info.last_adjustment = now;
			m_info.cnt_contig_interp = 0;

			if (frame) {
				*frameout = *frame;
				/* shrink by frame size we're throwing out */
				m_info.current -= frame->ms;
				m_info.frames_out++;
				DecLossPct();
				m_info.frames_dropped++;
				JIT_DBG("s");
				return eResultDrop;
			} else {
				/* shrink by last_voice_ms */
				m_info.current -= m_info.last_voice_ms;
				m_info.frames_lost++;
				IncLossPct();
				JIT_DBG("S");
				return eResultNoFrame;
			}
		}

		/* lost frame */
		if (!frame) {
			/* this is a bit of a hack for now, but if we're close to
			 * target, and we find a missing frame, it makes sense to
			 * grow, because the frame might just be a bit late;
			 * otherwise, we presently get into a pattern where we return
			 * INTERP for the lost frame, then it shows up next, and we
			 * throw it away because it's late */
			/* Update: that might have been a different bug, that has been fixed..
			 * But, this still seemed like a good idea, except that it ended up making a single actual
			 * lost frame get interpolated two or more times, when there was "room" to grow, so it might
			 * be a bit of a bad idea overall */
			/*if (diff > -1 * m_info.last_voice_ms) {
				m_info.current += m_info.last_voice_ms;
				m_info.last_adjustment = now;
				JB_WRN("g");
				return eResultInterp;
			} */
			m_info.frames_lost++;
			IncLossPct();
			m_info.next_voice_ts += interpl;
			m_info.last_voice_ms = interpl;
			m_info.cnt_contig_interp++;
			if (m_info.conf.max_contig_interp && m_info.cnt_contig_interp >= m_info.conf.max_contig_interp) {
				m_info.silence_begin_ts = m_info.next_voice_ts - m_info.current;
			}
			JIT_DBG("L");
			return eResultInterp;
		}

		/* normal case; return the frame, increment stuff */
		*frameout = *frame;
		m_info.next_voice_ts += frame->ms;
		m_info.frames_out++;
		m_info.cnt_contig_interp = 0;
		DecLossPct();
		JIT_DBG("v");
		return eResultOk;
	} else {
		/* TODO: after we get the non-silent case down, we'll make the
		 * silent case -- basically, we'll just grow and shrink faster
		 * here, plus handle next_voice_ts a bit differently */

		/* to disable silent special case altogether, just uncomment this: */
		/* m_info.silence_begin_ts = 0; */

 		/* shrink interpl len every 10ms during silence */
 		if (diff < -m_info.conf.target_extra &&
 			m_info.last_adjustment + 10 <= now) {
 			m_info.current -= interpl;
 			m_info.last_adjustment = now;
 		}

		frame = QueueGet(now - m_info.current);
		if (!frame) {
			return eResultNoFrame;
		} else if (frame->type != eFrameTypeVoice) {
			/* normal case; in silent mode, got a non-voice frame */
			*frameout = *frame;
			m_info.frames_out++;
			return eResultOk;
		}
		if (frame->ts < m_info.silence_begin_ts) {
			/* voice frame is late */
			*frameout = *frame;
			m_info.frames_out++;
			DecLossPct();
			m_info.frames_late++;
			m_info.frames_lost--;
			JIT_DBG("l");
			return eResultDrop;
		} else {
			/* voice frame */
			/* try setting current to target right away here */
			m_info.current = m_info.target;
			m_info.silence_begin_ts = 0;
			m_info.next_voice_ts = frame->ts + m_info.current + frame->ms;
			m_info.last_voice_ms = frame->ms;
			m_info.frames_out++;
			DecLossPct();
			*frameout = *frame;
			JIT_DBG("V");
			return eResultOk;
		}
	}
}

long JitterBuffer::Next()
{
	if (m_info.silence_begin_ts) {
		if (m_frames) {
			long next = QueueNext();
			HistoryGet();
			/* shrink during silence */
			if (m_info.target - m_info.current < -m_info.conf.target_extra)
				return m_info.last_adjustment + 10;
			return next + m_info.target;
		}
		else
			return LONG_MAX;
	} else {
		return m_info.next_voice_ts;
	}
}

JitResult JitterBuffer::Get( JitFrame *frameout, long now, long interpl )
{
	JitResult ret = _Get(frameout, now, interpl);
#if 0
	static int lastts=0;
	int thists = ((ret == eResultOk) || (ret == eResultDrop)) ? frameout->ts : 0;
	JB_WRN("jb_get(%x,%x,%ld) = %d (%d)\n", frameout, now, ret, thists);
	if (thists && thists < lastts) JB_WRN("XXXX timestamp roll-back!!!\n");
	lastts = thists;
#endif
	if (ret == eResultInterp)
		frameout->ms = m_info.last_voice_ms;

	return ret;
}

JitResult JitterBuffer::GetAll( JitFrame *frameout )
{
	JitFrame *frame = QueueGetAll();

	if (!frame) {
		return eResultNoFrame;
	}

	*frameout = *frame;
	return eResultOk;
}


JitResult JitterBuffer::GetInfo( JitInfo *stats )
{
	HistoryGet();

	*stats = m_info;

	return eResultOk;
}

JitResult JitterBuffer::SetConf( JitConf *conf )
{
	/* take selected settings from the struct */

	m_info.conf.max_jitterbuf = conf->max_jitterbuf;
 	m_info.conf.resync_threshold = conf->resync_threshold;
	m_info.conf.max_contig_interp = conf->max_contig_interp;

	/* -1 indicates use of the default D_YAK_JIT_TARGET_EXTRA value */
	m_info.conf.target_extra = ( conf->target_extra == -1 )
		? D_YAK_JIT_TARGET_EXTRA
		: conf->target_extra
		;

	/* update these to match new target_extra setting */
	m_info.current = m_info.conf.target_extra;
	m_info.target = m_info.conf.target_extra;

	return eResultOk;
}

void JitterBuffer::IncLossPct()
{
	m_info.losspct = (100000 + 499 * m_info.losspct)/500;
}

void JitterBuffer::DecLossPct()
{
	m_info.losspct = (499 * m_info.losspct)/500;
}

// ----------------------------------------------------------------------//
} // namespace yak;
