#ifndef __YAK_CJITTERBUFFER_H
#define __YAK_CJITTERBUFFER_H

//#define DEEP_DEBUG

#ifdef DEEP_DEBUG
#	define JIT_WRN(...) printf(__VA_ARGS__)
#	define JIT_ERR(...) printf(__VA_ARGS__)
#	define JIT_DBG(...) printf(__VA_ARGS__)
#else
#	define JIT_WRN(...)
#	define JIT_ERR(...)
#	define JIT_DBG(...)
#endif

#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//
	typedef enum
	{
		/* return codes */
		eResultOk,            /* 0 */
		eResultEmpty,         /* 1 */
		eResultNoFrame,       /* 2 */
		eResultInterp,        /* 3 */
		eResultDrop,          /* 4 */
		eResultSched          /* 5 */
	} JitResult;

	typedef enum
	{
		/* frame types */
		eFrameTypeControl,  /*0            */
		eFrameTypeVoice,    /*1            */
		eFrameTypeSilence   /*3            */
	} JitFrameType;

	typedef struct
	{
		/* settings */
		long max_jitterbuf;		/*defines a hard clamp to use in setting the jitter buffer delay */
		long resync_threshold;  /*the jb will resync when delay increases to (2 * jitter) + this param */
		long max_contig_interp; /*the max interp frames to return in a row */
		long target_extra ;     /*amount of additional jitterbuffer adjustment, overrides D_YAK_JIT_TARGET_EXTRA */
	} JitConf;

	typedef struct
	{
		JitConf conf;
		/* statistics */
		long frames_in;  		/*number of frames input to the jitterbuffer.*/
		long frames_out;  		/*number of frames output from the jitterbuffer.*/
		long frames_late; 		/*number of frames which were too late, and dropped.*/
		long frames_lost; 		/*number of missing frames.*/
		long frames_dropped; 	/*number of frames dropped (shrinkage) */
		long frames_ooo; 		/*number of frames received out-of-order */
		long frames_cur; 		/*number of frames presently in jb, awaiting delivery.*/
		long jitter; 			/*jitter measured within current history interval*/
		long min;				/*minimum lateness within current history interval */
		long current; 			/*the present jitterbuffer adjustment */
		long target; 			/*the target jitterbuffer adjustment */
		long losspct; 			/*recent lost frame percentage (* 1000) */
		long next_voice_ts;		/*the ts of the next frame to be read from the jb - in receiver's time */
		long last_voice_ms;		/*the duration of the last voice frame */
		long silence_begin_ts;	/*the time of the last CNG frame, when in silence */
		long last_adjustment;   /*the time of the last adjustment */
		long last_delay;        /*the last now added to history */
		long cnt_delay_discont;	/*the count of discontinuous delays */
		long resync_offset;     /*the amount to offset ts to support resyncs */
		long cnt_contig_interp; /*the number of contiguous interp frames returned */
	} JitInfo;

	typedef struct _JitFrame
	{
		void *data;               /* the frame data */
		long ts;                  /* the relative delivery time expected */
		long ms;                  /* the time covered by this frame, in sec/8000 */
		JitFrameType type;		  /* the type of frame */
		_JitFrame *next, *prev;
	} JitFrame;

//---------------------------------------------------------------------------//

class JitterBuffer
{
protected:
	JitInfo m_info;

	/* history */
	long m_history[ D_YAK_JIT_HISTORY_SZ ];   				/*history */
	int  m_hist_ptr;										/*points to index in history for next entry */
	long m_hist_maxbuf[ D_YAK_JIT_HISTORY_MAXBUF_SZ ];		/*a sorted buffer of the max delays (highest first) */
	long m_hist_minbuf[ D_YAK_JIT_HISTORY_MAXBUF_SZ ];		/*a sorted buffer of the min delays (lowest first) */
	int  m_hist_maxbuf_valid;								/*are the "maxbuf"/minbuf valid? */
	bool m_dropem;											/*flag to indicate dropping frames (overload) */

	JitFrame *m_frames; 									/*queued frames */
	JitFrame *m_free; 										/*free frames (avoid malloc?) */

protected:
	int					 CheckResync( long ts, long now, long ms, const JitFrameType type, long *delay );

	int					 HistoryPut( long ts, long now, long ms, long delay );
	void				 HistoryGet() ;
	void				 HistoryCalcMaxBuf();

	int					 QueuePut( void *data, const JitFrameType type, long ms, long ts );
	long				 QueueNext();
	long				 QueueLast();

	JitFrame*			_QueueGet( long ts, int all );
	JitFrame*			 QueueGet( long ts );
	JitFrame*			 QueueGetAll();

	JitResult			_Get( JitFrame *frameout, long now, long interpl );
public:
	JitterBuffer();
	~JitterBuffer();

	/*
	* The jitterbuffer should be empty before you call this, otherwise
	* you will leak queued frames, and some internal structures */
	void				Reset();

	/*queue a frame
	*
	* data=frame data, timings (in ms): ms=length of frame (for voice), ts=ts (sender's time)
	* now=now (in receiver's time) return value is one of
	* eResultOk: Frame added. Last call to jb_next() still valid
	* eResultDrop: Drop this frame immediately
	* eResultSched: Frame added. Call Next() to get a new time for the next frame
	*/
	JitResult			Put( void *data, const JitFrameType type, long ms, long ts, long now );

	/* get a frame for time now (receiver's time)  return value is one of
	* eResultOk:  You've got frame!
	* eResultDrop: Here's an audio frame you should just drop.  Ask me again for this time..
	* eResultNoFrame: There's no frame scheduled for this time.
	* eResultInterp: Please interpolate an interpl-length frame for this time (either we need to grow, or there was a lost frame)
	* eResultEmpty: The jitterbuffer is empty.
	*/
	JitResult			Get( JitFrame *frame, long now, long interpl );

	/*unconditionally get frames from jitterbuffer until empty */
	JitResult			GetAll( JitFrame *frameout );

	/*when is the next frame due out, in receiver's time (0=eResultEmpty)
	* This value may change as frames are added (esp non-audio frames) */
	long				Next();

	JitResult			GetInfo( JitInfo *stats );
	JitResult			SetConf( JitConf *conf );

	void				IncLossPct();
	void				DecLossPct();

#ifdef DEEP_DEBUG
	void				ChkQueue();
	void				DbgQueue();
	void				DbgInfo();
#endif
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CJITTERBUFFER_H
