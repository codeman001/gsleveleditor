#ifndef __YAK_CLIST_H
#define __YAK_CLIST_H

#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

template <class T> class List
{
public:
	class Node
	{
	public:
		T		*m_Data;
		Node	*m_Prev;
		Node	*m_Next;

		Node( T *pData, Node *pPrev = NULL, Node *pNext = NULL )
		{
			m_Prev		= pPrev;
			m_Next		= pNext;

			m_Data		= (T*)yaknew char[ sizeof( T ) ];
			memcpy( m_Data, pData, sizeof( T ) );
		}

		~Node()
		{
			yakdel( m_Data );

			if( m_Next )
				m_Next->m_Prev = m_Prev;

			if( m_Prev )
				m_Prev->m_Next = m_Next;
		}
	};

public:
	List();
	~List();
	
	bool				IsEmpty( void );
	unsigned int		Count( void );

	T*					GetFirst( void );
	T*					GetLast( void );
	T*					GetCurrent( void );
	
	void				AddToFront( T* item );
	void				AddToEnd( T* item );
	void				InsertAfter( T* item );
	void				InsertBefore( T* item );
	void				Begin();
	T*					Next();

	void 				RemoveFirst();
	void 				Remove( T* item );
	void 				RemoveAll();
	void 				RemoveLast();

	void 				MoveToEnd( T *item );
	void 				MoveToFront( T *item );

protected:
	Node				*m_First;
	Node				*m_Current;
	Node				*m_Last;

	unsigned int		m_NumItems;
};

template <class T> List<T>::List()
{
	m_NumItems	= 0;
	m_First		= NULL;
	m_Last		= NULL;
	m_Current	= NULL;
}


template <class T> List<T>::~List()
{
	m_Current = m_First;

	while( m_Current && m_First )
	{
		m_First = m_First->m_Next;

		yakdel( m_Current );

		m_Current = m_First;
	}
}

template <class T> bool List<T>::IsEmpty()
{
	return ( m_First == NULL );
}

template<class T> unsigned int List<T>::Count()
{
	return m_NumItems;
}

template <class T> T *List<T>::GetFirst()
{
	if(m_First == NULL)
		return NULL;

	return ( T* )( m_First->m_Data );
}

template <class T> T *List<T>::GetLast()
{
	if( m_Last == NULL )
		return NULL;

	return ( T* )( m_Last->m_Data );
}

template <class T> T *List<T>::GetCurrent()
{
	if( m_Current == NULL)
		return NULL;

	return ( T* )( m_Current->m_Data );
}


template <class T> void List<T>::InsertAfter( T *item )
{
	ASSERT( m_Current );

	Node *temp = yaknew Node( item, m_Current, m_Current->m_Next );

	if( m_Current->m_Next )
		m_Current->m_Next->prev = temp;

	m_Current->m_Next = temp;

	m_NumItems++;
}



template <class T> void List<T>::InsertBefore( T *item )
{
	ASSERT( m_Current );

	Node *temp = yaknew Node( item, m_Current->m_Prev, m_Current);

	if( m_Current->m_Prev )
		m_Current->m_Prev->m_Next = temp;

	m_Current->prev = temp;

	m_NumItems++;
}

template <class T> void List<T>::Begin()
{
	m_Current = m_First;
}

template <class T> T *List<T>::Next()
{
	if( !m_Current )
		return NULL;

	yakass( m_Current );
	yakass( m_Current->m_Data );
	T* temp = ( T* )( m_Current->m_Data );

	m_Current = m_Current->m_Next;

	return temp;
}

template <class T> void List<T>::AddToEnd( T *item )
{
	Node *temp = yaknew Node( item, m_Last, NULL);

	if( m_Last)
	{

		m_Last->m_Next = temp;
		m_Last = temp;
	}
	else
	{
		m_Last = temp;

		m_First = m_Last;
		m_Current = m_Last;
	}

	m_NumItems++;
}

template<class T> void List<T>::AddToFront(T *item )
{
	Node *temp = yaknew Node( item, NULL, m_First );

	if( m_First )
	{
		m_First->m_Prev = temp;
		m_First = temp;
	}
	else
	{
		m_First = temp;

		m_Current = m_First;
		m_Last = m_First;
	}

	m_NumItems++;
}

template<class T> void List<T>::RemoveFirst()
{
	if( m_First == NULL )
		return;

	if( m_First->m_Next )
		m_First->m_Next->m_Prev = NULL;

	if( m_First == m_Last )
		m_Last = NULL;

	yakdel( m_First );

	m_First = m_First->m_Next;

	m_NumItems--;
}

template<class T> void List<T>::RemoveAll()
{
	Node *temp = NULL;

	while( m_First )
	{
		temp	= m_First->m_Next;

		yakdel( m_First );

		m_First	= temp;	
	}

	m_First = m_Last = m_Current = NULL;
	m_NumItems	= 0;
}


template<class T> void List<T>::Remove( T *item )
{
	Node *temp = m_First;

	while( temp )
	{
		if( temp->m_Data == item )
		{
			if( temp->m_Next )
				temp->m_Next->m_Prev = temp->m_Prev;
		
			if( temp->m_Prev )
				temp->m_Prev->m_Next = temp->m_Next;

			yakdel( temp );

			m_NumItems--;

			return;
		}

		temp = temp->m_Next;
	}
}

template<class T> void List<T>::RemoveLast()
{
	Node *temp = m_Last;

	if( m_Last == NULL )
		return;

	if( m_Last->m_Prev )
		m_Last->m_Prev->m_Next = NULL;

	if( m_First == m_Last )
		m_First = NULL;

	yakdel( temp );

	m_Last = m_Last->m_Prev;

	m_NumItems--;

	yakdel( temp );
}

template<class T> void List<T>::MoveToFront( T *item )
{
	Node *temp;

	if( m_First->m_Data	== item )
		return;

	temp = m_First;
	
	while( temp != NULL )
	{
		if( temp->m_Data == item )
		{
			if( m_Last == temp )
				m_Last	= m_Last->m_Prev;

			if( temp->m_Next )
				temp->m_Next->m_Prev = temp->m_Prev;

			if( temp->m_Prev )
				temp->m_Prev->m_Next = temp->m_Next;

			temp->m_Prev	= NULL;
			temp->m_Next	= m_First;

			if( m_First )
				m_First->m_Prev	= temp;

			m_First			= temp;

			return;
		}

		temp = temp->m_Next;
	}
}

template<class T> void List<T>::MoveToEnd( T *item )
{
	Node *temp;

	if( m_Last->m_Data == item )
		return;

	temp = m_First;
	
	while( temp != NULL )
	{
		if( temp->m_Data == item )
		{
			if( m_First == temp )
				m_First	= m_First->m_Next;

			if( temp->m_Next )
				temp->m_Next->m_Prev = temp->m_Prev;
			if( temp->m_Prev )
				temp->m_Prev->m_Next = temp->m_Next;

			temp->m_Prev	= m_Last;
			temp->m_Next	= NULL;

			if(m_Last)
				m_Last->next	= temp;

			m_Last			= temp;

			return;
		}

		temp = temp->m_Next;
	}
}


// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CLIST_H
