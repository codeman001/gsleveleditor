#include "yak_mutex.h"

namespace yak
{
// ----------------------------------------------------------------------//

Mutex::Mutex()
{
    m_pmutex  = yaknew pthread_mutex_t;

    pthread_mutex_init(m_pmutex, 0);
}

Mutex::~Mutex()
{
	if (pthread_mutex_destroy(m_pmutex) == EBUSY)
	{
		Unlock();
		pthread_mutex_destroy(m_pmutex);
	}

	yakdel( m_pmutex );
}

bool Mutex::Lock()
{
    return (pthread_mutex_lock(m_pmutex) == 0);
}

bool Mutex::Unlock()
{
    return (pthread_mutex_unlock(m_pmutex) == 0);
}

Condition::Condition(Mutex *mutex) 
	: m_mutex( mutex )
{
	m_mutex->Lock();
}

Condition::~Condition()
{
	m_mutex->Unlock();
}

// ----------------------------------------------------------------------//
} // namespace yak;



