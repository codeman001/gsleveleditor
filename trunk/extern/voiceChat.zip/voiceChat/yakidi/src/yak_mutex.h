
#ifndef __YAK_CMUTEX_H_
#define __YAK_CMUTEX_H_

#include <pthread.h>

#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

class Mutex
{
protected:
    pthread_mutex_t      *m_pmutex;

public:
    Mutex();
    virtual ~Mutex();

    bool Lock();
    bool Unlock();
};

class Condition
{
protected:
    Mutex				*m_mutex;

public:
    Condition( Mutex *m_mutex );
    virtual ~Condition();
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_MUTEX_H_


