#include <math.h>

#include "yak_conference.h"
#include "yak_codec.h"
#include "yak_peer.h"


#if !D_YAK_IS_LINUX_SERVER
#	ifdef D_YAK_CONFIG_USE_VOX_1_0
#		include "vox/plugin/vox_minibus_data_generator_plugin_1_0.h"
#	else
#		include "vox/plugin/vox_minibus_data_generator_plugin_1_1.h"
#	endif
#endif // !D_YAK_IS_LINUX_SERVER

namespace yak
{
// ----------------------------------------------------------------------//

Peer::Peer( Conference *conference, bool canRegister )
{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE
	m_sineWaveBuffer = new short[ D_YAK_SOUND_NETWORK_SAMPLING_RATE ];

	float angle;
	float frequency = 500.0f;
	float inverseSampleRate = 2.0f * 3.1415926535897932f / D_YAK_SOUND_NETWORK_SAMPLING_RATE;

	for(int i = 0; i < D_YAK_SOUND_NETWORK_SAMPLING_RATE; i++)
	{
		angle = inverseSampleRate * frequency;
		m_sineWaveBuffer[i] = static_cast<vox::s16> (5000 * sin(i * angle));
	}

	m_sineWaveCursor = 0;
#endif // D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE

#if D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
	m_clientMixCache = yaknew char[ D_YAK_CONFIG_RAW_DUMP_MAX_SIZE ];
	m_clientMixBuffer = yaknew Buffer( m_clientMixCache, D_YAK_CONFIG_RAW_DUMP_MAX_SIZE );
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
//-----------------------------------------------------------------------//

	m_conference		= conference;
	m_codec				= yaknew Codec( conference->GetOutContext(), conference->GetInContext() );

	m_memberId			= D_YAK_PEER_UID_MAX;

	m_isReachable					= false;
	m_isAcceptingConnections		= true;
	m_isRegistered		= false;
	m_canRegister		= canRegister;

	m_connectionTime				= 0;

	m_isPinged			= false;
	m_rtt				= 0;
	m_lastPingTime		= 0;
	m_lastStateSyncTime	= 0;

	Codec::Context *ctx	= m_codec->GetInContext();
	int cacheSize		= D_YAK_SOUND_FRAME_NUM * ctx->m_bufferSize;

    m_cacheData			= yaknew char[ cacheSize ];
    m_cacheBuffer		= yaknew Buffer( m_cacheData, cacheSize );
	m_playout			= yaknew Playout( this );

#if !D_YAK_IS_LINUX_SERVER
	if( canRegister )
	{
		m_voxDataManager	= yaknew VoxDataManager();
		m_voxDataProvider	= yaknew VoxDataProvider( m_voxDataManager, ctx->m_samplingRate );
	}
#endif // !D_YAK_IS_LINUX_SERVER

#if D_YAK_CONFIG_USE_3DFX_VOICES
	if( ArchSupports3DVoice() )
	{
		memset( &m_3DParameters, 0, sizeof( m_3DParameters ) );
		memset( &m_3DPositioning, 0, sizeof( m_3DPositioning ) );
		memset( &m_3DListenerPositioning, 0, sizeof( m_3DListenerPositioning ) );

		m_voxDataManager->SetEnhanced3D( true );
	}
#endif // D_YAK_CONFIG_USE_3DFX_VOICES


	m_packetCount		= 0;

	SetLocalIP( 0 );
	SetLocalPort( 0 );
	SetRemoteIP( 0 );
	SetRemotePort( 0 );

    m_localState = Peer::eStateIdle;
    m_remoteState = Peer::eStateIdle;
}

Peer::~Peer()
{
	m_pingPackets.RemoveAll();

#if !D_YAK_IS_LINUX_SERVER
	if( m_canRegister )
	{
		yakdel( m_voxDataProvider );

		if( m_isRegistered )
		{
			vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
			vox.UnregisterExternalDataGenerator( m_voxDataManager );
		}

		yakdel( m_voxDataManager );
	}
#endif // !D_YAK_IS_LINUX_SERVER

    yakdel( m_cacheBuffer );
    yakdelarray( m_cacheData );

	yakdel( m_playout );

	yakdel( m_codec );

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE
	yakdelarray( m_sineWaveBuffer );
#endif // D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE

#if D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
	yakdel( m_clientMixBuffer );
	yakdelarray( m_clientMixCache);
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
//-----------------------------------------------------------------------//
}

bool Peer::SetLocalState( EState state )
{
	if( m_localState != state )
	{
#if !D_YAK_IS_LINUX_SERVER
		if( m_canRegister )
		{
			if( !m_isRegistered )
			{
				if( state == Peer::eStatePaired )
				{
					vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
					vox.RegisterExternalDataGenerator( m_voxDataManager, "MASTER" );

					m_isRegistered = true;
				}
			}
			else
			{
				if( state != Peer::eStatePaired )
				{
					m_isRegistered = false;

					vox::VoxEngine& vox = vox::VoxEngine::GetVoxEngine();
					vox.UnregisterExternalDataGenerator( m_voxDataManager );
				}
			}
		}
#endif // !D_YAK_IS_LINUX_SERVER

		m_localState = state;

		return true;
	}


	return false;
}

bool Peer::HolePunchTimedOut()
{
	return ( ( m_conference->GetCurrentTime() - m_connectionTime ) > D_YAK_PEER_TIMEOUT_INTERVAL );
}

void Peer::ComputeRtt()
{
	unsigned long long sum = 0;
	PingPacket *pP = NULL;

	m_pingPackets.Begin();

	while( NULL != ( pP = m_pingPackets.Next() ) ) {

		sum += pP->m_time1 - pP->m_time0;
	}

	m_rtt = ( unsigned int ) ( ( sum / m_pingPackets.Count() ) >> 1 );
	m_pingPackets.RemoveAll();

	yakout( "\n Peer (%d) RTT: %u", m_memberId, m_rtt );
}

#if !D_YAK_IS_LINUX_SERVER
void Peer::Set3DListenerPositioning( vox::Mdgp3DListenerPositioning &listenerPositioning3D )
{
#if D_YAK_CONFIG_USE_3DFX_VOICES
	if( ArchSupports3DVoice() )
	{
		memcpy( &m_3DListenerPositioning, &listenerPositioning3D, sizeof( m_3DListenerPositioning ) ) ;

		m_voxDataManager->Set3DListenerPositioning( m_3DListenerPositioning );
	}
#endif // D_YAK_CONFIG_USE_3DFX_VOICES
}

void Peer::Set3DPositioning( vox::Mdgp3DListenerPositioning &positioning3D )
{
#if D_YAK_CONFIG_USE_3DFX_VOICES
	if( ArchSupports3DVoice() )
	{
		memcpy( &m_3DPositioning, &positioning3D, sizeof( m_3DPositioning ) ) ;

		m_voxDataManager->Set3DSourcePositioning( m_3DPositioning );
	}
#endif // D_YAK_CONFIG_USE_3DFX_VOICES
}

void Peer::Set3DParameters( vox::Vox3DEmitterParameters &params3D )
{
#if D_YAK_CONFIG_USE_3DFX_VOICES
	if( ArchSupports3DVoice() )
	{
		memcpy( &m_3DParameters, &params3D, sizeof( m_3DParameters ) ) ;

		m_voxDataManager->Set3DSourceParameters( m_3DParameters );
	}
#endif // D_YAK_CONFIG_USE_3DFX_VOICES
}
#endif // !D_YAK_IS_LINUX_SERVER

void Peer::AddSoundFrame( unsigned int timestamp, char *data, short dataSize )
{
	if( data != NULL && dataSize > 0 )
	{
		m_packetCount++;

		int decSize = 0;

		Codec::LockDecode();
		decSize = m_codec->Decode( data, dataSize );

		if( !m_cacheBuffer->CanWrite( decSize ) ) {
			m_cacheBuffer->WriteRewind();
		}

		char *pData = m_cacheBuffer->GetPtrW();
		m_cacheBuffer->WriteBlock( Codec::GetDecodeBuffer(), decSize );
		Codec::UnlockDecode();

		m_playout->Put( pData, timestamp, S_GetTime() );
	}
	else {
		m_playout->Put( NULL, timestamp, S_GetTime() );
	}
}

void Peer::Update()
{
	char *pData = NULL;
	Codec::Context *ctx = m_codec->GetInContext();
    unsigned int now = S_GetTime();
    
    JitResult ret = m_playout->Get( now, &pData );
    
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
	if( !m_clientMixBuffer->CanWrite( ctx->m_bufferSize ) )
	{
		char dbgName[ 64 ];

		sprintf( dbgName, "mix_cli_1_8KHz_%d_%d.pcm16", m_memberId, S_GetTime() );
		BufToFile( m_clientMixBuffer, dbgName );

		m_clientMixBuffer->WriteRewind();
	}
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
//-----------------------------------------------------------------------//

	if( ret != eResultOk )
	{
//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
		m_clientMixBuffer->WriteZeroes( ctx->m_bufferSize );
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
//-----------------------------------------------------------------------//

		return;
	}

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
	if( pData != NULL ) {
		m_clientMixBuffer->WriteBlock( pData, ctx->m_bufferSize );
	}
	else {
		m_clientMixBuffer->WriteZeroes( ctx->m_bufferSize );
	}
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
//-----------------------------------------------------------------------//

//-------------------        DEBUGGING STUFF           ------------------//    
#if D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE
    if( m_sineWaveCursor + D_YAK_SOUND_NETWORK_FRAME_SIZE <= D_YAK_SOUND_NETWORK_SAMPLING_RATE )
    {
        m_voxDataProvider->Update( ctx->m_samplingRate, m_sineWaveBuffer + m_sineWaveCursor, D_YAK_SOUND_NETWORK_FRAME_SIZE );
        m_sineWaveCursor += ctx->m_frameSize;
    }
    else
    {
        static short sineFrame[ D_YAK_SOUND_NETWORK_FRAME_SIZE ];
        
        int nFree   = D_YAK_SOUND_NETWORK_SAMPLING_RATE - m_sineWaveCursor;
        int nRemain = D_YAK_SOUND_NETWORK_FRAME_SIZE - nFree;
        
        memcpy( sineFrame, m_sineWaveBuffer + m_sineWaveCursor, nFree*sizeof(short) );
        memcpy( sineFrame + nFree, m_sineWaveBuffer, nRemain*sizeof(short) );
        m_sineWaveCursor = nRemain;
        
        m_voxDataProvider->Update( ctx->m_samplingRate, sineFrame, D_YAK_SOUND_NETWORK_FRAME_SIZE );
    }
    
    return;
#endif // D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE
//-----------------------------------------------------------------------//
    
#if !D_YAK_IS_LINUX_SERVER
    
    m_voxDataProvider->Update( 
                              (vox::s16*) pData, 
                              pData == NULL ? 0 : ctx->m_frameSize
                              );
#endif // !D_YAK_IS_LINUX_SERVER
}

// ----------------------------------------------------------------------//
} // namespace yak;
