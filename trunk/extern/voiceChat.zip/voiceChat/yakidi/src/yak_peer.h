#ifndef __YAK_CPEER_H
#define __YAK_CPEER_H

#if !D_YAK_IS_LINUX_SERVER
#include "vox/yak_vox_data_manager.h"
#include "vox/yak_vox_data_provider.h"
#endif // !D_YAK_IS_LINUX_SERVER

#include "yak_buffer.h"
#include "yak_playout.h"
#include "yak_list.h"
#include "yak_config.h"
#include "yak_socket.h"

namespace yak
{
// ----------------------------------------------------------------------//

class Conference;
class Codec;

class Peer
{
	friend class Server;
	friend class Session;

public:
	typedef struct
	{
		int					m_ip;
		unsigned short		m_port;

	} Address;

	typedef struct
	{
		unsigned int	m_time0;
		unsigned int	m_time1;
	} PingPacket;

	typedef enum 
	{
		eStateIdle = 0,
		eStateMuted,
		eStatePaired
	} EState;

protected:
	Conference					*m_conference;
	Codec						*m_codec;

	Address						m_localAddress;
	Address						m_remoteAddress;

	EState						m_localState;
	EState						m_remoteState;

	char						m_memberId;

	bool						m_isReachable;
	bool						m_isAcceptingConnections;
	bool						m_isRegistered;
	bool						m_canRegister;

	unsigned int				m_connectionTime;
	unsigned int				m_packetCount;

	char						*m_cacheData;
	Buffer						*m_cacheBuffer;
	Playout						*m_playout;

#if !D_YAK_IS_LINUX_SERVER
	VoxDataManager				*m_voxDataManager;
	VoxDataProvider				*m_voxDataProvider;

	vox::Vox3DEmitterParameters		m_3DParameters;
	vox::Mdgp3DSourcePositioning	m_3DPositioning;
	vox::Mdgp3DListenerPositioning	m_3DListenerPositioning;
#endif // !D_YAK_IS_LINUX_SERVER

	bool						m_isPinged;
	unsigned int				m_rtt;
	unsigned int				m_lastPingTime;
	unsigned int				m_lastStateSyncTime;
	List<PingPacket>			m_pingPackets;

#if D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE
	short						*m_sineWaveBuffer;
	unsigned int				m_sineWaveCursor;
#endif // D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE

//-------------------        DEBUGGING STUFF           ------------------//
#if D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
	char						*m_clientMixCache;
	Buffer						*m_clientMixBuffer;
#endif // D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE
//-----------------------------------------------------------------------//

public:
	Peer( Conference *conf, bool canRegister );
	virtual ~Peer();

	void				SetMemberId( char memberId )	{ m_memberId = memberId; }
	char				GetMemberId()const		{ return m_memberId; }

	bool				SetLocalState( EState state );
	EState				GetLocalState() { return m_localState; }

	void				SetRemoteState( EState state ) { m_remoteState = state; }
	EState				GetRemoteState() { return m_remoteState; }

	bool				IsPaired() { return ( m_remoteState == eStatePaired && m_localState == eStatePaired ); }

	void				SetReachable( bool isReachable ) { m_isReachable = isReachable; }
	bool				IsReachable() { return m_isReachable; }

	void				SetLocalIP( int ip )		{ m_localAddress.m_ip = ip; }
	unsigned long		GetLocalIP()				{ return m_localAddress.m_ip; }

	void				SetRemoteIP( int ip )		{ m_remoteAddress.m_ip = ip; }
	int					GetRemoteIP()				{ return m_remoteAddress.m_ip; }

	void				SetLocalPort( unsigned short port ) { m_localAddress.m_port = port; }
	unsigned short		GetLocalPort()				{ return m_localAddress.m_port; }

	void				SetRemotePort( unsigned short port ) { m_remoteAddress.m_port = port; }
	unsigned short		GetRemotePort()				{ return m_remoteAddress.m_port; }

	Codec*				GetCodec()					{ return m_codec; }

	void				SetConnectionTime( unsigned int tm ) { m_connectionTime = tm; }
	bool				HolePunchTimedOut();
	void				SetPinged( bool pinged )	{ m_isPinged = pinged; }
	bool				IsPinged()					{ return m_isPinged; }

	unsigned int		GetLastPingTime() { return m_lastPingTime; }
	void				SetLastPingTime( unsigned int tm ) { m_lastPingTime = tm; }
	
	unsigned int		GetLastStateSyncTime() { return m_lastStateSyncTime; }
	void				SetLastStateSyncTime( unsigned int tm ) { m_lastStateSyncTime = tm; }

	void				AddPingPacket( PingPacket *pP ) { m_pingPackets.AddToEnd( pP ); }
	bool				CanComputeRtt() { return m_pingPackets.Count() >= D_YAK_PACKET_PING_COUNT; }
	void				ComputeRtt();

#if !D_YAK_IS_LINUX_SERVER
	void				Set3DListenerPositioning( vox::Mdgp3DListenerPositioning &listenerPositioning3D );
	void				Set3DPositioning( vox::Mdgp3DListenerPositioning &positioning3D );
	void				Set3DParameters( vox::Vox3DEmitterParameters &params3D );
#endif // !D_YAK_IS_LINUX_SERVER

	void				AddSoundFrame( unsigned int timestamp, char *data, short dataSize );
	void				Update();

	bool				IsAcceptingConnections() { return m_isAcceptingConnections; }
	void				SetAcceptingConnections( bool isAccept ) { m_isAcceptingConnections = isAccept; }

	unsigned int		GetPacketCount() { return m_packetCount; }
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CPEER_H
