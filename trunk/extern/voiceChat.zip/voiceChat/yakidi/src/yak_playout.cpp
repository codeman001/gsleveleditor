#include "yak_conference.h"
#include "yak_playout.h"

namespace yak
{
// ----------------------------------------------------------------------//

Playout::Playout( Peer *peer )
{
	yakass( peer != NULL );

	m_jitterBuffer  = yaknew JitterBuffer;
	m_peer			= peer;

	JitConf conf;
	conf.max_jitterbuf		= D_YAK_SOUND_BUFFER_TIME;
	conf.resync_threshold	= D_YAK_JIT_RESYNC_TIME;
	conf.max_contig_interp	= 1;
	conf.target_extra		= -1;

	m_nJitFrames			= 0;

	m_jitterBuffer->SetConf( &conf );
	m_jitterBuffer->Reset();
}

Playout::~Playout()
{
	yakdel( m_jitterBuffer );
}

void Playout::Reset()
{
	m_jitterBuffer->Reset();
}

JitResult Playout::Put( char *data, long ts, unsigned int now )
{
	JitResult ret = m_jitterBuffer->Put( data,
										 data == NULL ? eFrameTypeSilence : eFrameTypeVoice,
										 D_YAK_SOUND_FRAME_TIME,
										 ts,
										 now );

	++m_nJitFrames;

	return ret;
}

JitResult Playout::Get( unsigned int now, char **data )
{
	yakass( data != NULL );

    JitResult ret = eResultNoFrame;

	if( m_nJitFrames > 2 )
	{
		JitFrame frame;
		ret	            = m_jitterBuffer->GetAll( &frame );
		*data			= (char*)frame.data;

		--m_nJitFrames;
	}
	else {
		*data = NULL;
	}

	return ret;
}
// ----------------------------------------------------------------------//
} // namespace yak;
