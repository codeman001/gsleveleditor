#ifndef __YAK_CPLAYOUT_H
#define __YAK_CPLAYOUT_H

#include "yak_jitter_buffer.h"
#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

class Peer;

class Playout
{
protected:
	Peer				   *m_peer;
	JitterBuffer		   *m_jitterBuffer;
	unsigned int			m_nJitFrames;

public:
	Playout( Peer *peer );
	~Playout();

	void					Reset();

	JitResult				Put( char *data, long ts, unsigned int now );
	JitResult				Get( unsigned int now, char **data );
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CPLAYOUT_H
