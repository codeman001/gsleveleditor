#ifndef __YAK_CSINGLETON_H
#define __YAK_CSINGLETON_H

#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

template <typename T> 
class Singleton
{
protected:
	static T* m_Singleton;

public:
	Singleton()
	{
		yakass( !m_Singleton );

		m_Singleton = ( T* )( ( size_t ) this + ( ( size_t )( T* ) 1 - ( size_t )( Singleton < T > * )( T * ) 1 ) );
	}

	~Singleton()
	{
		yakass( m_Singleton );
		m_Singleton = NULL;
	}

	static T& GetSingleton()
	{
		yakass( m_Singleton );
		return ( *m_Singleton);
	}

	static T* GetSingletonPtr()
	{
		return m_Singleton;
	}
};

template <typename T> 
T* Singleton< T > :: m_Singleton = NULL;

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CSINGLETON_H