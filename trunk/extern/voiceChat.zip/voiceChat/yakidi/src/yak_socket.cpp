#if defined ( OS_IPHONE )
#	include <sys/poll.h>
#	include <ifaddrs.h>
#endif

#include "yak_socket.h"


namespace yak
{
// ----------------------------------------------------------------------//

Socket::Socket()
{
	m_handle = INVALID_SOCKET;
}

Socket::~Socket()
{
	if( m_handle != INVALID_SOCKET ) {
		Close();
	}
}

#if defined( WIN32 )
bool Socket::Init(WSADATA* wsaData)
{
	const int WINSOCK_VERSION = 0x0101;	 //Socket version over 1.1

	int iErrorCode = WSAStartup(WINSOCK_VERSION,wsaData);

	return iErrorCode != 0;
}

bool Socket::Term()
{
	int iErrorCode = WSACleanup();

	return iErrorCode != 0;
}
#endif // WIN32

bool Socket::Create()
{
	m_handle = socket( PF_INET, SOCK_STREAM, 0 );

	yakass( m_handle != INVALID_SOCKET );

	return m_handle != INVALID_SOCKET;
}

bool Socket::Create( int af, int type, int protocol )
{
	m_handle = socket( af, type, protocol );

	yakass( m_handle != INVALID_SOCKET );

	return m_handle != INVALID_SOCKET;
}

void Socket::SetNonBlocking()
{
#if defined( WIN32)
	unsigned long arg = 1;
	ioctlsocket( m_handle, FIONBIO, &arg );
#else
	int arg;
	arg = fcntl( m_handle, F_GETFL, 0 );
	arg |= O_NONBLOCK;
	fcntl( m_handle, F_SETFL, arg );
#endif	
}

bool Socket::Bind( int ip, unsigned short port )
{
	SOCKADDR_IN addr;
	addr.sin_family			= AF_INET;
	addr.sin_addr.s_addr	= ip;
	addr.sin_port			= htons( port );
	
	if( bind( m_handle, (SOCKADDR*) &addr, sizeof( SOCKADDR_IN ) ) == SOCKET_ERROR )
	{
		yakout( "Could not bind server socket.\n", 0 );
		return false;
	}

	if ( port == 0 )
	{
		socklen_t slen = sizeof(addr);
		if ( getsockname(m_handle, (struct sockaddr *)&addr, &slen) == SOCKET_ERROR )
		{
			yakout( "Could not get server socket.\n", 0 );
			return false;
		}

		m_port = ntohs(addr.sin_port);
	}
	else
	{
		m_port = port;
	}

	return true;

}

bool Socket::Bind( unsigned short port )
{
	return Bind(INADDR_ANY, port);
}

int Socket::Send( int ip, unsigned short port, const char *buf, int len, int flags )
{
	SOCKADDR_IN addr;
	addr.sin_family			= AF_INET;
	addr.sin_addr.s_addr	= ip;
	addr.sin_port			= htons( port );
	
	socklen_t addrLen = sizeof( SOCKADDR_IN );

	int err = sendto( m_handle, buf, len, flags, (const sockaddr*)&addr, addrLen );
	return err;
}

int Socket::SendMultiple( int ip, unsigned short port, const char *buf, int len, int n, int flags )
{
	int nBytes = 0;

	for( int k = 0; k < n; k++ ) {
		nBytes += Send( ip, port, buf, len, flags );
	}

	return nBytes;
}

int Socket::Receive( char *buf, int len, int *ip, unsigned short *port, int flags )
{
	yakass( buf != NULL );
	yakass( len > 0 );
	yakass( ip != NULL );
	yakass( port != NULL );
	
	SOCKADDR_IN addr;
	
	socklen_t addrLen = sizeof( SOCKADDR_IN );
	int err = recvfrom( m_handle, buf, len, flags, (sockaddr*)&addr, &addrLen );
	
	*ip		= addr.sin_addr.s_addr;
	*port	= ntohs( addr.sin_port );
	
	return err;
}

bool Socket::CanRead( unsigned int microsec )
{
//#ifdef OS_IPHONE
//	pollfd	pfd;
//	
//	pfd.fd		= m_handle;
//	pfd.events	= POLLIN;
//	pfd.revents	= 0;
//	
//	return ( ( poll( &pfd, 1, microsec / 1000 ) > 0 ) && 
//			 ( pfd.revents & POLLIN )  != 0 );
//#else	
	fd_set fds;
    struct timeval tv;

    FD_ZERO( &fds );
    FD_SET( m_handle, &fds );

    tv.tv_sec  = 0;
    tv.tv_usec = microsec;

    return ( ( select( (int) m_handle + 1, &fds, 0, 0, &tv ) > 0 )
             && FD_ISSET( m_handle, &fds ) != 0 );
//#endif	
}

bool Socket::CanWrite( unsigned int microsec )
{
//#ifdef OS_IPHONE
//	pollfd	pfd;
//	
//	pfd.fd		= m_handle;
//	pfd.events	= POLLOUT;
//	pfd.revents	= 0;
//	
//	return ( ( poll( &pfd, 1, microsec / 1000 ) > 0 ) && 
//			 ( pfd.revents & POLLOUT ) != 0 );
//#else	
	fd_set fds;
    struct timeval tv;

    FD_ZERO( &fds );
    FD_SET( m_handle, &fds );

    tv.tv_sec  = 0;
    tv.tv_usec = microsec;

    return ( ( select( (int) m_handle + 1, 0, &fds, 0, &tv ) > 0 )
             && FD_ISSET( m_handle, &fds ) != 0 );
//#endif	
}

int Socket::SetSocketOpt( int optname, const char *optval, int optlen, int level )
{
	return setsockopt( m_handle, level, optname, optval, optlen );
}


int Socket::GetSocketOpt( int optname, char *optval, int *optlen, int level )
{
	return getsockopt(m_handle,level,optname,optval, (socklen_t*) optlen);
}


bool Socket::Close()
{
	bool	result = ( CLOSESOCKET( m_handle ) ? true : false );

	return	result;
}

bool Socket::GetHostName( char *name, int namelen )
{
	if( gethostname( name, namelen ) )
	{
		yakout("\nCould not resolve local host!\nAre you on-line?\n", 0);
		return false;
	}

	yakout( "Socket::GetHostName : %s", name );
	return true;
}

bool Socket::GetLocalIP( int *ip )
{
#if defined ( OS_IPHONE )
    struct in_addr iphone_in_addr;
	
	struct ifaddrs *ifaddr, *ifa;
    int family, s;
    char host[32];
	
	if( ip != NULL )
	{
		if( getifaddrs( &ifaddr ) == -1 ) {
			yakout( "\nError getting interface list");
		}

		for( ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next ) 
		{
			if( !ifa->ifa_addr ) continue;
			family = ifa->ifa_addr->sa_family;

			if( family == AF_INET ) 
			{
				s = getnameinfo(ifa->ifa_addr, sizeof(struct sockaddr_in), host, 32, NULL, 0, NI_NUMERICHOST);
				if (s != 0) 
				{
					yakout ("\ngetnameinfo() failed: %s", gai_strerror(s));
				}
				yakout ("\nIP address: %s", host);

				if( inet_aton( host, &iphone_in_addr ) == 0 ) 
				{
					perror( "inet_aton" );
				}
				else 
				{
					bool testAddr = false;
					testAddr =   ( htonl(iphone_in_addr.s_addr) != (u_int32_t) INADDR_LOOPBACK)
						&&  ( htonl(iphone_in_addr.s_addr) != (u_int32_t) INADDR_ANY)
						&&  ( htonl(iphone_in_addr.s_addr) != (u_int32_t) INADDR_BROADCAST);
					if ( testAddr) 
						break;
				}
			}
		}


		freeifaddrs( ifaddr );

		*ip = *((int*)&iphone_in_addr);

		yakout( "\nSocket::GetLocalIP --- Local Address : %s", inet_ntoa( iphone_in_addr ) );

		return true;
	}
	
    return false;

#elif defined( OS_ANDROID )
	
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    yakass(sock != -1);

    const char* kGoogleDnsIp = "8.8.8.8";
    uint16_t kDnsPort = 53;
    struct sockaddr_in serv;
    memset(&serv, 0, sizeof(serv));
    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = inet_addr(kGoogleDnsIp);
    serv.sin_port = htons(kDnsPort);

    int err = connect(sock, (const sockaddr*) &serv, sizeof(serv));
    yakass(err != -1);

    sockaddr_in addr;
    socklen_t addrlen = sizeof(addr);
    err = getsockname(sock, (sockaddr*) &addr, &addrlen);
    yakass(err != -1);

	*ip = addr.sin_addr.s_addr;

	yakout( "\nSocket::GetLocalIP --- Local Address : %s", inet_ntoa(*((in_addr*)ip)) );

    close(sock);

	return true;

#else
    char ac[ 128 ];

	if( ip != NULL && Socket::GetHostName( ac, sizeof( ac ) ) )
	{
		struct hostent *phe = gethostbyname( ac );
		if( phe == 0 ) {
			yakout( "\nYow! Bad host lookup.", 0 );
			return false;
		}

		for( int i = 0; phe->h_addr_list[i] != 0; ++i ) {

			struct in_addr addr;
			
			memcpy( &addr, phe->h_addr_list[i], sizeof( struct in_addr ) );

			yakout( "\nSocket::GetLocalIP --- Trying : %s", inet_ntoa( addr ) );

			if( addr.s_addr != htonl(INADDR_LOOPBACK) && 
				addr.s_addr != htonl(INADDR_ANY) &&
				addr.s_addr != htonl(INADDR_BROADCAST))
			{
		
				*ip = addr.s_addr;		
				yakout( "\nSocket::GetLocalIP --- Local Address : %s", inet_ntoa( addr ) );

				break;
			}
		}

		return true;
	}
    
    return false;
#endif
}

// ----------------------------------------------------------------------//
} // namespace yak;