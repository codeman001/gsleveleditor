#ifndef __YAK_CSOCKET_H
#define __YAK_CSOCKET_H

#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

class Socket  
{
protected:

	SOCKET			m_handle;
	unsigned short	m_port;

public:

	Socket();
	Socket( SOCKET s ){ m_handle = s; }

	virtual ~Socket();

public:

#if defined(WIN32)
	static bool Init( WSADATA* wsaData );
	static bool Term();
#endif

	bool		Create( int af, int type, int protocol );
	bool		Create();

	void		SetNonBlocking();

	bool		Bind( int ip, unsigned short port );
	bool		Bind( unsigned short port );

	int			SetSocketOpt( int optname, const char *optval, int optlen, int level = SOL_SOCKET);
	int			GetSocketOpt( int optname, char * optval, int *optlen, int level = SOL_SOCKET);

	bool		Close();

	int			SendMultiple( int ip, unsigned short port, const char *buf, int len, int n, int flags = 0 );
	int			Send( int ip, unsigned short port, const char *buf, int len, int flags = 0 );
	int			Receive( char *buf, int len, int *ip, unsigned short *port, int flags = 0 );
	
	bool		CanRead( unsigned int microsec = 0 );
	bool		CanWrite( unsigned int microsec = 0 );

	SOCKET			GetSocket()		{ return m_handle;	}
	unsigned short	GetPort()		{ return m_port;	}

	static bool	GetHostName( char *name, int namelen );
	static bool	GetLocalIP( int *ip );
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CSOCKET_H
