#include "yak_state_machine.h"

namespace yak
{
// ----------------------------------------------------------------------//

void StateMachine::Init( char curStateCode )
{
	yakass( curStateCode >= 0 );

	m_currentStateCode	= curStateCode;
}

void StateMachine::Destroy( void )
{
	m_allStates.RemoveAll();
}

void StateMachine::AddState( char code, void *param, StateCallback callback )
{
	yakass( code >= 0 );

	StateMachine::State *item	= yaknew State;

	item->m_code			= code;
	item->m_param			= param;
	item->m_callback		= callback;

	m_allStates.AddToEnd( item );
}

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void StateMachine::RemoveState( char code )
{
	State *item			= NULL;
	State *tmp_item		= NULL;

	m_allStates.Begin();
	while( NULL != ( item = m_allStates.Next() ) )
	{
		if( item->m_code == code )
		{
			m_allStates.Remove( m_allStates.GetCurrent() );
			break;
		}
	}
}

void StateMachine::ReplaceStateCallbackFunc( char code, StateCallback callback )
{
	State *item = NULL;

	m_allStates.Begin();
	while( NULL != ( item = m_allStates.Next() ) )
	{
		if( item->m_code == code )
		{
			item->m_callback = callback;
			break;
		}
	}
}

void StateMachine::Run( void )
{
	State *item		= NULL;
	
	yakass( m_allStates.Count() > 0 && m_currentStateCode >= 0 );

	m_allStates.Begin();

	while( NULL != ( item = m_allStates.Next() ) )
	{
		if( item->m_code == m_currentStateCode ) {
			m_currentStateCode = item->m_callback( item->m_param );
		}
	}
}

// ----------------------------------------------------------------------//
} // namespace yak;