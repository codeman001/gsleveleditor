#ifndef __YAK_CSTATEMACHINE_H
#define __YAK_CSTATEMACHINE_H

#include "yak_list.h"	
#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

typedef int (*StateCallback)(void *);

class StateMachine
{
	typedef struct 
	{
		int										 m_code;
		void									*m_param;
		StateCallback							 m_callback;
	} State;

	protected:
		char									m_currentStateCode;
		List<State>								m_allStates;

	public:
		StateMachine() { m_currentStateCode = -1; }

		void Init( char curStateCode );
		void Destroy( void );

		void AddState( char code, void *param, StateCallback callback );
		void RemoveState( char code );
		void ReplaceStateCallbackFunc( char code, StateCallback callback );

		void Run( void );
};


// ----------------------------------------------------------------------//
} // namespace yak;

#endif //__YAK_CSTATEMACHINE_H
