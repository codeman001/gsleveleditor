#include "yak_thread.h"

namespace yak
{
// ----------------------------------------------------------------------//

Thread::Thread()
{
	m_isRunning = false;
	m_runFn		= NULL;
	m_priority	= 0;
}

Thread::~Thread()
{
	Stop();
}

void Thread::Init( ThreadRunFn fn, void *arg, int prio )
{
	m_priority = prio;
	m_isRunning = false;
	m_runFn		= fn;
	m_arg		= arg;

    pthread_attr_init( &m_attr );

	if( prio != 0 )
	{
		struct sched_param param;
		memset( &param, 0, sizeof( param ) );
		param.sched_priority =  prio; //sched_get_priority_max( SCHED_FIFO );

#ifndef OS_ANDROID
		pthread_attr_setinheritsched( &m_attr, PTHREAD_EXPLICIT_SCHED );
#endif
		pthread_attr_setschedpolicy( &m_attr, SCHED_FIFO );
		pthread_attr_setscope( &m_attr, PTHREAD_SCOPE_PROCESS );

		pthread_attr_setschedparam( &m_attr, &param );
	}
}

int Thread::RunRealTime( int period, int computation, int constraint )
{
	if( m_priority == 0 ) {
		return 0;
	}

	int ret = 0;

#if defined ( OS_IPHONE )
	static double clock2abs = 0.0;
	struct thread_time_constraint_policy ttcpolicy;
	
	thread_port_t thread_port = pthread_mach_thread_np( m_thread );
	
	if( clock2abs == 0.0 )
	{
		mach_timebase_info_data_t tbinfo;
		(void)mach_timebase_info( &tbinfo );
		clock2abs = ( ( (double)tbinfo.denom / (double)tbinfo.numer ) ) * 1000000;
	}
	
	int c2ai = int( clock2abs );
	
	ttcpolicy.period		= period * c2ai;
	ttcpolicy.computation	= computation * c2ai;
	ttcpolicy.constraint	= constraint * c2ai;
	ttcpolicy.preemptible	= 1;
	
	ret = thread_policy_set( thread_port, THREAD_TIME_CONSTRAINT_POLICY, 
							(thread_policy_t) &ttcpolicy,
							THREAD_TIME_CONSTRAINT_POLICY_COUNT );
	
	yakass( ret == KERN_SUCCESS );
	
#endif		
	
	return ret;
}
	
void Thread::Start()
{
	if( !m_isRunning )
	{
		m_isRunning = true;
		pthread_create( &m_thread, &m_attr, m_runFn, m_arg );

//		struct sched_param param;
//		int policy = SCHED_FIFO;
//		pthread_getschedparam( m_thread, &policy, &param );
//		yakout( "\n thread prio: %d", param.sched_priority );
	}
}

void Thread::Stop()
{
	if( m_isRunning )
	{
		void *ret;

		m_isRunning = false;
		pthread_join(m_thread, &ret);
	}
}

void Thread::Wait( int ms )
{
	if( m_priority != 0 ) {
		sched_yield();
	}

	Sleep( ms );
}

void Thread::WaitMicro( int micros )
{
	if( m_priority != 0 ) {
		sched_yield();
	}

	SleepMicro( micros );
}

void Thread::DebugSched( const char *str )
{
	int policy;
	struct sched_param param;
	int status;
	
	status = pthread_getschedparam( pthread_self(), &policy, &param );
	
	static const char *policy_str[] = { "OTHER", "FIFO", "RR" };
	
	const char *p = policy_str[ 0 ];
	
	if( policy == SCHED_FIFO )
		p = policy_str[ 1 ];
	else if( policy == SCHED_RR )
		p = policy_str[ 2 ];
		
	yakout( "\n %s -- %s[%d]", str, p, param.sched_priority );
}

// ----------------------------------------------------------------------//
} // namespace yak;