#ifndef __YAK_CTHREAD_H
#define __YAK_CTHREAD_H

#include <pthread.h>
#if defined ( OS_IPHONE )
#	include <mach/thread_policy.h>
#	include <mach/thread_act.h>
#	include <mach/mach_time.h>
#endif

#include "yak_config.h"

namespace yak
{
// ----------------------------------------------------------------------//

typedef void* (*ThreadRunFn) (void *pParam);

class Thread 
{
protected:
    pthread_t			m_thread;
    pthread_attr_t		m_attr;

	bool				m_isRunning;
	ThreadRunFn			m_runFn;
	void			   *m_arg;
	int					m_priority;

public:
	static const int	DEFAULT_PRIORITY	=	5;

public:
	Thread();
	virtual ~Thread();

public:
	void Init( ThreadRunFn fn, void *arg, int prio );

	void		Start();
	void		Stop();
	void		Wait( int ms );
	void		WaitMicro( int micros );
	int			RunRealTime( int period, int computation, int constraint );

	bool		IsActive() { return m_isRunning; }
	
	static void DebugSched( const char *str );
};

// ----------------------------------------------------------------------//
} // namespace yak;

#endif // __YAK_CTHREAD_H
