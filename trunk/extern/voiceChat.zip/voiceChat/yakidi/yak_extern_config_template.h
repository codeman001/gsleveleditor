#ifndef __YAK_EXTERN_CONFIG_H
#define __YAK_EXTERN_CONFIG_H

// Configurable options
#define D_YAK_CONFIG_USE_3DFX_VOICES							( 0 )
#define D_YAK_CONFIG_USE_AGC_ON_SERVER							( 0 )
#define D_YAK_CONFIG_USE_WHITE_NOISE_FOR_SILENCE				( 0 )

// debugging stuff
#define D_YAK_CONFIG_DEBUG_LOOPBACK_CHAT						( 0 )
#define D_YAK_CONFIG_DEBUG_3DFX_VOICES							( 0 && D_YAK_CONFIG_USE_3DFX_VOICES )
#define D_YAK_CONFIG_DEBUG_RECV_REPLACE_WITH_SINE_WAVE			( 0 )
#define D_YAK_CONFIG_DEBUG_SEND_REPLACE_WITH_SINE_WAVE			( 0 )
#define D_YAK_CONFIG_DEBUG_SAVE_CLI_MIX_TO_FILE					( 0 )
#define D_YAK_CONFIG_DEBUG_SAVE_CLI_REC_TO_FILE					( 0 )
#define D_YAK_CONFIG_DEBUG_SAVE_CLI_VOX_TO_FILE					( 0 )
#define D_YAK_CONFIG_DEBUG_SAVE_SRV_REC_TO_FILE					( 0 )
#define D_YAK_CONFIG_DEBUG_SAVE_SRV_MIX_TO_FILE					( 0 )

// optional configurable options
#define D_YAK_SOUND_RECORDER_SAMPLING_RATE						( 44100 )
#define D_YAK_SOUND_VOICE_ENERGY_THRESHOLD						( 1000.0f )

#endif
