#ifdef GAMESWF
//
//  Filename:	UIManager.h
//	Created:	23:8:2011   15:26

#ifndef		__UIManager_H__
#define		__UIManager_H__

/*
=========================================================================================

			HEADERS & DEFS

=========================================================================================
*/

#include	"../stdafx.h"

/*
=========================================================================================

			CODE

=========================================================================================
*/

// ** class cUIManager
class cUIManager
{
	private:

		tSwfRenderer	renderer;
		tUIObjectList	uiObjects;
		tSwfPlayer			player_null;

	private:

		tSwfPlayer		CreatePlayerInstance ( void );

		static tSwfFile	FileOpener ( const char *identifier );
		static void		FsCallback ( tSwfCharacter movie, const char *command, const char *args );
		static void		LogCallback ( bool error, const char *message );

	public:

		cUIManager ( void );
		virtual			~cUIManager ( void );

		cUIObject		*CreateUIObject ( const char *identifier );
		void			ReleaseUIObject ( cUIObject *uiObject );
		void			Update ( int cursorX, int cursorY, bool mousePressed ,float deltaTime=60, bool forceRealtimeFramerate=true );
		void			Render ( int width, int height, bool background );
};

#endif	/*	!__UIManager_H__	*/
#endif //ifdef GAMESWF